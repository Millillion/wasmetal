#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__21(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__21\n"); );
    // Init
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128060___O;
    wasmetal_core__DOT____Vcellout___128060___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128410___O;
    wasmetal_core__DOT____Vcellout___128410___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134212___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134212___DOT__CO__BRA__2__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___022500_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022499_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022497_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022495_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022494_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022493_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022490_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022488_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022487_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022485_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022483_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022477_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022472_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc6c88546__0))));
    vlSelf->wasmetal_core__DOT___022473_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___048702_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005711_)))))));
    vlSelf->wasmetal_core__DOT___022474_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h13911493__0))));
    vlSelf->wasmetal_core__DOT___022475_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7ef4e0e__0))));
    vlSelf->wasmetal_core__DOT___022476_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89d79bf3__0))));
    vlSelf->wasmetal_core__DOT___022478_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfa88dfaf__0))));
    vlSelf->wasmetal_core__DOT___022479_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3cb929d5__0))));
    vlSelf->wasmetal_core__DOT___022480_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fed8b62__0))));
    vlSelf->wasmetal_core__DOT___022481_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd64632c9__0))));
    vlSelf->wasmetal_core__DOT___022482_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0283b263__0))));
    vlSelf->wasmetal_core__DOT___022484_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbacebd3b__0))));
    vlSelf->wasmetal_core__DOT___022486_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha45fb011__0))));
    vlSelf->wasmetal_core__DOT___022489_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab846b7c__0))));
    vlSelf->wasmetal_core__DOT___060463_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)))))));
    vlSelf->__VdfgTmp_he55adf41__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___005816_));
    vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003806_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___071787_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid 
        = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048133_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048134_))));
    vlSelf->wasmetal_core__DOT___005670_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048134_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048949_))));
    vlSelf->__VdfgTmp_hf36d9f62__0 = (((IData)(vlSelf->wasmetal_core__DOT___048134_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048133_));
    vlSelf->wasmetal_core__DOT___060493_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___060507_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___060521_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___060549_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___060563_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___060535_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    wasmetal_core__DOT____Vcellout___128410___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032034_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032033_)))) 
                                                   ^ 
                                                   (1U 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__0__KET__) 
                                                             << 1U)))));
    vlSelf->wasmetal_core__DOT___032026_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026484_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026451_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b8__05d));
    vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036761_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h291433ac__0))));
    wasmetal_core__DOT____Vcellout___128060___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028287_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028286_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028316_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028315_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028282_)))));
    vlSelf->wasmetal_core__DOT___028254_ = ((IData)(vlSelf->wasmetal_core__DOT___028287_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028222_));
    vlSelf->wasmetal_core__DOT___045492_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071349_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071348_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071347_))))))));
    vlSelf->wasmetal_core__DOT___045516_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071349_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071348_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071347_)))))))));
    vlSelf->wasmetal_core__DOT___045489_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071346_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071345_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071344_)))))))));
    vlSelf->wasmetal_core__DOT___045513_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071346_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071345_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071344_)))))))));
    vlSelf->wasmetal_core__DOT___045288_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071412_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071411_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071410_))))))));
    vlSelf->wasmetal_core__DOT___045312_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071412_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071411_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071410_)))))))));
    vlSelf->wasmetal_core__DOT___045285_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071409_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071408_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071407_)))))))));
    vlSelf->wasmetal_core__DOT___045309_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071409_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071408_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071407_)))))))));
    vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026592_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026559_)
            : (IData)(vlSelf->wasmetal_core__DOT___001370_));
    vlSelf->wasmetal_core__DOT____Vcellout___128348___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031332_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031331_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031361_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031360_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031327_)))));
    vlSelf->wasmetal_core__DOT___031300_ = ((IData)(vlSelf->wasmetal_core__DOT___031332_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034322_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034489_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027471_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127952___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027394_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027393_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027388_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027377_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027301_)))));
    vlSelf->wasmetal_core__DOT___027330_ = ((IData)(vlSelf->wasmetal_core__DOT___027394_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b7__05d));
    vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 0x14U) & (IData)(vlSelf->wasmetal_core__DOT___027939_));
    vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x100000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x14U)
                  : (IData)(vlSelf->wasmetal_core__DOT___030474_)));
    wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032875_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027810_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b18__05d));
    vlSelf->wasmetal_core__DOT___066399_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066525_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066313_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066602_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 0x14U) & (IData)(vlSelf->wasmetal_core__DOT___028165_));
    vlSelf->wasmetal_core__DOT____Vcellout___128045___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028097_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028096_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028095_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028094_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028061_)))));
    vlSelf->wasmetal_core__DOT___028065_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028097_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0xfU)));
    vlSelf->wasmetal_core__DOT___044764_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 0xcU)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                                        >> 1U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 0x12U)))))))));
    vlSelf->wasmetal_core__DOT___044776_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 0xfU)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 0x10U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 0x11U))))))))));
    vlSelf->wasmetal_core__DOT___044763_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 9U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 0xfU)))))))));
    vlSelf->wasmetal_core__DOT___044775_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128318___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 0xcU)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 0xdU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128317___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 0xeU))))))))));
    vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 0x14U)) & (IData)(vlSelf->wasmetal_core__DOT___030956_));
    vlSelf->wasmetal_core__DOT___044808_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070645_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___044796_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070643_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032683_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    wasmetal_core__DOT___134212___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037193_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h148285ae__0))));
    vlSelf->wasmetal_core__DOT___063557_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063552_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))))))));
    vlSelf->wasmetal_core__DOT___063565_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063560_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063573_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063568_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b14__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063581_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063576_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b15__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128518___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128526___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128603___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026366_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b18__05d));
    vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b10__05d) {
        wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
        vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
    } else {
        wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___011156_ = (1U & (IData)(
                                                         (0xffff800000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056534_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                                                << 4U)) 
                                                                                | (0xfU 
                                                                                & ((0xcU 
                                                                                & ((~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                                                >> 1U))) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & (~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                                                >> 1U)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (3U 
                                                                             & (~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056530_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0812d53d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___011110_ = (1U & (IData)(
                                                         (0x5050f0f00ff0033ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056499_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                          ? 
                                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___010969_)))
                                                                          : 
                                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___011115_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011604_)))))))));
    vlSelf->wasmetal_core__DOT___011359_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056594_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056593_)))));
    vlSelf->wasmetal_core__DOT___056801_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010196_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h42ead4cc__0)))))));
    vlSelf->wasmetal_core__DOT___011109_ = (1U & (IData)(
                                                         (0xff005533330f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056500_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4cd16820__0)))))));
    vlSelf->wasmetal_core__DOT___056964_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010722_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                      ? 
                                                     (0xfff4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x5c00U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___011522_))))) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2790f0bb__0))))
                                                      : 
                                                     (0xf1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0xa300U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_he7cac7a8__0)))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0xa03U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011513_))))))))))));
    vlSelf->__VdfgTmp_h9edc9904__0 = (((IData)(vlSelf->wasmetal_core__DOT___011771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011772_));
    vlSelf->__VdfgTmp_h2d927cdc__0 = (((IData)(vlSelf->wasmetal_core__DOT___011206_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011207_));
    vlSelf->__VdfgTmp_h9b5fb542__0 = (((IData)(vlSelf->wasmetal_core__DOT___010412_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hb44ad26b__0));
    vlSelf->__VdfgTmp_h890ba8da__0 = (((IData)(vlSelf->wasmetal_core__DOT___010412_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb44ad26b__0)));
    vlSelf->__VdfgTmp_ha28d971c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)));
    vlSelf->wasmetal_core__DOT___011029_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011030_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010291_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011031_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010282_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011038_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010273_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011039_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010254_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011040_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010243_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT___056894_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x5300U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7e112ed5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013099_))));
    vlSelf->wasmetal_core__DOT___011184_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h00eaf9c7__0))))));
    vlSelf->wasmetal_core__DOT___056921_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h00eaf9c7__0))))));
    vlSelf->wasmetal_core__DOT___056431_ = (1U & (0xf0f00077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011899_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xccccaaaaf0f000ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011520_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011518_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011522_)))))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2790f0bb__0))))));
    vlSelf->__VdfgTmp_hdd9e6a33__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056379_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056378_))))));
    vlSelf->wasmetal_core__DOT___056346_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056173_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056172_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)))))))));
    vlSelf->__VdfgTmp_h0e06d26a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 4U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3fe4e0c8__0)));
    vlSelf->wasmetal_core__DOT___013143_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3fe4e0c8__0))))));
    vlSelf->__VdfgTmp_hf19e2482__0 = (((IData)(vlSelf->wasmetal_core__DOT___056721_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056720_));
    vlSelf->__VdfgTmp_h36a8bb37__0 = (((IData)(vlSelf->wasmetal_core__DOT___011921_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011922_));
    vlSelf->wasmetal_core__DOT___010402_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010392_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010391_))));
    vlSelf->__VdfgTmp_hc88b842e__0 = (((IData)(vlSelf->wasmetal_core__DOT___056641_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010182_));
    vlSelf->__VdfgTmp_h84e2ca83__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056379_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056378_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056377_))))));
    vlSelf->__VdfgTmp_h584e6b29__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056379_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056378_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056377_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056376_))))));
    vlSelf->__VdfgTmp_h29c29c56__0 = (((IData)(vlSelf->wasmetal_core__DOT___056377_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h375c9c07__0));
    vlSelf->__VdfgTmp_h766276ef__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)));
    vlSelf->wasmetal_core__DOT___011915_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010342_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010340_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf508d85__0))))))));
    vlSelf->__VdfgTmp_h619b0a2b__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_haf508d85__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___011912_));
    vlSelf->__VdfgTmp_h234e76cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___012383_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056291_));
    vlSelf->wasmetal_core__DOT___057551_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056552_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011666_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h98e4ab16__0))))))));
    vlSelf->wasmetal_core__DOT___011191_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011182_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011181_))));
    vlSelf->__VdfgTmp_h43b12a4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011528_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011381_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h14d4af94__0)))));
    vlSelf->wasmetal_core__DOT___012797_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h14d4af94__0)))));
    vlSelf->wasmetal_core__DOT___011887_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h14d4af94__0))));
    vlSelf->wasmetal_core__DOT___056774_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011922_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011921_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4284cb76__0))))));
    vlSelf->__VdfgTmp_h8262dffe__0 = (((IData)(vlSelf->wasmetal_core__DOT___010389_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010390_));
    vlSelf->__VdfgTmp_he0f8989d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010390_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010389_));
    vlSelf->wasmetal_core__DOT___013167_ = (1U & (IData)(
                                                         (0x30303030000ffaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056925_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056923_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056920_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056919_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))))));
    vlSelf->wasmetal_core__DOT___011961_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he09ec1d2__0))))));
    vlSelf->__VdfgTmp_hc77b1aaa__0 = ((2U & ((IData)(
                                                     (0xf4f4000000ffULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                           << 4U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he09ec1d2__0))))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                         & (IData)(
                                                   (0xff00ffaaf0f0fcfcULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010189_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010188_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d))))))))));
    vlSelf->wasmetal_core__DOT___072147_ = (1U & (0x17U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hee315f88__0))));
    vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___010022_) 
           & (IData)(vlSelf->wasmetal_core__DOT___033452_));
    vlSelf->wasmetal_core__DOT___056289_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011997_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011998_))));
    vlSelf->__VdfgTmp_h5e559da9__0 = ((2U & ((0xeU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056437_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___010530_)))) 
                                             << 1U)) 
                                      | (1U & (0xdU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___011859_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011604_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010530_))))));
    vlSelf->__VdfgTmp_h5fdab2da__0 = (((IData)(vlSelf->wasmetal_core__DOT___011859_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011604_));
    vlSelf->__VdfgTmp_h0a5eca32__0 = (((IData)(vlSelf->wasmetal_core__DOT___011538_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011530_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011529_)));
    vlSelf->wasmetal_core__DOT___011361_ = (1U & (IData)(
                                                         (0x5500ff33330f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056595_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1d16dec4__0)))))));
    vlSelf->__VdfgTmp_ha12381c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9484b551__0)));
    vlSelf->wasmetal_core__DOT___056728_ = (1U & (0xa030000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056725_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011924_)))))));
    vlSelf->wasmetal_core__DOT___012806_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056720_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056721_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056725_)))))));
    vlSelf->wasmetal_core__DOT___056901_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012179_))));
    vlSelf->wasmetal_core__DOT___072013_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071983_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h6bff4562__0))))))));
    vlSelf->wasmetal_core__DOT___013104_ = (1U & (0xf011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xaaaaccccf0f0ff00ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h6bff4562__0))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056897_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056898_))))));
    vlSelf->__VdfgTmp_he9efeda2__0 = ((4U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_hda718c9e__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_ha4e3e772__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h58c9f225__0)))));
    vlSelf->__VdfgTmp_h74dc1f9c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h58c9f225__0)))));
    vlSelf->__VdfgTmp_h2aa20ca5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010198_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010197_)));
    vlSelf->wasmetal_core__DOT___056922_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011697_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h42ead4cc__0)))))));
    vlSelf->wasmetal_core__DOT___010948_ = (1U & (IData)(
                                                         (0xff00ff5533330f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056440_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4cd16820__0)))))));
    vlSelf->wasmetal_core__DOT___012801_ = (1U & (IData)(
                                                         (0xff00aa0f0f0c0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056437_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056440_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcef50cee__0))))))));
    vlSelf->wasmetal_core__DOT___011596_ = (1U & (IData)(
                                                         (0xaa00ffccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013096_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1d16dec4__0)))))));
    vlSelf->wasmetal_core__DOT___013139_ = (1U & (IData)(
                                                         (0x111111110000ff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013096_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011602_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011603_)))))))));
    vlSelf->wasmetal_core__DOT___072145_ = (1U & (IData)(
                                                         (0xe8e8e800e8000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xfef0U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))));
    vlSelf->wasmetal_core__DOT___072146_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))))));
    vlSelf->wasmetal_core__DOT___072160_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009833_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))))));
    vlSelf->wasmetal_core__DOT___072177_ = (1U & (0x96696996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))))));
    vlSelf->wasmetal_core__DOT___072002_ = (1U & (IData)(
                                                         (0x55553333000f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056596_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011388_)))))))));
    vlSelf->wasmetal_core__DOT___011444_ = (1U & (IData)(
                                                         (0x3300ff0f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056596_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcd2c6110__0)))))));
    vlSelf->wasmetal_core__DOT___010719_ = (1U & (IData)(
                                                         (0xff000f33335555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056369_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1055e951__0)))))));
    vlSelf->wasmetal_core__DOT___012045_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010125_));
    vlSelf->wasmetal_core__DOT___012295_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010125_));
    if (vlSelf->wasmetal_core__DOT___010182_) {
        if (vlSelf->wasmetal_core__DOT___010124_) {
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___010198_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010197_))));
            vlSelf->wasmetal_core__DOT___011770_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010342_)));
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010221_)));
            vlSelf->wasmetal_core__DOT___056863_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___010705_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
            vlSelf->wasmetal_core__DOT___057023_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___012295_)));
        } else {
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010198_)));
            vlSelf->wasmetal_core__DOT___011770_ = 
                (1U & (0x302U >> (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010342_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_h45be7681__0)))));
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_he9d803b7__0)));
            vlSelf->wasmetal_core__DOT___056863_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012044_)));
            vlSelf->wasmetal_core__DOT___057023_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___012295_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012294_))));
        }
        vlSelf->wasmetal_core__DOT___012548_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011701_));
        vlSelf->wasmetal_core__DOT___057009_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___012287_)) 
                                                   & (0xfbfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___012286_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h8b4e795d__0))))));
        vlSelf->wasmetal_core__DOT___056830_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011998_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011997_)))));
    } else {
        if (vlSelf->wasmetal_core__DOT___010124_) {
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h42ead4cc__0)));
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010220_)));
            vlSelf->wasmetal_core__DOT___056863_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___012045_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012043_))));
            vlSelf->wasmetal_core__DOT___057023_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012293_)));
        } else {
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010196_)));
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010219_)));
            vlSelf->wasmetal_core__DOT___056863_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___012045_)));
            vlSelf->wasmetal_core__DOT___057023_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h4a9b748c__0)));
        }
        vlSelf->wasmetal_core__DOT___012548_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___011697_)) 
                                                   & (0xf0fbU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010199_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hca8ac9e4__0))))));
        vlSelf->wasmetal_core__DOT___011770_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   | (0x53U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0))));
        vlSelf->wasmetal_core__DOT___057009_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011701_));
        vlSelf->wasmetal_core__DOT___056830_ = (1U 
                                                & (0xf4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2aa20ca5__0))));
    }
    vlSelf->wasmetal_core__DOT___011831_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010767_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011478_)));
    vlSelf->wasmetal_core__DOT___011473_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                   ? 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010767_)))
                                                   : 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___011478_))));
    if (vlSelf->wasmetal_core__DOT___010531_) {
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___011633_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_hee8b18a4__0)));
            vlSelf->wasmetal_core__DOT___011595_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_hbc86843d__0)));
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011528_)));
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012131_)));
            vlSelf->wasmetal_core__DOT___057440_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011858_)));
            vlSelf->wasmetal_core__DOT___012793_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011858_)));
        } else {
            vlSelf->wasmetal_core__DOT___011633_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011379_)));
            vlSelf->wasmetal_core__DOT___011595_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011604_)));
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)));
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011868_)));
            vlSelf->wasmetal_core__DOT___057440_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_hbc86843d__0)));
            vlSelf->wasmetal_core__DOT___012793_ = 
                (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___011605_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_hf996b543__0))));
        }
        vlSelf->wasmetal_core__DOT___011586_ = (1U 
                                                & (0x23U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011473_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011471_))))));
    } else {
        vlSelf->wasmetal_core__DOT___011633_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011636_));
        vlSelf->wasmetal_core__DOT___011595_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011603_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011602_))));
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011529_)));
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011869_)));
            vlSelf->wasmetal_core__DOT___057440_ = 
                (1U & (2U >> (IData)(vlSelf->__VdfgTmp_h5fdab2da__0)));
            vlSelf->wasmetal_core__DOT___012793_ = 
                (1U & (0xdU >> (IData)(vlSelf->__VdfgTmp_h5fdab2da__0)));
        } else {
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011530_)));
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)));
            vlSelf->wasmetal_core__DOT___057440_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011859_)));
            vlSelf->wasmetal_core__DOT___012793_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011859_)));
        }
        vlSelf->wasmetal_core__DOT___011586_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011470_))))));
    }
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___011304_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)));
        vlSelf->wasmetal_core__DOT___010790_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0)));
    } else {
        vlSelf->wasmetal_core__DOT___011304_ = (1U 
                                                & (0xfdfU 
                                                   >> 
                                                   ((0x10U 
                                                     & ((0xfef0U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                        << 4U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9b5fb542__0))));
        vlSelf->wasmetal_core__DOT___010790_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d)) 
                                                   & (0xfdfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9b5fb542__0)))));
    }
    vlSelf->wasmetal_core__DOT___056177_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009808_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___009807_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xfef0U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hee315f88__0))))))))));
    vlSelf->__VdfgTmp_h5164472e__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)));
    vlSelf->wasmetal_core__DOT___011962_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010220_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010219_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010261_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010260_)))))))));
    if (vlSelf->wasmetal_core__DOT___010124_) {
        if (vlSelf->wasmetal_core__DOT___010182_) {
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010261_)));
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011198_)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_he9d803b7__0)));
        } else {
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010259_)));
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_he9d803b7__0)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010219_)));
        }
        vlSelf->wasmetal_core__DOT___056930_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h45be7681__0)))));
        vlSelf->wasmetal_core__DOT___012979_ = vlSelf->wasmetal_core__DOT___012042_;
        vlSelf->wasmetal_core__DOT___056638_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011722_));
        vlSelf->wasmetal_core__DOT___012631_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011666_)));
    } else {
        if (vlSelf->wasmetal_core__DOT___010182_) {
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010260_)));
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010221_)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010220_)));
        } else {
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h493dc6bd__0)));
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010220_)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010261_)));
        }
        vlSelf->wasmetal_core__DOT___056930_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0))));
        vlSelf->wasmetal_core__DOT___012979_ = vlSelf->wasmetal_core__DOT___011722_;
        vlSelf->wasmetal_core__DOT___056638_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010705_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d))))));
        vlSelf->wasmetal_core__DOT___012631_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011666_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___010301_)))
                                                    : (IData)(
                                                              (0xbfULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011666_) 
                                                                 << 5U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha28d971c__0))))));
    }
    vlSelf->__VdfgTmp_h744d21e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010260_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010259_));
    vlSelf->wasmetal_core__DOT___056349_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d)) 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)) 
                                                           & (IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((0xfef0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb211d2c2__0))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)) 
                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d)) 
                                                            & (IData)(
                                                                      (1ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hee315f88__0)))))))))))));
    vlSelf->__VdfgTmp_h028857f6__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb211d2c2__0));
    vlSelf->wasmetal_core__DOT___057068_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057067_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057066_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057065_)))))));
    vlSelf->wasmetal_core__DOT___057558_ = (1U & (0xeef0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057557_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057067_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057264_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    vlSelf->wasmetal_core__DOT___056775_ = (1U & (0xc000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011924_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011923_)))))));
    if (vlSelf->wasmetal_core__DOT___010530_) {
        vlSelf->wasmetal_core__DOT___011405_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011413_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010574_))));
        vlSelf->wasmetal_core__DOT___010841_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___010577_));
    } else {
        vlSelf->wasmetal_core__DOT___011405_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___010577_));
        vlSelf->wasmetal_core__DOT___010841_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010574_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010573_))));
    }
    if (vlSelf->wasmetal_core__DOT___010721_) {
        if (vlSelf->wasmetal_core__DOT___010722_) {
            vlSelf->wasmetal_core__DOT___011955_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011924_)));
            vlSelf->wasmetal_core__DOT___011099_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010842_)));
        } else {
            vlSelf->wasmetal_core__DOT___011955_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___011922_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011921_))));
            vlSelf->wasmetal_core__DOT___011099_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hdeb472fa__0)));
        }
        vlSelf->wasmetal_core__DOT___012828_ = (1U 
                                                & (0xc4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011923_)))));
    } else {
        if (vlSelf->wasmetal_core__DOT___010722_) {
            vlSelf->wasmetal_core__DOT___011955_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011923_)));
            vlSelf->wasmetal_core__DOT___011099_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010841_)));
        } else {
            vlSelf->wasmetal_core__DOT___011955_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h4284cb76__0)));
            vlSelf->wasmetal_core__DOT___011099_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___010727_));
        }
        vlSelf->wasmetal_core__DOT___012828_ = (1U 
                                                & (0xf00ee00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011924_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h36a8bb37__0))))));
    }
    if (vlSelf->wasmetal_core__DOT___010530_) {
        if (vlSelf->wasmetal_core__DOT___010531_) {
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011381_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011868_)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011868_)));
        } else {
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)));
        }
        vlSelf->wasmetal_core__DOT___011649_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011528_)));
    } else {
        if (vlSelf->wasmetal_core__DOT___010531_) {
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011528_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011869_)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011869_)));
        } else {
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011529_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011870_)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011870_)));
        }
        vlSelf->wasmetal_core__DOT___011649_ = (1U 
                                                & (0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)));
    }
    vlSelf->wasmetal_core__DOT___013041_ = ((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                            & (IData)(
                                                      (0xff00fff0f0eeeeULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013047_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xaaaaccccf0f0ff00ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h6bff4562__0))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012175_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___012176_)))))))));
    vlSelf->__VdfgTmp_h6c83109e__0 = (((IData)(vlSelf->wasmetal_core__DOT___012176_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012175_));
    vlSelf->wasmetal_core__DOT___071993_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xfff4f4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010574_) 
                                                                << 3U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha620249b__0)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf0faaccU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h88f91f2d__0)))))));
    vlSelf->wasmetal_core__DOT___011403_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h88f91f2d__0)))));
    vlSelf->wasmetal_core__DOT___057010_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3a025ab3__0))))));
    vlSelf->wasmetal_core__DOT___071999_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011605_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf996b543__0))))));
    vlSelf->__VdfgTmp_hefe0e1be__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011604_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h146131dd__0)));
    vlSelf->wasmetal_core__DOT___010850_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h146131dd__0))))))));
    vlSelf->wasmetal_core__DOT___057134_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057102_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056291_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010395_)))));
    vlSelf->wasmetal_core__DOT___012506_ = (1U & (0xf40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057102_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056291_)))))));
    vlSelf->wasmetal_core__DOT___056573_ = ((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                               & (IData)(
                                                         (0xfffcff00aaaa0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeeeULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011207_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011206_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011205_))))))))));
    vlSelf->wasmetal_core__DOT___056578_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011205_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))));
    vlSelf->wasmetal_core__DOT___011253_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011205_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010085_))))));
    vlSelf->__VdfgTmp_h55e24ebb__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011205_));
    vlSelf->__VdfgTmp_h77b6db08__0 = ((4U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___011205_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010395_)));
    vlSelf->__VdfgTmp_hef0b5c34__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0)))))));
    vlSelf->__VdfgTmp_h86de1fc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___012286_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8b4e795d__0));
    vlSelf->wasmetal_core__DOT___072175_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x96U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h08c644ac__0))))));
    vlSelf->__VdfgTmp_hab99f676__0 = ((2U & ((IData)(
                                                     (0x55f366c366cfaa0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                        << 5U) 
                                                       | ((0x10U 
                                                           & ((0xfef0U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)))))))) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_h08c644ac__0))));
    vlSelf->wasmetal_core__DOT___055309_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d))));
    vlSelf->wasmetal_core__DOT___013103_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056896_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056895_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012177_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012178_)))))));
    vlSelf->__VdfgTmp_hc338337f__0 = (((IData)(vlSelf->wasmetal_core__DOT___012182_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012183_));
    vlSelf->__VdfgTmp_hc49b4927__0 = (((IData)(vlSelf->wasmetal_core__DOT___012183_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012182_));
    vlSelf->wasmetal_core__DOT___012402_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hede7bfa8__0))))))));
    vlSelf->wasmetal_core__DOT___056717_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hede7bfa8__0)))));
    vlSelf->wasmetal_core__DOT___010720_ = (1U & (IData)(
                                                         (0x333355550f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7bcb9cab__0))))))));
    vlSelf->wasmetal_core__DOT___011937_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7bcb9cab__0)))));
    vlSelf->__VdfgTmp_h31fa1bee__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056281_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056280_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_had4ae229__0)))));
    vlSelf->wasmetal_core__DOT___056211_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056206_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056205_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___011992_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056191_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_heb18a766__0)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (((~ (IData)(vlSelf->wasmetal_core__DOT___009833_)) 
                                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___009832_)) 
                                                                    & (IData)(
                                                                              (1ULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___009831_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009830_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d)))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (1ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___011520_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056187_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056186_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfe9a1cba__0))))))))))))));
    vlSelf->__VdfgTmp_he9aaeb48__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hb1f92188__0)))));
    vlSelf->wasmetal_core__DOT___011960_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010221_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he9d803b7__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b53__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b52__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b50__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b49__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b47__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b46__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b44__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b43__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b41__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b40__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b38__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b37__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b36__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b34__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b32__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d 
        = (1U & (0xeU >> ((2U & ((0xfef0U >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b30__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b29__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b28__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b27__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d 
        = (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___055194_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    vlSelf->wasmetal_core__DOT___057096_ = (1U & (0x100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010842_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h15546f37__0))));
    vlSelf->wasmetal_core__DOT___012413_ = (1U & (0xef00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010842_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010722_))))));
    vlSelf->wasmetal_core__DOT___012714_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xffaaccf0U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)))))))));
    vlSelf->wasmetal_core__DOT___012582_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xffaaccf0U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010722_))))));
    vlSelf->wasmetal_core__DOT___056831_ = (1U & (IData)(
                                                         (0xff0f11111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056827_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056277_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056826_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056825_)))))))));
    vlSelf->__VdfgTmp_h1d3dc22c__0 = ((2U & ((0x503U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h23ac912c__0)))) 
                                             << 1U)) 
                                      | (1U & (0x3500U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011870_)))))));
    vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030124_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d));
    vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030284_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134173___O 
        = ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0))) 
           ^ ((((4U >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0)) 
                & (IData)(vlSelf->wasmetal_core__DOT___036894_)) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036894_)));
    vlSelf->wasmetal_core__DOT___064906_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___064471_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___064736_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___063848_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063845_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063844_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042224_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048361_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048349_)))))))));
    vlSelf->__VdfgTmp_h60159710__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d)));
    vlSelf->wasmetal_core__DOT___070412_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053904_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b124__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xfe01ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051546_)))))))));
    vlSelf->wasmetal_core__DOT___069782_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053549_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051063_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051062_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053545_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b85__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xd1c40000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((0xc0aU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051065_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070323_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b117__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h37b9b4c8__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053875_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053545_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009523_)))))))))))));
    vlSelf->wasmetal_core__DOT___068763_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b53__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h37b9b4c8__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT___009501_)) 
                                                            & (IData)(
                                                                      (0xffffffff10ff1010ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___009524_) 
                                                                         << 5U) 
                                                                        | ((0x10U 
                                                                            & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 4U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009523_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009520_))))))))))))));
    vlSelf->wasmetal_core__DOT___069804_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053556_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050067_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051117_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053551_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b86__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053553_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050041_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070335_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b118__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051110_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051109_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053879_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053551_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051119_)))))))))))));
    vlSelf->wasmetal_core__DOT___051121_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051110_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b54__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051109_))))));
    vlSelf->wasmetal_core__DOT___070230_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053850_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b110__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049481_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049482_)))))))));
    vlSelf->wasmetal_core__DOT___070261_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053857_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b112__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049695_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049696_)))))))));
    vlSelf->wasmetal_core__DOT___070142_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053825_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x802aaaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b104__05d)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053823_)))))))));
    vlSelf->wasmetal_core__DOT___068094_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068093_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x802aaaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b40__05d)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053823_)))))))));
    vlSelf->wasmetal_core__DOT___070363_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053889_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xa802aaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b120__05d)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051322_)))))))));
    vlSelf->wasmetal_core__DOT___070200_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053842_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b108__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xe01fffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050879_)))))))));
    vlSelf->wasmetal_core__DOT___070082_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053804_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b100__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x807fffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053802_)))))))));
    vlSelf->wasmetal_core__DOT___070310_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053873_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b116__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xf807ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050722_)))))))));
    vlSelf->wasmetal_core__DOT___068714_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050724_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b52__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xf807ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009506_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050722_)))))))));
    vlSelf->wasmetal_core__DOT___070125_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b103__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009512_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009513_)))))))));
    vlSelf->wasmetal_core__DOT___067680_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053797_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b33__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053706_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009506_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053708_)))))))));
    vlSelf->wasmetal_core__DOT___067617_ = (1U & (IData)(
                                                         (0xff8f8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067616_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccffffa000f0ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b32__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051654_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009537_)))))))));
    vlSelf->wasmetal_core__DOT___068910_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051334_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbfbfbfU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051331_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b56__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6a1d65be__0)))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb829d41d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051332_)))))))));
    vlSelf->wasmetal_core__DOT___069846_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053638_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b88__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0x1fe0000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7578f7f__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050641_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051330_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053634_))))))))))))));
    vlSelf->wasmetal_core__DOT___069761_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053538_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x70U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b84__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0x7fff80000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 3U))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050705_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050704_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053534_))))))))))))));
    vlSelf->wasmetal_core__DOT___067859_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053921_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf4ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051843_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051842_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051841_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053798_)))))))));
    vlSelf->wasmetal_core__DOT___068307_ = (1U & (IData)(
                                                         (0xff00ff4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050882_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b44__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048681_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048680_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050880_)))))))));
    vlSelf->wasmetal_core__DOT___069102_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051556_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b60__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051553_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048673_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051554_)))))))));
    vlSelf->wasmetal_core__DOT___069929_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053668_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              >> 1U)) 
                                                                          | ((2U 
                                                                              & ((0xa300U 
                                                                                >> 
                                                                                ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051552_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053663_)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052603_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b92__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x6020U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                               << 3U) 
                                                                              | ((6U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052601_)))))))))))));
    vlSelf->wasmetal_core__DOT___067744_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054756_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f7700003f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050896_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050974_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053712_)))))))));
    vlSelf->wasmetal_core__DOT___069888_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053650_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x9f00df00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b90__05d) 
                                                                              << 3U) 
                                                                             | ((6U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053647_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051370_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051369_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053646_))))))))))))));
    vlSelf->wasmetal_core__DOT___070387_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053897_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b122__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051362_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051363_)))))))));
    vlSelf->wasmetal_core__DOT___069009_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b58__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051363_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051362_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051374_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___051373_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051372_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___067958_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067955_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x2202ff0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067953_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051989_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053811_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053810_)))))))));
    vlSelf->wasmetal_core__DOT___070110_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053814_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x48ccc8ccU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 4U) 
                                                                          | ((0xcU 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b102__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053811_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0xbbb0U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053810_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051764_))))))))))))));
    vlSelf->wasmetal_core__DOT___068416_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049542_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b46__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049539_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049538_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049537_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049540_)))))))));
    vlSelf->wasmetal_core__DOT___070437_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053912_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b126__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051609_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051610_)))))))));
    vlSelf->wasmetal_core__DOT___051621_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051610_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b62__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051609_))))));
    vlSelf->wasmetal_core__DOT___069867_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053644_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051350_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051349_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053640_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b89__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xd1c40000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053641_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051351_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070375_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b121__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051343_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051342_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053891_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053640_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051355_)))))))))))));
    vlSelf->wasmetal_core__DOT___051357_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051343_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b57__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051342_))))));
    vlSelf->wasmetal_core__DOT___067915_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053530_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaa0ccc0fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053525_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b37__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha128d41e__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053528_)))))))));
    vlSelf->wasmetal_core__DOT___070424_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053908_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b125__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051577_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051578_)))))))));
    vlSelf->wasmetal_core__DOT___069152_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b61__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051578_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051577_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051588_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___051587_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051586_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___069950_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053687_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x1111f00000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053114_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x503U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x3333aaaaf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0x5cU 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc0f91dc6__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049132_))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xf0faaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049142_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0a02dc0e__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049120_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048585_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048584_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf502c6b2__0))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xf0faaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049747_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfbafed17__0))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049794_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049883_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4cf0cb93__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf0faaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051345_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7cd11e4f__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051364_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051518_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h36154466__0)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xfeff0000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053680_) 
                                                                                << 3U) 
                                                                                | (4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b93__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053684_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053112_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___069826_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053585_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050981_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051291_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053581_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b87__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053582_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050795_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070347_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b119__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h47401135__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053883_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053581_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051293_)))))))))))));
    vlSelf->wasmetal_core__DOT___068863_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0xbbff33000f0f0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b55__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xef00efefULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___051294_) 
                                                                                << 5U) 
                                                                               | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051293_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xff55ccf0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h35851421__0)))))))))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h47401135__0))))))));
    vlSelf->wasmetal_core__DOT___069991_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053699_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b95__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0xfe540000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053695_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053389_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051634_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051633_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053694_))))))))))))));
    vlSelf->wasmetal_core__DOT___070449_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053916_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b127__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051626_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051627_)))))))));
    vlSelf->wasmetal_core__DOT___051640_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051627_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b63__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051626_))))));
    vlSelf->wasmetal_core__DOT___070399_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051517_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b123__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xbb00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053898_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051527_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053652_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051516_))))))))))));
    vlSelf->wasmetal_core__DOT___051529_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051517_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b59__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051516_))))));
    vlSelf->wasmetal_core__DOT___068199_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051662_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f7700003f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050869_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050868_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b42__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050867_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051660_)))))))));
    vlSelf->wasmetal_core__DOT___068566_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049771_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049768_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049767_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b49__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049766_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049769_)))))))));
    vlSelf->wasmetal_core__DOT___068617_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049823_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xef00efefefefULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049820_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0xf0f0f77U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049821_)))))))));
    vlSelf->wasmetal_core__DOT___068666_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049904_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049901_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049900_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049899_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049902_)))))))));
    vlSelf->wasmetal_core__DOT___063524_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___063532_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___063540_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___063548_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029612_));
    vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030656_));
    vlSelf->wasmetal_core__DOT___051276_ = (1U & (0xb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050459_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050458_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050457_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->reset)))))));
    vlSelf->wasmetal_core__DOT___050463_ = (1U & (0xe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050459_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050458_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050457_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050456_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->reset)))))));
    vlSelf->wasmetal_core__DOT___053249_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053248_))));
    vlSelf->wasmetal_core__DOT___053369_ = (1U & (IData)(
                                                         (0xbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053163_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053088_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053092_)))))))));
    vlSelf->wasmetal_core__DOT___053097_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053088_))));
    vlSelf->wasmetal_core__DOT___052863_ = (1U & (IData)(
                                                         (0xb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052861_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052684_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052860_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___045941_)))))))));
    vlSelf->wasmetal_core__DOT___052711_ = (1U & (IData)(
                                                         (0x7f7f7f7f7f7f7fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052679_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052706_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052705_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050364_)))))))));
    vlSelf->__VdfgTmp_h461b3fd9__0 = (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___052679_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___052678_)))));
    vlSelf->wasmetal_core__DOT___051230_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051226_))));
    vlSelf->wasmetal_core__DOT___052657_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051226_))));
    vlSelf->wasmetal_core__DOT___019789_ = (1U & (IData)(
                                                         (0x23a0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052835_)))))))));
    vlSelf->wasmetal_core__DOT___019785_ = (1U & (IData)(
                                                         (0xa03000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050446_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048518_)))))))));
    vlSelf->wasmetal_core__DOT___053590_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0))))));
    vlSelf->wasmetal_core__DOT___053576_ = (1U & (IData)(
                                                         (0x40400000ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c1295c2__0))))))));
    vlSelf->wasmetal_core__DOT___000130_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->reset)))));
    vlSelf->wasmetal_core__DOT___053098_ = (1U & (0xfbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053094_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053093_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h44c20413__0))))));
    vlSelf->__VdfgTmp_h554fca93__0 = ((2U & ((IData)(
                                                     (0x7770fff0fffULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052844_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052843_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & (4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h7e6b8024__0)))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xff40404000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___053019_))))))))));
    vlSelf->wasmetal_core__DOT___053621_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053434_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___051228_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___053359_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053263_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___053516_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053514_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h8ecdfd77__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___053363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3eb9c9bf__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050365_))));
    vlSelf->wasmetal_core__DOT___053493_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050389_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)))))));
    vlSelf->wasmetal_core__DOT___053502_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052655_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050446_)))));
    vlSelf->wasmetal_core__DOT___053494_ = (1U & (0x2fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053091_))))));
    vlSelf->wasmetal_core__DOT___052709_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050365_))));
    vlSelf->wasmetal_core__DOT___052917_ = (1U & (IData)(
                                                         (0xbfbfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052864_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1a7964bb__0))))))));
    vlSelf->wasmetal_core__DOT___052712_ = (1U & (0x7f7f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052700_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050380_)))))));
    vlSelf->wasmetal_core__DOT___050382_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050380_))));
    vlSelf->wasmetal_core__DOT___052690_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052687_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050365_))))));
    vlSelf->wasmetal_core__DOT___052703_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h568bee24__0))));
    vlSelf->wasmetal_core__DOT___058694_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058692_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5e920d5f__0)))));
    vlSelf->wasmetal_core__DOT___017220_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017324_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017226_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017333_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017318_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017312_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017241_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057889_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017355_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017354_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057922_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017383_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017384_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___058013_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017425_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017426_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017409_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017283_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017284_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___058005_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017345_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013687_))));
    vlSelf->wasmetal_core__DOT___017344_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013656_))));
    vlSelf->wasmetal_core__DOT___017274_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013635_))));
    vlSelf->wasmetal_core__DOT___017273_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xeU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))))));
    vlSelf->wasmetal_core__DOT___057987_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013705_))));
    vlSelf->wasmetal_core__DOT___017437_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013692_))));
    vlSelf->wasmetal_core__DOT___014415_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013712_))));
    vlSelf->wasmetal_core__DOT___014408_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013690_))));
    vlSelf->wasmetal_core__DOT___014401_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013654_))));
    vlSelf->wasmetal_core__DOT___014394_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013648_))));
    vlSelf->wasmetal_core__DOT___014428_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013666_))));
    vlSelf->wasmetal_core__DOT___017396_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013658_))));
    vlSelf->wasmetal_core__DOT___014422_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013719_))));
    vlSelf->wasmetal_core__DOT___014425_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013701_))));
    vlSelf->wasmetal_core__DOT___017401_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013722_))));
    vlSelf->wasmetal_core__DOT___017404_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013694_))));
    vlSelf->wasmetal_core__DOT___057941_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013670_))));
    vlSelf->wasmetal_core__DOT___057949_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013672_))));
    vlSelf->wasmetal_core__DOT___023566_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019197_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023552_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023551_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048712_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023550_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048717_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023549_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022502_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb3f3e4b7__0))));
    vlSelf->wasmetal_core__DOT___022498_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha93fec6f__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___006115_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006114_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006113_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048703_))))));
    vlSelf->wasmetal_core__DOT___051504_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051501_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006065_)))));
    vlSelf->wasmetal_core__DOT___022496_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he648fa65__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127601___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hb70db301__0))) 
           ^ (1U | ((8U & (((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d)) 
                            | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__1__KET__)) 
                           << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__1__KET__) 
                                       << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                 << 1U)))));
    vlSelf->wasmetal_core__DOT___058932_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051501_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048703_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006115_)))))));
    vlSelf->wasmetal_core__DOT___022492_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h21922827__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127427___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005935_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h76ba8332__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___022537_ = ((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___057805_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013635_))));
    vlSelf->wasmetal_core__DOT___017909_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xeU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))))));
    vlSelf->wasmetal_core__DOT___017871_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013705_))));
    vlSelf->wasmetal_core__DOT___017872_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013692_))));
    vlSelf->wasmetal_core__DOT___057857_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013712_))));
    vlSelf->wasmetal_core__DOT___017885_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013690_))));
    vlSelf->wasmetal_core__DOT___017886_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013654_))));
    vlSelf->wasmetal_core__DOT___057874_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013648_))));
    vlSelf->wasmetal_core__DOT___014289_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013719_))));
    vlSelf->wasmetal_core__DOT___014300_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013701_))));
    vlSelf->wasmetal_core__DOT___014350_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013722_))));
    vlSelf->wasmetal_core__DOT___014338_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013694_))));
    vlSelf->wasmetal_core__DOT___017903_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013668_))));
    vlSelf->wasmetal_core__DOT___057883_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013670_))));
    vlSelf->wasmetal_core__DOT___057923_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013672_))));
    vlSelf->wasmetal_core__DOT___022713_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022700_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022699_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___005663_ = (1U & ((0x80U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006204_)))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___003130_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003129_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003128_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0x80U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h28ae1e0e__0))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((8U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005770_))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h76ba8332__0))))))))))));
    vlSelf->__VdfgTmp_h15b2e0c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___000134_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000139_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000138_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000137_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000136_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000135_))))));
    vlSelf->wasmetal_core__DOT___000140_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000139_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000138_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000137_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000136_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000135_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000134_)))))))));
    vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013778_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___022853_ = ((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127477___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006099_) 
             << 3U) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006022_)) 
                              << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006106_)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___005868_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127462___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013687_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___002473_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022737_ = ((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___016197_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006898_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006899_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___051557_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___016206_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006918_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006919_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006932_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006933_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006944_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006951_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006959_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006966_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006969_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___051542_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___051541_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___016297_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022643_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022630_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022629_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___059202_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051507_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051506_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051505_))))));
    vlSelf->wasmetal_core__DOT___059159_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051506_))));
    vlSelf->wasmetal_core__DOT___006972_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048702_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048701_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___005903_))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x8000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006226_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d))))))))))));
    vlSelf->wasmetal_core__DOT___022491_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he55adf41__0))));
    vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005903_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127453___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003805_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___005770_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022667_ = ((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___020524_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid))));
    vlSelf->wasmetal_core__DOT___040092_ = (1U & (0xfb080808U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128793___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid))));
    vlSelf->wasmetal_core__DOT___014875_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015196_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058620_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058648_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058645_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058641_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058611_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015441_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___014689_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015140_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015025_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015166_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015102_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015078_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015109_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___014931_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___014714_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___019773_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048949_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))))));
    vlSelf->wasmetal_core__DOT___019023_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))))));
    vlSelf->wasmetal_core__DOT___006127_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))));
    vlSelf->wasmetal_core__DOT___063466_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128410___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063474_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128410___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063482_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128410___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063455_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128410___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032026_));
    vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026485_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b9__05d));
    vlSelf->wasmetal_core__DOT___036730_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036762_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6d2d9567__0))));
    vlSelf->wasmetal_core__DOT___063144_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128060___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063150_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128060___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063156_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128060___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063162_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128060___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028288_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028254_)
            : (IData)(vlSelf->wasmetal_core__DOT___028223_));
    vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026593_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001382_));
    vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031333_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031300_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034323_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034490_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127961___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027472_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027471_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027470_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027469_)))) 
           ^ (((IData)(wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027436_ = ((IData)(vlSelf->wasmetal_core__DOT___027472_)
                                             ? (IData)(wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b3__05d));
    vlSelf->wasmetal_core__DOT___027473_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b4__05d))));
    vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027395_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027330_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b8__05d));
    vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 0x15U) & (IData)(vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x200000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x15U)
                  : (IData)(vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128486___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032876_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032875_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032874_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032873_)))) 
           ^ (((IData)(wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032840_)))));
    vlSelf->wasmetal_core__DOT___032844_ = ((IData)(vlSelf->wasmetal_core__DOT___032876_)
                                             ? (IData)(wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128014___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027811_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027810_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027809_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027808_)))) 
           ^ (((IData)(wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027775_)))));
    vlSelf->wasmetal_core__DOT___027779_ = ((IData)(vlSelf->wasmetal_core__DOT___027811_)
                                             ? (IData)(wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b19__05d));
    vlSelf->wasmetal_core__DOT___066402_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066399_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x10U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066528_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066525_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x11U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066316_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066313_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xfU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066605_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066602_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x12U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 0x15U) & (IData)(vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028098_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028065_)
                  : (vlSelf->insn_x >> 0x10U)));
    vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 0x15U)) & (IData)(vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128470___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032684_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032683_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032682_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032681_)))) 
           ^ (((IData)(wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032648_)))));
    vlSelf->wasmetal_core__DOT___032652_ = ((IData)(vlSelf->wasmetal_core__DOT___032684_)
                                             ? (IData)(wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134212___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037194_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037193_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037192_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037191_)))) 
           ^ (((IData)(wasmetal_core__DOT___134212___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037159_)))));
    vlSelf->wasmetal_core__DOT___037163_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037194_)
                                                   ? (IData)(wasmetal_core__DOT___134212___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1274aae9__0))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b3__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b2__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b1__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127846___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026367_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026366_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026365_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026364_)))) 
           ^ (((IData)(wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026331_)))));
    vlSelf->wasmetal_core__DOT___026335_ = ((IData)(vlSelf->wasmetal_core__DOT___026367_)
                                             ? (IData)(wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128172___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
           ^ (((IData)(wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029502_)))));
    vlSelf->wasmetal_core__DOT___029506_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128292___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030718_)))));
    vlSelf->wasmetal_core__DOT___030691_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hcec95e31__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056801_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056800_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hf4d8b80a__0)))));
    vlSelf->wasmetal_core__DOT___012866_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056800_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056801_))));
    vlSelf->wasmetal_core__DOT___011564_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010232_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056451_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010194_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056450_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011052_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056449_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010188_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056455_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010189_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056454_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010184_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056453_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010185_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056452_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010180_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056459_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010181_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056458_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010216_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056457_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010199_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056456_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010208_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___056460_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010206_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___011306_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010165_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___011305_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010159_)) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffdfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                                                               << 5U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890ba8da__0))))));
    vlSelf->wasmetal_core__DOT___010417_ = (1U & (IData)(
                                                         (0xff00ff00ff0fffdfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h890ba8da__0)))));
    vlSelf->wasmetal_core__DOT___011914_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(
                                                      (0xffff0000ffffff40ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_ha28d971c__0)))));
    vlSelf->wasmetal_core__DOT___011913_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011029_));
    vlSelf->wasmetal_core__DOT___012629_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011029_));
    vlSelf->wasmetal_core__DOT___056445_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011030_));
    vlSelf->wasmetal_core__DOT___012630_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011030_));
    vlSelf->wasmetal_core__DOT___056444_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011031_));
    vlSelf->wasmetal_core__DOT___012628_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011031_));
    vlSelf->wasmetal_core__DOT___011035_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011038_));
    vlSelf->wasmetal_core__DOT___012627_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011038_));
    vlSelf->wasmetal_core__DOT___011034_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011039_));
    vlSelf->wasmetal_core__DOT___011566_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011039_));
    vlSelf->wasmetal_core__DOT___011033_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011040_));
    vlSelf->wasmetal_core__DOT___011565_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___011040_));
    vlSelf->wasmetal_core__DOT___055188_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x5505cc0cff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055186_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010241_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010242_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5f0d294__0)))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___055149_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa0acc0cff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055147_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hffef1e62__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h35b20f8b__0)))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___055134_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0x1111fff000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0549af28__0))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055130_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054814_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054835_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054834_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054832_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054813_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054812_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054811_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054825_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf5533ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hafe0013c__0)))))))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___055104_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___011763_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011184_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011183_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011181_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011182_)))))))));
    vlSelf->wasmetal_core__DOT___011192_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011184_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011183_))));
    vlSelf->wasmetal_core__DOT___056443_ = (1U & (7U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xf0f00003355ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011900_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x5cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6a02124a__0))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056428_)))))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056431_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010721_))))));
    vlSelf->wasmetal_core__DOT___056351_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056347_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056346_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d)))))))));
    vlSelf->__VdfgTmp_hb331ded8__0 = (((IData)(vlSelf->wasmetal_core__DOT___013143_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013142_));
    vlSelf->wasmetal_core__DOT___012915_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffff0f0fff001111ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056725_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011924_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hf19e2482__0)))))))))));
    vlSelf->wasmetal_core__DOT___012934_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011923_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h36a8bb37__0))))));
    vlSelf->wasmetal_core__DOT___056647_ = (1U & (IData)(
                                                         (0xf000f0000ddddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056644_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056642_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc88b842e__0))))))));
    vlSelf->wasmetal_core__DOT___011854_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011939_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))))))));
    vlSelf->__VdfgTmp_h9d4acb63__0 = (((IData)(vlSelf->wasmetal_core__DOT___012184_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x555533330f0f00ffULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0)))));
    vlSelf->__VdfgTmp_h758d714e__0 = ((2U & ((IData)(
                                                     (0xaaaaccccf0f0ff00ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013100_));
    vlSelf->wasmetal_core__DOT___011593_ = (1U & (IData)(
                                                         (0xff00aaaaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056621_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h29c29c56__0)))))));
    vlSelf->wasmetal_core__DOT___011441_ = (1U & (IData)(
                                                         (0xff555533330f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056368_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h29c29c56__0)))))));
    vlSelf->__VdfgTmp_hf6de1ad3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056378_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h29c29c56__0))));
    vlSelf->wasmetal_core__DOT___056292_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h234e76cf__0))));
    vlSelf->__VdfgTmp_h03a652de__0 = (((IData)(vlSelf->wasmetal_core__DOT___012798_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012797_));
    vlSelf->wasmetal_core__DOT___010949_ = (1U & (0xf0f05533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011887_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011528_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011381_)))))));
    vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___033411_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___010394_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056289_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056288_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012286_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8b4e795d__0)))))))))));
    vlSelf->wasmetal_core__DOT___010950_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e559da9__0)))));
    vlSelf->wasmetal_core__DOT___056424_ = (1U & (IData)(
                                                         (0xff00aaaaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0a5eca32__0)))))));
    vlSelf->wasmetal_core__DOT___013145_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011539_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0a5eca32__0)))))));
    vlSelf->wasmetal_core__DOT___013200_ = (1U & (0xa03U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013104_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013047_))))));
    vlSelf->wasmetal_core__DOT___012868_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056289_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2aa20ca5__0)))))));
    vlSelf->wasmetal_core__DOT___057255_ = (1U & (0x5500fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011184_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011183_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012548_)))))));
    vlSelf->__VdfgTmp_haa3334f5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056922_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056921_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056920_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056919_))))));
    if (vlSelf->wasmetal_core__DOT___010722_) {
        vlSelf->wasmetal_core__DOT___012642_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011595_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xaaaaccccf0f0ff00ULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0))))))));
        vlSelf->wasmetal_core__DOT___011407_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011405_)));
        vlSelf->wasmetal_core__DOT___012420_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010841_)));
    } else {
        vlSelf->wasmetal_core__DOT___012642_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011596_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xf0f0000aaccULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf0faacc00000000ULL 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0)))))))));
        vlSelf->wasmetal_core__DOT___011407_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2994a26e__0)));
        vlSelf->wasmetal_core__DOT___012420_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9c39d480__0)));
    }
    vlSelf->wasmetal_core__DOT___072179_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___072177_))));
    vlSelf->wasmetal_core__DOT___072011_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071991_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072002_)))));
    vlSelf->wasmetal_core__DOT___012362_ = (1U & (0xddf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012045_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056277_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012043_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010124_)))))));
    vlSelf->wasmetal_core__DOT___056640_ = (1U & (IData)(
                                                         (0xf0f0cccc00ff00aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012295_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012044_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012043_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012294_)))))))));
    vlSelf->wasmetal_core__DOT___012400_ = (1U & (IData)(
                                                         (0xff00ff0f33335555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011831_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1055e951__0)))))));
    vlSelf->__VdfgTmp_h1632b282__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011831_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9484b551__0)))));
    vlSelf->__VdfgTmp_h53b21008__0 = (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011831_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011472_))));
    vlSelf->wasmetal_core__DOT___012761_ = ((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                            & (IData)(
                                                      (0xff55ff0033330f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011473_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012749_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011471_)))))))));
    vlSelf->wasmetal_core__DOT___012185_ = (1U & (IData)(
                                                         (0xaaaacccc00f000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011473_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012729_)))))))));
    vlSelf->wasmetal_core__DOT___056210_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056179_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056178_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056177_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb211d2c2__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)))))))));
    vlSelf->__VdfgTmp_h5ae30e42__0 = ((2U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h5164472e__0)) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_hb1f92188__0))));
    vlSelf->__VdfgTmp_hf6f4b63c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5164472e__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h766276ef__0)))));
    vlSelf->wasmetal_core__DOT___012878_ = (1U & (0x5500fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011772_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011771_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011962_)))))));
    vlSelf->wasmetal_core__DOT___012440_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057102_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012384_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h234e76cf__0))))))));
    vlSelf->wasmetal_core__DOT___011185_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010219_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010261_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h744d21e3__0))))))));
    vlSelf->wasmetal_core__DOT___056928_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h744d21e3__0))));
    vlSelf->__VdfgTmp_h64d6559e__0 = ((8U & ((0xe8U 
                                              >> (IData)(vlSelf->__VdfgTmp_h6af19a3e__0)) 
                                             << 3U)) 
                                      | ((4U & ((0xb2U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___033411_)))) 
                                                << 2U)) 
                                         | ((2U & (
                                                   (0x17U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h028857f6__0)) 
                                                   << 1U)) 
                                            | (1U & 
                                               (0x17U 
                                                >> (IData)(vlSelf->__VdfgTmp_hc33f85b3__0))))));
    vlSelf->__VdfgTmp_hf95d62e9__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h028857f6__0)))));
    vlSelf->wasmetal_core__DOT___011437_ = (1U & (0xc000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x55330fU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011405_)))))));
    vlSelf->wasmetal_core__DOT___011576_ = (1U & (0xfcf50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xffaaccf0U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011405_)))))));
    vlSelf->wasmetal_core__DOT___012393_ = (1U & (IData)(
                                                         (0xf0f0ff001111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010842_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010841_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdeb472fa__0))))))));
    vlSelf->__VdfgTmp_h62b744ad__0 = (((IData)(vlSelf->wasmetal_core__DOT___010842_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010841_));
    vlSelf->wasmetal_core__DOT___012180_ = (1U & (0x1111fff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012178_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012177_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6c83109e__0))))));
    vlSelf->wasmetal_core__DOT___072014_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071993_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071992_)))));
    vlSelf->__VdfgTmp_h56d07f21__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___071983_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___010721_))) 
                                                   << 1U)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___010722_))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xaaaaf0f0ff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071993_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071992_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071991_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6bff4562__0)))))))))))));
    vlSelf->__VdfgTmp_h39b11875__0 = (((IData)(vlSelf->wasmetal_core__DOT___011404_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011403_));
    vlSelf->wasmetal_core__DOT___057547_ = (1U & (IData)(
                                                         (0xffaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057024_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056641_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057010_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057011_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))))));
    vlSelf->wasmetal_core__DOT___072001_ = (1U & (IData)(
                                                         (0x33330f0f00ff5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071999_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011604_)))))))));
    vlSelf->wasmetal_core__DOT___011358_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefe0e1be__0))))));
    vlSelf->__VdfgTmp_h23c0a543__0 = (((IData)(vlSelf->wasmetal_core__DOT___010850_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010849_));
    vlSelf->wasmetal_core__DOT___056475_ = (1U & (0x5f3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010850_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha8f305c7__0))))));
    vlSelf->wasmetal_core__DOT___057196_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057134_))))));
    vlSelf->wasmetal_core__DOT___012427_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057134_))))));
    vlSelf->wasmetal_core__DOT___064527_ = (1U & (0x40000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h55e24ebb__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048330_)))))));
    vlSelf->wasmetal_core__DOT___011765_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h55e24ebb__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010084_))))));
    vlSelf->wasmetal_core__DOT___056686_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xf4f40000ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h55e24ebb__0)) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeeeULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h2d927cdc__0)))))))))));
    vlSelf->wasmetal_core__DOT___011176_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                   ? 
                                                  (0xfef0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xfff00000eeeeULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011207_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011206_))))))
                                                   : 
                                                  (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h55e24ebb__0)))));
    vlSelf->wasmetal_core__DOT___057334_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xbU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h77b6db08__0)))))))));
    vlSelf->wasmetal_core__DOT___057306_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xbU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h77b6db08__0)))))));
    vlSelf->wasmetal_core__DOT___012687_ = (1U & (0xf40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h77b6db08__0)))));
    vlSelf->wasmetal_core__DOT___010904_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hef0b5c34__0))))));
    vlSelf->wasmetal_core__DOT___010081_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hef0b5c34__0)))));
    vlSelf->wasmetal_core__DOT___057399_ = (1U & (0xeU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xfff00000eeee0000ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011770_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010395_)))));
    vlSelf->wasmetal_core__DOT___056703_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xfffcff0055550000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & ((IData)(
                                                                          (0xfff00000eeeeULL 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011772_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011771_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011770_)))))))));
}
