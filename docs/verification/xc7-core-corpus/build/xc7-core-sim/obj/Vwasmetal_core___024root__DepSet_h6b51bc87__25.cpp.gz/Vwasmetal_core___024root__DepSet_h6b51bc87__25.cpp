#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__23(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__23\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006670_;
    wasmetal_core__DOT___006670_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006674_;
    wasmetal_core__DOT___006674_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006705_;
    wasmetal_core__DOT___006705_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006716_;
    wasmetal_core__DOT___006716_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006735_;
    wasmetal_core__DOT___006735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013745_;
    wasmetal_core__DOT___013745_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013753_;
    wasmetal_core__DOT___013753_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013755_;
    wasmetal_core__DOT___013755_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013762_;
    wasmetal_core__DOT___013762_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013789_;
    wasmetal_core__DOT___013789_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013790_;
    wasmetal_core__DOT___013790_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013799_;
    wasmetal_core__DOT___013799_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013800_;
    wasmetal_core__DOT___013800_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013806_;
    wasmetal_core__DOT___013806_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013807_;
    wasmetal_core__DOT___013807_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013815_;
    wasmetal_core__DOT___013815_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013848_;
    wasmetal_core__DOT___013848_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013849_;
    wasmetal_core__DOT___013849_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013854_;
    wasmetal_core__DOT___013854_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013855_;
    wasmetal_core__DOT___013855_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013860_;
    wasmetal_core__DOT___013860_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013861_;
    wasmetal_core__DOT___013861_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013866_;
    wasmetal_core__DOT___013866_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013867_;
    wasmetal_core__DOT___013867_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013877_;
    wasmetal_core__DOT___013877_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013878_;
    wasmetal_core__DOT___013878_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013883_;
    wasmetal_core__DOT___013883_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013884_;
    wasmetal_core__DOT___013884_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013889_;
    wasmetal_core__DOT___013889_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013890_;
    wasmetal_core__DOT___013890_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013901_;
    wasmetal_core__DOT___013901_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013919_;
    wasmetal_core__DOT___013919_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013925_;
    wasmetal_core__DOT___013925_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013926_;
    wasmetal_core__DOT___013926_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013931_;
    wasmetal_core__DOT___013931_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013932_;
    wasmetal_core__DOT___013932_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013937_;
    wasmetal_core__DOT___013937_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013938_;
    wasmetal_core__DOT___013938_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013949_;
    wasmetal_core__DOT___013949_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013950_;
    wasmetal_core__DOT___013950_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013955_;
    wasmetal_core__DOT___013955_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013956_;
    wasmetal_core__DOT___013956_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013961_;
    wasmetal_core__DOT___013961_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013962_;
    wasmetal_core__DOT___013962_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013967_;
    wasmetal_core__DOT___013967_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013968_;
    wasmetal_core__DOT___013968_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013978_;
    wasmetal_core__DOT___013978_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013979_;
    wasmetal_core__DOT___013979_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013984_;
    wasmetal_core__DOT___013984_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013985_;
    wasmetal_core__DOT___013985_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013990_;
    wasmetal_core__DOT___013990_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013991_;
    wasmetal_core__DOT___013991_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016471_;
    wasmetal_core__DOT___016471_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017915_;
    wasmetal_core__DOT___017915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017925_;
    wasmetal_core__DOT___017925_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018349_;
    wasmetal_core__DOT___018349_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022550_;
    wasmetal_core__DOT___022550_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023421_;
    wasmetal_core__DOT___023421_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023710_;
    wasmetal_core__DOT___023710_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023775_;
    wasmetal_core__DOT___023775_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023776_;
    wasmetal_core__DOT___023776_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023777_;
    wasmetal_core__DOT___023777_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023778_;
    wasmetal_core__DOT___023778_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026644_;
    wasmetal_core__DOT___026644_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026779_;
    wasmetal_core__DOT___026779_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026914_;
    wasmetal_core__DOT___026914_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027114_;
    wasmetal_core__DOT___027114_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027435_;
    wasmetal_core__DOT___027435_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030198_;
    wasmetal_core__DOT___030198_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033456_;
    wasmetal_core__DOT___033456_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034397_;
    wasmetal_core__DOT___034397_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034558_;
    wasmetal_core__DOT___034558_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036430_;
    wasmetal_core__DOT___036430_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043050_;
    wasmetal_core__DOT___043050_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043058_;
    wasmetal_core__DOT___043058_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043064_;
    wasmetal_core__DOT___043064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___046654_;
    wasmetal_core__DOT___046654_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050101_;
    wasmetal_core__DOT___050101_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050103_;
    wasmetal_core__DOT___050103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050110_;
    wasmetal_core__DOT___050110_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050119_;
    wasmetal_core__DOT___050119_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050120_;
    wasmetal_core__DOT___050120_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050159_;
    wasmetal_core__DOT___050159_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050160_;
    wasmetal_core__DOT___050160_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050161_;
    wasmetal_core__DOT___050161_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057749_;
    wasmetal_core__DOT___057749_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057753_;
    wasmetal_core__DOT___057753_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057764_;
    wasmetal_core__DOT___057764_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057765_;
    wasmetal_core__DOT___057765_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057768_;
    wasmetal_core__DOT___057768_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058219_;
    wasmetal_core__DOT___058219_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058798_;
    wasmetal_core__DOT___058798_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058885_;
    wasmetal_core__DOT___058885_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058887_;
    wasmetal_core__DOT___058887_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058888_;
    wasmetal_core__DOT___058888_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059077_;
    wasmetal_core__DOT___059077_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127555___O;
    wasmetal_core__DOT____Vcellout___127555___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127555___CO;
    wasmetal_core__DOT____Vcellout___127555___CO = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127572___O;
    wasmetal_core__DOT____Vcellout___127572___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127572___CO;
    wasmetal_core__DOT____Vcellout___127572___CO = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127963___O;
    wasmetal_core__DOT____Vcellout___127963___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127977___O;
    wasmetal_core__DOT____Vcellout___127977___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127431___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127431___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127431___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127431___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127431___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127431___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127555___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127555___DOT__CO__BRA__2__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___127555___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127555___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127572___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127572___DOT__CO__BRA__2__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___127572___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127572___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127586___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127586___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127586___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127586___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127586___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127586___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127604___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127604___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127604___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127604___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127620___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127620___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127620___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127620___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127880___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127880___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127880___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127880___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127880___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127880___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127895___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127895___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127897___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127897___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127897___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127897___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127897___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127897___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127912___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127912___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127914___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127914___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127914___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127914___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127914___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127914___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127929___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127929___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127931___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127931___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127931___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127931___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127931___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127931___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127947___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127947___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127947___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127947___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127948___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127948___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127948___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127948___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127948___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127948___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128242___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128242___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128242___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128242___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128242___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128242___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128544___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128544___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128544___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128544___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128645___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128645___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128645___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128645___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128645___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128645___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128660___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128660___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128660___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128660___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128661___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128661___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128661___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128661___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128661___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128661___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128864___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128864___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128864___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128864___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128864___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128864___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135430___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135430___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135430___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___135430___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135430___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___135430___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135431___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135431___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135431___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___135431___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135432___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135432___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135432___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___135432___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135432___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___135432___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hdd7f22ed__0;
    __VdfgTmp_hdd7f22ed__0 = 0;
    CData/*1:0*/ __VdfgTmp_hde068c37__0;
    __VdfgTmp_hde068c37__0 = 0;
    CData/*1:0*/ __VdfgTmp_h12f11d8e__0;
    __VdfgTmp_h12f11d8e__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2a48d0b8__0;
    __VdfgTmp_h2a48d0b8__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd5198b33__0;
    __VdfgTmp_hd5198b33__0 = 0;
    CData/*3:0*/ __VdfgTmp_h1d05a5f0__0;
    __VdfgTmp_h1d05a5f0__0 = 0;
    CData/*3:0*/ __VdfgTmp_h888c419a__0;
    __VdfgTmp_h888c419a__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4f0a13d1__0;
    __VdfgTmp_h4f0a13d1__0 = 0;
    CData/*5:0*/ __VdfgTmp_hadd1132f__0;
    __VdfgTmp_hadd1132f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5fca0975__0;
    __VdfgTmp_h5fca0975__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbd290b9b__0;
    __VdfgTmp_hbd290b9b__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc00fbc95__0;
    __VdfgTmp_hc00fbc95__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1d85aab9__0;
    __VdfgTmp_h1d85aab9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h18f38a33__0;
    __VdfgTmp_h18f38a33__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf5ed4ddb__0;
    __VdfgTmp_hf5ed4ddb__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf52f9344__0;
    __VdfgTmp_hf52f9344__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___070749_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054410_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070747_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)))))))))));
    vlSelf->wasmetal_core__DOT___070748_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070747_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054410_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d)))))))));
    wasmetal_core__DOT___127929___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027173_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d));
    vlSelf->wasmetal_core__DOT___070847_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054403_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070845_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)))))))))));
    vlSelf->wasmetal_core__DOT___070846_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070845_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054403_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___070852_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054409_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070850_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)))))))))));
    vlSelf->wasmetal_core__DOT___070851_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070850_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054409_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d)))))))));
    wasmetal_core__DOT___127912___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026973_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d));
    wasmetal_core__DOT___127895___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hb948b455__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d));
    vlSelf->wasmetal_core__DOT___030262_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135429___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))))));
    vlSelf->wasmetal_core__DOT___030261_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135429___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))))));
    vlSelf->wasmetal_core__DOT___030260_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135429___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))))));
    vlSelf->wasmetal_core__DOT___030259_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135429___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))))));
    wasmetal_core__DOT___135430___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___046645_));
    vlSelf->wasmetal_core__DOT___128659___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034492_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034549_));
    wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030257_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d));
    wasmetal_core__DOT____Vcellout___127977___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027431_)))));
    wasmetal_core__DOT___027435_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                     >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063308_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063310_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063312_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063314_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128355___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128443___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027371_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027305_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b44__05d));
    wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022486_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___043064_ = (1U & (0x90U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017834_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017831_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017832_)))));
    wasmetal_core__DOT___043058_ = (1U & (IData)((0xff40ffff4040ff40ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057769_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070587_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017831_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017834_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017832_)))))))));
    __VdfgTmp_h5fca0975__0 = ((((IData)(vlSelf->wasmetal_core__DOT___017834_) 
                                & ((IData)(vlSelf->wasmetal_core__DOT___017833_) 
                                   & (IData)((0x9009000000009009ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___017832_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017831_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017830_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h103cd5d4__0))))))))) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017811_) 
                                          << 1U) | 
                                         ((IData)(vlSelf->wasmetal_core__DOT___017863_) 
                                          & ((IData)(
                                                     (0x9009000000000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___059072_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___059071_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057923_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h2b8ef9eb__0))))))) 
                                             & (IData)(
                                                       (0x8000000000000000ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___017861_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017860_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017859_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017858_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hb36cd122__0)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127633___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024026_)))));
    vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023767_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127617___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023899_)))));
    vlSelf->wasmetal_core__DOT___023903_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d) {
        vlSelf->wasmetal_core__DOT___024030_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d;
        vlSelf->wasmetal_core__DOT___127603___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024030_ = vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127603___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023903_;
    }
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b37__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058498_))));
    wasmetal_core__DOT___016471_ = (1U & (IData)((0xe00000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058535_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058534_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058533_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058432_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058434_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058470_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b5__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058432_))));
    wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0))) 
                 & (9U >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0))));
    __VdfgTmp_h4f0a13d1__0 = ((2U & ((IData)((0x1000000000000000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___058542_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058541_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058540_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xcc0dULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___051562_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058477_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016486_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058480_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016487_)))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h99986d68__0)) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_ha19857b4__0)))))))))) 
                                     << 1U)) | (1U 
                                                & (0xeee00000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___058538_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058484_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058485_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h32c10bb5__0)))))));
    wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034328_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128542___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011478_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033451_)))));
    wasmetal_core__DOT___033456_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___011478_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005921_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013701_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127878___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026704_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026703_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026702_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026701_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026635_)))));
    vlSelf->wasmetal_core__DOT___026639_ = ((IData)(vlSelf->wasmetal_core__DOT___026704_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d));
    vlSelf->wasmetal_core__DOT___045234_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070743_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054402_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___045210_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070744_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054406_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x24U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054402_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070743_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U))))))))))))));
    vlSelf->wasmetal_core__DOT___045235_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070748_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054408_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___045211_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070749_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054412_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x27U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054408_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070748_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127929___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027174_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027173_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027172_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027171_)))) 
           ^ (((IData)(wasmetal_core__DOT___127929___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027105_)))));
    vlSelf->wasmetal_core__DOT___027109_ = ((IData)(vlSelf->wasmetal_core__DOT___027174_)
                                             ? (IData)(wasmetal_core__DOT___127929___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d));
    vlSelf->wasmetal_core__DOT___044962_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054401_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___044938_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054405_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x24U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054401_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070846_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U))))))))))))));
    vlSelf->wasmetal_core__DOT___044963_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070851_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054407_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___044939_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070852_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054411_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x27U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054407_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070851_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127912___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026974_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026973_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026972_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026971_)))) 
           ^ (((IData)(wasmetal_core__DOT___127912___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026905_)))));
    vlSelf->wasmetal_core__DOT___026909_ = ((IData)(vlSelf->wasmetal_core__DOT___026974_)
                                             ? (IData)(wasmetal_core__DOT___127912___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127895___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h2b7d2fec__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_hb948b455__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5dede88d__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8c7509c5__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127895___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026770_)))));
    vlSelf->wasmetal_core__DOT___026774_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2b7d2fec__0)))
                                             ? (IData)(wasmetal_core__DOT___127895___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d));
    wasmetal_core__DOT___135430___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)) 
           & (IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034493_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128659___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128240___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030258_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030257_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030256_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030255_)))) 
           ^ (((IData)(wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030189_)))));
    vlSelf->wasmetal_core__DOT___030194_ = ((IData)(vlSelf->wasmetal_core__DOT___030258_)
                                             ? (IData)(wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d));
    __VdfgTmp_hbd290b9b__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                     << 1U)) | (1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d)))));
    vlSelf->__VdfgTmp_h06766dbc__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d)))));
    wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
           & (IData)(wasmetal_core__DOT___027435_));
    wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027372_)
            ? (IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b45__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127429___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022487_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022486_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022484_)))) 
           ^ (((IData)(wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022541_)))));
    vlSelf->wasmetal_core__DOT___022545_ = ((IData)(vlSelf->wasmetal_core__DOT___022487_) 
                                            & (IData)(wasmetal_core__DOT___127429___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___043050_ = ((IData)(wasmetal_core__DOT___043064_)
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___043063_)
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___043062_)
                                             ? ((1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb36cd122__0)))
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___043060_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___017861_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017860_)
                                                    ? 
                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043059_)) 
                                                    & (IData)(vlSelf->wasmetal_core__DOT___043051_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___043052_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___043053_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___043054_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043055_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___043056_))
                                         : (IData)(vlSelf->wasmetal_core__DOT___043057_))
                                     : (IData)(wasmetal_core__DOT___043058_));
    __VdfgTmp_hadd1132f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017815_) 
                               << 5U) | ((0x10U & (
                                                   (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                   << 4U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___017813_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h5fca0975__0))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d) {
        vlSelf->wasmetal_core__DOT___127619___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d;
        wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127619___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024030_;
        wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127603___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023768_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d));
    vlSelf->__VdfgTmp_h7be661a5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005948_));
    vlSelf->__VdfgTmp_h6202353f__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005809_));
    vlSelf->__VdfgTmp_hd2dd278c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005882_));
    vlSelf->__VdfgTmp_hdd48e33a__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005802_));
    vlSelf->wasmetal_core__DOT___128862___DOT__CO__BRA__2__KET__ 
        = ((9U >> (IData)(vlSelf->__VdfgTmp_ha5a16447__0)) 
           & (IData)(wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___017947_ = (1U & ((1U 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016474_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                             >> 1U)))))
                                                   ? (IData)(
                                                             (0x7fff0000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((0x4fU 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016496_) 
                                                                   << 4U) 
                                                                  | (((IData)(wasmetal_core__DOT___016471_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016472_) 
                                                                         << 2U) 
                                                                        | (IData)(__VdfgTmp_h4f0a13d1__0)))))))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (1U 
                                                    & (0x4fU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))));
    vlSelf->wasmetal_core__DOT___017946_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016474_)
                                                   ? 
                                                  ((~ 
                                                    (0x4fU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))) 
                                                   & (IData)(
                                                             (0x7fffffff00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016473_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016472_) 
                                                                   << 4U) 
                                                                  | (((IData)(wasmetal_core__DOT___016471_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & (((0x8000ffffU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058434_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058501_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058500_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058435_)))))) 
                                                                             & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016483_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016482_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016481_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40ff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058543_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058436_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058439_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058506_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058508_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058459_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058466_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058463_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058511_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058510_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058509_))))))))))))) 
                                                                            << 2U)) 
                                                                        | (IData)(__VdfgTmp_h4f0a13d1__0))))))))
                                                   : 
                                                  (~ 
                                                   (0x4fU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128643___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034329_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034328_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034326_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034325_)))) 
           ^ (((IData)(wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034388_)))));
    vlSelf->wasmetal_core__DOT___034393_ = ((IData)(vlSelf->wasmetal_core__DOT___034329_) 
                                            & (IData)(wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___011738_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff55550f0f3333ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d)) 
           & (IData)(wasmetal_core__DOT___033456_));
    vlSelf->wasmetal_core__DOT____Vcellout___127554___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005738_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005875_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023484_)))));
    vlSelf->wasmetal_core__DOT___023488_ = ((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127571___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013722_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9b9779ca__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023605_)))));
    vlSelf->wasmetal_core__DOT___023609_ = ((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___071313_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071312_))));
    vlSelf->wasmetal_core__DOT___071308_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071307_))));
    vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026705_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026639_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d));
    vlSelf->wasmetal_core__DOT___054420_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054414_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054416_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054418_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027175_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027109_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d));
    vlSelf->wasmetal_core__DOT___054419_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054413_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054415_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054417_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026975_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026909_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d));
    vlSelf->wasmetal_core__DOT___045866_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha17b8b2d__0))))));
    vlSelf->wasmetal_core__DOT___045890_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004684_)))))))));
    vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hd06fbc0c__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026774_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d));
    wasmetal_core__DOT___135430___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)) 
           & (IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034494_) 
           & (IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030259_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030194_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d));
    vlSelf->wasmetal_core__DOT___044849_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___127977___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(__VdfgTmp_hbd290b9b__0)))))))))));
    vlSelf->wasmetal_core__DOT___044873_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(__VdfgTmp_hbd290b9b__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127977___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d))))))));
    wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027373_)
            ? (IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b46__05d));
    vlSelf->__VdfgTmp_hde33bda2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_hde955cd8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O)));
    vlSelf->wasmetal_core__DOT___023190_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022484_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O))))));
    __VdfgTmp_hdd7f22ed__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___023188_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022486_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                                            >> 2U))))));
    __VdfgTmp_hde068c37__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                               >> 3U)));
    vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022488_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022545_));
    wasmetal_core__DOT___017915_ = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043035_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059072_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___043050_))))));
    vlSelf->wasmetal_core__DOT___018081_ = ((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                            & (IData)(
                                                      (0xffffff80ffff0000ULL 
                                                       >> (IData)(__VdfgTmp_hadd1132f__0))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d) {
        wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d;
        wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d;
    } else {
        wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127619___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127599___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023769_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023768_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023767_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023766_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023702_)))));
    vlSelf->wasmetal_core__DOT___023706_ = ((IData)(vlSelf->wasmetal_core__DOT___023769_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d));
    vlSelf->wasmetal_core__DOT___058886_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7be661a5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d))));
    vlSelf->wasmetal_core__DOT___023773_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7be661a5__0))));
    vlSelf->wasmetal_core__DOT___023772_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6202353f__0))));
    vlSelf->wasmetal_core__DOT___058867_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd2dd278c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d))));
    vlSelf->wasmetal_core__DOT___058797_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127633___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd2dd278c__0))))));
    vlSelf->wasmetal_core__DOT___023771_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2dd278c__0))));
    vlSelf->wasmetal_core__DOT___058790_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127633___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdd48e33a__0))))));
    vlSelf->wasmetal_core__DOT___023770_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd48e33a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128862___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                   << 3U)) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_ha5a16447__0)) 
                                     << 2U)) | ((2U 
                                                 & ((9U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128862___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128862___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0))) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___036426_ = ((9U >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128862___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___060243_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017945_)))));
    vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034330_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034393_));
    wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)) 
           & (IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___050162_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049002_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                                            >> 1U))))));
    wasmetal_core__DOT___050119_ = (1U & (0xbb0bU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___050105_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                               << 3U) 
                                              | ((4U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                        >> 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___006015_)))))));
    __VdfgTmp_hd5198b33__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->__VdfgTmp_h8c84070d__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    vlSelf->wasmetal_core__DOT___127555___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005935_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023488_));
    wasmetal_core__DOT___013815_ = (1U & (0x45cfcfU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___002187_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002190_)))))));
    vlSelf->wasmetal_core__DOT___013824_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000148_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000144_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000143_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000147_) 
                                                                     << 2U) 
                                                                    | (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___013821_ = (1U & ((1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O))
                                                   ? (IData)(
                                                             (0xe0e0e0e0eULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___002187_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___002190_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002469_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002468_))))))))
                                                   : 
                                                  (0x1fU 
                                                   >> 
                                                   ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002187_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002190_))))));
    vlSelf->wasmetal_core__DOT___013754_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000142_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000146_)))));
    vlSelf->wasmetal_core__DOT___013760_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048791_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048788_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000143_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000147_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___013812_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002470_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002471_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000144_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000148_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___127572___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013694_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023609_));
    vlSelf->wasmetal_core__DOT___071314_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071313_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___071309_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071308_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026706_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d));
    vlSelf->wasmetal_core__DOT___070752_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054418_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x29U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027176_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d));
    vlSelf->wasmetal_core__DOT___070855_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054417_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x29U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026976_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d));
    vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h375e931a__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___135430___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046645_)))));
    vlSelf->wasmetal_core__DOT___046650_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)) 
                                            & (IData)(wasmetal_core__DOT___135430___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128659___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034495_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034494_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034493_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034492_)))) 
           ^ (((IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128659___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034549_)))));
    vlSelf->wasmetal_core__DOT___034554_ = ((IData)(vlSelf->wasmetal_core__DOT___034495_) 
                                            & (IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030260_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d));
    wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127946___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027374_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027373_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027372_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027371_)))) 
           ^ (((IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027305_)))));
    vlSelf->wasmetal_core__DOT___027309_ = ((IData)(vlSelf->wasmetal_core__DOT___027374_)
                                             ? (IData)(wasmetal_core__DOT___127946___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b47__05d));
    vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022489_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___017925_ = (1U & ((1U & (4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___005711_))))
                                           ? (1U >> 
                                              (1U & 
                                               (8U 
                                                >> (IData)(vlSelf->__VdfgTmp_hff203b22__0))))
                                           : ((1U & 
                                               (0xf800U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043035_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___043050_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___059072_))))))
                                               ? (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017813_)))
                                               : (IData)(
                                                         (0x7f00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017813_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___017915_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h5fca0975__0)))))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d) {
        wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d;
        vlSelf->wasmetal_core__DOT___023908_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d;
    } else {
        wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023908_ = wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023770_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023706_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d));
    vlSelf->__VdfgTmp_h9bd72b18__0 = (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128862___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->__VdfgTmp_h647a213f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128862___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->__VdfgTmp_h632fa2db__0 = (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128862___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->__VdfgTmp_h8e80d283__0 = (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128862___O) 
                                                         >> 2U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036426_));
    vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034331_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d)) 
           & (IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___050120_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050104_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050115_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050114_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050102_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___006058_))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(__VdfgTmp_hd5198b33__0)))))))))));
    vlSelf->wasmetal_core__DOT___050106_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hd5198b33__0)))));
    vlSelf->wasmetal_core__DOT___006736_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c84070d__0)))));
    vlSelf->wasmetal_core__DOT___127555___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005716_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127555___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013733_ = (1U & ((0x1f000000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___057763_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057762_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048789_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___048792_)))))) 
                                                  & ((IData)(
                                                             (0x111511151115333fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048790_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048787_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000142_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000146_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                                               >> 2U)) 
                                                                           | (1U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O))))))))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___013815_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013814_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013813_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013763_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013812_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013760_)))))))))));
    vlSelf->wasmetal_core__DOT___013743_ = (1U & (0xd0000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013812_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057761_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xb0bbU 
                                                              >> 
                                                              ((8U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___002635_))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb00ae252__0))))));
    vlSelf->wasmetal_core__DOT___127572___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013668_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127572___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___045032_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071314_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___045008_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071314_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054211_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054213_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071312_))))));
    vlSelf->wasmetal_core__DOT___045031_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071309_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___045007_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071309_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054205_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                   << 1U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054207_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071307_))))));
    vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026708_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d));
    vlSelf->wasmetal_core__DOT___070754_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054416_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070752_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)))))))))));
    vlSelf->wasmetal_core__DOT___070753_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070752_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054416_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027178_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d));
    vlSelf->wasmetal_core__DOT___070857_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054415_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)))))))))));
    vlSelf->wasmetal_core__DOT___070856_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070855_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054415_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026978_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d));
    vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h379ad787__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d));
    vlSelf->wasmetal_core__DOT___030267_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135430___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))))));
    vlSelf->wasmetal_core__DOT___030266_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135430___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))))));
    vlSelf->wasmetal_core__DOT___030264_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135430___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))))));
    vlSelf->wasmetal_core__DOT___030263_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135430___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))))));
    vlSelf->wasmetal_core__DOT___135431___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001327_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___046650_));
    vlSelf->wasmetal_core__DOT___128660___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034496_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034554_));
    vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030261_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127962___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
           ^ (((IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027435_)))));
    vlSelf->wasmetal_core__DOT___027440_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127945___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127962___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063316_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063318_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063320_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063322_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128356___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128444___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___127947___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027375_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027309_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b48__05d));
    vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022490_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___060212_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((~ (IData)(vlSelf->wasmetal_core__DOT___017185_)) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___018857_)
                                                             ? (IData)(
                                                                       (0xefffffff2000a000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                                          << 5U) 
                                                                         | ((0x10U 
                                                                             & ((IData)(
                                                                                (0x7f0000ffffULL 
                                                                                >> (IData)(__VdfgTmp_hadd1132f__0))) 
                                                                                << 4U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___017925_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005711_))))))))
                                                             : 
                                                            (0xeU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))))));
    wasmetal_core__DOT___059077_ = (1U & (IData)((0x3222bfff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___017925_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___018081_)))))))));
    vlSelf->__VdfgTmp_h2082f5a2__0 = ((8U & ((IData)(
                                                     (0x7f0000ffffULL 
                                                      >> (IData)(__VdfgTmp_hadd1132f__0))) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                          << 2U) | 
                                         (((IData)(wasmetal_core__DOT___017925_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017924_))));
    wasmetal_core__DOT___018349_ = (1U & (0x40U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0x7f0000ffffULL 
                                                         >> (IData)(__VdfgTmp_hadd1132f__0))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___017925_)))));
    vlSelf->wasmetal_core__DOT___018082_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___017925_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127619___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127619___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127619___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024030_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d) {
        vlSelf->wasmetal_core__DOT___024035_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d;
        vlSelf->wasmetal_core__DOT___127604___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024035_ = wasmetal_core__DOT___127619___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127604___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023908_;
    }
    vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023771_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127603___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127603___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127603___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127603___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023903_)))));
    vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034332_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128543___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033456_)))));
    vlSelf->wasmetal_core__DOT___033460_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)) 
                                            & (IData)(wasmetal_core__DOT___128543___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___050109_ = (1U & (0xd0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050106_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050105_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006672_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___006661_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050121_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___050120_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___050119_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___006736_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050092_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4f1b49a4__0)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050093_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___006676_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006675_))))))))))));
    wasmetal_core__DOT___127555___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005928_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127555___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___023546_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048727_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn)))));
    wasmetal_core__DOT___127572___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013670_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127572___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127879___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026709_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026708_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026706_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026705_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026639_)))));
    wasmetal_core__DOT___026644_ = ((IData)(vlSelf->wasmetal_core__DOT___026709_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127879___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d));
    vlSelf->wasmetal_core__DOT___045236_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070753_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054414_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___045212_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070754_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054418_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x29U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054414_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070753_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 4U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127930___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027179_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027178_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027176_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027175_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027109_)))));
    wasmetal_core__DOT___027114_ = ((IData)(vlSelf->wasmetal_core__DOT___027179_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127930___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d));
    vlSelf->wasmetal_core__DOT___044964_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070856_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054413_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___044940_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070857_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054417_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x29U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054413_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070856_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 4U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127913___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026979_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026978_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026976_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026975_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026909_)))));
    wasmetal_core__DOT___026914_ = ((IData)(vlSelf->wasmetal_core__DOT___026979_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127913___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127896___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hbf523586__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h379ad787__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h375e931a__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd06fbc0c__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026774_)))));
    wasmetal_core__DOT___026779_ = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hbf523586__0)))
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127896___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d));
    wasmetal_core__DOT___135431___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000980_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135431___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128660___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034497_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128660___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128241___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030262_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030261_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030260_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030259_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030194_)))));
    wasmetal_core__DOT___030198_ = ((IData)(vlSelf->wasmetal_core__DOT___030262_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128241___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d));
    vlSelf->wasmetal_core__DOT___044850_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127962___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127962___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h06766dbc__0)))))))))));
    vlSelf->wasmetal_core__DOT___044874_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h06766dbc__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127962___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d))))))));
    vlSelf->__VdfgTmp_h4257ff1b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127962___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d)))));
    vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027440_));
    wasmetal_core__DOT___127947___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027376_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127947___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b49__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127430___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022491_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022490_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022489_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022488_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022545_)))));
    wasmetal_core__DOT___022550_ = ((IData)(vlSelf->wasmetal_core__DOT___022491_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127430___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___059925_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059923_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059917_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                : 
                                                                               (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3222bfff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017816_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___017925_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018081_)))))))))))))))));
    vlSelf->__VdfgTmp_h3f27e0dd__0 = (((IData)(wasmetal_core__DOT___018349_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018081_)));
    vlSelf->__VdfgTmp_h2b45c525__0 = (((IData)(wasmetal_core__DOT___018349_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018081_)));
    vlSelf->wasmetal_core__DOT___059220_ = (1U & (IData)(
                                                         (0x11fff0ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059210_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017174_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbb0b0bU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                              << 3U) 
                                                                             | (((IData)(wasmetal_core__DOT___018349_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017185_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___059077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xbeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                                 ? (IData)(
                                                                                (0xffff30f08aaa0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                                 : 
                                                                                (0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017175_)))))))));
    vlSelf->__VdfgTmp_h3c24edc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018080_)));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d) {
        vlSelf->wasmetal_core__DOT___127620___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d;
        wasmetal_core__DOT___127604___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127620___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024035_;
        wasmetal_core__DOT___127604___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127604___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023772_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d));
    vlSelf->__VdfgTmp_h6b40bfd0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006058_));
    vlSelf->__VdfgTmp_h85736cb0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006044_));
    vlSelf->__VdfgTmp_hde857550__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006029_));
    vlSelf->__VdfgTmp_h5220a2be__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006051_));
    vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__2__KET__ 
        = ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h45a50d9d__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128644___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034333_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034332_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034331_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034330_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034393_)))));
    wasmetal_core__DOT___034397_ = ((IData)(vlSelf->wasmetal_core__DOT___034333_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___057498_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d)))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                                >> 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d))))))))))));
    vlSelf->wasmetal_core__DOT___057319_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d))))))))))));
    vlSelf->wasmetal_core__DOT___128544___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033460_));
    vlSelf->wasmetal_core__DOT___023425_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)))));
    wasmetal_core__DOT___127555___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___127555___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127555___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127555___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___127572___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___127572___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127572___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127572___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___071318_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071317_))));
    wasmetal_core__DOT___127880___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026710_)
            ? (IData)(wasmetal_core__DOT___026644_)
            : (IData)(vlSelf->wasmetal_core__DOT___001327_));
    vlSelf->wasmetal_core__DOT___054426_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127930___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054422_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127930___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054428_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127930___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054424_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127930___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127931___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027180_)
            ? (IData)(wasmetal_core__DOT___027114_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d));
    vlSelf->wasmetal_core__DOT___054425_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127913___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054421_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127913___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054427_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127913___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054423_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127913___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127914___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026980_)
            ? (IData)(wasmetal_core__DOT___026914_)
            : (IData)(vlSelf->wasmetal_core__DOT___001327_));
    vlSelf->wasmetal_core__DOT___045867_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h73e9a4a1__0)))))));
    vlSelf->wasmetal_core__DOT___045891_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004018_)))))))));
    wasmetal_core__DOT___127897___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hc67fdbf4__0)))
            ? (IData)(wasmetal_core__DOT___026779_)
            : (IData)(vlSelf->wasmetal_core__DOT___001327_));
    wasmetal_core__DOT___135431___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000992_)) 
           & (IData)(wasmetal_core__DOT___135431___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128660___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034498_) 
           & (IData)(wasmetal_core__DOT___128660___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128242___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030263_)
            ? (IData)(wasmetal_core__DOT___030198_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d));
    vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127947___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027378_)
            ? (IData)(wasmetal_core__DOT___127947___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b50__05d));
    vlSelf->__VdfgTmp_hd9cc8b65__0 = (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                                       >> 3U))));
    vlSelf->__VdfgTmp_h18c745e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                                    >> 1U)));
    vlSelf->wasmetal_core__DOT___023185_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022489_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___023183_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022491_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                                            >> 3U))))));
    __VdfgTmp_h18f38a33__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O)));
    __VdfgTmp_h1d85aab9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                               >> 2U)));
    wasmetal_core__DOT___127431___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022492_) 
           & (IData)(wasmetal_core__DOT___022550_));
    vlSelf->wasmetal_core__DOT___059580_ = (1U & ((4U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                  & (IData)(
                                                            (0x5f3ff00003333ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___017927_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3f27e0dd__0))))))));
    vlSelf->wasmetal_core__DOT___018686_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059752_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3f1b0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013705_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018082_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfffa0c00ffffccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017927_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013705_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3f27e0dd__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___059949_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059942_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3f1b0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018082_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfffa0c00ffffccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017927_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3f27e0dd__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___018443_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059610_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x3f1b0000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___018080_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018082_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((4U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                             & (IData)(
                                                                                (0x5f3ff00003333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017927_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3f27e0dd__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___059631_ = (1U & ((4U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                  & (IData)(
                                                            (0x5f3ff00003333ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___017927_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3f27e0dd__0))))))));
    vlSelf->wasmetal_core__DOT___059652_ = (1U & ((4U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                  & (IData)(
                                                            (0x5f3ff00003333ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___017927_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013654_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3f27e0dd__0))))))));
    vlSelf->wasmetal_core__DOT___059978_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059973_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x2220a2aaaaaaaaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  & (IData)(
                                                                            (0x3337f3ff0000ffffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))))))))));
    vlSelf->wasmetal_core__DOT___060007_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060000_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x2220a2aaaaaaaaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  & (IData)(
                                                                            (0x3337f3ff0000ffffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))))))))));
    vlSelf->wasmetal_core__DOT___060037_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060032_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x2220a2aaaaaaaaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  & (IData)(
                                                                            (0x3337f3ff0000ffffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))))))))));
    vlSelf->wasmetal_core__DOT___060061_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060056_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x2220a2aaaaaaaaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  & (IData)(
                                                                            (0x3337f3ff0000ffffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))))))))));
    vlSelf->wasmetal_core__DOT___060086_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060081_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x2220a2aaaaaaaaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  & (IData)(
                                                                            (0x3337f3ff0000ffffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))))))))));
    vlSelf->wasmetal_core__DOT___060133_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060128_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x2220a2aaaaaaaaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  & (IData)(
                                                                            (0x3337f3ff0000ffffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))))))))));
    vlSelf->wasmetal_core__DOT___059705_ = (1U & (0xdU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xfcfaf0f000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003809_))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h607e9020__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127472___O))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                      ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                      : 
                                                                     (1U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))
                                                               ? 
                                                              (8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___003809_)))
                                                               : (IData)(
                                                                         (0xffff0000ff755755ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019194_))))));
    vlSelf->wasmetal_core__DOT___059731_ = (1U & (0xdU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xfcfaf0f000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003810_))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127472___O) 
                                                                                >> 1U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                      ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                      : 
                                                                     (1U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))
                                                               ? 
                                                              (8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___003810_)))
                                                               : (IData)(
                                                                         (0xffff0000ff755755ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019194_))))));
    vlSelf->wasmetal_core__DOT___059783_ = (1U & (0xdU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xfcfaf0f000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006400_))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127472___O) 
                                                                                >> 3U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                      ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0xeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                      : 
                                                                     (1U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))
                                                               ? 
                                                              (8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___006400_)))
                                                               : (IData)(
                                                                         (0xffff0000ff755755ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((0xeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019194_))))));
    vlSelf->wasmetal_core__DOT___059811_ = (1U & (0xdU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xfcfaf0f000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003807_))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h57318413__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127473___O))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((1U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT___017927_)
                                                                      ? (IData)(
                                                                                (0xcf0f7555ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2082f5a2__0)))))
                                                                      : 
                                                                     (1U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017924_))))))
                                                               ? 
                                                              (8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___003807_)))
                                                               : (IData)(
                                                                         (0xffff0000ff755755ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c24edc0__0))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019194_))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d) {
        wasmetal_core__DOT___127620___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d;
        wasmetal_core__DOT___127604___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d;
    } else {
        wasmetal_core__DOT___127620___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127620___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127604___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127604___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127600___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023773_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023772_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023771_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023770_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023706_)))));
    wasmetal_core__DOT___023710_ = ((IData)(vlSelf->wasmetal_core__DOT___023773_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127600___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d));
    vlSelf->wasmetal_core__DOT___058760_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127619___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6b40bfd0__0))))));
    wasmetal_core__DOT___023778_ = (1U & (0xe1U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h6b40bfd0__0))));
    vlSelf->wasmetal_core__DOT___058892_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h85736cb0__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d))));
    wasmetal_core__DOT___023777_ = (1U & (0xe1U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h85736cb0__0))));
    wasmetal_core__DOT___058885_ = (1U & (8U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hde857550__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d))));
    wasmetal_core__DOT___023776_ = (1U & (0xe1U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_hde857550__0))));
    wasmetal_core__DOT___023775_ = (1U & (0xe1U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h5220a2be__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128863___O 
        = (((8U & ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h459e7eca__0)) 
                   << 3U)) | ((4U & ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h45a50d9d__0)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b5__05d) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036426_)))));
    wasmetal_core__DOT___036430_ = ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h459e7eca__0)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128863___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128645___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034334_) 
           & (IData)(wasmetal_core__DOT___034397_));
    wasmetal_core__DOT___128544___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128544___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127555___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___005731_) 
           & (IData)(wasmetal_core__DOT___127555___DOT__CO__BRA__2__KET__)) 
          << 3U) | (IData)(wasmetal_core__DOT___127555___DOT____VdfgTmp_h3cda4b7d__0));
    wasmetal_core__DOT____Vcellout___127555___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___005935_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127555___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___023488_)));
    wasmetal_core__DOT____Vcellout___127572___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___013672_) 
           & (IData)(wasmetal_core__DOT___127572___DOT__CO__BRA__2__KET__)) 
          << 3U) | (IData)(wasmetal_core__DOT___127572___DOT____VdfgTmp_h3cda4b7d__0));
    wasmetal_core__DOT____Vcellout___127572___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h009053fc__0))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127572___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___023609_)));
    vlSelf->wasmetal_core__DOT___071319_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d)))))))));
    wasmetal_core__DOT___127880___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026711_)
            ? (IData)(wasmetal_core__DOT___127880___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000980_));
    vlSelf->wasmetal_core__DOT___070757_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054424_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2cU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b49__05d)))))));
    wasmetal_core__DOT___127931___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027181_)
            ? (IData)(wasmetal_core__DOT___127931___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d));
    vlSelf->wasmetal_core__DOT___070860_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054423_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2cU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b49__05d)))))));
    wasmetal_core__DOT___127914___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026981_)
            ? (IData)(wasmetal_core__DOT___127914___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000980_));
    wasmetal_core__DOT___127897___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_heb331328__0)))
            ? (IData)(wasmetal_core__DOT___127897___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000980_));
    vlSelf->wasmetal_core__DOT____Vcellout___135431___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001014_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000992_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___000980_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001327_)))))) 
           ^ (((IData)(wasmetal_core__DOT___135431___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___135431___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___135431___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046650_)))));
    wasmetal_core__DOT___046654_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001014_)) 
                                    & (IData)(wasmetal_core__DOT___135431___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128660___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034499_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034498_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034497_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034496_)))) 
           ^ (((IData)(wasmetal_core__DOT___128660___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128660___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128660___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034554_)))));
    wasmetal_core__DOT___034558_ = ((IData)(vlSelf->wasmetal_core__DOT___034499_) 
                                    & (IData)(wasmetal_core__DOT___128660___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128242___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030264_)
            ? (IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d));
    vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127947___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027379_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027378_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027376_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027375_)))) 
           ^ (((IData)(wasmetal_core__DOT___127947___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127947___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127947___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027309_)))));
    vlSelf->wasmetal_core__DOT___027314_ = ((IData)(vlSelf->wasmetal_core__DOT___027379_)
                                             ? (IData)(wasmetal_core__DOT___127947___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b51__05d));
    vlSelf->__VdfgTmp_h5a8057b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h18f38a33__0)));
    vlSelf->__VdfgTmp_he5d5d55b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h18f38a33__0)))));
    vlSelf->__VdfgTmp_h7136f53f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h1d85aab9__0)));
    vlSelf->__VdfgTmp_h2c009b21__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h1d85aab9__0)))));
    if (vlSelf->wasmetal_core__DOT___005715_) {
        vlSelf->wasmetal_core__DOT___023192_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04d557bc__0))));
        vlSelf->wasmetal_core__DOT___023189_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_hdd7f22ed__0))))))));
        vlSelf->wasmetal_core__DOT___023187_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_hde068c37__0))))))));
        vlSelf->wasmetal_core__DOT___023186_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_he5d5d55b__0))));
        vlSelf->wasmetal_core__DOT___023184_ = (1U 
                                                & (IData)(
                                                          (0xf0c0f0d1f0c05555ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2c009b21__0))));
    } else {
        vlSelf->wasmetal_core__DOT___023192_ = (1U 
                                                & (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf628d2c5__0)));
        vlSelf->wasmetal_core__DOT___023189_ = (1U 
                                                & (0xfcfdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hdd7f22ed__0)))));
        vlSelf->wasmetal_core__DOT___023187_ = (1U 
                                                & (0xfcfdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hde068c37__0)))));
        vlSelf->wasmetal_core__DOT___023186_ = (1U 
                                                & (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5a8057b5__0)));
        vlSelf->wasmetal_core__DOT___023184_ = (1U 
                                                & (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7136f53f__0)));
    }
    wasmetal_core__DOT___127431___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022493_) 
           & (IData)(wasmetal_core__DOT___127431___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d) {
        wasmetal_core__DOT___127620___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d;
        vlSelf->wasmetal_core__DOT___023912_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d;
    } else {
        wasmetal_core__DOT___127620___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127620___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023912_ = wasmetal_core__DOT___127604___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___058893_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058886_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058885_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h263b1cf5__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6202353f__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)))))))));
    wasmetal_core__DOT___127586___DOT__CO__BRA__0__KET__ 
        = ((IData)(wasmetal_core__DOT___023775_) ? (IData)(wasmetal_core__DOT___023710_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d));
    vlSelf->__VdfgTmp_hcdadba0d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058430_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128863___O)))));
    vlSelf->__VdfgTmp_hd5e7a9c4__0 = ((8U & ((0x10U 
                                              >> (IData)(vlSelf->__VdfgTmp_h45a50d9d__0)) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128863___O) 
                                                 >> 2U)))));
    vlSelf->__VdfgTmp_hd560ff4d__0 = ((8U & ((0x10U 
                                              >> (IData)(vlSelf->__VdfgTmp_h459e7eca__0)) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128863___O) 
                                                 >> 3U)))));
    wasmetal_core__DOT___128864___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b8__05d) 
           & (IData)(wasmetal_core__DOT___036430_));
    wasmetal_core__DOT___128645___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034335_) 
           & (IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128544___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d)) 
           & (IData)(wasmetal_core__DOT___128544___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___006674_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006683_)) 
                                          & ((~ ((IData)(wasmetal_core__DOT____Vcellout___127555___CO) 
                                                 >> 3U)) 
                                             & (IData)(
                                                       (0xb0bb0000b0bbb0bbULL 
                                                        >> 
                                                        ((0x20U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127560___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                             << 4U) 
                                                            | ((8U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127560___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h90f032b2__0))))))))));
    wasmetal_core__DOT___050103_ = (1U & (0xdU >> (
                                                   (4U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127555___CO) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                            >> 1U))))));
    wasmetal_core__DOT___050159_ = (1U & (0xd00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___050106_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___127555___CO) 
                                                >> 1U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127555___O) 
                                                       >> 1U)))))));
    wasmetal_core__DOT___006670_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127555___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005935_))));
    wasmetal_core__DOT___006716_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127555___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h8c84070d__0))))))));
    wasmetal_core__DOT___006735_ = (1U & (0xb0bbU >> 
                                          ((8U & (IData)(wasmetal_core__DOT____Vcellout___127555___O)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                               << 2U) 
                                              | ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___127555___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005716_))))));
    __VdfgTmp_h2a48d0b8__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127555___O) 
                                     >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    wasmetal_core__DOT___057768_ = (1U & (0xd00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___013761_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___127572___CO) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hb00ae252__0)))));
    wasmetal_core__DOT___057749_ = (1U & (0xdU >> (
                                                   (4U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127572___CO) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013795_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O))))));
    wasmetal_core__DOT___057764_ = (1U & (0xdU >> (
                                                   (4U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127572___CO) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                            >> 2U))))));
    wasmetal_core__DOT___013901_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127572___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127572___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013694_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___013690_)))))))));
    wasmetal_core__DOT___013762_ = (1U & (0x45cfcfU 
                                          >> ((0x10U 
                                               & ((IData)(wasmetal_core__DOT____Vcellout___127572___O) 
                                                  << 1U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___001796_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001800_)))))));
    wasmetal_core__DOT___013753_ = (1U & (0xe0U >> 
                                          ((4U & ((IData)(wasmetal_core__DOT____Vcellout___127572___O) 
                                                  >> 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___001796_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001800_)))));
    wasmetal_core__DOT___013755_ = (1U & (0xe0U >> 
                                          ((4U & ((IData)(wasmetal_core__DOT____Vcellout___127572___O) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___001798_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001802_)))));
    vlSelf->wasmetal_core__DOT___045033_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071319_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___045009_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071319_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054217_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054219_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071317_))))));
    wasmetal_core__DOT___127880___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026712_)
            ? (IData)(wasmetal_core__DOT___127880___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000992_));
    vlSelf->wasmetal_core__DOT___070759_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054422_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070757_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2bU)))))))))));
    vlSelf->wasmetal_core__DOT___070758_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070757_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054422_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2bU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d)))))))));
    wasmetal_core__DOT___127931___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027182_)
            ? (IData)(wasmetal_core__DOT___127931___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d));
    vlSelf->wasmetal_core__DOT___070862_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054421_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070860_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2bU)))))))))));
    vlSelf->wasmetal_core__DOT___070861_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070860_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054421_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2bU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d)))))))));
    wasmetal_core__DOT___127914___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026982_)
            ? (IData)(wasmetal_core__DOT___127914___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000992_));
    wasmetal_core__DOT___127897___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_ha541df85__0)))
            ? (IData)(wasmetal_core__DOT___127897___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000992_));
    vlSelf->wasmetal_core__DOT___030271_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135431___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001014_))))));
    vlSelf->wasmetal_core__DOT___030270_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135431___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000992_))))));
    vlSelf->wasmetal_core__DOT___030269_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135431___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000980_))))));
    vlSelf->wasmetal_core__DOT___030268_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135431___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001327_))))));
    wasmetal_core__DOT___135432___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001036_)) 
           & (IData)(wasmetal_core__DOT___046654_));
    wasmetal_core__DOT___128661___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034500_) 
           & (IData)(wasmetal_core__DOT___034558_));
    wasmetal_core__DOT___128242___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030266_)
            ? (IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d));
    wasmetal_core__DOT____Vcellout___127963___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027440_)))));
    vlSelf->wasmetal_core__DOT___027444_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127946___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127963___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063324_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127947___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128357___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128445___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063326_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127947___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128357___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128445___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063328_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127947___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128357___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128445___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063330_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127947___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128357___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128445___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    wasmetal_core__DOT___127948___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027380_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027314_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b52__05d));
    wasmetal_core__DOT___127431___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022494_) 
           & (IData)(wasmetal_core__DOT___127431___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127620___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127620___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127620___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127620___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024035_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d) {
        vlSelf->wasmetal_core__DOT___024039_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d;
        vlSelf->wasmetal_core__DOT___127605___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024039_ = wasmetal_core__DOT___127620___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127605___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023912_;
    }
    wasmetal_core__DOT___127586___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___023776_) ? (IData)(wasmetal_core__DOT___127586___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127604___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127604___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127604___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127604___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023908_)))));
    wasmetal_core__DOT___128864___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b9__05d) 
           & (IData)(wasmetal_core__DOT___128864___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128645___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034336_) 
           & (IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128544___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128544___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128544___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128544___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033460_)))));
    vlSelf->wasmetal_core__DOT___033465_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d)) 
                                            & (IData)(wasmetal_core__DOT___128544___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___050110_ = (1U & (IData)((0x8acf000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050104_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___050103_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006178_))))))));
    __VdfgTmp_h12f11d8e__0 = ((2U & ((4U >> ((2U & 
                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127564___O) 
                                               << 1U)) 
                                             | (IData)(vlSelf->wasmetal_core__DOT___003805_))) 
                                     << 1U)) | (IData)(wasmetal_core__DOT___006670_));
    wasmetal_core__DOT___006705_ = ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O))
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                        & (IData)(wasmetal_core__DOT___006716_))
                                     : (IData)(wasmetal_core__DOT___006716_));
    vlSelf->wasmetal_core__DOT___006694_ = (1U & ((IData)(
                                                          (0xb0bb0000b0bbb0bbULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127560___O)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hfb6e9604__0))))))) 
                                                  & (IData)(
                                                            (0x1000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006737_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006736_) 
                                                                  << 4U) 
                                                                 | (((IData)(wasmetal_core__DOT___006735_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006734_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((4U 
                                                                               >> 
                                                                               ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127562___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006099_))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4f1b49a4__0))))))))))));
    vlSelf->wasmetal_core__DOT___006652_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006704_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___006735_) 
                                                          << 1U) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___006676_) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___006675_) 
                                                               & (IData)(
                                                                         (0x1000000000000ULL 
                                                                          >> 
                                                                          (((IData)(wasmetal_core__DOT___006674_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006673_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006672_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd5a5809b__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(wasmetal_core__DOT___006670_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(__VdfgTmp_h2a48d0b8__0)))))))))))))))));
    wasmetal_core__DOT___050101_ = (1U & (0xb0bbU >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127554___O) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h2a48d0b8__0)))));
    wasmetal_core__DOT___057765_ = (1U & (IData)((0x8acf000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057757_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___057764_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014037_)))))))));
    vlSelf->wasmetal_core__DOT___013744_ = (1U & ((IData)(
                                                          (0x111511151115333fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___002470_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___002471_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000142_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000146_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                                            >> 2U)) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O) 
                                                                              >> 3U))))))))) 
                                                  & ((0x1f00U 
                                                      >> 
                                                      ((((IData)(vlSelf->wasmetal_core__DOT___013776_) 
                                                         & (IData)(
                                                                   (0x8acf000000000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___013775_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013774_) 
                                                                         << 4U) 
                                                                        | ((0xcU 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hed5eddc9__0))))))) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___127572___O)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001797_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___001801_))))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___013764_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013763_) 
                                                                     << 4U) 
                                                                    | (((IData)(wasmetal_core__DOT___013762_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013761_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013760_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013756_)))))))))));
    wasmetal_core__DOT___057753_ = (1U & (IData)((0xd00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057749_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057748_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057747_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___013755_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O) 
                                                                     >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___013741_ = ((IData)(vlSelf->wasmetal_core__DOT___013756_) 
                                            & ((~ (IData)(wasmetal_core__DOT___013755_)) 
                                               & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013754_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___013753_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127570___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013654_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013705_))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127880___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026713_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026712_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026711_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026710_)))) 
           ^ (((IData)(wasmetal_core__DOT___127880___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127880___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127880___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026644_)))));
    vlSelf->wasmetal_core__DOT___026648_ = ((IData)(vlSelf->wasmetal_core__DOT___026713_)
                                             ? (IData)(wasmetal_core__DOT___127880___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001014_));
    vlSelf->wasmetal_core__DOT___045237_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070758_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054420_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2aU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___045213_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070759_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054424_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b49__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2cU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054420_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070758_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2aU))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127931___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027183_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027182_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027181_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027180_)))) 
           ^ (((IData)(wasmetal_core__DOT___127931___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127931___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127931___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027114_)))));
    vlSelf->wasmetal_core__DOT___027118_ = ((IData)(vlSelf->wasmetal_core__DOT___027183_)
                                             ? (IData)(wasmetal_core__DOT___127931___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d));
    vlSelf->wasmetal_core__DOT___044965_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070861_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054419_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2aU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___044941_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070862_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054423_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b49__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2cU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054419_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070861_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2aU))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127914___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026983_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026982_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026981_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026980_)))) 
           ^ (((IData)(wasmetal_core__DOT___127914___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127914___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127914___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026914_)))));
    vlSelf->wasmetal_core__DOT___026918_ = ((IData)(vlSelf->wasmetal_core__DOT___026983_)
                                             ? (IData)(wasmetal_core__DOT___127914___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001014_));
    vlSelf->wasmetal_core__DOT____Vcellout___127897___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026848_) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_ha541df85__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_heb331328__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc67fdbf4__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127897___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127897___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127897___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026779_)))));
    vlSelf->wasmetal_core__DOT___026783_ = ((IData)(vlSelf->wasmetal_core__DOT___026848_)
                                             ? (IData)(wasmetal_core__DOT___127897___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001014_));
    wasmetal_core__DOT___135432___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001058_)) 
           & (IData)(wasmetal_core__DOT___135432___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128661___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034501_) 
           & (IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128242___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030267_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030266_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030264_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030263_)))) 
           ^ (((IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030198_)))));
    vlSelf->wasmetal_core__DOT___030203_ = ((IData)(vlSelf->wasmetal_core__DOT___030267_)
                                             ? (IData)(wasmetal_core__DOT___128242___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d));
    vlSelf->wasmetal_core__DOT___044851_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127962___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127963___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4257ff1b__0)))))))))));
    vlSelf->wasmetal_core__DOT___044875_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4257ff1b__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127963___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127962___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d)))))))));
    __VdfgTmp_hc00fbc95__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127963___O)) 
                              | (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d)))));
    vlSelf->wasmetal_core__DOT___127964___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127947___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027444_));
    wasmetal_core__DOT___127948___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027381_)
            ? (IData)(wasmetal_core__DOT___127948___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b53__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127431___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022495_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022494_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022493_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022492_)))) 
           ^ (((IData)(wasmetal_core__DOT___127431___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127431___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127431___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___022550_)))));
    vlSelf->wasmetal_core__DOT___022554_ = ((IData)(vlSelf->wasmetal_core__DOT___022495_) 
                                            & (IData)(wasmetal_core__DOT___127431___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d) {
        vlSelf->wasmetal_core__DOT___127621___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d;
        vlSelf->wasmetal_core__DOT___127605___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127621___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024039_;
        vlSelf->wasmetal_core__DOT___127605___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127605___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127586___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___023777_) ? (IData)(wasmetal_core__DOT___127586___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d));
    vlSelf->__VdfgTmp_had5b18f3__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006274_));
    vlSelf->__VdfgTmp_h2b50f7e1__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006226_));
    vlSelf->__VdfgTmp_hfc74bd0d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006151_));
    vlSelf->__VdfgTmp_h61354930__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006178_));
    wasmetal_core__DOT___128864___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b10__05d) 
           & (IData)(wasmetal_core__DOT___128864___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128645___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034337_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034336_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034335_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034334_)))) 
           ^ (((IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034397_)))));
    vlSelf->wasmetal_core__DOT___034401_ = ((IData)(vlSelf->wasmetal_core__DOT___034337_) 
                                            & (IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128545___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033465_));
    vlSelf->wasmetal_core__DOT___006662_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050111_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___050110_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050109_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050095_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006736_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006676_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x8acf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006737_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050102_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006274_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h276936c0__0)))))))))));
    wasmetal_core__DOT___050160_ = (1U & (0xd0000U 
                                          >> (((IData)(wasmetal_core__DOT___006705_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___050094_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050098_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                             >> 1U))))))));
    vlSelf->wasmetal_core__DOT___006692_ = (1U & ((0xb0bbU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127552___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127560___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___005795_))))) 
                                                  & (IData)(
                                                            (0x1000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006707_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006706_) 
                                                                  << 4U) 
                                                                 | (((IData)(wasmetal_core__DOT___006705_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006704_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((4U 
                                                                               >> 
                                                                               ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003806_))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h27384d82__0))))))))))));
    wasmetal_core__DOT___058219_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___006695_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006694_))));
    vlSelf->wasmetal_core__DOT___023426_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)))));
    wasmetal_core__DOT___050161_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006734_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___050101_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___050100_)))));
    vlSelf->wasmetal_core__DOT___006693_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___050101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050100_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h276936c0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050098_)))))));
    vlSelf->wasmetal_core__DOT___013734_ = (1U & ((0x45cfcfU 
                                                   >> 
                                                   ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127571___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000142_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___000146_)))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013826_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013825_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013824_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0x1f000000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___057763_) 
                                                                              << 4U) 
                                                                             | (((IData)(wasmetal_core__DOT___057765_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002029_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002033_)))))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013822_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___013821_))))))))));
    vlSelf->wasmetal_core__DOT___023544_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048725_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013744_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___023567_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048725_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013744_)))));
    vlSelf->wasmetal_core__DOT___013735_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013822_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057753_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8acf000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013763_) 
                                                                                << 5U) 
                                                                                | (((IData)(wasmetal_core__DOT___013762_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002634_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(wasmetal_core__DOT____Vcellout___127572___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013670_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127572___O) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___013694_))))))))))));
    if (vlSelf->wasmetal_core__DOT___013743_) {
        vlSelf->wasmetal_core__DOT___014039_ = (1U 
                                                & (0x5333U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014037_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___013780_))))));
        wasmetal_core__DOT___013919_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013739_))))));
        wasmetal_core__DOT___013745_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h097d2f7b__0)))));
        wasmetal_core__DOT___013926_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013740_))))));
        wasmetal_core__DOT___013790_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013786_))))));
        wasmetal_core__DOT___013925_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013785_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013787_))))));
        wasmetal_core__DOT___013789_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h7faa2984__0)))));
        wasmetal_core__DOT___013932_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013788_))))));
        wasmetal_core__DOT___013800_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013796_))))));
        wasmetal_core__DOT___013931_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013795_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013797_))))));
        wasmetal_core__DOT___013799_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h81ac2e72__0)))));
        wasmetal_core__DOT___013938_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013798_))))));
        wasmetal_core__DOT___013807_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013771_))))));
        wasmetal_core__DOT___013937_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013770_))))));
        wasmetal_core__DOT___013806_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h0d220f7a__0)))));
        wasmetal_core__DOT___013950_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___002635_))))));
        wasmetal_core__DOT___013849_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___002632_))))));
        wasmetal_core__DOT___013949_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___002631_))))));
        wasmetal_core__DOT___013848_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h0ed8cd5e__0)))));
        wasmetal_core__DOT___013956_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___002633_))))));
        wasmetal_core__DOT___013855_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___002630_))))));
        wasmetal_core__DOT___013955_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___002629_))))));
        wasmetal_core__DOT___013854_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h80016717__0)))));
        wasmetal_core__DOT___013962_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___002473_))))));
        wasmetal_core__DOT___013861_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___002472_))))));
        wasmetal_core__DOT___013961_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___002193_))))));
        wasmetal_core__DOT___013860_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h62ff3be8__0)))));
        wasmetal_core__DOT___013968_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h13976eb2__0)))));
        wasmetal_core__DOT___013867_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013652_))))));
        wasmetal_core__DOT___013967_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((0xeU 
                                                             >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013635_))))));
        wasmetal_core__DOT___013866_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h0db23397__0)))));
        wasmetal_core__DOT___013979_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h3f696fc8__0)))));
        wasmetal_core__DOT___013878_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013692_))))));
        wasmetal_core__DOT___013978_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013712_))))));
        wasmetal_core__DOT___013877_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h41b1ef3d__0)))));
        wasmetal_core__DOT___013985_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h7d2fcfb3__0)))));
        wasmetal_core__DOT___013884_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013648_))))));
        wasmetal_core__DOT___013984_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013666_))))));
        wasmetal_core__DOT___013883_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h9b9779ca__0)))));
        wasmetal_core__DOT___013991_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hfe0efeb9__0)))));
        wasmetal_core__DOT___013890_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013701_))))));
        wasmetal_core__DOT___013990_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013694_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___013722_))))));
        wasmetal_core__DOT___013889_ = (1U & (0xacccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h009053fc__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___014039_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014037_)));
        wasmetal_core__DOT___013919_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013737_)));
        wasmetal_core__DOT___013745_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013740_)));
        wasmetal_core__DOT___013926_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013786_)));
        wasmetal_core__DOT___013790_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013787_)));
        wasmetal_core__DOT___013925_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013785_)));
        wasmetal_core__DOT___013789_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013788_)));
        wasmetal_core__DOT___013932_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013796_)));
        wasmetal_core__DOT___013800_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013797_)));
        wasmetal_core__DOT___013931_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013795_)));
        wasmetal_core__DOT___013799_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013798_)));
        wasmetal_core__DOT___013938_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013771_)));
        wasmetal_core__DOT___013807_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013770_)));
        wasmetal_core__DOT___013937_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013805_)));
        wasmetal_core__DOT___013806_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002635_)));
        wasmetal_core__DOT___013950_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002632_)));
        wasmetal_core__DOT___013849_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002631_)));
        wasmetal_core__DOT___013949_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002634_)));
        wasmetal_core__DOT___013848_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002633_)));
        wasmetal_core__DOT___013956_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002630_)));
        wasmetal_core__DOT___013855_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002629_)));
        wasmetal_core__DOT___013955_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002636_)));
        wasmetal_core__DOT___013854_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002473_)));
        wasmetal_core__DOT___013962_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002472_)));
        wasmetal_core__DOT___013861_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___002193_)));
        wasmetal_core__DOT___013961_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013687_)));
        wasmetal_core__DOT___013860_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013656_)));
        wasmetal_core__DOT___013968_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013652_)));
        wasmetal_core__DOT___013867_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013635_)));
        wasmetal_core__DOT___013967_ = (1U & (2U >> 
                                              (1U & 
                                               (0xeU 
                                                >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)))));
        wasmetal_core__DOT___013866_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013705_)));
        wasmetal_core__DOT___013979_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013692_)));
        wasmetal_core__DOT___013878_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013712_)));
        wasmetal_core__DOT___013978_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013690_)));
        wasmetal_core__DOT___013877_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013654_)));
        wasmetal_core__DOT___013985_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013648_)));
        wasmetal_core__DOT___013884_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013666_)));
        wasmetal_core__DOT___013984_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013658_)));
        wasmetal_core__DOT___013883_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013719_)));
        wasmetal_core__DOT___013991_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013701_)));
        wasmetal_core__DOT___013890_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013722_)));
        wasmetal_core__DOT___013990_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013694_)));
        wasmetal_core__DOT___013889_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013668_)));
    }
    __VdfgTmp_h1d05a5f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013918_))));
    vlSelf->wasmetal_core__DOT___013872_ = (1U & (IData)(
                                                         (0x40007fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013744_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013670_)))))))));
    __VdfgTmp_h888c419a__0 = (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_hf8096cfd__0)));
    vlSelf->__VdfgTmp_h895aa12b__0 = (((IData)(wasmetal_core__DOT___057768_) 
                                       << 3U) | (((
                                                   (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127581___O))
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                                    & (IData)(wasmetal_core__DOT___013901_))
                                                    : (IData)(wasmetal_core__DOT___013901_)) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((0x80U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___013812_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013821_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013760_)))) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013741_))));
    vlSelf->wasmetal_core__DOT___057830_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013741_)))));
    vlSelf->wasmetal_core__DOT___071323_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071322_))));
    vlSelf->wasmetal_core__DOT___127881___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026714_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026648_)
            : (IData)(vlSelf->wasmetal_core__DOT___001036_));
    vlSelf->wasmetal_core__DOT___054432_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127931___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054434_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127931___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054430_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127931___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054436_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127931___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127932___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027184_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027118_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d));
    vlSelf->wasmetal_core__DOT___054431_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127914___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054433_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127914___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054429_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127914___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054435_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127914___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127915___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026984_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026918_)
            : (IData)(vlSelf->wasmetal_core__DOT___001036_));
    vlSelf->wasmetal_core__DOT___045869_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h92d5757b__0)))))));
    vlSelf->wasmetal_core__DOT___045868_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7b969d91__0)))))));
    vlSelf->wasmetal_core__DOT___045893_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003360_)))))))));
    vlSelf->wasmetal_core__DOT___045892_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003876_)))))))));
    vlSelf->wasmetal_core__DOT___127898___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026849_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026783_)
            : (IData)(vlSelf->wasmetal_core__DOT___001036_));
    wasmetal_core__DOT___135432___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001080_)) 
           & (IData)(wasmetal_core__DOT___135432___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128661___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034502_) 
           & (IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128243___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030268_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030203_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d));
    vlSelf->wasmetal_core__DOT___044852_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127963___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127963___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(__VdfgTmp_hc00fbc95__0)))))))))));
    vlSelf->wasmetal_core__DOT___044876_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(__VdfgTmp_hc00fbc95__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127963___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d))))))));
    vlSelf->wasmetal_core__DOT___127964___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127947___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127964___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127948___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027382_)
            ? (IData)(wasmetal_core__DOT___127948___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b54__05d));
    vlSelf->__VdfgTmp_hf5f6fc6e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127431___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_hf53bec91__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127431___O)));
    vlSelf->wasmetal_core__DOT___023182_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022492_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127431___O))))));
    vlSelf->__VdfgTmp_h3b955ce1__0 = (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022495_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127431___O) 
                                                       >> 3U))));
    __VdfgTmp_hf52f9344__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127431___O) 
                                               >> 1U)));
    __VdfgTmp_hf5ed4ddb__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127431___O) 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT___127432___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022496_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022554_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d) {
        vlSelf->wasmetal_core__DOT___127621___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d;
        vlSelf->wasmetal_core__DOT___127605___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127621___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127621___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127605___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127605___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127586___O 
        = ((((IData)(wasmetal_core__DOT___023778_) 
             << 3U) | (((IData)(wasmetal_core__DOT___023777_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___023776_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___023775_)))) 
           ^ (((IData)(wasmetal_core__DOT___127586___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127586___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127586___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023710_)))));
    vlSelf->wasmetal_core__DOT___023715_ = ((IData)(wasmetal_core__DOT___023778_)
                                             ? (IData)(wasmetal_core__DOT___127586___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d));
    wasmetal_core__DOT___058888_ = (1U & (8U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_had5b18f3__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d))));
    vlSelf->wasmetal_core__DOT___023782_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_had5b18f3__0))));
    wasmetal_core__DOT___058798_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058790_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058789_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127619___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127620___O)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h2b50f7e1__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h85736cb0__0)))))))))));
    vlSelf->wasmetal_core__DOT___023781_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2b50f7e1__0))));
    wasmetal_core__DOT___058887_ = (1U & (8U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hfc74bd0d__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d))));
    vlSelf->wasmetal_core__DOT___023780_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfc74bd0d__0))));
    vlSelf->wasmetal_core__DOT___058911_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfc74bd0d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h61354930__0))))));
    vlSelf->wasmetal_core__DOT___058759_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127620___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h61354930__0))))));
    vlSelf->wasmetal_core__DOT___023779_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61354930__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128864___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b8__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128864___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128864___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128864___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036430_)))));
    vlSelf->wasmetal_core__DOT___036403_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128864___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128646___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034339_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034401_));
    vlSelf->wasmetal_core__DOT___128545___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128545___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h33619ff1__0 = (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006661_));
    vlSelf->wasmetal_core__DOT___023424_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)))));
    wasmetal_core__DOT___023421_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___058219_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___023444_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___058219_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005830_)))));
    vlSelf->wasmetal_core__DOT___006653_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050162_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___050161_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___050160_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___050159_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h12f11d8e__0))))))));
    vlSelf->wasmetal_core__DOT___013549_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___050160_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___050159_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050162_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(__VdfgTmp_h12f11d8e__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(wasmetal_core__DOT___050161_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)))))))));
    vlSelf->wasmetal_core__DOT___013449_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006274_))))));
    vlSelf->wasmetal_core__DOT___006768_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005903_))))));
    vlSelf->wasmetal_core__DOT___013452_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005823_))))));
    vlSelf->wasmetal_core__DOT___006774_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006151_))))));
    vlSelf->wasmetal_core__DOT___013458_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006178_))))));
    vlSelf->wasmetal_core__DOT___013351_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006058_))))));
    vlSelf->wasmetal_core__DOT___006783_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006044_))))));
    vlSelf->wasmetal_core__DOT___006780_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006029_))))));
    vlSelf->wasmetal_core__DOT___013401_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006051_))))));
    vlSelf->wasmetal_core__DOT___013357_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005948_))))));
    vlSelf->wasmetal_core__DOT___006789_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005809_))))));
    vlSelf->wasmetal_core__DOT___006786_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005882_))))));
    vlSelf->wasmetal_core__DOT___013365_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005802_))))));
    vlSelf->wasmetal_core__DOT___013333_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005955_))))));
    vlSelf->wasmetal_core__DOT___006795_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005788_))))));
    vlSelf->wasmetal_core__DOT___006792_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005889_))))));
    vlSelf->wasmetal_core__DOT___013371_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005795_))))));
    vlSelf->wasmetal_core__DOT___013270_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005711_))))));
    vlSelf->wasmetal_core__DOT___006801_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006215_))))));
    vlSelf->wasmetal_core__DOT___006798_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006144_))))));
    vlSelf->wasmetal_core__DOT___006985_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0c779906__0)))));
    vlSelf->wasmetal_core__DOT___006982_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005989_))))));
    vlSelf->wasmetal_core__DOT___006807_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006099_))))));
    vlSelf->wasmetal_core__DOT___006804_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006022_))))));
    vlSelf->wasmetal_core__DOT___006991_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006106_))))));
    vlSelf->wasmetal_core__DOT___006988_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005868_))))));
    vlSelf->wasmetal_core__DOT___006813_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005770_))))));
    vlSelf->wasmetal_core__DOT___006810_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005855_))))));
    vlSelf->wasmetal_core__DOT___006997_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h83434591__0)))));
    vlSelf->wasmetal_core__DOT___006994_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003805_))))));
    vlSelf->wasmetal_core__DOT___006701_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003808_))))));
    vlSelf->wasmetal_core__DOT___006698_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003811_))))));
    vlSelf->wasmetal_core__DOT___007003_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003807_))))));
    vlSelf->wasmetal_core__DOT___007000_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006400_))))));
    vlSelf->wasmetal_core__DOT___006751_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006204_))))));
    vlSelf->wasmetal_core__DOT___006748_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003810_))))));
    vlSelf->wasmetal_core__DOT___007015_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003809_))))));
    vlSelf->wasmetal_core__DOT___007012_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005982_))))));
    vlSelf->wasmetal_core__DOT___013309_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005716_))))));
    vlSelf->wasmetal_core__DOT___006656_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006695_)
                                                   ? (IData)(
                                                             (0xaaf0f0f0ccffffffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___006694_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                                      << 3U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h68317e95__0))))))
                                                   : 
                                                  (0xbfU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005928_))))));
    vlSelf->wasmetal_core__DOT___013241_ = (1U & (IData)(
                                                         (0x5333000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006695_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006694_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005928_)))))))));
    vlSelf->wasmetal_core__DOT___007004_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006695_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006694_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005731_)))))));
    vlSelf->wasmetal_core__DOT___006757_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006085_))))));
    vlSelf->wasmetal_core__DOT___006754_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006015_))))));
    vlSelf->wasmetal_core__DOT___007021_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006092_))))));
    vlSelf->wasmetal_core__DOT___007018_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005875_))))));
    vlSelf->wasmetal_core__DOT___006763_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005745_))))));
    vlSelf->wasmetal_core__DOT___006760_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005921_))))));
    vlSelf->wasmetal_core__DOT___007027_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005738_))))));
    vlSelf->wasmetal_core__DOT___007024_ = (1U & (0xacccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005935_))))));
    vlSelf->wasmetal_core__DOT___058220_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006692_))));
    vlSelf->wasmetal_core__DOT___014002_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013744_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he2ae9361__0))))))));
    vlSelf->wasmetal_core__DOT___014257_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013744_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013734_)))))))));
    vlSelf->wasmetal_core__DOT___023545_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048726_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn)))));
    vlSelf->__VdfgTmp_hfb436b73__0 = ((((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                        & (IData)((0x4000000000000000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013744_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_he2ae9361__0)))))))) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013735_));
    vlSelf->wasmetal_core__DOT___023547_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048713_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn)))));
    if (vlSelf->wasmetal_core__DOT___013744_) {
        vlSelf->wasmetal_core__DOT___014035_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014039_));
        if (vlSelf->wasmetal_core__DOT___013743_) {
            vlSelf->wasmetal_core__DOT___013916_ = 
                (1U & (0xacccU >> (IData)(__VdfgTmp_h1d05a5f0__0)));
            vlSelf->wasmetal_core__DOT___013732_ = 
                (1U & (0xacccU >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                    << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___013738_))))));
        } else {
            vlSelf->wasmetal_core__DOT___013916_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013738_)));
            vlSelf->wasmetal_core__DOT___013732_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013739_)));
        }
        vlSelf->wasmetal_core__DOT___014034_ = wasmetal_core__DOT___013919_;
        vlSelf->wasmetal_core__DOT___014111_ = wasmetal_core__DOT___013745_;
        vlSelf->wasmetal_core__DOT___013915_ = wasmetal_core__DOT___013926_;
        vlSelf->wasmetal_core__DOT___013731_ = wasmetal_core__DOT___013790_;
        vlSelf->wasmetal_core__DOT___014033_ = wasmetal_core__DOT___013925_;
        vlSelf->wasmetal_core__DOT___014110_ = wasmetal_core__DOT___013789_;
        vlSelf->wasmetal_core__DOT___013914_ = wasmetal_core__DOT___013932_;
        vlSelf->wasmetal_core__DOT___013730_ = wasmetal_core__DOT___013800_;
        vlSelf->wasmetal_core__DOT___014032_ = wasmetal_core__DOT___013931_;
        vlSelf->wasmetal_core__DOT___014109_ = wasmetal_core__DOT___013799_;
        vlSelf->wasmetal_core__DOT___013913_ = wasmetal_core__DOT___013938_;
        vlSelf->wasmetal_core__DOT___013729_ = wasmetal_core__DOT___013807_;
        vlSelf->wasmetal_core__DOT___014065_ = wasmetal_core__DOT___013937_;
        vlSelf->wasmetal_core__DOT___014135_ = wasmetal_core__DOT___013806_;
        vlSelf->wasmetal_core__DOT___013946_ = wasmetal_core__DOT___013950_;
        vlSelf->wasmetal_core__DOT___013845_ = wasmetal_core__DOT___013849_;
        vlSelf->wasmetal_core__DOT___014064_ = wasmetal_core__DOT___013949_;
        vlSelf->wasmetal_core__DOT___014134_ = wasmetal_core__DOT___013848_;
        vlSelf->wasmetal_core__DOT___013945_ = wasmetal_core__DOT___013956_;
        vlSelf->wasmetal_core__DOT___013844_ = wasmetal_core__DOT___013855_;
        vlSelf->wasmetal_core__DOT___014063_ = wasmetal_core__DOT___013955_;
        vlSelf->wasmetal_core__DOT___014133_ = wasmetal_core__DOT___013854_;
        vlSelf->wasmetal_core__DOT___013944_ = wasmetal_core__DOT___013962_;
        vlSelf->wasmetal_core__DOT___013843_ = wasmetal_core__DOT___013861_;
        vlSelf->wasmetal_core__DOT___014062_ = wasmetal_core__DOT___013961_;
        vlSelf->wasmetal_core__DOT___014132_ = wasmetal_core__DOT___013860_;
        vlSelf->wasmetal_core__DOT___013943_ = wasmetal_core__DOT___013968_;
        vlSelf->wasmetal_core__DOT___013842_ = wasmetal_core__DOT___013867_;
        vlSelf->wasmetal_core__DOT___014001_ = wasmetal_core__DOT___013967_;
        vlSelf->wasmetal_core__DOT___014165_ = wasmetal_core__DOT___013866_;
        vlSelf->wasmetal_core__DOT___013976_ = wasmetal_core__DOT___013979_;
        vlSelf->wasmetal_core__DOT___013875_ = wasmetal_core__DOT___013878_;
        vlSelf->wasmetal_core__DOT___014000_ = wasmetal_core__DOT___013978_;
        vlSelf->wasmetal_core__DOT___014164_ = wasmetal_core__DOT___013877_;
        vlSelf->wasmetal_core__DOT___013975_ = wasmetal_core__DOT___013985_;
        vlSelf->wasmetal_core__DOT___013874_ = wasmetal_core__DOT___013884_;
        vlSelf->wasmetal_core__DOT___013999_ = wasmetal_core__DOT___013984_;
        vlSelf->wasmetal_core__DOT___014163_ = wasmetal_core__DOT___013883_;
        vlSelf->wasmetal_core__DOT___013974_ = wasmetal_core__DOT___013991_;
        vlSelf->wasmetal_core__DOT___013873_ = wasmetal_core__DOT___013890_;
        vlSelf->wasmetal_core__DOT___014162_ = (1U 
                                                & (IData)(wasmetal_core__DOT___013889_));
        vlSelf->wasmetal_core__DOT___013998_ = (1U 
                                                & (IData)(wasmetal_core__DOT___013990_));
        vlSelf->wasmetal_core__DOT___013973_ = (1U 
                                                & (0xacccccccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                     << 4U) 
                                                    | (IData)(__VdfgTmp_h888c419a__0))));
    } else {
        if (vlSelf->wasmetal_core__DOT___013743_) {
            vlSelf->wasmetal_core__DOT___014035_ = 
                (1U & (0x5333U >> (IData)(__VdfgTmp_h1d05a5f0__0)));
            vlSelf->wasmetal_core__DOT___014162_ = 
                (1U & (0xacccU >> (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                    << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___013670_))))));
            vlSelf->wasmetal_core__DOT___013998_ = 
                (1U & (0xacccU >> (IData)(__VdfgTmp_h888c419a__0)));
        } else {
            vlSelf->wasmetal_core__DOT___014035_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___013738_)));
            vlSelf->wasmetal_core__DOT___014162_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013672_)));
            vlSelf->wasmetal_core__DOT___013998_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013670_)));
        }
        vlSelf->wasmetal_core__DOT___013916_ = (1U 
                                                & (IData)(wasmetal_core__DOT___013919_));
        vlSelf->wasmetal_core__DOT___013732_ = (1U 
                                                & (IData)(wasmetal_core__DOT___013745_));
        vlSelf->wasmetal_core__DOT___014034_ = wasmetal_core__DOT___013926_;
        vlSelf->wasmetal_core__DOT___014111_ = wasmetal_core__DOT___013790_;
        vlSelf->wasmetal_core__DOT___013915_ = wasmetal_core__DOT___013925_;
        vlSelf->wasmetal_core__DOT___013731_ = wasmetal_core__DOT___013789_;
        vlSelf->wasmetal_core__DOT___014033_ = wasmetal_core__DOT___013932_;
        vlSelf->wasmetal_core__DOT___014110_ = wasmetal_core__DOT___013800_;
        vlSelf->wasmetal_core__DOT___013914_ = wasmetal_core__DOT___013931_;
        vlSelf->wasmetal_core__DOT___013730_ = wasmetal_core__DOT___013799_;
        vlSelf->wasmetal_core__DOT___014032_ = wasmetal_core__DOT___013938_;
        vlSelf->wasmetal_core__DOT___014109_ = wasmetal_core__DOT___013807_;
        vlSelf->wasmetal_core__DOT___013913_ = wasmetal_core__DOT___013937_;
        vlSelf->wasmetal_core__DOT___013729_ = wasmetal_core__DOT___013806_;
        vlSelf->wasmetal_core__DOT___014065_ = wasmetal_core__DOT___013950_;
        vlSelf->wasmetal_core__DOT___014135_ = wasmetal_core__DOT___013849_;
        vlSelf->wasmetal_core__DOT___013946_ = wasmetal_core__DOT___013949_;
        vlSelf->wasmetal_core__DOT___013845_ = wasmetal_core__DOT___013848_;
        vlSelf->wasmetal_core__DOT___014064_ = wasmetal_core__DOT___013956_;
        vlSelf->wasmetal_core__DOT___014134_ = wasmetal_core__DOT___013855_;
        vlSelf->wasmetal_core__DOT___013945_ = wasmetal_core__DOT___013955_;
        vlSelf->wasmetal_core__DOT___013844_ = wasmetal_core__DOT___013854_;
        vlSelf->wasmetal_core__DOT___014063_ = wasmetal_core__DOT___013962_;
        vlSelf->wasmetal_core__DOT___014133_ = wasmetal_core__DOT___013861_;
        vlSelf->wasmetal_core__DOT___013944_ = wasmetal_core__DOT___013961_;
        vlSelf->wasmetal_core__DOT___013843_ = wasmetal_core__DOT___013860_;
        vlSelf->wasmetal_core__DOT___014062_ = wasmetal_core__DOT___013968_;
        vlSelf->wasmetal_core__DOT___014132_ = wasmetal_core__DOT___013867_;
        vlSelf->wasmetal_core__DOT___013943_ = wasmetal_core__DOT___013967_;
        vlSelf->wasmetal_core__DOT___013842_ = wasmetal_core__DOT___013866_;
        vlSelf->wasmetal_core__DOT___014001_ = wasmetal_core__DOT___013979_;
        vlSelf->wasmetal_core__DOT___014165_ = wasmetal_core__DOT___013878_;
        vlSelf->wasmetal_core__DOT___013976_ = wasmetal_core__DOT___013978_;
        vlSelf->wasmetal_core__DOT___013875_ = wasmetal_core__DOT___013877_;
        vlSelf->wasmetal_core__DOT___014000_ = wasmetal_core__DOT___013985_;
        vlSelf->wasmetal_core__DOT___014164_ = wasmetal_core__DOT___013884_;
        vlSelf->wasmetal_core__DOT___013975_ = wasmetal_core__DOT___013984_;
        vlSelf->wasmetal_core__DOT___013874_ = wasmetal_core__DOT___013883_;
        vlSelf->wasmetal_core__DOT___013999_ = wasmetal_core__DOT___013991_;
        vlSelf->wasmetal_core__DOT___014163_ = wasmetal_core__DOT___013890_;
        vlSelf->wasmetal_core__DOT___013974_ = wasmetal_core__DOT___013990_;
        vlSelf->wasmetal_core__DOT___013873_ = wasmetal_core__DOT___013889_;
        vlSelf->wasmetal_core__DOT___013973_ = (1U 
                                                & (0xbfffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___013672_))))));
    }
    vlSelf->wasmetal_core__DOT___057845_ = ((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___013872_));
    vlSelf->wasmetal_core__DOT___014330_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h895aa12b__0))));
    vlSelf->wasmetal_core__DOT___023542_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048718_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057830_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___023565_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057830_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048718_)))));
    vlSelf->wasmetal_core__DOT___071324_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071323_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___127881___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026715_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127881___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001058_));
    vlSelf->wasmetal_core__DOT___070762_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054430_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2fU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___070767_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054436_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x31U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___127932___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027185_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127932___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d));
    vlSelf->wasmetal_core__DOT___070865_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054429_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2fU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___070870_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054435_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x31U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___127915___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026985_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127915___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001058_));
    vlSelf->wasmetal_core__DOT___127898___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026850_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127898___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001058_));
    vlSelf->wasmetal_core__DOT____Vcellout___135432___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001102_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001080_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___001058_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001036_)))))) 
           ^ (((IData)(wasmetal_core__DOT___135432___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___135432___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___135432___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___046654_)))));
    vlSelf->wasmetal_core__DOT___046658_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001102_)) 
                                            & (IData)(wasmetal_core__DOT___135432___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128661___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034503_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034502_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034501_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034500_)))) 
           ^ (((IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034558_)))));
    vlSelf->wasmetal_core__DOT___034562_ = ((IData)(vlSelf->wasmetal_core__DOT___034503_) 
                                            & (IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128243___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030269_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128243___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d));
    vlSelf->wasmetal_core__DOT___127964___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127947___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127964___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127948___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027383_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027382_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027381_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027380_)))) 
           ^ (((IData)(wasmetal_core__DOT___127948___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127948___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127948___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027314_)))));
    vlSelf->wasmetal_core__DOT___027318_ = ((IData)(vlSelf->wasmetal_core__DOT___027383_)
                                             ? (IData)(wasmetal_core__DOT___127948___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b55__05d));
    vlSelf->wasmetal_core__DOT___050073_ = (1U & (0xa300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b955ce1__0))));
    vlSelf->__VdfgTmp_h397c5a04__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hf52f9344__0)));
    vlSelf->__VdfgTmp_hb31c73a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hf52f9344__0)))));
    vlSelf->__VdfgTmp_h399a9b9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hf5ed4ddb__0)));
    vlSelf->__VdfgTmp_h444b75da__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hf5ed4ddb__0)))));
    vlSelf->wasmetal_core__DOT___127432___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022497_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127432___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127621___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127621___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___058812_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058798_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058797_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058796_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127632___O)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a46858f__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5220a2be__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127619___O))))))))));
    vlSelf->wasmetal_core__DOT___058894_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058888_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058887_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h5220a2be__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6b40bfd0__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___127587___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023779_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023715_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d));
    vlSelf->__VdfgTmp_h9152e63a__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058447_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128864___O) 
                                                          >> 3U)))));
    vlSelf->__VdfgTmp_hdb61f435__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058443_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128864___O) 
                                                          >> 2U)))));
    vlSelf->__VdfgTmp_h5aa7dbd9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcb1f4515__0)) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128864___O)))));
    vlSelf->wasmetal_core__DOT___128865___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036403_));
    vlSelf->wasmetal_core__DOT___128646___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034340_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128646___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128545___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128545___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127549___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___023444_)) 
           & (IData)(wasmetal_core__DOT___023421_));
    vlSelf->__VdfgTmp_ha83a9342__0 = (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___006653_))));
    vlSelf->wasmetal_core__DOT___023427_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013549_))));
}
