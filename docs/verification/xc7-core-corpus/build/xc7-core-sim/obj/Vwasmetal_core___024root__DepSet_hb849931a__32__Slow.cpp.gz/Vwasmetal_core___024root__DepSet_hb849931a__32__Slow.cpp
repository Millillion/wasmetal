#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__50(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__50\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___017577_;
    wasmetal_core__DOT___017577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017805_;
    wasmetal_core__DOT___017805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022571_;
    wasmetal_core__DOT___022571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022575_;
    wasmetal_core__DOT___022575_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022579_;
    wasmetal_core__DOT___022579_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022584_;
    wasmetal_core__DOT___022584_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022592_;
    wasmetal_core__DOT___022592_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023314_;
    wasmetal_core__DOT___023314_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023318_;
    wasmetal_core__DOT___023318_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023322_;
    wasmetal_core__DOT___023322_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023327_;
    wasmetal_core__DOT___023327_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023331_;
    wasmetal_core__DOT___023331_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023336_;
    wasmetal_core__DOT___023336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023340_;
    wasmetal_core__DOT___023340_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023344_;
    wasmetal_core__DOT___023344_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023349_;
    wasmetal_core__DOT___023349_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023353_;
    wasmetal_core__DOT___023353_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023358_;
    wasmetal_core__DOT___023358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023364_;
    wasmetal_core__DOT___023364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036068_;
    wasmetal_core__DOT___036068_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036854_;
    wasmetal_core__DOT___036854_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036861_;
    wasmetal_core__DOT___036861_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036862_;
    wasmetal_core__DOT___036862_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036867_;
    wasmetal_core__DOT___036867_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036908_;
    wasmetal_core__DOT___036908_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036914_;
    wasmetal_core__DOT___036914_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036915_;
    wasmetal_core__DOT___036915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037013_;
    wasmetal_core__DOT___037013_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058165_;
    wasmetal_core__DOT___058165_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058936_;
    wasmetal_core__DOT___058936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058968_;
    wasmetal_core__DOT___058968_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058972_;
    wasmetal_core__DOT___058972_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058983_;
    wasmetal_core__DOT___058983_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059018_;
    wasmetal_core__DOT___059018_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059056_;
    wasmetal_core__DOT___059056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060497_;
    wasmetal_core__DOT___060497_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060511_;
    wasmetal_core__DOT___060511_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060525_;
    wasmetal_core__DOT___060525_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060597_;
    wasmetal_core__DOT___060597_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d;
    wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry;
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d;
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127444___O;
    wasmetal_core__DOT____Vcellout___127444___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127445___O;
    wasmetal_core__DOT____Vcellout___127445___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127446___O;
    wasmetal_core__DOT____Vcellout___127446___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127447___O;
    wasmetal_core__DOT____Vcellout___127447___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127448___O;
    wasmetal_core__DOT____Vcellout___127448___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127449___O;
    wasmetal_core__DOT____Vcellout___127449___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127536___O;
    wasmetal_core__DOT____Vcellout___127536___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127537___O;
    wasmetal_core__DOT____Vcellout___127537___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127538___O;
    wasmetal_core__DOT____Vcellout___127538___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127539___O;
    wasmetal_core__DOT____Vcellout___127539___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127542___O;
    wasmetal_core__DOT____Vcellout___127542___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127544___O;
    wasmetal_core__DOT____Vcellout___127544___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127546___O;
    wasmetal_core__DOT____Vcellout___127546___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127547___O;
    wasmetal_core__DOT____Vcellout___127547___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127548___O;
    wasmetal_core__DOT____Vcellout___127548___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134170___O;
    wasmetal_core__DOT____Vcellout___134170___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134171___O;
    wasmetal_core__DOT____Vcellout___134171___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134175___O;
    wasmetal_core__DOT____Vcellout___134175___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h4ac2372d__0;
    __VdfgTmp_h4ac2372d__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7a7f7b8b__0;
    __VdfgTmp_h7a7f7b8b__0 = 0;
    CData/*2:0*/ __VdfgTmp_hc2887b39__0;
    __VdfgTmp_hc2887b39__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0e008e26__0;
    __VdfgTmp_h0e008e26__0 = 0;
    CData/*4:0*/ __VdfgTmp_h3eda33ce__0;
    __VdfgTmp_h3eda33ce__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___058164_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058163_))));
    __VdfgTmp_hc2887b39__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h639f1e1d__0));
    vlSelf->wasmetal_core__DOT___058176_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h639f1e1d__0))));
    vlSelf->wasmetal_core__DOT___036073_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b12__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)) 
                                                                 ^ (IData)(vlSelf->wasmetal_core__DOT___036940_)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (~ 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___035703_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__2__KET__)
                                                                    : 
                                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___035703_)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128773___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035703_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035702_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035712_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035711_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035698_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127540___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d) 
             << 3U) | ((4U & ((4U >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023345_)))));
    wasmetal_core__DOT___023364_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127444___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022588_)))));
    wasmetal_core__DOT___022592_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hf715e513__0 = (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058175_));
    vlSelf->wasmetal_core__DOT___036072_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b11__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b10__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O) 
                                                      >> 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O) 
                                                        >> 2U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b9__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O) 
                                                        >> 1U))))))));
    vlSelf->wasmetal_core__DOT___036071_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b8__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O))))))));
    vlSelf->__VdfgTmp_h6ecbbe50__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O) 
                                               >> 2U)));
    vlSelf->__VdfgTmp_h7af47ace__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d));
    wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d) 
           & (IData)(wasmetal_core__DOT___023364_));
    vlSelf->wasmetal_core__DOT___058956_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___127444___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___058964_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___127444___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d)))));
    wasmetal_core__DOT___058968_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___127444___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d)))));
    wasmetal_core__DOT___058983_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___127444___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d)))));
    wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
           & (IData)(wasmetal_core__DOT___022592_));
    vlSelf->wasmetal_core__DOT___015429_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036072_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d))));
    wasmetal_core__DOT___058165_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___036071_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d))));
    wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___036071_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d));
    __VdfgTmp_h7a7f7b8b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036071_)));
    wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d) 
           & (IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
           & (IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___058155_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___036071_)))))));
    vlSelf->wasmetal_core__DOT___015427_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x1000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___058165_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036072_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058097_))));
    wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
           & (IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___016659_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___015569_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xf8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___017059_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___015521_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___015511_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___058156_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h7a7f7b8b__0)))));
    wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)) 
           & (IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
           & (IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___015434_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015427_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058098_)))));
    vlSelf->wasmetal_core__DOT___015204_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015427_))));
    wasmetal_core__DOT___036068_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036072_)) 
                                          | (IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128815___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036072_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036071_)))) 
           ^ (((IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036071_)) 
                                          << 1U)))));
    vlSelf->__VdfgTmp_ha1ddff2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058099_));
    vlSelf->wasmetal_core__DOT___015584_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058176_)))));
    vlSelf->wasmetal_core__DOT___015559_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058184_)))));
    vlSelf->wasmetal_core__DOT___015579_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf715e513__0)))));
    vlSelf->wasmetal_core__DOT___015565_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xf8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058095_)))))));
    vlSelf->wasmetal_core__DOT___015564_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xf8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))));
    vlSelf->wasmetal_core__DOT___017105_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058171_)))));
    vlSelf->wasmetal_core__DOT___015443_ = (1U & (IData)(
                                                         (0x7f000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058172_)))))))));
    vlSelf->wasmetal_core__DOT___015554_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058095_)))))));
    vlSelf->wasmetal_core__DOT___017072_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))));
    vlSelf->wasmetal_core__DOT___015589_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058095_)))))));
    vlSelf->wasmetal_core__DOT___015542_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))));
    vlSelf->wasmetal_core__DOT___015526_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7751e274__0))))))));
    vlSelf->wasmetal_core__DOT___015534_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058188_)))));
    vlSelf->wasmetal_core__DOT___015533_ = (1U & (0x10ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058190_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)))))))));
    vlSelf->wasmetal_core__DOT___015532_ = (1U & (0x10ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h63b44d2e__0)))));
    vlSelf->wasmetal_core__DOT___015496_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xe0U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd141341a__0))))));
    vlSelf->wasmetal_core__DOT___016680_ = (1U & (IData)(
                                                         (0xf4ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb1419641__0)))))));
    vlSelf->wasmetal_core__DOT___016668_ = (1U & (IData)(
                                                         (0xf8ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4352298b__0)))))));
    vlSelf->wasmetal_core__DOT___015491_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058099_))))));
    vlSelf->wasmetal_core__DOT___016632_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058096_))))));
    vlSelf->wasmetal_core__DOT___015435_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))))));
    vlSelf->__VdfgTmp_h124450b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc2843286__0));
    vlSelf->wasmetal_core__DOT___015454_ = (1U & (IData)(
                                                         (0xef0000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))))));
    vlSelf->__VdfgTmp_hc4af22e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___058183_)));
    vlSelf->__VdfgTmp_hb78750ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058177_));
    vlSelf->__VdfgTmp_hb7a356d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058189_));
    vlSelf->wasmetal_core__DOT___016840_ = (1U & (IData)(
                                                         (0xbf000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h372a4d3e__0)))))));
    vlSelf->wasmetal_core__DOT___016828_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2e648f5f__0)))))));
    vlSelf->wasmetal_core__DOT___016805_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058161_)))));
    vlSelf->wasmetal_core__DOT___015516_ = (1U & (IData)(
                                                         (0x4fff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xe0U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h187f5418__0))))))));
    vlSelf->wasmetal_core__DOT___015506_ = (1U & (IData)(
                                                         (0x8fff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xe0U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2e648f5f__0)))))));
    vlSelf->wasmetal_core__DOT___015501_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8e2d1d0c__0)))))));
    vlSelf->wasmetal_core__DOT___016706_ = (1U & (0xef0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___015486_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xf7f00000U 
                                                            >> 
                                                            ((0x10U 
                                                              & ((8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))))))));
    vlSelf->wasmetal_core__DOT___016612_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058164_)))));
    vlSelf->wasmetal_core__DOT___016644_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___015266_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x8fff000000000000ULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))))));
    vlSelf->wasmetal_core__DOT___015262_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xefff000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))))));
    vlSelf->wasmetal_core__DOT___015451_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)))))));
    vlSelf->wasmetal_core__DOT___015522_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xbfffU 
                                                            >> 
                                                            ((0x10U 
                                                              & ((1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                 << 3U) 
                                                                | (IData)(__VdfgTmp_hc2887b39__0)))))))));
    vlSelf->wasmetal_core__DOT___015450_ = (1U & (IData)(
                                                         (0xbf0000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_hc2887b39__0)))))));
    vlSelf->__VdfgTmp_h62a95291__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (1U 
                                                 & (0xbfff0000U 
                                                    >> 
                                                    ((0x10U 
                                                      & ((0xe0U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                         << 4U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                         << 3U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h372a4d3e__0))))));
    vlSelf->__VdfgTmp_h5cb76656__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (1U 
                                                 & (0xefff0000U 
                                                    >> 
                                                    ((0x10U 
                                                      & ((8U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                         << 4U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                         << 3U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8e2d1d0c__0))))));
    vlSelf->wasmetal_core__DOT___015481_ = (1U & (IData)(
                                                         (0xfe000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4352298b__0)))))));
    vlSelf->wasmetal_core__DOT___016578_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058095_))))));
    vlSelf->wasmetal_core__DOT___016564_ = (1U & (0x10ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))))));
    vlSelf->wasmetal_core__DOT___015263_ = (1U & (IData)(
                                                         (0x40ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb1419641__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127541___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d) 
             << 3U) | ((4U & ((4U >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023364_)))));
    wasmetal_core__DOT___023314_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127445___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022592_)))));
    wasmetal_core__DOT___022571_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                    & (IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036073_)) 
                 | (IData)(wasmetal_core__DOT___036068_)));
    vlSelf->wasmetal_core__DOT___014593_ = (1U & (0xffffbf00U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058097_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___014589_ = (1U & (0xffffbf00U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058099_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058097_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___014944_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d))));
    vlSelf->wasmetal_core__DOT___015574_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc4af22e3__0))));
    vlSelf->wasmetal_core__DOT___015549_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb78750ce__0))));
    vlSelf->wasmetal_core__DOT___015442_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb7a356d8__0))));
    vlSelf->wasmetal_core__DOT___015265_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015451_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015522_))));
    vlSelf->wasmetal_core__DOT___015395_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015450_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015454_))));
    vlSelf->wasmetal_core__DOT___015531_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h62a95291__0))));
    vlSelf->wasmetal_core__DOT___016760_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5cb76656__0))));
    vlSelf->wasmetal_core__DOT___058167_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016564_))));
    vlSelf->wasmetal_core__DOT___015202_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016564_))));
    vlSelf->__VdfgTmp_hcf32a2f0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d));
    vlSelf->wasmetal_core__DOT___058571_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d)))));
    vlSelf->__VdfgTmp_h5c254f34__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O) 
                                               >> 2U)));
    wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
           & (IData)(wasmetal_core__DOT___023314_));
    wasmetal_core__DOT___058972_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127445___O))))));
    vlSelf->wasmetal_core__DOT___059014_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127445___O) 
                                                            >> 1U))))));
    wasmetal_core__DOT___059018_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127445___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT___059022_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127445___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
           & (IData)(wasmetal_core__DOT___022571_));
    vlSelf->wasmetal_core__DOT____Vcellout___128816___O 
        = ((3U & (- (IData)((IData)(vlSelf->wasmetal_core__DOT___036073_)))) 
           ^ (((4U & (((~ (IData)(vlSelf->wasmetal_core__DOT___036073_)) 
                       | (IData)(wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__)) 
                      << 2U)) | ((IData)(wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(wasmetal_core__DOT___036068_)));
    vlSelf->wasmetal_core__DOT___058104_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014944_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))));
    vlSelf->wasmetal_core__DOT___058100_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014944_)))));
    wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_h52595424__0)) 
           & (IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__ 
        = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
           & (IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___014845_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014917_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014886_ = (1U & (0xef0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058107_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014881_ = (1U & (0xef0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014901_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8cb25dc3__0))))));
    vlSelf->wasmetal_core__DOT___014891_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h786a2bba__0))))));
    vlSelf->wasmetal_core__DOT___014850_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc4384494__0))))));
    vlSelf->wasmetal_core__DOT___014860_ = (1U & (0x80ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9949a0e3__0))))));
    vlSelf->wasmetal_core__DOT___014896_ = (1U & (0x80ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hac20e9d0__0)))));
    vlSelf->__VdfgTmp_h89d6ed4e__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058099_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d))));
    vlSelf->__VdfgTmp_h98bb6818__0 = (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb0ec899f__0))));
    vlSelf->__VdfgTmp_hd1e881b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h283c0448__0))));
    vlSelf->wasmetal_core__DOT___058115_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058100_))));
    __VdfgTmp_h4ac2372d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d));
    wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
           & (IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
           & (IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___014987_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89d6ed4e__0))));
    vlSelf->wasmetal_core__DOT___014719_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0)))));
    vlSelf->wasmetal_core__DOT___058108_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h786a2bba__0)))));
    vlSelf->wasmetal_core__DOT___014720_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9949a0e3__0)))));
    vlSelf->wasmetal_core__DOT___014722_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc4384494__0)))));
    vlSelf->wasmetal_core__DOT___014982_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h4ac2372d__0))));
    wasmetal_core__DOT____Vcellout___127542___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h52595424__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023314_)))));
    wasmetal_core__DOT___023318_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                    & (IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127446___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0xeU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022571_)))));
    wasmetal_core__DOT___022575_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___014837_ = (1U & (0xef00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h283c0448__0)))));
    vlSelf->wasmetal_core__DOT___014873_ = (1U & (0xef00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0)))));
    vlSelf->wasmetal_core__DOT___014927_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))));
    vlSelf->__VdfgTmp_hd9e83ce6__0 = ((4U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___015076_))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___015076_)));
    vlSelf->__VdfgTmp_hb3aa193a__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h52595424__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_h842e8acf__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT___058574_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                                               >> 3U)))))));
    wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
           & (IData)(wasmetal_core__DOT___023318_));
    vlSelf->wasmetal_core__DOT___059027_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127446___O))))));
    vlSelf->wasmetal_core__DOT___058992_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127446___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___058996_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127446___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___059005_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127446___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
           & (IData)(wasmetal_core__DOT___022575_));
    wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
           & (IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
           & (IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
           & (IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
           & (IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127543___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023318_)))));
    wasmetal_core__DOT___023322_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                    & (IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127447___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022575_)))));
    wasmetal_core__DOT___022579_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                    & (IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058575_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O)))))));
    vlSelf->wasmetal_core__DOT___058584_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O) 
                                                               >> 1U)))))));
    wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
           & (IData)(wasmetal_core__DOT___023322_));
    vlSelf->wasmetal_core__DOT___059000_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127447___O))))));
    vlSelf->wasmetal_core__DOT___059035_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127447___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___059040_ = (1U & (IData)(
                                                         (0xff00ff1111f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127447___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058396_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058394_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058395_)))))))));
    vlSelf->wasmetal_core__DOT___059044_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127447___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
           & (IData)(wasmetal_core__DOT___022579_));
    wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
           & (IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
           & (IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
           & (IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
           & (IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127544___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023322_)))));
    wasmetal_core__DOT___023327_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                    & (IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127448___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022579_)))));
    wasmetal_core__DOT___022584_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                    & (IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hca8853c2__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127544___O)));
    vlSelf->wasmetal_core__DOT___058589_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127544___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d))))));
    vlSelf->wasmetal_core__DOT___058590_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127544___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d))))));
    vlSelf->wasmetal_core__DOT___058593_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127544___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d))))));
    wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d) 
           & (IData)(wasmetal_core__DOT___023327_));
    vlSelf->__VdfgTmp_h0da91de8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127448___O)));
    vlSelf->wasmetal_core__DOT___059059_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127448___O) 
                                                            >> 1U))))));
    wasmetal_core__DOT___059056_ = (1U & (IData)((0xff00ff1111f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127448___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058419_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058417_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058418_)))))))));
    wasmetal_core__DOT____Vcellout___127449___O = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                      & (IData)(wasmetal_core__DOT___022584_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___022584_)));
    wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
           & (IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___036915_ = (1U & (0x78U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d) 
                                            << 2U) 
                                           | ((2U & (IData)(wasmetal_core__DOT____Vcellout___127449___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d)))));
    wasmetal_core__DOT___036914_ = (1U & (0x3c5aU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127449___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d))))));
    wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
           & (IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036914_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127545___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023327_)))));
    wasmetal_core__DOT___023331_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
                                    & (IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036915_) ? (IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d));
    vlSelf->wasmetal_core__DOT___058594_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d))))));
    vlSelf->wasmetal_core__DOT___058597_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d))))));
    vlSelf->wasmetal_core__DOT___058598_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d))))));
    wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
           & (IData)(wasmetal_core__DOT___023331_));
    wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
           & (IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d)
            ? (IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134174___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036915_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___036914_)))) 
           ^ (((IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
           & (IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O))));
    wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O))));
    wasmetal_core__DOT___036908_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d)
                                     ? (IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d));
    wasmetal_core__DOT____Vcellout___127546___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023331_)))));
    wasmetal_core__DOT___023336_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                                    & (IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d)
            ? (IData)(wasmetal_core__DOT___036908_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d));
    wasmetal_core__DOT____Vcellout___134175___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___134167___DI) 
                                                   ^ 
                                                   (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)
                                                        ? (IData)(wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__)
                                                        : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)) 
                                                      << 2U) 
                                                     | ((IData)(wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__) 
                                                        << 1U)) 
                                                    | (IData)(wasmetal_core__DOT___036908_)));
    vlSelf->__VdfgTmp_hc42a79ae__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127546___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d));
    vlSelf->wasmetal_core__DOT___058605_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___127546___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014712_)))));
    vlSelf->__VdfgTmp_hfa9cb9e8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127546___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d))))));
    vlSelf->wasmetal_core__DOT___058613_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127546___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d))))));
    wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
           & (IData)(wasmetal_core__DOT___023336_));
    vlSelf->wasmetal_core__DOT____Vcellout___134188___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                          << 1U)))));
    wasmetal_core__DOT___037013_ = (IData)((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                             >> 3U) 
                                            | (IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___017805_ = (1U & (7U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))));
    wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d 
        = (1U & (8U >> ((2U & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___127468___O 
        = (((8U & ((~ (IData)(wasmetal_core__DOT____Vcellout___134175___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                       >> 1U)))))) 
           ^ (1U | ((((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                          >> 3U)) & (IData)(wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__)) 
                     << 3U) | (((IData)(wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    wasmetal_core__DOT___058936_ = (1U & (1U >> ((4U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                     << 2U)) 
                                                 | (3U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
           & (IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                 | (IData)(wasmetal_core__DOT___037013_)));
    vlSelf->wasmetal_core__DOT___059236_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (2U 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d))));
    vlSelf->wasmetal_core__DOT___017493_ = (1U & (IData)(
                                                         (0xfeff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                                  << 1U)) 
                                                              | (((IData)(wasmetal_core__DOT___058936_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___134175___O)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                                             >> 1U))))))))));
    wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
           & (IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                  >> 1U) | (IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__)));
    __VdfgTmp_h3eda33ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                          << 3U) | 
                                         ((4U & ((8U 
                                                  >> 
                                                  (2U 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                 << 2U)) 
                                          | (((IData)(wasmetal_core__DOT___017805_) 
                                              << 1U) 
                                             | (IData)(wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___017538_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017495_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (2U 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017493_))))));
    vlSelf->__VdfgTmp_h1a828198__0 = (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (2U 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))));
    wasmetal_core__DOT____Vcellout___127547___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023336_)))));
    wasmetal_core__DOT___023340_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                    & (IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134189___O 
        = ((((IData)(wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d) 
             << 3U) | (((IData)(wasmetal_core__DOT___017805_) 
                        << 2U) | ((2U & ((~ ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                             >> 1U)) 
                                         << 1U)) | 
                                  (1U & (~ (IData)(wasmetal_core__DOT____Vcellout___134175___O)))))) 
           ^ ((8U & (((~ (IData)(wasmetal_core__DOT___017805_)) 
                      | (IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___037013_)))));
    vlSelf->wasmetal_core__DOT___059065_ = (1U & ((1U 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___036825_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d))))
                                                   ? (IData)(
                                                             (0xfff4ffff00040000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___017806_) 
                                                                << 5U) 
                                                               | (IData)(__VdfgTmp_h3eda33ce__0))))
                                                   : 
                                                  (0x40000U 
                                                   >> (IData)(__VdfgTmp_h3eda33ce__0))));
    vlSelf->wasmetal_core__DOT___060064_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134188___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017534_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058956_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017549_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058964_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017562_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___058968_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___059238_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017805_)))));
    wasmetal_core__DOT___017577_ = (1U & (0x1000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___058972_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017664_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059014_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017677_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___059018_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017702_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059027_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017611_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058992_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017624_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058996_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017729_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059040_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017536_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1a828198__0))));
    vlSelf->wasmetal_core__DOT___058612_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d))))));
    vlSelf->wasmetal_core__DOT___058642_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127547___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d))))));
    vlSelf->wasmetal_core__DOT___058646_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d))))));
    wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
           & (IData)(wasmetal_core__DOT___023340_));
    vlSelf->wasmetal_core__DOT___060196_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134189___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___059550_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058968_)))));
    vlSelf->wasmetal_core__DOT___059588_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058983_)))));
    vlSelf->wasmetal_core__DOT___059980_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059056_))));
    vlSelf->wasmetal_core__DOT___059346_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058946_)))));
    vlSelf->wasmetal_core__DOT___018176_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058940_)))));
    vlSelf->wasmetal_core__DOT___059660_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___059018_)))));
    vlSelf->wasmetal_core__DOT___059614_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058972_))));
    vlSelf->wasmetal_core__DOT___058950_ = (1U & (0x8800f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058947_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058946_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___058945_ = (1U & (0x8800f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058941_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058940_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___058987_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058984_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___058983_)))))));
    vlSelf->wasmetal_core__DOT___058975_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___017579_)
                                                      ? (IData)(
                                                                (0xff00ff00fffbfff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(wasmetal_core__DOT___017577_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h5bb2fc7d__0))))))
                                                      : 
                                                     (2U 
                                                      >> (IData)(wasmetal_core__DOT___017577_)))));
    vlSelf->wasmetal_core__DOT___059009_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059006_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059005_)))))));
    vlSelf->wasmetal_core__DOT___059004_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059001_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059000_)))))));
    vlSelf->wasmetal_core__DOT___059053_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 3U) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                        & (IData)(
                                                                  (0xa000c00000000ULL 
                                                                   >> 
                                                                   (8U 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h0da91de8__0)))))))) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059049_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017536_))))));
    vlSelf->wasmetal_core__DOT___059063_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059060_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059059_)))))));
    vlSelf->wasmetal_core__DOT___018073_ = (1U & (0xf0feU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x1000000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(wasmetal_core__DOT___059056_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___059057_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018504_)))))));
    wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
           & (IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
           & (IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127548___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023340_)))));
    wasmetal_core__DOT___023344_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                    & (IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058649_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d))))));
    vlSelf->wasmetal_core__DOT___058656_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                            >> 1U))))));
    vlSelf->__VdfgTmp_h54a2cb2f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                    >> 2U)));
    vlSelf->wasmetal_core__DOT___058660_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
           & (IData)(wasmetal_core__DOT___023344_));
    wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
           & (IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__ 
        = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
           & (IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127536___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0xeU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023344_)))));
    wasmetal_core__DOT___023349_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058661_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127536___O))))));
    vlSelf->wasmetal_core__DOT___058631_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127536___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___058632_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xeU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127536___O) 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___058622_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127536___O) 
                                                               >> 3U)))))));
    wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
           & (IData)(wasmetal_core__DOT___023349_));
    wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
           & (IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
           & (IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127537___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023349_)))));
    wasmetal_core__DOT___023353_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                    & (IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058625_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(wasmetal_core__DOT____Vcellout___127537___O)))))));
    vlSelf->__VdfgTmp_h2932eeac__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xff00ff1111f0f0ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                                 << 4U) 
                                                                | ((8U 
                                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127537___O) 
                                                                       << 2U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hf41b4843__0))))))));
    vlSelf->wasmetal_core__DOT___058639_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127537___O) 
                                                               >> 3U)))))));
    __VdfgTmp_h0e008e26__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                               << 1U) | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127537___O) 
                                               >> 2U)));
    wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
           & (IData)(wasmetal_core__DOT___023353_));
    vlSelf->wasmetal_core__DOT___060398_ = (1U & (0xa0c0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h0e008e26__0))))));
    wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
           & (IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
           & (IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127538___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023353_)))));
    wasmetal_core__DOT___023358_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                    & (IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h01fee3b7__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (0x53U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___127538___O)))))));
    vlSelf->__VdfgTmp_h192fc191__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127538___O) 
                                                    >> 1U)));
    vlSelf->wasmetal_core__DOT___058664_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127538___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___058665_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127538___O) 
                                                               >> 3U)))))));
    wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
           & (IData)(wasmetal_core__DOT___023358_));
    wasmetal_core__DOT____Vcellout___127539___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                   ^ 
                                                   (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                       & (IData)(wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__)) 
                                                      << 2U) 
                                                     | ((IData)(wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__) 
                                                        << 1U)) 
                                                    | (IData)(wasmetal_core__DOT___023358_)));
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d 
        = (1U & (8U >> ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127539___O) 
                               >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___058423_))));
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127539___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___036862_ = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d))));
    wasmetal_core__DOT___036861_ = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry))));
    wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036861_)) 
           & (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry));
    wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036862_) ? (IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__)
            : (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d));
    wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d)
            ? (IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d));
    wasmetal_core__DOT___036854_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d)
                                     ? (IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d));
    wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d)
            ? (IData)(wasmetal_core__DOT___036854_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134166___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036862_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___036861_)))) 
           ^ (((IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O))));
    wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O))));
    wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134167___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___134167___DI) 
           ^ (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)
                  ? (IData)(wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)) 
                << 2U) | ((IData)(wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(wasmetal_core__DOT___036854_)));
    vlSelf->wasmetal_core__DOT____Vcellout___134169___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                          << 1U)))));
    wasmetal_core__DOT___036867_ = (IData)((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                             >> 3U) 
                                            | (IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___023670_ = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O)) 
                                            & (IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127583___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                       >> 1U)))))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    vlSelf->__VdfgTmp_he997ff62__0 = (0x10U | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                << 3U) 
                                               | (2U 
                                                  & ((IData)(
                                                             (0x1000000000000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((1U 
                                                                    >> 
                                                                    (3U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                                        >> 1U))) 
                                                                   << 5U)) 
                                                               | ((0x10U 
                                                                   & ((1U 
                                                                       >> 
                                                                       (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                                           >> 3U))) 
                                                                      << 4U)) 
                                                                  | ((0xeU 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                                           >> 3U))))))) 
                                                     << 1U))));
    wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                 | (IData)(wasmetal_core__DOT___036867_)));
    wasmetal_core__DOT___060497_ = (1U & (4U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134169___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xff4fffU 
                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))));
    wasmetal_core__DOT___060511_ = (1U & (4U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134169___O)) 
                                                 | (1U 
                                                    & (0xff4fffU 
                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))));
    wasmetal_core__DOT___060525_ = (1U & (4U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134169___O) 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (0xff4fffU 
                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))));
    vlSelf->wasmetal_core__DOT___060308_ = (1U & (IData)(
                                                         (0xa000c00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h54a2cb2f__0))))))));
    vlSelf->wasmetal_core__DOT___019073_ = (1U & (IData)(
                                                         (0xa000c00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                                             >> 3U))))))))));
    vlSelf->__VdfgTmp_hdfb00432__0 = ((2U & ((0xff4fffU 
                                              >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___059242_));
    vlSelf->wasmetal_core__DOT___017018_ = (1U & (IData)(
                                                         (0xff4fff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___006127_))) 
                                                               << 5U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_he997ff62__0)))));
    wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                  >> 1U) | (IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___060499_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060497_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x80U 
                                                                      >> 
                                                                      (4U 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f50000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058508_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058358_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060513_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060511_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x80U 
                                                                      >> 
                                                                      (4U 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f50000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058509_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O) 
                                                                                >> 1U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058359_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O) 
                                                                                >> 1U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060527_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060525_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x80U 
                                                                      >> 
                                                                      (4U 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f50000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058510_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O) 
                                                                                >> 2U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058360_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O) 
                                                                                >> 2U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059551_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6ecbbe50__0))))));
    vlSelf->wasmetal_core__DOT___018432_ = (1U & (IData)(
                                                         (0x3050f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7af47ace__0))))))));
    vlSelf->wasmetal_core__DOT___059517_ = (1U & (IData)(
                                                         (0x3050f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___059394_ = (1U & (0xca000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___059686_ = (1U & (0xca000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___059435_ = (1U & (0xca000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___060170_ = (1U & (0x100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058605_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdfb00432__0)))));
    vlSelf->wasmetal_core__DOT___018537_ = (1U & (IData)(
                                                         (0x5030f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c254f34__0))))))));
    vlSelf->wasmetal_core__DOT___060252_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058642_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb00432__0))));
    vlSelf->wasmetal_core__DOT___018492_ = (1U & (0xbf00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058571_))))));
    vlSelf->wasmetal_core__DOT___016587_ = (1U & (IData)(
                                                         (0xf088000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058561_)))))))));
    vlSelf->wasmetal_core__DOT___016538_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___016798_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___016780_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hca8853c2__0))))));
    vlSelf->wasmetal_core__DOT___016801_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017018_))));
    vlSelf->wasmetal_core__DOT___016824_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058593_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017018_))));
    vlSelf->wasmetal_core__DOT___016836_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058594_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017018_))));
    vlSelf->wasmetal_core__DOT___016848_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___016536_ = (1U & (0x7fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018964_)))))));
    wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___016933_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057895_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058613_))))));
    vlSelf->wasmetal_core__DOT___016915_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057892_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058612_))))));
    vlSelf->wasmetal_core__DOT___017087_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x3355ffff0f0f0f0fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057844_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                                                >> 2U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016536_))));
    vlSelf->wasmetal_core__DOT___017068_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057854_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058649_))))));
    vlSelf->wasmetal_core__DOT___016995_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057811_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2932eeac__0))))));
    vlSelf->wasmetal_core__DOT___017006_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017018_)
                                                   ? 
                                                  (0xac00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h0e008e26__0)))))
                                                   : 
                                                  (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017017_)))));
    vlSelf->wasmetal_core__DOT___017157_ = (1U & (0xc05U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058665_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051320_))))));
    wasmetal_core__DOT____Vcellout___134170___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                          >> 3U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                             >> 2U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                                >> 1U)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036867_)))));
    wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__ 
        = (IData)((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                    >> 3U) | (IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___060555_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060553_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060552_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134170___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060569_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060567_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060566_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(wasmetal_core__DOT____Vcellout___134170___O)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060586_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060584_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060583_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134170___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    wasmetal_core__DOT___060597_ = (1U & (0xdU >> (
                                                   (4U 
                                                    & ((0x80U 
                                                        >> 
                                                        (4U 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xff4fffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134170___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (7U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                 | (IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___060601_ = (1U & (IData)(
                                                         (0xff0f8808ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060598_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060597_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ff0077770f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127508___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058322_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015597_)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)))))))));
    wasmetal_core__DOT____Vcellout___134171___O = (
                                                   (1U 
                                                    | ((4U 
                                                        & ((8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                           << 2U)) 
                                                       | (2U 
                                                          & ((7U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                             << 1U)))) 
                                                   ^ 
                                                   ((8U 
                                                     & (((1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))
                                                          ? (IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__)
                                                          : 
                                                         (8U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                        << 3U)) 
                                                    | (((IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (3U 
                                                          & (- (IData)((IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__)))))));
    vlSelf->wasmetal_core__DOT___060617_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060615_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060614_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134171___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060643_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060639_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134171___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060627_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060624_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060623_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(wasmetal_core__DOT____Vcellout___134171___O)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
}

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__56(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__56\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___015190_;
    wasmetal_core__DOT___015190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015210_;
    wasmetal_core__DOT___015210_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016558_;
    wasmetal_core__DOT___016558_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016567_;
    wasmetal_core__DOT___016567_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016571_;
    wasmetal_core__DOT___016571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016581_;
    wasmetal_core__DOT___016581_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016593_;
    wasmetal_core__DOT___016593_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016599_;
    wasmetal_core__DOT___016599_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016602_;
    wasmetal_core__DOT___016602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016606_;
    wasmetal_core__DOT___016606_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016615_;
    wasmetal_core__DOT___016615_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016627_;
    wasmetal_core__DOT___016627_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016639_;
    wasmetal_core__DOT___016639_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016647_;
    wasmetal_core__DOT___016647_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016653_;
    wasmetal_core__DOT___016653_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016654_;
    wasmetal_core__DOT___016654_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016671_;
    wasmetal_core__DOT___016671_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016675_;
    wasmetal_core__DOT___016675_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016683_;
    wasmetal_core__DOT___016683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016687_;
    wasmetal_core__DOT___016687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016700_;
    wasmetal_core__DOT___016700_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016701_;
    wasmetal_core__DOT___016701_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016709_;
    wasmetal_core__DOT___016709_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016717_;
    wasmetal_core__DOT___016717_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016721_;
    wasmetal_core__DOT___016721_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016728_;
    wasmetal_core__DOT___016728_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016732_;
    wasmetal_core__DOT___016732_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016739_;
    wasmetal_core__DOT___016739_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016755_;
    wasmetal_core__DOT___016755_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016763_;
    wasmetal_core__DOT___016763_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016767_;
    wasmetal_core__DOT___016767_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016774_;
    wasmetal_core__DOT___016774_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016778_;
    wasmetal_core__DOT___016778_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016779_;
    wasmetal_core__DOT___016779_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016786_;
    wasmetal_core__DOT___016786_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016794_;
    wasmetal_core__DOT___016794_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016800_;
    wasmetal_core__DOT___016800_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016808_;
    wasmetal_core__DOT___016808_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016812_;
    wasmetal_core__DOT___016812_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016819_;
    wasmetal_core__DOT___016819_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016823_;
    wasmetal_core__DOT___016823_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016831_;
    wasmetal_core__DOT___016831_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016835_;
    wasmetal_core__DOT___016835_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016843_;
    wasmetal_core__DOT___016843_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016847_;
    wasmetal_core__DOT___016847_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016854_;
    wasmetal_core__DOT___016854_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016858_;
    wasmetal_core__DOT___016858_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016865_;
    wasmetal_core__DOT___016865_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016869_;
    wasmetal_core__DOT___016869_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016876_;
    wasmetal_core__DOT___016876_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016880_;
    wasmetal_core__DOT___016880_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016887_;
    wasmetal_core__DOT___016887_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016891_;
    wasmetal_core__DOT___016891_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016898_;
    wasmetal_core__DOT___016898_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016902_;
    wasmetal_core__DOT___016902_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016909_;
    wasmetal_core__DOT___016909_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016913_;
    wasmetal_core__DOT___016913_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016914_;
    wasmetal_core__DOT___016914_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016921_;
    wasmetal_core__DOT___016921_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016929_;
    wasmetal_core__DOT___016929_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016949_;
    wasmetal_core__DOT___016949_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016972_;
    wasmetal_core__DOT___016972_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016973_;
    wasmetal_core__DOT___016973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016980_;
    wasmetal_core__DOT___016980_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016988_;
    wasmetal_core__DOT___016988_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017043_;
    wasmetal_core__DOT___017043_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017050_;
    wasmetal_core__DOT___017050_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017054_;
    wasmetal_core__DOT___017054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017062_;
    wasmetal_core__DOT___017062_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017066_;
    wasmetal_core__DOT___017066_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017067_;
    wasmetal_core__DOT___017067_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017075_;
    wasmetal_core__DOT___017075_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017083_;
    wasmetal_core__DOT___017083_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017089_;
    wasmetal_core__DOT___017089_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017096_;
    wasmetal_core__DOT___017096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017100_;
    wasmetal_core__DOT___017100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017108_;
    wasmetal_core__DOT___017108_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017116_;
    wasmetal_core__DOT___017116_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017123_;
    wasmetal_core__DOT___017123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017772_;
    wasmetal_core__DOT___017772_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017802_;
    wasmetal_core__DOT___017802_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018071_;
    wasmetal_core__DOT___018071_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018072_;
    wasmetal_core__DOT___018072_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019250_;
    wasmetal_core__DOT___019250_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019251_;
    wasmetal_core__DOT___019251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025141_;
    wasmetal_core__DOT___025141_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025171_;
    wasmetal_core__DOT___025171_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025173_;
    wasmetal_core__DOT___025173_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025174_;
    wasmetal_core__DOT___025174_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025175_;
    wasmetal_core__DOT___025175_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027528_;
    wasmetal_core__DOT___027528_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027533_;
    wasmetal_core__DOT___027533_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027537_;
    wasmetal_core__DOT___027537_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027542_;
    wasmetal_core__DOT___027542_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027546_;
    wasmetal_core__DOT___027546_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027550_;
    wasmetal_core__DOT___027550_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036108_;
    wasmetal_core__DOT___036108_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036112_;
    wasmetal_core__DOT___036112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036117_;
    wasmetal_core__DOT___036117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036121_;
    wasmetal_core__DOT___036121_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036125_;
    wasmetal_core__DOT___036125_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036128_;
    wasmetal_core__DOT___036128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036138_;
    wasmetal_core__DOT___036138_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036144_;
    wasmetal_core__DOT___036144_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036148_;
    wasmetal_core__DOT___036148_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036151_;
    wasmetal_core__DOT___036151_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036152_;
    wasmetal_core__DOT___036152_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036214_;
    wasmetal_core__DOT___036214_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036218_;
    wasmetal_core__DOT___036218_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036223_;
    wasmetal_core__DOT___036223_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036227_;
    wasmetal_core__DOT___036227_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036232_;
    wasmetal_core__DOT___036232_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036236_;
    wasmetal_core__DOT___036236_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036240_;
    wasmetal_core__DOT___036240_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036241_;
    wasmetal_core__DOT___036241_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036245_;
    wasmetal_core__DOT___036245_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036260_;
    wasmetal_core__DOT___036260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037138_;
    wasmetal_core__DOT___037138_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037144_;
    wasmetal_core__DOT___037144_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043012_;
    wasmetal_core__DOT___043012_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043014_;
    wasmetal_core__DOT___043014_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043015_;
    wasmetal_core__DOT___043015_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043016_;
    wasmetal_core__DOT___043016_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050291_;
    wasmetal_core__DOT___050291_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058973_;
    wasmetal_core__DOT___058973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058974_;
    wasmetal_core__DOT___058974_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059002_;
    wasmetal_core__DOT___059002_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059003_;
    wasmetal_core__DOT___059003_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059007_;
    wasmetal_core__DOT___059007_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059008_;
    wasmetal_core__DOT___059008_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059061_;
    wasmetal_core__DOT___059061_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059062_;
    wasmetal_core__DOT___059062_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059064_;
    wasmetal_core__DOT___059064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060715_;
    wasmetal_core__DOT___060715_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060722_;
    wasmetal_core__DOT___060722_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060723_;
    wasmetal_core__DOT___060723_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060764_;
    wasmetal_core__DOT___060764_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060777_;
    wasmetal_core__DOT___060777_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060803_;
    wasmetal_core__DOT___060803_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060805_;
    wasmetal_core__DOT___060805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060810_;
    wasmetal_core__DOT___060810_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060850_;
    wasmetal_core__DOT___060850_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060854_;
    wasmetal_core__DOT___060854_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060864_;
    wasmetal_core__DOT___060864_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060891_;
    wasmetal_core__DOT___060891_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060892_;
    wasmetal_core__DOT___060892_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060931_;
    wasmetal_core__DOT___060931_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060936_;
    wasmetal_core__DOT___060936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060942_;
    wasmetal_core__DOT___060942_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060983_;
    wasmetal_core__DOT___060983_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060987_;
    wasmetal_core__DOT___060987_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061017_;
    wasmetal_core__DOT___061017_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061018_;
    wasmetal_core__DOT___061018_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061021_;
    wasmetal_core__DOT___061021_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061027_;
    wasmetal_core__DOT___061027_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061077_;
    wasmetal_core__DOT___061077_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061101_;
    wasmetal_core__DOT___061101_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061103_;
    wasmetal_core__DOT___061103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061112_;
    wasmetal_core__DOT___061112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061158_;
    wasmetal_core__DOT___061158_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061184_;
    wasmetal_core__DOT___061184_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061185_;
    wasmetal_core__DOT___061185_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061188_;
    wasmetal_core__DOT___061188_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061194_;
    wasmetal_core__DOT___061194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061224_;
    wasmetal_core__DOT___061224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061267_;
    wasmetal_core__DOT___061267_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061268_;
    wasmetal_core__DOT___061268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061271_;
    wasmetal_core__DOT___061271_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061277_;
    wasmetal_core__DOT___061277_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061305_;
    wasmetal_core__DOT___061305_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061310_;
    wasmetal_core__DOT___061310_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061334_;
    wasmetal_core__DOT___061334_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061335_;
    wasmetal_core__DOT___061335_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061338_;
    wasmetal_core__DOT___061338_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061344_;
    wasmetal_core__DOT___061344_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061345_;
    wasmetal_core__DOT___061345_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061351_;
    wasmetal_core__DOT___061351_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061356_;
    wasmetal_core__DOT___061356_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061373_;
    wasmetal_core__DOT___061373_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061383_;
    wasmetal_core__DOT___061383_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061387_;
    wasmetal_core__DOT___061387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061398_;
    wasmetal_core__DOT___061398_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061424_;
    wasmetal_core__DOT___061424_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061433_;
    wasmetal_core__DOT___061433_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061435_;
    wasmetal_core__DOT___061435_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061720_;
    wasmetal_core__DOT___061720_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eencode32__02ein__05b30__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eencode32__02ein__05b30__05d = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow;
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b24__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b24__05d = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b25__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b25__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127979___O;
    wasmetal_core__DOT____Vcellout___127979___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127980___O;
    wasmetal_core__DOT____Vcellout___127980___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127981___O;
    wasmetal_core__DOT____Vcellout___127981___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127982___O;
    wasmetal_core__DOT____Vcellout___127982___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127983___O;
    wasmetal_core__DOT____Vcellout___127983___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127984___O;
    wasmetal_core__DOT____Vcellout___127984___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127993___O;
    wasmetal_core__DOT____Vcellout___127993___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128810___O;
    wasmetal_core__DOT____Vcellout___128810___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128818___O;
    wasmetal_core__DOT____Vcellout___128818___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128820___O;
    wasmetal_core__DOT____Vcellout___128820___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128821___O;
    wasmetal_core__DOT____Vcellout___128821___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128822___O;
    wasmetal_core__DOT____Vcellout___128822___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128823___O;
    wasmetal_core__DOT____Vcellout___128823___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128824___O;
    wasmetal_core__DOT____Vcellout___128824___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128825___O;
    wasmetal_core__DOT____Vcellout___128825___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128826___O;
    wasmetal_core__DOT____Vcellout___128826___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128827___O;
    wasmetal_core__DOT____Vcellout___128827___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128829___O;
    wasmetal_core__DOT____Vcellout___128829___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128833___O;
    wasmetal_core__DOT____Vcellout___128833___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128834___O;
    wasmetal_core__DOT____Vcellout___128834___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128835___O;
    wasmetal_core__DOT____Vcellout___128835___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128836___O;
    wasmetal_core__DOT____Vcellout___128836___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128837___O;
    wasmetal_core__DOT____Vcellout___128837___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128838___O;
    wasmetal_core__DOT____Vcellout___128838___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128839___O;
    wasmetal_core__DOT____Vcellout___128839___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128840___O;
    wasmetal_core__DOT____Vcellout___128840___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128841___O;
    wasmetal_core__DOT____Vcellout___128841___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134206___O;
    wasmetal_core__DOT____Vcellout___134206___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127757___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127757___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128263___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128263___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128263___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128263___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128264___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128264___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128264___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128264___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128264___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128264___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128264___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128264___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128810___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128810___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128820___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128820___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128820___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128820___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128820___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128820___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128821___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128821___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128821___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128821___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128821___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128821___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128822___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128822___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128822___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128822___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128822___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128822___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128824___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128824___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128824___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128824___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128824___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128824___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128825___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128825___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128825___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128825___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128825___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128825___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128826___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128826___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128826___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128826___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128826___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128826___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128827___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128827___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128827___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128827___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128829___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128829___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128829___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128829___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128829___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128829___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128830___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128830___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128830___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128830___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128830___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128830___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128835___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128835___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128835___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128835___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128836___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128836___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128836___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128836___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128836___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128836___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128837___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128837___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128837___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128837___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128837___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128837___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128838___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128838___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128838___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128838___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128838___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128838___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128839___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128839___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128839___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128839___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128839___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128839___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128840___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128840___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128840___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128840___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128840___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128840___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128841___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128841___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128841___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128841___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128841___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128841___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134206___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134206___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134206___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134206___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134207___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134207___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134207___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134207___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hf3e1ab91__0;
    __VdfgTmp_hf3e1ab91__0 = 0;
    CData/*4:0*/ __VdfgTmp_hbc941cc7__0;
    __VdfgTmp_hbc941cc7__0 = 0;
    CData/*4:0*/ __VdfgTmp_h4ef0e6f0__0;
    __VdfgTmp_h4ef0e6f0__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8cd84d2f__0;
    __VdfgTmp_h8cd84d2f__0 = 0;
    CData/*2:0*/ __VdfgTmp_he63183d7__0;
    __VdfgTmp_he63183d7__0 = 0;
    CData/*2:0*/ __VdfgTmp_he967bd3f__0;
    __VdfgTmp_he967bd3f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h56377d30__0;
    __VdfgTmp_h56377d30__0 = 0;
    CData/*2:0*/ __VdfgTmp_h823d6b3b__0;
    __VdfgTmp_h823d6b3b__0 = 0;
    CData/*5:0*/ __VdfgTmp_h58253077__0;
    __VdfgTmp_h58253077__0 = 0;
    CData/*2:0*/ __VdfgTmp_hea8c747f__0;
    __VdfgTmp_hea8c747f__0 = 0;
    CData/*2:0*/ __VdfgTmp_hed321262__0;
    __VdfgTmp_hed321262__0 = 0;
    CData/*5:0*/ __VdfgTmp_hb9661308__0;
    __VdfgTmp_hb9661308__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc68349d0__0;
    __VdfgTmp_hc68349d0__0 = 0;
    CData/*3:0*/ __VdfgTmp_h5c0f2a5b__0;
    __VdfgTmp_h5c0f2a5b__0 = 0;
    CData/*1:0*/ __VdfgTmp_he0568e2c__0;
    __VdfgTmp_he0568e2c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6eb6be0b__0;
    __VdfgTmp_h6eb6be0b__0 = 0;
    CData/*2:0*/ __VdfgTmp_h410f7c75__0;
    __VdfgTmp_h410f7c75__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1ff7b9c3__0;
    __VdfgTmp_h1ff7b9c3__0 = 0;
    CData/*4:0*/ __VdfgTmp_h860e6d13__0;
    __VdfgTmp_h860e6d13__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc59b0ae4__0;
    __VdfgTmp_hc59b0ae4__0 = 0;
    CData/*2:0*/ __VdfgTmp_hd985bb83__0;
    __VdfgTmp_hd985bb83__0 = 0;
    CData/*4:0*/ __VdfgTmp_h188a23cd__0;
    __VdfgTmp_h188a23cd__0 = 0;
    CData/*2:0*/ __VdfgTmp_h237a6a81__0;
    __VdfgTmp_h237a6a81__0 = 0;
    // Body
    vlSelf->__VdfgTmp_ha00e7863__0 = (((IData)(vlSelf->wasmetal_core__DOT___015451_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015523_));
    wasmetal_core__DOT___015210_ = (1U & (IData)((0xfbULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058187_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058186_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058185_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015523_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015262_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015451_)))))))));
    vlSelf->wasmetal_core__DOT___016553_ = (1U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___058216_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058215_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                ? 
                                                               ((~ (IData)(vlSelf->wasmetal_core__DOT___015584_)) 
                                                                & (0xf0f0ccaaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcbc05328__0)))
                                                                : 
                                                               ((~ (IData)(vlSelf->wasmetal_core__DOT___015584_)) 
                                                                & (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d)))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014723_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___015263_)))))) 
                                                  & (((~ 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___015574_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___014772_))
                                                         : 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___015574_)) 
                                                         & (2U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d))))) 
                                                      & (IData)(
                                                                (0xaaaf888cULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___015566_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015565_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014689_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014688_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014686_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___015564_))))))))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015464_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015463_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015462_) 
                                                                        << 3U) 
                                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___015534_)
                                                                             ? (IData)(vlSelf->wasmetal_core__DOT___015537_)
                                                                             : 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014588_) 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___015537_))) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & (((~ 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015526_)) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014926_))
                                                                                 : 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015526_)) 
                                                                                & (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d))))) 
                                                                                & (IData)(
                                                                                (0xeee0eee0eee00000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015262_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015523_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014718_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015134_))))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((~ 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015516_)) 
                                                                                & (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hadaed6e9__0)))
                                                                                 : 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015516_)) 
                                                                                & (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b21__05d))))) 
                                                                                & ((~ 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015511_)) 
                                                                                & (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5047773c__0)))
                                                                                 : 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015511_)) 
                                                                                & (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d))))) 
                                                                                & (IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015475_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015474_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015473_) 
                                                                                << 3U) 
                                                                                | ((((~ (IData)(vlSelf->wasmetal_core__DOT___015491_)) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___015409_)) 
                                                                                << 2U) 
                                                                                | ((((~ (IData)(vlSelf->wasmetal_core__DOT___015486_)) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___015361_)) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015481_)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? (IData)(
                                                                                (0xfff0fffcfff0fffaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015025_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015024_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b356604__0)))))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___015025_)))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h003f7a85__0 = ((2U & ((0xf8ffU 
                                              >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___015523_));
    vlSelf->wasmetal_core__DOT___017470_ = (1U & ((1U 
                                                   >> 
                                                   ((2U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                          ? 
                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___014850_)) 
                                                          & (IData)(vlSelf->wasmetal_core__DOT___014682_))
                                                          : 
                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___014850_)) 
                                                          & (2U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                           ? 
                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT___014845_)) 
                                                           & (0xf0f0ccaaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7c5b2a1d__0)))
                                                           : 
                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT___014845_)) 
                                                           & (2U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d))))))) 
                                                  & (IData)(
                                                            (0xe00000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014842_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014841_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014840_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((0xf8ffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___015523_))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014838_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___014837_))))))))));
    __VdfgTmp_h8cd84d2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___015428_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015427_)));
    vlSelf->wasmetal_core__DOT___036202_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015266_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014592_))));
    wasmetal_core__DOT___016599_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___015204_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014592_))));
    vlSelf->wasmetal_core__DOT___017498_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014593_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014592_))));
    vlSelf->wasmetal_core__DOT___036093_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058108_))));
    wasmetal_core__DOT___060987_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060985_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127992___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060891_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060889_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127992___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060810_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060807_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127992___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060722_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060717_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127992___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    if (vlSelf->wasmetal_core__DOT___027566_) {
        wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027524_;
        wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027528_ = wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027528_;
        wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027533_ = wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027533_;
        wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027537_ = wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027537_;
        wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027542_ = wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027542_;
        wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027546_ = wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027546_;
        wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027550_ = wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027550_;
        wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__;
    } else {
        wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027528_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027533_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027537_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027542_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027546_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027550_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
    }
    vlSelf->wasmetal_core__DOT___016552_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058213_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058212_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058211_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfc00aaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058207_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058206_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xfc00aaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017072_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058205_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058204_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfc00aaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017105_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058203_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058202_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d)))))))))))))));
    __VdfgTmp_h4ef0e6f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015395_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014928_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015266_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_h34f07943__0))));
    vlSelf->wasmetal_core__DOT___017469_ = (((IData)(vlSelf->wasmetal_core__DOT___015134_) 
                                             & ((IData)(vlSelf->wasmetal_core__DOT___015133_) 
                                                & (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015132_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015131_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015130_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015129_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015128_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___015127_)))))))))) 
                                            & (((IData)(vlSelf->wasmetal_core__DOT___015062_) 
                                                & (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015061_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015060_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015059_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015058_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015057_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___015056_))))))))) 
                                               & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014911_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014910_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014909_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___014931_)) 
                                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT___014930_)) 
                                                                            & (IData)(
                                                                                (0xaaaf888cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014929_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014928_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014689_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014719_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014927_)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfca8ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058133_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058132_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014723_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014718_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014720_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014722_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___014588_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014593_))))))))))))));
    __VdfgTmp_hbc941cc7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015265_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015264_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015263_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_h71404310__0))));
    vlSelf->wasmetal_core__DOT___017473_ = (1U & ((IData)(
                                                          (0xfdULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___058122_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058121_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058120_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015264_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014720_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (0xf8ffU 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)))))))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014585_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014584_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014583_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0xaf8cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058114_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058113_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((0xf8ffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf8ffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058108_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015523_)))))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((IData)(
                                                                                (0xfdULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058111_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058110_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015394_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058108_)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & ((1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005670_))))
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___014593_)
                                                                                 ? 
                                                                                (0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7eb9770e__0)))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___014589_)))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___014593_)
                                                                                 ? (IData)(
                                                                                (0xaaaaaaaa3f3f3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014591_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014590_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7eb9770e__0)))))))
                                                                                 : 
                                                                                (0x777fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014591_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014590_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014589_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___016551_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058200_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058199_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015058_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015059_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___016668_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xfff01110U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015056_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9c126c52__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                              ? 
                                                                             (0xfff00bbU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___014872_) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h8cd84d2f__0))))
                                                                              : 
                                                                             (0xff0fbb00U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h8cd84d2f__0))))))))))))));
    vlSelf->__VdfgTmp_h605612ae__0 = (((IData)(wasmetal_core__DOT___016599_) 
                                       << 1U) | (1U 
                                                 & (0xc5U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h09c9c684__0))));
    wasmetal_core__DOT___036128_ = (1U & (0xc500U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017498_) 
                                            << 3U) 
                                           | (IData)(vlSelf->__VdfgTmp_h069b89c3__0))));
    wasmetal_core__DOT___015190_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014592_)
                                           ? (IData)(
                                                     (0xcc0c5505ff0fff0fULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015204_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015203_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015202_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014872_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d))))))))
                                           : (0xdU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015203_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015202_)))));
    vlSelf->wasmetal_core__DOT___016554_ = (1U & ((IData)(
                                                          (0xfff0fff01111ffffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___016644_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015056_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h42abc930__0))))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___015190_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015189_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015188_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0xeeeef0ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___015516_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016805_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014992_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he6b298f6__0))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((0xfff0bbbbU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___016840_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016828_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015130_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015531_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015062_)))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (0xfff0bbbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015501_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015481_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015132_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016760_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014998_))))))))))))))));
    wasmetal_core__DOT___061373_ = (1U & (IData)((0xf0faaaaccccff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060910_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___060890_) 
                                                                   << 1U) 
                                                                  | (IData)(wasmetal_core__DOT___060891_))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0xf4f400ffU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060919_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060920_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060917_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___060918_)))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0xee0fU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hd0027aa1__0)))))))))));
    wasmetal_core__DOT___061351_ = (1U & (IData)((0xf0faaaaccccff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060729_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___060721_) 
                                                                   << 1U) 
                                                                  | (IData)(wasmetal_core__DOT___060722_))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0xbU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060756_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h27adf041__0))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___060755_)))))))));
    __VdfgTmp_he63183d7__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014589_)));
    __VdfgTmp_he967bd3f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014944_)));
    __VdfgTmp_h56377d30__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014896_)));
    __VdfgTmp_h823d6b3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014860_)));
    __VdfgTmp_hea8c747f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | 
                                         (1U & (0x80ffU 
                                                >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)))));
    __VdfgTmp_hed321262__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | 
                                         (1U & (0x80ffU 
                                                >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)))));
    vlSelf->__VdfgTmp_h624ea096__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014850_)));
    vlSelf->__VdfgTmp_h44742984__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014891_)));
    vlSelf->__VdfgTmp_hb82ac2db__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014901_)));
    vlSelf->__VdfgTmp_h703c2d50__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014927_)));
    vlSelf->__VdfgTmp_hb3e763f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014873_)));
    vlSelf->__VdfgTmp_h0a1cab09__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014881_)));
    vlSelf->__VdfgTmp_h98026846__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014886_)));
    vlSelf->__VdfgTmp_h9f21faf7__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014837_)));
    vlSelf->__VdfgTmp_hba893859__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014917_)));
    vlSelf->__VdfgTmp_h9bcd87c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014845_)));
    vlSelf->__VdfgTmp_h6331a531__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014987_)));
    vlSelf->__VdfgTmp_h155f9d55__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014982_)));
    vlSelf->__VdfgTmp_hb895011c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014719_)));
    vlSelf->__VdfgTmp_heacb01d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014720_)));
    vlSelf->wasmetal_core__DOT___016555_ = (1U & ((1U 
                                                   >> 
                                                   ((8U 
                                                     & (((0x80U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha1ddff2b__0))) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                             ? (IData)(
                                                                       (0xfff0fffcfff0fffaULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015078_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015077_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1a5afed0__0)))))))
                                                             : 
                                                            (2U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___015078_)))) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & (((0x4000U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0)) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___058096_))))) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                ? (IData)(
                                                                          (0xfff0fffcfff0fffaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015032_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015031_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h210df1ee__0)))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___015032_)))) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (((0x80U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))) 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                   ? (IData)(
                                                                             (0xfff0fff3fff0fffaULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015096_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015095_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h39f326f7__0)))))))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015096_)))) 
                                                              << 1U)) 
                                                          | ((0x4000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_ha1ddff2b__0)))) 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___015409_)))))) 
                                                  & (((~ 
                                                       ((0x4000U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058183_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___058098_))))) 
                                                        & (IData)(vlSelf->wasmetal_core__DOT___014813_))) 
                                                      & ((1U 
                                                          & (4U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015522_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015450_))))
                                                          ? (IData)(
                                                                    (0xef00efef00000000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___014718_) 
                                                                       << 5U) 
                                                                      | (IData)(__VdfgTmp_h4ef0e6f0__0))))
                                                          : 
                                                         (0xef00efefU 
                                                          >> (IData)(__VdfgTmp_h4ef0e6f0__0)))) 
                                                     & (IData)(
                                                               (0x4000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015212_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015211_) 
                                                                     << 4U) 
                                                                    | (((IData)(wasmetal_core__DOT___015210_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (((~ 
                                                                                ((0x10000000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h124450b0__0)))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014626_))) 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT___015266_)
                                                                                 ? 
                                                                                (0xef00efefU 
                                                                                >> (IData)(__VdfgTmp_hbc941cc7__0))
                                                                                 : (IData)(
                                                                                (0xef00efef00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 5U) 
                                                                                | (IData)(__VdfgTmp_hbc941cc7__0)))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & (((~ 
                                                                                ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015569_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb78750ce__0))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014645_))) 
                                                                                & (IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015223_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015222_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015221_) 
                                                                                << 3U) 
                                                                                | ((((0x10000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc2843286__0))))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014680_)) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((0x8000U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xf8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058156_))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfd6d7e7__0))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d)))) 
                                                                                << 1U)) 
                                                                                | ((0x80000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058156_)))))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014653_)))))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0x13135f0000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015204_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015432_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014592_)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___058153_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017473_)))));
    wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h605612ae__0))) 
                 & (7U >> (IData)(vlSelf->__VdfgTmp_hc0955a68__0))));
    wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___036128_)) 
                 & (7U >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0))));
    vlSelf->wasmetal_core__DOT___058217_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016555_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016554_))));
    wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036176_) 
           & (IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036094_) 
           & (IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127993___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___027524_))))));
    vlSelf->wasmetal_core__DOT___058218_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058217_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128828___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_hd5ff8c3b__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036176_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hc0955a68__0)) 
                                                << 1U)) 
                                         | (1U & (8U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h605612ae__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h605612ae__0))) 
                                          << 1U)))));
    wasmetal_core__DOT___036241_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hd5ff8c3b__0)) 
                                    & (IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128817___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036094_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0)) 
                                                << 1U)) 
                                         | (IData)(wasmetal_core__DOT___036128_)))) 
           ^ (((IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(wasmetal_core__DOT___036128_)) 
                                          << 1U)))));
    wasmetal_core__DOT___036121_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0)) 
                                    & (IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___061224_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061221_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127993___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061158_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061155_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___127993___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061077_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061075_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127993___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061310_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061307_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127993___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___016602_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___016599_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016593_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016558_ = (1U & (0xd5555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hefd4f1fe__0)) 
           & (IData)(wasmetal_core__DOT___036241_));
    vlSelf->wasmetal_core__DOT___058948_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                               << 3U)) 
                                                           | ((8U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0)) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___017498_)))))))));
    vlSelf->wasmetal_core__DOT___058942_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017471_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_he63183d7__0)))))));
    wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036096_) 
           & (IData)(wasmetal_core__DOT___036121_));
    wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036203_) 
           & (IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___017473_) {
        vlSelf->wasmetal_core__DOT___058949_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017471_))));
        vlSelf->wasmetal_core__DOT___058943_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___058949_ = (1U 
                                                & (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                           << 1U)) 
                                                       | (IData)(__VdfgTmp_he63183d7__0)))));
        vlSelf->wasmetal_core__DOT___058943_ = (1U 
                                                & (0x7f00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O)) 
                                                       | (IData)(__VdfgTmp_he967bd3f__0)))));
    }
    vlSelf->__VdfgTmp_h74f09674__0 = (((IData)(vlSelf->wasmetal_core__DOT___058942_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058943_));
    wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036097_) 
           & (IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___016555_) {
        if (vlSelf->wasmetal_core__DOT___016554_) {
            vlSelf->wasmetal_core__DOT___058563_ = 
                (1U & (1U >> (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hc0955a68__0)))));
            vlSelf->wasmetal_core__DOT___016585_ = 
                (1U & (1U >> (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___058137_))))));
        } else {
            vlSelf->wasmetal_core__DOT___058563_ = 
                (1U & (IData)(wasmetal_core__DOT___016602_));
            vlSelf->wasmetal_core__DOT___016585_ = 
                (1U & (IData)(wasmetal_core__DOT___016593_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___058563_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016602_));
        vlSelf->wasmetal_core__DOT___016585_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016593_));
    }
    vlSelf->__VdfgTmp_h4cc4790a__0 = (((IData)(vlSelf->wasmetal_core__DOT___058563_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016585_));
    vlSelf->wasmetal_core__DOT___016586_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd5ff8c3b__0))))
                                                    : (IData)(wasmetal_core__DOT___016558_))
                                                   : (IData)(wasmetal_core__DOT___016558_)));
    vlSelf->__VdfgTmp_h6047dcd2__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___016585_))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___016586_)))));
    wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1cf51478__0)) 
           & (IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036098_) 
           & (IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127979___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027528_))))));
    wasmetal_core__DOT____Vcellout___128833___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3aabb4dd__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1cf51478__0)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036203_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hefd4f1fe__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036241_)))));
    wasmetal_core__DOT___036260_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h3aabb4dd__0)) 
                                    & (IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128818___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)) 
                                                        << 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___036098_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036097_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036096_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036121_)))));
    wasmetal_core__DOT___036125_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)) 
                                    & (IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___060983_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060981_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127979___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060892_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060887_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127979___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060803_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___127979___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    wasmetal_core__DOT___060715_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127979___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    wasmetal_core__DOT___016567_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016564_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128833___O))))))));
    wasmetal_core__DOT___016581_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128833___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016647_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016644_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128833___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016615_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128833___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h9711c1d2__0)) 
           & (IData)(wasmetal_core__DOT___036260_));
    vlSelf->__VdfgTmp_ha3f8ca93__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff007f7f0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                           << 1U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0)) 
                                                              << 3U)) 
                                                          | (IData)(__VdfgTmp_he967bd3f__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017513_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                             << 3U)) 
                                                         | (IData)(__VdfgTmp_h56377d30__0)))))));
    vlSelf->__VdfgTmp_ha61a6e02__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                           << 4U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017513_) 
                                                           << 3U) 
                                                          | (IData)(__VdfgTmp_h56377d30__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017527_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                             << 2U)) 
                                                         | (IData)(__VdfgTmp_h823d6b3b__0)))))));
    vlSelf->__VdfgTmp_hac5f758c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017527_) 
                                                           << 3U) 
                                                          | (IData)(__VdfgTmp_h823d6b3b__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017544_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                             << 1U)) 
                                                         | (IData)(__VdfgTmp_hea8c747f__0)))))));
    vlSelf->__VdfgTmp_h6c11e1cc__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017544_) 
                                                           << 3U) 
                                                          | (IData)(__VdfgTmp_hea8c747f__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128818___O)) 
                                                         | (IData)(__VdfgTmp_hed321262__0)))))));
    vlSelf->wasmetal_core__DOT___058985_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                               << 1U)) 
                                                           | ((8U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)) 
                                                                  << 3U)) 
                                                              | (IData)(__VdfgTmp_hed321262__0)))))));
    wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036100_) 
           & (IData)(wasmetal_core__DOT___036125_));
    wasmetal_core__DOT___060805_ = (1U & (IData)((0xff1fff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___060803_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfff4ff0000000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9d165bb7__0))))))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019202_)))))))));
    wasmetal_core__DOT___060723_ = (1U & (IData)((0xff1fff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___060715_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfff4ff0000000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb9d2a0bf__0))))))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019202_)))))))));
    wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h84efc1e5__0)) 
           & (IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hc81f4faf__0)) 
           & (IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___060862_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___019222_)
                                                   ? 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xeU 
                                                            >> 
                                                            (((IData)(wasmetal_core__DOT___060810_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h55155be3__0)))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0xe00U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___060805_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060804_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007874_)))))))))
                                                   : 
                                                  (0xc5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019219_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xffffb0b0ff00ff00ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060825_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055410_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060824_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))))))))));
    if (vlSelf->wasmetal_core__DOT___016555_) {
        if (vlSelf->wasmetal_core__DOT___016554_) {
            vlSelf->wasmetal_core__DOT___016572_ = 
                (1U & (1U >> (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hefd4f1fe__0)))));
            wasmetal_core__DOT___016571_ = (1U & (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xe0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9c126c52__0)))));
        } else {
            vlSelf->wasmetal_core__DOT___016572_ = 
                (1U & (IData)(wasmetal_core__DOT___016567_));
            wasmetal_core__DOT___016571_ = (1U & (IData)(wasmetal_core__DOT___016581_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___016572_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016567_));
        wasmetal_core__DOT___016571_ = (1U & (IData)(wasmetal_core__DOT___016581_));
    }
    vlSelf->__VdfgTmp_h52207b53__0 = (((IData)(vlSelf->wasmetal_core__DOT___016572_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016571_));
    wasmetal_core__DOT___016639_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1cf51478__0))))
                                               : (IData)(wasmetal_core__DOT___016647_))
                                           : (IData)(wasmetal_core__DOT___016647_)));
    vlSelf->__VdfgTmp_hc5bb64fc__0 = (((IData)(wasmetal_core__DOT___016571_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016639_));
    vlSelf->wasmetal_core__DOT___016607_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3aabb4dd__0))))
                                                    : (IData)(wasmetal_core__DOT___016615_))
                                                   : (IData)(wasmetal_core__DOT___016615_)));
    vlSelf->__VdfgTmp_he0d8c702__0 = (((IData)(wasmetal_core__DOT___016639_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016607_));
    wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1cfd4ffd__0)) 
           & (IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036078_) 
           & (IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127980___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027533_))))));
    wasmetal_core__DOT____Vcellout___128834___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hee3b5d3c__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1cfd4ffd__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h84efc1e5__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h9711c1d2__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036260_)))));
    vlSelf->wasmetal_core__DOT___036210_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hee3b5d3c__0)) 
                                            & (IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128819___O 
        = (((8U & ((0x3affU >> (IData)(vlSelf->__VdfgTmp_h40a80dc0__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036078_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hc81f4faf__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___036100_)))) 
           ^ (((IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036125_)))));
    vlSelf->wasmetal_core__DOT___036104_ = ((0x3affU 
                                             >> (IData)(vlSelf->__VdfgTmp_h40a80dc0__0)) 
                                            & (IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__));
    __VdfgTmp_h237a6a81__0 = ((4U & ((IData)((0x77070000ffff0000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061217_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127980___O) 
                                                                  >> 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___061218_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_)));
    __VdfgTmp_hd985bb83__0 = ((4U & ((IData)((0x77070000ffff0000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061151_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___127980___O)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___061152_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_)));
    __VdfgTmp_hc59b0ae4__0 = ((2U & ((1U >> (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                              << 1U) 
                                             | (IData)(vlSelf->wasmetal_core__DOT___061071_))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0x77070000ffff0000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___061070_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127980___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___019280_))))))))));
    wasmetal_core__DOT___061305_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061303_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127980___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    vlSelf->wasmetal_core__DOT___016623_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015435_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___128834___O))))))));
    vlSelf->wasmetal_core__DOT___016635_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016632_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128834___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___016694_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015491_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128834___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___016662_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128834___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128835___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1f9a82f6__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036210_));
    wasmetal_core__DOT___058973_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                    & (IData)((0xff00ff00bfbf0000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017569_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h624ea096__0)))))));
    vlSelf->__VdfgTmp_h15aa6b6f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                           << 3U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc81f4faf__0)) 
                                                              << 3U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h44742984__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017660_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb82ac2db__0)))))));
    vlSelf->__VdfgTmp_hdb9ea8ba__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017660_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb82ac2db__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x3a00U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h40a80dc0__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h703c2d50__0)))))));
    wasmetal_core__DOT___128820___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_had382f57__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036104_));
    vlSelf->wasmetal_core__DOT___061275_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___061215_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xe00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                              << 3U) 
                                                                             | (IData)(__VdfgTmp_h237a6a81__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(wasmetal_core__DOT___061224_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb48e4863__0)))))))))))));
    vlSelf->wasmetal_core__DOT___061192_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061162_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___061133_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> 
                                                                            (((IData)(wasmetal_core__DOT___061158_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd485fb84__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xe00U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                               << 3U) 
                                                                              | (IData)(__VdfgTmp_hd985bb83__0))))))))))));
    vlSelf->wasmetal_core__DOT___061110_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061081_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfacc0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061052_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061051_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061050_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> 
                                                                            (((IData)(wasmetal_core__DOT___061077_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061076_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_hc59b0ae4__0))))))))))));
    wasmetal_core__DOT___128835___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h2a76d0fc__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128835___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___058986_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                   ? 
                                                  (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017569_)))
                                                   : 
                                                  (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                           << 3U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h624ea096__0))))));
    vlSelf->__VdfgTmp_hcb62e82f__0 = (((IData)(vlSelf->wasmetal_core__DOT___058985_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058986_));
    wasmetal_core__DOT___058974_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                           ? (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (1U 
                                                  & (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hc81f4faf__0)))))
                                           : (0xbf00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                         << 2U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h44742984__0))))));
    vlSelf->__VdfgTmp_h7385dfc5__0 = (((IData)(wasmetal_core__DOT___058973_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058974_));
    wasmetal_core__DOT___128820___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hdd2d87f1__0)) 
           & (IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___016606_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9711c1d2__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___016623_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___016623_)));
    vlSelf->__VdfgTmp_h27d7faf5__0 = (((IData)(vlSelf->wasmetal_core__DOT___016607_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016606_));
    wasmetal_core__DOT___016627_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h84efc1e5__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___016635_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___016635_)));
    vlSelf->__VdfgTmp_h04ff9270__0 = (((IData)(wasmetal_core__DOT___016606_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016627_));
    wasmetal_core__DOT___016687_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1cfd4ffd__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___016694_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___016694_)));
    vlSelf->__VdfgTmp_hb1afd8c5__0 = (((IData)(wasmetal_core__DOT___016627_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016687_));
    wasmetal_core__DOT___016654_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hee3b5d3c__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___016662_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___016662_)));
    vlSelf->__VdfgTmp_h5f559dac__0 = (((IData)(wasmetal_core__DOT___016687_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016654_));
    wasmetal_core__DOT___128835___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hdbf08427__0)) 
           & (IData)(wasmetal_core__DOT___128835___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128820___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036082_) 
           & (IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127981___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027537_))))));
    wasmetal_core__DOT____Vcellout___128835___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1758afa1__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hdbf08427__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2a76d0fc__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1f9a82f6__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128835___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128835___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128835___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036210_)))));
    wasmetal_core__DOT___036214_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h1758afa1__0)) 
                                    & (IData)(wasmetal_core__DOT___128835___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128820___O = (
                                                   ((8U 
                                                     & ((0x3affU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3b293f2f__0)) 
                                                        << 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___036082_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdd2d87f1__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_had382f57__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036104_)))));
    wasmetal_core__DOT___036108_ = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_h3b293f2f__0)) 
                                    & (IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___061017_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061012_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127981___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060931_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060929_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127981___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060850_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060848_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___127981___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    __VdfgTmp_h1ff7b9c3__0 = ((2U & ((IData)((0xfff8888800000000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060758_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127981___O) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___019283_));
    wasmetal_core__DOT___016671_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016668_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128835___O))))))));
    wasmetal_core__DOT___016683_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016680_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128835___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016739_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015486_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128835___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016709_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016706_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128835___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128836___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hb48d784b__0)) 
           & (IData)(wasmetal_core__DOT___036214_));
    vlSelf->__VdfgTmp_hea1901c2__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                           << 1U)) 
                                                       | ((8U 
                                                           & ((0x3a00U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h40a80dc0__0)) 
                                                              << 3U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h703c2d50__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_had382f57__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb3e763f1__0)))))));
    vlSelf->__VdfgTmp_h214cf44d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                           << 4U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_had382f57__0)) 
                                                              << 3U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb3e763f1__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hdd2d87f1__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0a1cab09__0)))))));
    vlSelf->__VdfgTmp_h11c34da7__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                           << 3U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdd2d87f1__0)) 
                                                              << 3U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h0a1cab09__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017606_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h98026846__0)))))));
    vlSelf->__VdfgTmp_hdf3a557f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017606_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h98026846__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x3a00U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h3b293f2f__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128820___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9f21faf7__0)))))));
    wasmetal_core__DOT___059007_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                    & (IData)((0xff00ff00bfbf0000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                          << 1U)) 
                                                      | ((8U 
                                                          & ((0x3a00U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3b293f2f__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9f21faf7__0)))))));
    wasmetal_core__DOT___128821___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h8afeda64__0)) 
           & (IData)(wasmetal_core__DOT___036108_));
    wasmetal_core__DOT___061356_ = (1U & (IData)((0xf0f0f5f5ff00ff33ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___060805_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___060850_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060804_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___060849_)))))))));
    wasmetal_core__DOT___128836___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hf4473e75__0)) 
           & (IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128821___DOT__CO__BRA__1__KET__ 
        = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hfc02ca5b__0)) 
           & (IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___016653_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1f9a82f6__0))))
                                               : (IData)(wasmetal_core__DOT___016671_))
                                           : (IData)(wasmetal_core__DOT___016671_)));
    vlSelf->__VdfgTmp_hfa0a9622__0 = (((IData)(wasmetal_core__DOT___016654_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016653_));
    wasmetal_core__DOT___016675_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2a76d0fc__0))))
                                               : (IData)(wasmetal_core__DOT___016683_))
                                           : (IData)(wasmetal_core__DOT___016683_)));
    vlSelf->__VdfgTmp_hfccc26d7__0 = (((IData)(wasmetal_core__DOT___016653_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016675_));
    wasmetal_core__DOT___016732_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hdbf08427__0))))
                                               : (IData)(wasmetal_core__DOT___016739_))
                                           : (IData)(wasmetal_core__DOT___016739_)));
    vlSelf->__VdfgTmp_h6fb1c908__0 = (((IData)(wasmetal_core__DOT___016675_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016732_));
    wasmetal_core__DOT___016701_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1758afa1__0))))
                                               : (IData)(wasmetal_core__DOT___016709_))
                                           : (IData)(wasmetal_core__DOT___016709_)));
    vlSelf->__VdfgTmp_h23178df2__0 = (((IData)(wasmetal_core__DOT___016732_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016701_));
    wasmetal_core__DOT___128836___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h112e4f0e__0)) 
           & (IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128821___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h6dc90017__0)) 
           & (IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127982___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027542_))))));
    wasmetal_core__DOT____Vcellout___128836___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he6b298f6__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h112e4f0e__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf4473e75__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb48d784b__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036214_)))));
    wasmetal_core__DOT___036218_ = ((7U >> (IData)(vlSelf->__VdfgTmp_he6b298f6__0)) 
                                    & (IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128821___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h75855164__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6dc90017__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((0x3affU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc02ca5b__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8afeda64__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036108_)))));
    wasmetal_core__DOT___036112_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h75855164__0)) 
                                    & (IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___061268_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061260_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127982___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061184_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061178_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___127982___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061101_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127982___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    wasmetal_core__DOT___061334_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061332_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127982___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___016717_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015481_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128836___O))))))));
    wasmetal_core__DOT___016728_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015501_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128836___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016763_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016760_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128836___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016774_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015511_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128836___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128837___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h4ee6c9c0__0)) 
           & (IData)(wasmetal_core__DOT___036218_));
    wasmetal_core__DOT___059002_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                    & (IData)((0xff00ff00bfbf0000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8afeda64__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hba893859__0)))))));
    __VdfgTmp_he0568e2c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                & (IData)((0xff00ff00bfbf0000ULL 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                << 5U) 
                                               | ((0x10U 
                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                      << 3U)) 
                                                  | ((8U 
                                                      & ((0x3a00U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hfc02ca5b__0)) 
                                                         << 3U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h9bcd87c8__0))))))) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                ? (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h6dc90017__0)))))
                                                : (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h6331a531__0)))))));
    vlSelf->__VdfgTmp_h64c7108d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                           << 2U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6dc90017__0)) 
                                                              << 3U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6331a531__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h75855164__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128821___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h155f9d55__0)))))));
    vlSelf->wasmetal_core__DOT___059047_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                               << 1U)) 
                                                           | ((8U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h75855164__0)) 
                                                                  << 3U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h155f9d55__0)))))));
    wasmetal_core__DOT___128822___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1a8efff9__0)) 
           & (IData)(wasmetal_core__DOT___036112_));
    wasmetal_core__DOT___061103_ = (1U & (IData)((0xff1fffULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061101_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfafcf0f000000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h91f4b3ba__0))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))))));
    wasmetal_core__DOT___061424_ = (1U & (IData)((0xf0f0f5f5ff00ff33ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061305_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___061334_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061304_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061333_)))))))));
    wasmetal_core__DOT___128837___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h8a1979d6__0)) 
           & (IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___059008_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                           ? (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (1U 
                                                  & (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h8afeda64__0)))))
                                           : (0xbf00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                         << 3U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_hba893859__0))))));
    vlSelf->__VdfgTmp_hc369107b__0 = (((IData)(wasmetal_core__DOT___059007_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___059008_));
    wasmetal_core__DOT___059003_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                           ? (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (1U 
                                                  & (0x3a00U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hfc02ca5b__0)))))
                                           : (0xbf00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                         << 2U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h9bcd87c8__0))))));
    vlSelf->__VdfgTmp_h5cb81b0a__0 = (((IData)(wasmetal_core__DOT___059002_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___059003_));
    wasmetal_core__DOT___128822___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h003f7a85__0)) 
           & (IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___019251_ = (1U & (0xe0eeeeU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___061103_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___061102_)))))));
    wasmetal_core__DOT___016700_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hb48d784b__0))))
                                               : (IData)(wasmetal_core__DOT___016717_))
                                           : (IData)(wasmetal_core__DOT___016717_)));
    vlSelf->__VdfgTmp_hdbda1ab6__0 = (((IData)(wasmetal_core__DOT___016701_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016700_));
    wasmetal_core__DOT___016721_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf4473e75__0))))
                                               : (IData)(wasmetal_core__DOT___016728_))
                                           : (IData)(wasmetal_core__DOT___016728_)));
    vlSelf->__VdfgTmp_h2d6cb346__0 = (((IData)(wasmetal_core__DOT___016700_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016721_));
    wasmetal_core__DOT___016755_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h112e4f0e__0))))
                                               : (IData)(wasmetal_core__DOT___016763_))
                                           : (IData)(wasmetal_core__DOT___016763_)));
    vlSelf->__VdfgTmp_hefec7bb7__0 = (((IData)(wasmetal_core__DOT___016721_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016755_));
    wasmetal_core__DOT___016767_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he6b298f6__0))))
                                               : (IData)(wasmetal_core__DOT___016774_))
                                           : (IData)(wasmetal_core__DOT___016774_)));
    vlSelf->__VdfgTmp_h8b17c158__0 = (((IData)(wasmetal_core__DOT___016755_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016767_));
    wasmetal_core__DOT___128837___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hc38ac7a3__0)) 
           & (IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128822___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h6f76189e__0)) 
           & (IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127983___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027546_))))));
    wasmetal_core__DOT____Vcellout___128837___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hebdd5702__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc38ac7a3__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8a1979d6__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4ee6c9c0__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036218_)))));
    wasmetal_core__DOT___036223_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hebdd5702__0)) 
                                    & (IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128822___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___036092_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6f76189e__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h003f7a85__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1a8efff9__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036112_)))));
    wasmetal_core__DOT___036117_ = ((IData)(vlSelf->wasmetal_core__DOT___036092_) 
                                    & (IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__2__KET__));
    __VdfgTmp_h860e6d13__0 = (((IData)(vlSelf->wasmetal_core__DOT___061015_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                           << 2U) | 
                                          ((((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                             & (IData)(
                                                       (0xfffefff0ff00ff00ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (0xac00U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h2577a83c__0))))))))))))) 
                                            << 1U) 
                                           | (1U & 
                                              (8U >> 
                                               ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127983___O) 
                                                    >> 2U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___019280_))))))));
    wasmetal_core__DOT___060936_ = (1U & (IData)((0xeee00000fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060935_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127983___O) 
                                                                         >> 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___019280_))) 
                                                                   << 1U)) 
                                                               | ((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                  & (IData)(
                                                                            (0xfffefff0ff00ff00ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xac00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd69bf43a__0)))))))))))))))))))));
    wasmetal_core__DOT___060854_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060852_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___127983___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060764_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127983___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    wasmetal_core__DOT___016786_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015506_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128837___O))))))));
    wasmetal_core__DOT___016794_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015516_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128837___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016808_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016805_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128837___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016819_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015496_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128837___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128838___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h0e9f92ff__0)) 
           & (IData)(wasmetal_core__DOT___036223_));
    vlSelf->wasmetal_core__DOT___059052_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128822___O) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1a8efff9__0)) 
                                                                  << 3U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb895011c__0)))))));
    wasmetal_core__DOT___059061_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                    & (IData)((0xff00ff00bfbf0000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128822___O) 
                                                          << 3U)) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h003f7a85__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_heacb01d3__0)))))));
    __VdfgTmp_h5c0f2a5b__0 = ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128822___O) 
                                     << 1U)) | (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf8ffU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0))))));
    if (vlSelf->wasmetal_core__DOT___017473_) {
        vlSelf->wasmetal_core__DOT___059046_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h1a8efff9__0))))));
        vlSelf->wasmetal_core__DOT___059051_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h003f7a85__0))))));
        wasmetal_core__DOT___018071_ = (1U & (1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (1U 
                                                  & (4U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014722_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___015394_)))))));
        wasmetal_core__DOT___059062_ = (1U & (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (1U 
                                                  & (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h6f76189e__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___059046_ = (1U 
                                                & (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128822___O) 
                                                           << 3U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb895011c__0)))));
        vlSelf->wasmetal_core__DOT___059051_ = (1U 
                                                & (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128822___O) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_heacb01d3__0)))));
        wasmetal_core__DOT___018071_ = (1U & (0x40ffU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & (IData)(wasmetal_core__DOT____Vcellout___128822___O)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (0xf8ffU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)))))))));
        wasmetal_core__DOT___059062_ = (1U & (0xbf00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                   << 4U) 
                                                  | (IData)(__VdfgTmp_h5c0f2a5b__0))));
    }
    wasmetal_core__DOT____Vcellout___128823___O = ((IData)(vlSelf->wasmetal_core__DOT___036093_) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___036093_) 
                                                      & (IData)(wasmetal_core__DOT___036117_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___036117_)));
    wasmetal_core__DOT___061383_ = (1U & (IData)((0xef0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061348_) 
                                                    << 5U) 
                                                   | (IData)(__VdfgTmp_h860e6d13__0)))));
    wasmetal_core__DOT___061018_ = (1U & (IData)((0xef0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 5U) 
                                                   | (IData)(__VdfgTmp_h860e6d13__0)))));
    vlSelf->__VdfgTmp_h1772264d__0 = ((2U & ((IData)(
                                                     (0xf0fcf0f5ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((IData)(
                                                                            (0xfff00000eeee0000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060893_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060892_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___060891_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060890_)))))))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060910_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & (IData)(
                                                                                (0xffffb0b0ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060908_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060907_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))))))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___019221_)
                                                ? (IData)(
                                                          (0xeeee0000fff0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019228_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xdd0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060920_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060919_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060918_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060917_)))))))) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((0xeU 
                                                                             >> 
                                                                             (((IData)(wasmetal_core__DOT___060931_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060930_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_))))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (8U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 1U) 
                                                                               | (IData)(wasmetal_core__DOT___060936_)))))))))))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019229_)))));
    vlSelf->wasmetal_core__DOT___060861_ = (1U & (IData)(
                                                         (0x1111000f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xdd0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060835_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060834_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060833_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060832_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xe00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                              << 3U) 
                                                                             | (((IData)(wasmetal_core__DOT___060854_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h798d913c__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(wasmetal_core__DOT___060850_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060849_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_))))))))))))));
    __VdfgTmp_h410f7c75__0 = ((4U & ((IData)((0xff1fff00000000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                   << 5U) 
                                                  | (((IData)(wasmetal_core__DOT___060764_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xfff4ff0000000000ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4a046d69__0))))))))))) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___019202_)))))))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___060766_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_)));
    wasmetal_core__DOT___128838___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h645aaafb__0)) 
           & (IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h4ab5d99d__0 = (((IData)(vlSelf->wasmetal_core__DOT___059052_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___059051_));
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b25__05d 
        = (1U & (0xb00U >> ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128823___O) 
                                   << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058153_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___058108_))))));
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b24__05d 
        = (1U & (IData)((0x30303030aaff0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128823___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058153_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058108_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014722_)))))))));
    wasmetal_core__DOT___061387_ = (1U & (0xff1fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                            << 4U) 
                                           | (((IData)(wasmetal_core__DOT___061383_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(
                                                                (0xf0f0f5f5ff00ff33ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___060983_) 
                                                                         << 3U) 
                                                                        | (((IData)(wasmetal_core__DOT___061017_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060982_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___061016_)))))))) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___019221_)))))));
    wasmetal_core__DOT___061021_ = (1U & (IData)((0xfff100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___061018_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061017_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061016_)))))))));
    wasmetal_core__DOT___060942_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060941_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1772264d__0))));
    wasmetal_core__DOT___060864_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060863_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060862_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___060861_))))));
    vlSelf->__VdfgTmp_hc5bdda4d__0 = ((2U & ((IData)(
                                                     (0xf0fcf0faULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((IData)(
                                                                            (0xfff00000eeee0000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060724_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060723_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___060722_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060721_)))))))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060729_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & (IData)(
                                                                                (0x4f4f00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060727_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055239_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043901_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xef0000ffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060770_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060761_) 
                                                                              << 2U) 
                                                                             | (IData)(__VdfgTmp_h1ff7b9c3__0)))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xe00U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                            << 3U) 
                                                                           | (IData)(__VdfgTmp_h410f7c75__0)))))))))))));
    wasmetal_core__DOT____Vcellout___127984___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      ((((IData)(vlSelf->wasmetal_core__DOT___027566_)
                                                          ? (IData)(wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__)
                                                          : (IData)(vlSelf->wasmetal_core__DOT___027484_)) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027550_))))));
    wasmetal_core__DOT___016779_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h4ee6c9c0__0))))
                                               : (IData)(wasmetal_core__DOT___016786_))
                                           : (IData)(wasmetal_core__DOT___016786_)));
    vlSelf->__VdfgTmp_h83a58712__0 = (((IData)(wasmetal_core__DOT___016767_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016779_));
    wasmetal_core__DOT___016778_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8a1979d6__0))))
                                               : (IData)(wasmetal_core__DOT___016794_))
                                           : (IData)(wasmetal_core__DOT___016794_)));
    vlSelf->__VdfgTmp_h44d9a03d__0 = (((IData)(wasmetal_core__DOT___016779_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016778_));
    wasmetal_core__DOT___016800_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hc38ac7a3__0))))
                                               : (IData)(wasmetal_core__DOT___016808_))
                                           : (IData)(wasmetal_core__DOT___016808_)));
    vlSelf->__VdfgTmp_hc66d6698__0 = (((IData)(wasmetal_core__DOT___016778_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016800_));
    wasmetal_core__DOT___016812_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hebdd5702__0))))
                                               : (IData)(wasmetal_core__DOT___016819_))
                                           : (IData)(wasmetal_core__DOT___016819_)));
    vlSelf->__VdfgTmp_hc9aeb4c0__0 = (((IData)(wasmetal_core__DOT___016800_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016812_));
    wasmetal_core__DOT___128838___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h6560f9f5__0)) 
           & (IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__1__KET__));
    __VdfgTmp_h6eb6be0b__0 = (((IData)(wasmetal_core__DOT___059061_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059062_));
    wasmetal_core__DOT___036152_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b25__05d))));
    wasmetal_core__DOT___036151_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b24__05d))));
    vlSelf->__VdfgTmp_h167c6955__0 = ((2U & ((IData)(
                                                     (0x11110000000fULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060991_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0x3a00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                       << 3U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h8e4351c5__0))) 
                                                                    << 2U)) 
                                                                | ((2U 
                                                                    & ((0xeU 
                                                                        >> 
                                                                        (((IData)(wasmetal_core__DOT___060987_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_haf42252b__0)))) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (0xe00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 3U) 
                                                                          | (((IData)(wasmetal_core__DOT___060983_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060982_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_))))))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfe0000ffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___061021_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xdd0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061001_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061000_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060999_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060998_)))))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0x11f00000U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hb8dfd2b5__0)))))))))))));
    wasmetal_core__DOT___025174_ = (1U & (9U >> (((IData)(wasmetal_core__DOT___060942_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025134_))));
    wasmetal_core__DOT___025173_ = (1U & (9U >> (((IData)(wasmetal_core__DOT___060864_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025133_))));
    wasmetal_core__DOT___060777_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060776_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc5bdda4d__0))));
    wasmetal_core__DOT___061433_ = (1U & (0xf00eeU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((0xefefef00U 
                                                         >> 
                                                         (((IData)(wasmetal_core__DOT___061424_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061348_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((0xf7f0000U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019282_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127984___O) 
                                                                                >> 3U))))))) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___019284_)))))) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xf0f0000ccaaULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((0xf4f400ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061323_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061324_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061321_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061322_)))))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h246938f7__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055853_)))))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xeef0f000000000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                          << 4U) 
                                                                         | (((IData)(wasmetal_core__DOT___061310_) 
                                                                             << 3U) 
                                                                            | ((4U 
                                                                                & ((IData)(
                                                                                (0xeee00000fff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061327_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061328_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061329_)))))))) 
                                                                                << 2U)) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h885d71fc__0))))))))))))));
    wasmetal_core__DOT___061267_ = (1U & (IData)((0xffffe0e0ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060710_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061264_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127984___O) 
                                                                         >> 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___019280_))) 
                                                                   << 1U)) 
                                                               | ((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                  & (IData)(
                                                                            (0xfffefff0ff00ff00ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xac00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb79381c2__0)))))))))))))))))))));
    __VdfgTmp_h188a23cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___061181_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                           << 2U) | 
                                          ((((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                             & (IData)(
                                                       (0xfffefff0ff00ff00ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (0xac00U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_hdf1f98b8__0))))))))))))) 
                                            << 1U) 
                                           | (1U & 
                                              (8U >> 
                                               ((2U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127984___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___019280_))))))));
    wasmetal_core__DOT___019250_ = (1U & (IData)((0xffffe0e0ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060710_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056168_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127984___O) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___019280_))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0xfef00000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0xfafcf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1c7a54d6__0))))))) 
                                                                                << 1U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))))))))))));
    wasmetal_core__DOT___061335_ = ((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                    & (IData)((0xf8ff00ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___019284_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019282_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127984___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT____Vcellout___128838___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbe619ad7__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6560f9f5__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h645aaafb__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h0e9f92ff__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036223_)))));
    wasmetal_core__DOT___036227_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hbe619ad7__0)) 
                                    & (IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128824___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036151_)) 
           & (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b24__05d));
    wasmetal_core__DOT___061027_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___061026_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h167c6955__0))));
    wasmetal_core__DOT___025171_ = (1U & (9U >> (((IData)(wasmetal_core__DOT___060777_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025131_))));
    wasmetal_core__DOT___061271_ = (1U & (0x33fa0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___061268_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___061267_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___061266_)))))));
    wasmetal_core__DOT___061185_ = (1U & (IData)((0xef0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 5U) 
                                                   | (IData)(__VdfgTmp_h188a23cd__0)))));
    wasmetal_core__DOT___061398_ = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(
                                                                (0xffff0f0f00ffeeeeULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___019251_) 
                                                                         << 3U) 
                                                                        | (((IData)(wasmetal_core__DOT___019250_) 
                                                                            << 2U) 
                                                                           | (IData)(__VdfgTmp_hc59b0ae4__0))))))) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___019222_)))));
    vlSelf->wasmetal_core__DOT___061109_ = ((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                            & (IData)(
                                                      (0x55553333000f000fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019253_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0x11f00000U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061099_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h54394b36__0))))) 
                                                                     << 2U)) 
                                                                 | (((IData)(wasmetal_core__DOT___019251_) 
                                                                     << 1U) 
                                                                    | (IData)(wasmetal_core__DOT___019250_)))))))));
    wasmetal_core__DOT___061338_ = (1U & (IData)((0xfff100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___061335_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061334_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061333_)))))))));
    wasmetal_core__DOT___016831_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016828_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128838___O))))))));
    wasmetal_core__DOT___016843_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016840_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128838___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016854_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015531_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128838___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016865_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128838___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128839___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h0abefb0b__0)) 
           & (IData)(wasmetal_core__DOT___036227_));
    wasmetal_core__DOT___128824___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036152_) ? (IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__0__KET__)
            : (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b25__05d));
    wasmetal_core__DOT___025175_ = (1U & (9U >> (((IData)(wasmetal_core__DOT___061027_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025135_))));
    wasmetal_core__DOT___127757___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___025171_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___025131_));
    vlSelf->wasmetal_core__DOT___061274_ = (1U & (0xff010000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___061271_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xdd0000f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061254_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061253_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061252_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061251_)))))))) 
                                                                << 1U)) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                               & (IData)(
                                                                         (0xfbfbff00ff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019273_) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd684d3d4__0)) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb7a13343__0)))))))))))));
    wasmetal_core__DOT___061188_ = (1U & (0xfe0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___061185_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___061184_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061183_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___019220_)))))));
    wasmetal_core__DOT___061112_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061111_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061110_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061109_))))));
    vlSelf->__VdfgTmp_h5501e8f9__0 = ((2U & ((IData)(
                                                     (0x11110000000fULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061314_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0x11f00000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055853_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h246938f7__0))))) 
                                                                    << 2U)) 
                                                                | ((2U 
                                                                    & ((0xeU 
                                                                        >> 
                                                                        (((IData)(wasmetal_core__DOT___061310_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h885d71fc__0)))) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (0xe00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 3U) 
                                                                          | (((IData)(wasmetal_core__DOT___061305_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061304_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_))))))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfe0000ffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___061338_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xdd0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061324_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061323_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061322_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061321_)))))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xef0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061330_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061329_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061328_))))))))))))))))));
    wasmetal_core__DOT___128839___DOT__CO__BRA__1__KET__ 
        = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hacb35d4c__0)) 
           & (IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128824___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
           & (IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128263___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___025173_) ? (IData)(wasmetal_core__DOT___127757___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___025133_));
    wasmetal_core__DOT___061277_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061276_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061275_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061274_))))));
    vlSelf->wasmetal_core__DOT___061191_ = (1U & (0xff010000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___061188_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xdd0000f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061172_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061169_)))))))) 
                                                                << 1U)) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                               & (IData)(
                                                                         (0xfbfbff00ff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019262_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019261_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_habd86bf6__0)))))))))))));
    vlSelf->wasmetal_core__DOT___025176_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061112_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025136_))));
    wasmetal_core__DOT___061344_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___061343_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5501e8f9__0))));
    wasmetal_core__DOT___016823_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h0e9f92ff__0))))
                                               : (IData)(wasmetal_core__DOT___016831_))
                                           : (IData)(wasmetal_core__DOT___016831_)));
    vlSelf->__VdfgTmp_hfbf01d74__0 = (((IData)(wasmetal_core__DOT___016812_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016823_));
    wasmetal_core__DOT___016835_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h645aaafb__0))))
                                               : (IData)(wasmetal_core__DOT___016843_))
                                           : (IData)(wasmetal_core__DOT___016843_)));
    vlSelf->__VdfgTmp_h5865698c__0 = (((IData)(wasmetal_core__DOT___016823_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016835_));
    wasmetal_core__DOT___016847_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h6560f9f5__0))))
                                               : (IData)(wasmetal_core__DOT___016854_))
                                           : (IData)(wasmetal_core__DOT___016854_)));
    vlSelf->__VdfgTmp_hd7617577__0 = (((IData)(wasmetal_core__DOT___016835_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016847_));
    wasmetal_core__DOT___016858_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hbe619ad7__0))))
                                               : (IData)(wasmetal_core__DOT___016865_))
                                           : (IData)(wasmetal_core__DOT___016865_)));
    vlSelf->__VdfgTmp_h72106b67__0 = (((IData)(wasmetal_core__DOT___016847_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016858_));
    wasmetal_core__DOT___128839___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1ae5646c__0)) 
           & (IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128824___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___036152_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036151_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | ((IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__0__KET__) 
                                                          << 1U))));
    wasmetal_core__DOT___036144_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                    & (IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128263___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___025174_) ? (IData)(wasmetal_core__DOT___128263___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___025134_));
    vlSelf->wasmetal_core__DOT___025178_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025138_))));
    wasmetal_core__DOT___061194_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061193_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061192_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061191_))))));
    vlSelf->wasmetal_core__DOT___025172_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061344_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025132_))));
    wasmetal_core__DOT___061435_ = (1U & (0xb0bbU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___061344_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061299_))))));
    wasmetal_core__DOT___061345_ = (1U & (0xb0bbU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___061344_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061299_))))));
    wasmetal_core__DOT____Vcellout___128839___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h98703c04__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1ae5646c__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((0x3affU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hacb35d4c__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h0abefb0b__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036227_)))));
    wasmetal_core__DOT___036232_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h98703c04__0)) 
                                    & (IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134206___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(wasmetal_core__DOT____Vcellout___128824___O))));
    wasmetal_core__DOT___128810___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(wasmetal_core__DOT____Vcellout___128824___O))));
    vlSelf->wasmetal_core__DOT___018075_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017495_)
                                                   ? 
                                                  (0xcccaccccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((8U 
                                                               >> 
                                                               (2U 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O)))))))
                                                   : 
                                                  (0xcccaccccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((8U 
                                                               >> 
                                                               (2U 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O)))))))));
    wasmetal_core__DOT___043014_ = (1U & (0x40U >> 
                                          ((4U & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                  << 2U)) 
                                           | ((2U & (IData)(wasmetal_core__DOT____Vcellout___128824___O)) 
                                              | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___128825___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
           & (IData)(wasmetal_core__DOT___036144_));
    vlSelf->wasmetal_core__DOT____Vcellout___127757___O 
        = ((((IData)(wasmetal_core__DOT___025175_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025174_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025173_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025171_)))) 
           ^ (((IData)(wasmetal_core__DOT___128263___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128263___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___127757___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___025164_ = ((IData)(wasmetal_core__DOT___025175_)
                                             ? (IData)(wasmetal_core__DOT___128263___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___025135_));
    vlSelf->wasmetal_core__DOT___025177_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061194_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025137_))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135195___A 
        = ((0x3fff8000U & ((- (IData)((1U & (0x4fU 
                                             >> (((IData)(wasmetal_core__DOT___061435_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___043541_))))))) 
                           << 0xfU)) | ((0x4000U & 
                                         ((0x4fU >> 
                                           (((IData)(wasmetal_core__DOT___061435_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___061212_)))) 
                                          << 0xeU)) 
                                        | ((0x2000U 
                                            & ((0x4fU 
                                                >> 
                                                (((IData)(wasmetal_core__DOT___061435_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___061130_)))) 
                                               << 0xdU)) 
                                           | ((0x1000U 
                                               & ((0x4fU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___061435_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___061049_)))) 
                                                  << 0xcU)) 
                                              | ((0x800U 
                                                  & ((0x4fU 
                                                      >> 
                                                      (((IData)(wasmetal_core__DOT___061435_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___060960_)))) 
                                                     << 0xbU)) 
                                                 | ((0x400U 
                                                     & ((0x4fU 
                                                         >> 
                                                         (((IData)(wasmetal_core__DOT___061435_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___060884_)))) 
                                                        << 0xaU)) 
                                                    | ((0x200U 
                                                        & ((0x4fU 
                                                            >> 
                                                            (((IData)(wasmetal_core__DOT___061435_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___060798_)))) 
                                                           << 9U)) 
                                                       | ((0x100U 
                                                           & ((0x4fU 
                                                               >> 
                                                               (((IData)(wasmetal_core__DOT___061435_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___060692_)))) 
                                                              << 8U)) 
                                                          | ((0x80U 
                                                              & ((0x4fU 
                                                                  >> 
                                                                  (((IData)(wasmetal_core__DOT___061435_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___061299_)))) 
                                                                 << 7U)) 
                                                             | ((0x40U 
                                                                 & ((0x1f11U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                       << 3U) 
                                                                      | (((IData)(wasmetal_core__DOT___061277_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061238_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                    << 6U)) 
                                                                | ((0x20U 
                                                                    & ((0x1f11U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                          << 3U) 
                                                                         | (((IData)(wasmetal_core__DOT___061194_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061145_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                       << 5U)) 
                                                                   | ((0x10U 
                                                                       & ((0x1f11U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                             << 3U) 
                                                                            | (((IData)(wasmetal_core__DOT___061112_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___061066_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                          << 4U)) 
                                                                      | ((8U 
                                                                          & ((0x1f11U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 3U) 
                                                                               | (((IData)(wasmetal_core__DOT___061027_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060977_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                             << 3U)) 
                                                                         | ((4U 
                                                                             & ((0x1f11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060942_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060907_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                                << 2U)) 
                                                                            | ((2U 
                                                                                & ((0x1f11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060864_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060824_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (0x1f11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060777_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043901_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054744_)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135195___B 
        = ((0x38000U & ((- (IData)((1U & (0x4fU >> 
                                          (((IData)(wasmetal_core__DOT___061345_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xcfafU 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___061433_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0x555533330f0f00ffULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055042_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055046_)))))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0x555533330f0f00ffULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055034_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055036_))))))))))))))))))))) 
                        << 0xfU)) | ((0x4000U & ((0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061345_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff0faa0aff0fcc0cULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061421_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061415_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___061224_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb48e4863__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4f400ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061253_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061254_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061251_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061252_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061215_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xffffeeee0f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xeU 
                                                                                >> (IData)(__VdfgTmp_h237a6a81__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(wasmetal_core__DOT___061267_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061266_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___061268_)))))))))))))))))))) 
                                                 << 0xeU)) 
                                     | ((0x2000U & 
                                         ((0x4fU >> 
                                           (((IData)(wasmetal_core__DOT___061345_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                << 1U) 
                                               | (1U 
                                                  & (IData)(
                                                            (0xff0faa0aff0fcc0cULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061410_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(
                                                                                (0xf0fccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061403_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___061158_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd485fb84__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4f400ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061172_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061169_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061170_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061133_)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xffffeeee0f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xeU 
                                                                                >> (IData)(__VdfgTmp_hd985bb83__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xef0fU 
                                                                                >> (IData)(__VdfgTmp_h188a23cd__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061183_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___061184_)))))))))))))))))))) 
                                          << 0xdU)) 
                                        | ((0x1000U 
                                            & ((0x4fU 
                                                >> 
                                                (((IData)(wasmetal_core__DOT___061345_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xcc00ffa0aaf0ffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                       << 4U) 
                                                                      | (((IData)(wasmetal_core__DOT___061398_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xff440f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061090_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010055_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061087_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061088_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061050_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061052_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061051_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff550f0f3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___061077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h54394b36__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061099_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061076_)))))))))))) 
                                                                                << 2U)) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054907_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054909_)))))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054898_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054901_)))))))))))))))))))) 
                                               << 0xcU)) 
                                           | ((0x800U 
                                               & ((0x4fU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___061345_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xcc00ffa0aaf0ffULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                          << 4U) 
                                                                         | (((IData)(wasmetal_core__DOT___061387_) 
                                                                             << 3U) 
                                                                            | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0faaaaccccff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xc5U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8e4351c5__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___060987_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf42252b__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4f400ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061000_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061001_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060998_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060999_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xee0fU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb8dfd2b5__0)))))))))) 
                                                                                << 2U)) 
                                                                               | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054862_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054866_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054861_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054865_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051491_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051496_)))))))))))))))))))) 
                                                  << 0xbU)) 
                                              | ((0x400U 
                                                  & ((0xbU 
                                                      >> 
                                                      (((IData)(wasmetal_core__DOT___061345_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xf3f5f0f000000000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                             << 3U) 
                                                                            | ((4U 
                                                                                & ((IData)(
                                                                                (0xf1f1000000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___061373_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061348_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___060936_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0f5f5ff00ff33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___060892_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060931_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061370_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060930_)))))))))))))))) 
                                                                                << 2U)) 
                                                                               | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054821_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054816_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054820_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054808_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054810_))))))))))))))))))) 
                                                     << 0xaU)) 
                                                 | ((0x200U 
                                                     & ((0xbU 
                                                         >> 
                                                         (((IData)(wasmetal_core__DOT___061345_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf3f5f0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfff01110fff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061348_) 
                                                                                << 5U) 
                                                                                | (((IData)(wasmetal_core__DOT___060854_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___061356_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h798d913c__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0faaaaccccff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019219_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___060810_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h55155be3__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4f400ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060834_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060835_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060832_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060833_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xee0fU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha2d50830__0))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054778_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054782_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054777_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054781_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054768_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054770_))))))))))))))))))) 
                                                        << 9U)) 
                                                    | ((0x100U 
                                                        & ((0xbU 
                                                            >> 
                                                            (((IData)(wasmetal_core__DOT___061345_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xf3f5f0f000000000ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf1f1000000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___061351_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xe00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061348_) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h410f7c75__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xffff2222fff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060761_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___060723_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060724_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h1ff7b9c3__0))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054675_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054688_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054674_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054706_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054705_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054698_))))))))))))))))))) 
                                                           << 8U)) 
                                                       | ((0x80U 
                                                           & ((0x4fU 
                                                               >> 
                                                               (((IData)(wasmetal_core__DOT___061345_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                    << 1U) 
                                                                   | (IData)(wasmetal_core__DOT___061344_)))) 
                                                              << 7U)) 
                                                          | ((0x40U 
                                                              & ((0x444fU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                    << 3U) 
                                                                   | (((IData)(wasmetal_core__DOT___061277_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___061238_))))) 
                                                                 << 6U)) 
                                                             | ((0x20U 
                                                                 & ((0x444fU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                       << 3U) 
                                                                      | (((IData)(wasmetal_core__DOT___061194_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___061145_))))) 
                                                                    << 5U)) 
                                                                | ((0x10U 
                                                                    & ((0x444fU 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                          << 3U) 
                                                                         | (((IData)(wasmetal_core__DOT___061112_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___061066_))))) 
                                                                       << 4U)) 
                                                                   | ((8U 
                                                                       & ((0x444fU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                             << 3U) 
                                                                            | (((IData)(wasmetal_core__DOT___061027_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060977_))))) 
                                                                          << 3U)) 
                                                                      | ((4U 
                                                                          & ((0x444fU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                                << 3U) 
                                                                               | (((IData)(wasmetal_core__DOT___060942_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060907_))))) 
                                                                             << 2U)) 
                                                                         | ((2U 
                                                                             & ((0x444fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060864_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060824_))))) 
                                                                                << 1U)) 
                                                                            | (1U 
                                                                               & (0x444fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060777_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043901_)))))))))))))))))))));
    wasmetal_core__DOT___016876_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015532_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128839___O))))))));
    wasmetal_core__DOT___016887_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015533_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128839___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016898_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015534_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128839___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016909_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015526_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128839___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128840___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h79cf8a49__0)) 
           & (IData)(wasmetal_core__DOT___036232_));
    wasmetal_core__DOT___134206___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134206___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___128825___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
           & (IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128264___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___025176_)
            ? (IData)(vlSelf->wasmetal_core__DOT___025164_)
            : (IData)(vlSelf->wasmetal_core__DOT___025136_));
    wasmetal_core__DOT___128840___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036180_) 
           & (IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___134206___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                          >> 3U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                             >> 2U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ 
                                                               ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                >> 1U)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(wasmetal_core__DOT____Vcellout___128824___O)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134206___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134206___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                             << 1U)))));
    wasmetal_core__DOT___037138_ = (IData)((((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                             >> 3U) 
                                            | (IData)(wasmetal_core__DOT___134206___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___128825___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
           & (IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128264___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___025177_)
            ? (IData)(wasmetal_core__DOT___128264___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___025137_));
    wasmetal_core__DOT___016869_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h0abefb0b__0))))
                                               : (IData)(wasmetal_core__DOT___016876_))
                                           : (IData)(wasmetal_core__DOT___016876_)));
    vlSelf->__VdfgTmp_hcacd7e7e__0 = (((IData)(wasmetal_core__DOT___016858_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016869_));
    wasmetal_core__DOT___016880_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0x3a00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hacb35d4c__0))))
                                               : (IData)(wasmetal_core__DOT___016887_))
                                           : (IData)(wasmetal_core__DOT___016887_)));
    vlSelf->__VdfgTmp_h1813ebc7__0 = (((IData)(wasmetal_core__DOT___016869_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016880_));
    wasmetal_core__DOT___016891_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1ae5646c__0))))
                                               : (IData)(wasmetal_core__DOT___016898_))
                                           : (IData)(wasmetal_core__DOT___016898_)));
    vlSelf->__VdfgTmp_ha74c2851__0 = (((IData)(wasmetal_core__DOT___016880_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016891_));
    wasmetal_core__DOT___016902_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h98703c04__0))))
                                               : (IData)(wasmetal_core__DOT___016909_))
                                           : (IData)(wasmetal_core__DOT___016909_)));
    vlSelf->__VdfgTmp_h06719132__0 = (((IData)(wasmetal_core__DOT___016891_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016902_));
    wasmetal_core__DOT___128840___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036181_) 
           & (IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128825___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128825___S) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036144_)))));
    wasmetal_core__DOT___036148_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                    & (IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128264___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___025178_)
            ? (IData)(wasmetal_core__DOT___128264___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___025138_));
    wasmetal_core__DOT____Vcellout___128840___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___036182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___036181_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036180_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h79cf8a49__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036232_)))));
    wasmetal_core__DOT___036236_ = ((IData)(vlSelf->wasmetal_core__DOT___036182_) 
                                    & (IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134207___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                 | (IData)(wasmetal_core__DOT___037138_)));
    wasmetal_core__DOT____Vcellout___128810___O = (
                                                   ((8U 
                                                     & ((~ (IData)(wasmetal_core__DOT____Vcellout___128825___O)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                             >> 3U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ 
                                                               ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                >> 2U)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ 
                                                                ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                 >> 1U)))))) 
                                                   ^ 
                                                   (1U 
                                                    | ((((~ 
                                                          ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                           >> 3U)) 
                                                         & (IData)(wasmetal_core__DOT___128810___DOT__CO__BRA__1__KET__)) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___128810___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (2U 
                                                             & ((~ 
                                                                 ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                  >> 1U)) 
                                                                << 1U))))));
    wasmetal_core__DOT___128826___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
           & (IData)(wasmetal_core__DOT___036148_));
    wasmetal_core__DOT___128264___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128264___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128264___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___128264___DOT__CO__BRA__0__KET__)));
    if (vlSelf->wasmetal_core__DOT___025172_) {
        vlSelf->wasmetal_core__DOT___025168_ = wasmetal_core__DOT___128264___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025168_;
        wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___025141_ = wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___025141_;
        wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___025145_ = wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025145_;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__1__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___025168_ = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___025141_ = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        vlSelf->wasmetal_core__DOT___025145_ = vlSelf->wasmetal_core__DOT___025132_;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
    }
    wasmetal_core__DOT___016921_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015542_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128840___O))))))));
    wasmetal_core__DOT___016929_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015589_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128840___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___017050_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128840___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___017062_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128840___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128841___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h8ba6f9f1__0)) 
           & (IData)(wasmetal_core__DOT___036236_));
    wasmetal_core__DOT___134207___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                  >> 1U) | (IData)(wasmetal_core__DOT___134207___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___017462_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128810___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127468___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128859___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___017463_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128810___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127468___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128859___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___018066_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128810___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127468___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128859___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___018065_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128810___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127468___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128859___O))))))));
    wasmetal_core__DOT___128826___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127758___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___025172_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___025178_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___025177_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025176_)))) 
           ^ (((IData)(wasmetal_core__DOT___128264___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025164_)));
    wasmetal_core__DOT___128841___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036184_) 
           & (IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h63ea3543__0 = ((2U & ((0xb0U 
                                              >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___017462_));
    vlSelf->__VdfgTmp_h1ab499a5__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___017462_));
    wasmetal_core__DOT___128826___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___019316_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___019304_)
                                                   ? 
                                                  (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xff440f0f00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054939_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054966_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8cc03967__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054696_)))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___019319_)))))
                                                   : 
                                                  (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___055606_))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0xf088U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O) 
                                                                     << 1U)) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___048324_)))))))))));
    vlSelf->wasmetal_core__DOT___019311_ = (1U & (IData)(
                                                         (0x11110000fff0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061951_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf088U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048324_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054920_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019323_)))))))));
    wasmetal_core__DOT___016914_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h79cf8a49__0))))
                                               : (IData)(wasmetal_core__DOT___016921_))
                                           : (IData)(wasmetal_core__DOT___016921_)));
    vlSelf->__VdfgTmp_h3bf6c465__0 = (((IData)(wasmetal_core__DOT___016902_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016914_));
    wasmetal_core__DOT___016913_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xfef00000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb8495bec__0)))))
                                               : (IData)(wasmetal_core__DOT___016929_))
                                           : (IData)(wasmetal_core__DOT___016929_)));
    vlSelf->__VdfgTmp_h98ad354c__0 = (((IData)(wasmetal_core__DOT___016914_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016913_));
    wasmetal_core__DOT___017043_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xfef00000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h38acc8e1__0)))))
                                               : (IData)(wasmetal_core__DOT___017050_))
                                           : (IData)(wasmetal_core__DOT___017050_)));
    vlSelf->__VdfgTmp_hd520545b__0 = (((IData)(wasmetal_core__DOT___016913_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017043_));
    wasmetal_core__DOT___017054_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xfef00000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017072_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hab75b8e3__0)))))
                                               : (IData)(wasmetal_core__DOT___017062_))
                                           : (IData)(wasmetal_core__DOT___017062_)));
    vlSelf->__VdfgTmp_h1c39cb98__0 = (((IData)(wasmetal_core__DOT___017043_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017054_));
    wasmetal_core__DOT___128841___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hce52e19d__0)) 
           & (IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128826___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036148_)))));
    wasmetal_core__DOT___036138_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128841___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha6af91c7__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hce52e19d__0)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036184_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8ba6f9f1__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036236_)))));
    wasmetal_core__DOT___036240_ = ((7U >> (IData)(vlSelf->__VdfgTmp_ha6af91c7__0)) 
                                    & (IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__2__KET__));
    __VdfgTmp_hf3e1ab91__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                     >> 2U)) | (1U 
                                                & (IData)(wasmetal_core__DOT____Vcellout___128826___O)));
    wasmetal_core__DOT___043012_ = (1U & (IData)((0x1fffULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128826___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___128825___O)) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___043015_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                       << 4U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128824___O)) 
                                                         | ((4U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                                >> 1U)) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128826___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128825___O))))))))));
    wasmetal_core__DOT___128827___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128816___O) 
           & (IData)(wasmetal_core__DOT___036138_));
    vlSelf->wasmetal_core__DOT____Vcellout___127759___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                   ^ (((IData)(wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__) 
                       << 3U) | (((IData)(wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___025168_))))));
    wasmetal_core__DOT___017075_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017072_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128841___O))))))));
    wasmetal_core__DOT___017083_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015554_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128841___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___017096_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015443_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128841___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___017108_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017105_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128841___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128829___DOT__CO__BRA__0__KET__ 
        = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hd270292e__0)) 
           & (IData)(wasmetal_core__DOT___036240_));
    wasmetal_core__DOT___128827___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128816___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128827___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___061720_ = (1U & (0x777U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___055759_) 
                                               << 2U) 
                                              | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127759___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048325_))))));
    wasmetal_core__DOT___128829___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h4200eb01__0)) 
           & (IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128827___O = (
                                                   ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128816___O) 
                                                        << 1U)) 
                                                    | (3U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128816___O))) 
                                                   ^ 
                                                   ((0xfffffff8U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128816___O) 
                                                         << 2U) 
                                                        & ((IData)(wasmetal_core__DOT___128827___DOT__CO__BRA__1__KET__) 
                                                           << 3U))) 
                                                    | (((IData)(wasmetal_core__DOT___128827___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128827___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036138_)))));
    vlSelf->wasmetal_core__DOT___061722_ = (1U & (0xf1f1ff00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___061720_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb5edd3cc__0)))));
    wasmetal_core__DOT___017067_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8ba6f9f1__0))))
                                               : (IData)(wasmetal_core__DOT___017075_))
                                           : (IData)(wasmetal_core__DOT___017075_)));
    vlSelf->__VdfgTmp_hde08d0b2__0 = (((IData)(wasmetal_core__DOT___017054_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017067_));
    wasmetal_core__DOT___017066_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xfef00000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015443_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h60abdace__0)))))
                                               : (IData)(wasmetal_core__DOT___017083_))
                                           : (IData)(wasmetal_core__DOT___017083_)));
    vlSelf->__VdfgTmp_he029cbf7__0 = (((IData)(wasmetal_core__DOT___017067_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017066_));
    wasmetal_core__DOT___017089_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hce52e19d__0))))
                                               : (IData)(wasmetal_core__DOT___017096_))
                                           : (IData)(wasmetal_core__DOT___017096_)));
    vlSelf->__VdfgTmp_h398f740d__0 = (((IData)(wasmetal_core__DOT___017066_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017089_));
    wasmetal_core__DOT___017100_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha6af91c7__0))))
                                               : (IData)(wasmetal_core__DOT___017108_))
                                           : (IData)(wasmetal_core__DOT___017108_)));
    vlSelf->__VdfgTmp_h19c83299__0 = (((IData)(wasmetal_core__DOT___017089_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017100_));
    wasmetal_core__DOT___128829___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h92569eda__0)) 
           & (IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___050291_ = (1U & (1U >> ((0x10U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128826___O) 
                                                     << 3U)) 
                                                 | ((8U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128827___O) 
                                                        << 2U)) 
                                                    | ((6U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128826___O) 
                                                           >> 1U)) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128827___O)))))));
    wasmetal_core__DOT____Vcellout___128829___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___036191_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h92569eda__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4200eb01__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0x3affU 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd270292e__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036240_)))));
    wasmetal_core__DOT___036245_ = ((IData)(vlSelf->wasmetal_core__DOT___036191_) 
                                    & (IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___017802_ = (1U & (0x8fU >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128827___O) 
                                                  << 1U)) 
                                           | (((IData)(wasmetal_core__DOT___050291_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_hf3e1ab91__0)))));
    wasmetal_core__DOT___043016_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___050291_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128827___O) 
                                                       >> 2U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127760___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                   ^ (((IData)(wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__) 
                       << 3U) | (((IData)(wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(wasmetal_core__DOT___025141_))))));
    wasmetal_core__DOT___017123_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015564_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128829___O))))))));
    wasmetal_core__DOT___016980_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015565_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128829___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016988_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015549_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128829___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016949_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015569_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128829___O) 
                                                             >> 3U))))))));
    if (vlSelf->wasmetal_core__DOT___016555_) {
        if (vlSelf->wasmetal_core__DOT___016554_) {
            wasmetal_core__DOT___017116_ = (1U & (1U 
                                                  >> 
                                                  (1U 
                                                   & (0x3a00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd270292e__0)))));
            wasmetal_core__DOT___016973_ = (1U & (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h4200eb01__0)))));
            wasmetal_core__DOT___016972_ = (1U & (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h92569eda__0)))));
            vlSelf->wasmetal_core__DOT___016942_ = 
                (1U & (1U >> (1U & (0xfef00000U >> 
                                    (((IData)(vlSelf->wasmetal_core__DOT___015579_) 
                                      << 4U) | (IData)(vlSelf->__VdfgTmp_h7054d7e2__0))))));
        } else {
            wasmetal_core__DOT___017116_ = (1U & (IData)(wasmetal_core__DOT___017123_));
            wasmetal_core__DOT___016973_ = (1U & (IData)(wasmetal_core__DOT___016980_));
            wasmetal_core__DOT___016972_ = (1U & (IData)(wasmetal_core__DOT___016988_));
            vlSelf->wasmetal_core__DOT___016942_ = 
                (1U & (IData)(wasmetal_core__DOT___016949_));
        }
    } else {
        wasmetal_core__DOT___017116_ = (1U & (IData)(wasmetal_core__DOT___017123_));
        wasmetal_core__DOT___016973_ = (1U & (IData)(wasmetal_core__DOT___016980_));
        wasmetal_core__DOT___016972_ = (1U & (IData)(wasmetal_core__DOT___016988_));
        vlSelf->wasmetal_core__DOT___016942_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016949_));
    }
    wasmetal_core__DOT___128830___DOT__CO__BRA__0__KET__ 
        = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hd6a04253__0)) 
           & (IData)(wasmetal_core__DOT___036245_));
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow 
        = (1U & ((IData)(wasmetal_core__DOT___043016_)
                  ? ((IData)(wasmetal_core__DOT___043015_)
                      ? ((~ (IData)(wasmetal_core__DOT___043014_)) 
                         & (7U >> (7U & (IData)(wasmetal_core__DOT____Vcellout___128824___O))))
                      : (IData)(wasmetal_core__DOT___043012_))
                  : ((IData)(wasmetal_core__DOT____Vcellout___128827___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT___062187_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127760___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    wasmetal_core__DOT___128830___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_he686eaae__0)) 
           & (IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT__fpu__02earithmetic__02eencode32__02ein__05b30__05d 
        = (1U & (IData)((0xfffff020ffffffffULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___017802_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___017772_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow))));
    wasmetal_core__DOT___018072_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014592_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                               ? (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___017772_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6f76189e__0)))))
                                               : (0xbf000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___017772_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h5c0f2a5b__0))))
                                           : (2U >> (IData)(wasmetal_core__DOT___017772_))));
    wasmetal_core__DOT___037144_ = (1U & (IData)((0xefffffffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___017802_)))))))));
    wasmetal_core__DOT___059064_ = ((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                    & (IData)((0xfff1ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___017802_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_hf3e1ab91__0))))))));
    vlSelf->wasmetal_core__DOT___058944_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017156_)))));
    vlSelf->__VdfgTmp_h776da2e2__0 = (((IData)(wasmetal_core__DOT___017100_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017116_));
    vlSelf->__VdfgTmp_hb1e20b97__0 = (((IData)(wasmetal_core__DOT___017116_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016973_));
    vlSelf->__VdfgTmp_h0184ff22__0 = (((IData)(wasmetal_core__DOT___016973_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016972_));
    vlSelf->__VdfgTmp_h11dd3326__0 = (((IData)(wasmetal_core__DOT___016972_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016942_));
    wasmetal_core__DOT___128830___DOT__CO__BRA__2__KET__ 
        = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hcec7f9ed__0)) 
           & (IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___059213_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eencode32__02ein__05b30__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfdf00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___017802_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                                            << 2U) 
                                                                           | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___128826___O)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___134207___O 
        = ((((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eencode32__02ein__05b30__05d) 
             << 3U) | (((IData)(wasmetal_core__DOT___037144_) 
                        << 2U) | ((2U & ((~ ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                             >> 1U)) 
                                         << 1U)) | 
                                  (1U & (~ (IData)(wasmetal_core__DOT____Vcellout___128825___O)))))) 
           ^ ((8U & (((~ (IData)(wasmetal_core__DOT___037144_)) 
                      | (IData)(wasmetal_core__DOT___134207___DOT__CO__BRA__1__KET__)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___134207___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___134207___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___037138_)))));
    vlSelf->wasmetal_core__DOT___018074_ = (1U & (0x3f0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___037144_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___059064_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059065_)))))));
    __VdfgTmp_hc68349d0__0 = ((2U & ((8U >> (((IData)(wasmetal_core__DOT___059064_) 
                                              << 1U) 
                                             | (IData)(wasmetal_core__DOT___037144_))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___059065_));
    vlSelf->wasmetal_core__DOT___018055_ = (1U & (1U 
                                                  >> 
                                                  ((((1U 
                                                      >> 
                                                      ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                           << 3U)) 
                                                       | ((0xcU 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                              << 2U)) 
                                                          | (3U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                >> 2U))))) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                                        & (IData)(
                                                                  (0xfff1ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                                     << 5U) 
                                                                    | (((IData)(wasmetal_core__DOT___017802_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                                           << 3U) 
                                                                          | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___128826___O))))))))))) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059064_))));
    vlSelf->wasmetal_core__DOT___059944_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h6eb6be0b__0))));
    vlSelf->wasmetal_core__DOT___059830_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he0568e2c__0))));
    vlSelf->__VdfgTmp_h7343b3bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x8800f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058952_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058951_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_ha3f8ca93__0)))));
    vlSelf->wasmetal_core__DOT___059012_ = (1U & (IData)(
                                                         (0x1fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059009_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___059008_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___059007_)))))))));
    vlSelf->wasmetal_core__DOT___059013_ = (1U & (IData)(
                                                         (0x1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059004_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___059003_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___059002_)))))))));
    vlSelf->__VdfgTmp_hfd96674a__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017537_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                                                << 4U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017534_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1e507ca5__0)))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017534_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_ha61a6e02__0)))));
    vlSelf->__VdfgTmp_h4f345a43__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058987_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hcb62e82f__0)))));
    vlSelf->__VdfgTmp_h9f5057e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058975_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h7385dfc5__0)))));
    __VdfgTmp_h58253077__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                           << 3U) | 
                                          ((4U & ((
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT___017551_)
                                                       ? (IData)(
                                                                 (0xff00ff00fffbfff0ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                    << 5U) 
                                                                   | ((0x10U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                                          << 3U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017549_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h6bcf76cf__0)))))))
                                                       : 
                                                      (2U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT___017549_)))) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_hac5f758c__0)))));
    vlSelf->__VdfgTmp_hb666b13b__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___059063_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___059062_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___059061_))))));
    vlSelf->__VdfgTmp_hafe91978__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017564_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017562_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h71876852__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017562_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h6c11e1cc__0)))));
    vlSelf->__VdfgTmp_h4ef846ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017666_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                                << 3U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017664_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8d1d0ffb__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017664_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h15aa6b6f__0)))));
    __VdfgTmp_hb9661308__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                           << 3U) | 
                                          ((4U & ((
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT___017679_)
                                                       ? (IData)(
                                                                 (0xff00ff00fffbfff0ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                    << 5U) 
                                                                   | ((0x10U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017677_) 
                                                                          << 3U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h6171bc25__0))))))
                                                       : 
                                                      (2U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT___017677_)))) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_hdb9ea8ba__0)))));
    vlSelf->__VdfgTmp_h1fd1b68c__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059009_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc369107b__0)))));
    vlSelf->__VdfgTmp_h27aa09ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059004_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h5cb81b0a__0)))));
    vlSelf->__VdfgTmp_h2dfd171f__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x4400f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059023_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___059022_)))))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_hea1901c2__0)))));
    vlSelf->__VdfgTmp_hc67fcbbc__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017704_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                                << 4U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017702_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf11557d__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017702_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h214cf44d__0)))));
    vlSelf->__VdfgTmp_hc60583d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017613_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                                << 3U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017611_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heb003047__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017611_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h11c34da7__0)))));
    vlSelf->__VdfgTmp_hc333bcf7__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059063_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6eb6be0b__0)))));
    vlSelf->__VdfgTmp_h8c11f975__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017626_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017624_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h43b37fbe__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017624_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_hdf3a557f__0)))));
    vlSelf->__VdfgTmp_h3ae10324__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x4400f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059036_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___059035_)))))) 
                                                           << 2U)) 
                                                       | (IData)(__VdfgTmp_he0568e2c__0)))));
    vlSelf->__VdfgTmp_h2c68bea6__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059053_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h4ab5d99d__0)))));
    vlSelf->__VdfgTmp_he4b52d96__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017731_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128852___O) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017729_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h69609ee5__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017729_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h64c7108d__0)))));
    vlSelf->__VdfgTmp_hfc3008ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x4400f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059045_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___059044_)))))) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___059047_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___059046_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128830___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h4e293e30__0)) 
                   << 3U)) | ((4U & ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hcec7f9ed__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_he686eaae__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0x3affU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd6a04253__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036245_)))));
    vlSelf->wasmetal_core__DOT___036249_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h4e293e30__0)) 
                                            & (IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h6e41553f__0 = (((IData)(wasmetal_core__DOT___018071_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___018072_));
    vlSelf->__VdfgTmp_h6799374a__0 = (((IData)(vlSelf->wasmetal_core__DOT___018073_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___018072_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___018071_))));
    vlSelf->wasmetal_core__DOT___059534_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hc68349d0__0))))));
    vlSelf->wasmetal_core__DOT___018159_ = (1U & (IData)(
                                                         (0x305000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hc68349d0__0))))))));
    vlSelf->wasmetal_core__DOT___059069_ = (1U & (0x3050000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hc68349d0__0))))));
    vlSelf->wasmetal_core__DOT___059992_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___134206___O))))));
    vlSelf->wasmetal_core__DOT___060049_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134206___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___060121_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134207___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060024_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134206___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060074_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134206___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___060156_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134207___O) 
                                                            >> 2U))))));
    vlSelf->__VdfgTmp_hbba2540d__0 = (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134207___O) 
                                                    >> 3U)));
    vlSelf->wasmetal_core__DOT___059217_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___037144_)))));
    vlSelf->wasmetal_core__DOT___018053_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h7343b3bd__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058945_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h74f09674__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfd96674a__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(__VdfgTmp_h58253077__0))))))))))));
    vlSelf->wasmetal_core__DOT___059488_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xfef0f0f0ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4f345a43__0))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfef0f0f000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hafe91978__0)))))));
    vlSelf->wasmetal_core__DOT___018147_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hfd96674a__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7343b3bd__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(__VdfgTmp_h58253077__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hafe91978__0))))))))))));
    vlSelf->wasmetal_core__DOT___018226_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(__VdfgTmp_h58253077__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfd96674a__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hafe91978__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4f345a43__0))))))))))));
    vlSelf->__VdfgTmp_hde0d3ce6__0 = ((8U & ((IData)(
                                                     (0xfef0f0f000000000ULL 
                                                      >> (IData)(__VdfgTmp_h58253077__0))) 
                                             << 3U)) 
                                      | ((4U & ((IData)(
                                                        (0xfef0f0f0ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_hafe91978__0))) 
                                                << 2U)) 
                                         | ((2U & ((IData)(
                                                           (0x1fff00000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058987_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058986_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___058985_)))))))) 
                                                   << 1U)) 
                                            | (1U & (IData)(
                                                            (0x1fffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058975_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                        << 2U) 
                                                                       | (((IData)(wasmetal_core__DOT___058974_) 
                                                                           << 1U) 
                                                                          | (IData)(wasmetal_core__DOT___058973_))))))))))));
    vlSelf->__VdfgTmp_h7afeeb38__0 = ((2U & ((IData)(
                                                     (0xfef0f0f000000000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9f5057e1__0))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfef0f0f0ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0)))));
    vlSelf->wasmetal_core__DOT___018372_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h9f5057e1__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4f345a43__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(__VdfgTmp_hb9661308__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))))))))))));
    vlSelf->wasmetal_core__DOT___018146_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h9f5057e1__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4f345a43__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(__VdfgTmp_hb9661308__0))))))))))));
    vlSelf->__VdfgTmp_hafdf98d6__0 = ((2U & ((IData)(
                                                     (0xfef0f0f000000000ULL 
                                                      >> (IData)(__VdfgTmp_hb9661308__0))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfef0f0f0ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0)))));
    vlSelf->wasmetal_core__DOT___018285_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(__VdfgTmp_hb9661308__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))))))))))));
    vlSelf->wasmetal_core__DOT___017460_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(__VdfgTmp_hb9661308__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0))))))))))));
    vlSelf->__VdfgTmp_h4e256671__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfef0f0f000000000ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfef0f0f0ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0))))));
    vlSelf->wasmetal_core__DOT___018050_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(__VdfgTmp_hb9661308__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))))))))))));
    vlSelf->wasmetal_core__DOT___018283_ = (1U & (IData)(
                                                         (0xfff0111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f000000000ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8c11f975__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059012_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059013_)))))))));
}
