#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__44(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__44\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___013506_;
    wasmetal_core__DOT___013506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016432_;
    wasmetal_core__DOT___016432_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016459_;
    wasmetal_core__DOT___016459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___042791_;
    wasmetal_core__DOT___042791_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___042795_;
    wasmetal_core__DOT___042795_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048954_;
    wasmetal_core__DOT___048954_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053623_;
    wasmetal_core__DOT___053623_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055238_;
    wasmetal_core__DOT___055238_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055449_;
    wasmetal_core__DOT___055449_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055622_;
    wasmetal_core__DOT___055622_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055850_;
    wasmetal_core__DOT___055850_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055851_;
    wasmetal_core__DOT___055851_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056008_;
    wasmetal_core__DOT___056008_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056148_;
    wasmetal_core__DOT___056148_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127528___O;
    wasmetal_core__DOT____Vcellout___127528___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127495___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127495___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127495___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127495___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_heeb49de9__0;
    __VdfgTmp_heeb49de9__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb3c8072f__0;
    __VdfgTmp_hb3c8072f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h7cc8bc90__0;
    __VdfgTmp_h7cc8bc90__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf9513718__0;
    __VdfgTmp_hf9513718__0 = 0;
    CData/*1:0*/ __VdfgTmp_he9adc993__0;
    __VdfgTmp_he9adc993__0 = 0;
    CData/*1:0*/ __VdfgTmp_hba82f58f__0;
    __VdfgTmp_hba82f58f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h66d4b740__0;
    __VdfgTmp_h66d4b740__0 = 0;
    CData/*1:0*/ __VdfgTmp_h78ab269f__0;
    __VdfgTmp_h78ab269f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h984be98a__0;
    __VdfgTmp_h984be98a__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc8a1f90d__0;
    __VdfgTmp_hc8a1f90d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h003583a9__0;
    __VdfgTmp_h003583a9__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha3cbecc2__0;
    __VdfgTmp_ha3cbecc2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8255702a__0;
    __VdfgTmp_h8255702a__0 = 0;
    CData/*2:0*/ __VdfgTmp_h58490cb9__0;
    __VdfgTmp_h58490cb9__0 = 0;
    CData/*2:0*/ __VdfgTmp_h0c69b60f__0;
    __VdfgTmp_h0c69b60f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h74a36385__0;
    __VdfgTmp_h74a36385__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6299ef40__0;
    __VdfgTmp_h6299ef40__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5311778a__0;
    __VdfgTmp_h5311778a__0 = 0;
    CData/*3:0*/ __VdfgTmp_hc1229de7__0;
    __VdfgTmp_hc1229de7__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4bc07745__0;
    __VdfgTmp_h4bc07745__0 = 0;
    CData/*1:0*/ __VdfgTmp_h073f9b05__0;
    __VdfgTmp_h073f9b05__0 = 0;
    CData/*2:0*/ __VdfgTmp_h1432c284__0;
    __VdfgTmp_h1432c284__0 = 0;
    CData/*1:0*/ __VdfgTmp_he55661b3__0;
    __VdfgTmp_he55661b3__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3043729e__0;
    __VdfgTmp_h3043729e__0 = 0;
    CData/*1:0*/ __VdfgTmp_hcf6d3894__0;
    __VdfgTmp_hcf6d3894__0 = 0;
    CData/*1:0*/ __VdfgTmp_h86440ee1__0;
    __VdfgTmp_h86440ee1__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6bf7b02b__0;
    __VdfgTmp_h6bf7b02b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1a11d128__0;
    __VdfgTmp_h1a11d128__0 = 0;
    CData/*1:0*/ __VdfgTmp_h281b8ab1__0;
    __VdfgTmp_h281b8ab1__0 = 0;
    CData/*1:0*/ __VdfgTmp_hae4042e0__0;
    __VdfgTmp_hae4042e0__0 = 0;
    CData/*1:0*/ __VdfgTmp_he0f5bdf9__0;
    __VdfgTmp_he0f5bdf9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6e85e3ea__0;
    __VdfgTmp_h6e85e3ea__0 = 0;
    CData/*1:0*/ __VdfgTmp_h77b03a4f__0;
    __VdfgTmp_h77b03a4f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h038396ba__0;
    __VdfgTmp_h038396ba__0 = 0;
    CData/*1:0*/ __VdfgTmp_h199a7061__0;
    __VdfgTmp_h199a7061__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf34c8dd6__0;
    __VdfgTmp_hf34c8dd6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h524558f7__0;
    __VdfgTmp_h524558f7__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1f1491ac__0;
    __VdfgTmp_h1f1491ac__0 = 0;
    CData/*1:0*/ __VdfgTmp_h45767413__0;
    __VdfgTmp_h45767413__0 = 0;
    CData/*1:0*/ __VdfgTmp_h509cc1df__0;
    __VdfgTmp_h509cc1df__0 = 0;
    CData/*1:0*/ __VdfgTmp_h62a41e7a__0;
    __VdfgTmp_h62a41e7a__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb0c1ca1e__0;
    __VdfgTmp_hb0c1ca1e__0 = 0;
    CData/*1:0*/ __VdfgTmp_h36eed793__0;
    __VdfgTmp_h36eed793__0 = 0;
    CData/*1:0*/ __VdfgTmp_h39517120__0;
    __VdfgTmp_h39517120__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9087e671__0;
    __VdfgTmp_h9087e671__0 = 0;
    CData/*1:0*/ __VdfgTmp_h7ae355e5__0;
    __VdfgTmp_h7ae355e5__0 = 0;
    CData/*1:0*/ __VdfgTmp_h029c8a85__0;
    __VdfgTmp_h029c8a85__0 = 0;
    CData/*1:0*/ __VdfgTmp_h004771e7__0;
    __VdfgTmp_h004771e7__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd226433b__0;
    __VdfgTmp_hd226433b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h31ba5af5__0;
    __VdfgTmp_h31ba5af5__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc49bb9d8__0;
    __VdfgTmp_hc49bb9d8__0 = 0;
    CData/*1:0*/ __VdfgTmp_hfb882020__0;
    __VdfgTmp_hfb882020__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4e0b8941__0;
    __VdfgTmp_h4e0b8941__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8b5fdfca__0;
    __VdfgTmp_h8b5fdfca__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6f4dbdf9__0;
    __VdfgTmp_h6f4dbdf9__0 = 0;
    CData/*1:0*/ __VdfgTmp_hea01e0cb__0;
    __VdfgTmp_hea01e0cb__0 = 0;
    CData/*1:0*/ __VdfgTmp_he9911376__0;
    __VdfgTmp_he9911376__0 = 0;
    CData/*1:0*/ __VdfgTmp_h7fe0949a__0;
    __VdfgTmp_h7fe0949a__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha94b79fc__0;
    __VdfgTmp_ha94b79fc__0 = 0;
    CData/*1:0*/ __VdfgTmp_h23e62674__0;
    __VdfgTmp_h23e62674__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf92edf21__0;
    __VdfgTmp_hf92edf21__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6bd09dd8__0;
    __VdfgTmp_h6bd09dd8__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8a1e5cea__0;
    __VdfgTmp_h8a1e5cea__0 = 0;
    CData/*1:0*/ __VdfgTmp_h09e28282__0;
    __VdfgTmp_h09e28282__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___019060_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060258_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013798_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005788_)))))));
    vlSelf->__VdfgTmp_h3835a6cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___018273_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h74741c3a__0));
    wasmetal_core__DOT___127495___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_had1ad578__0))) 
                 & (6U >> (IData)(vlSelf->__VdfgTmp_hba6f19f8__0))));
    vlSelf->__VdfgTmp_h10d9a2f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016443_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b38__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058345_))));
    vlSelf->__VdfgTmp_h14d2ff5c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058266_));
    wasmetal_core__DOT___016432_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___058266_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___058256_))));
    vlSelf->__VdfgTmp_hed92d4b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058256_));
    wasmetal_core__DOT___016459_ = (1U & (IData)((0x1fff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058524_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058356_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbec899f6__0))))));
    vlSelf->wasmetal_core__DOT___016502_ = (1U & ((4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfcfaf0f000000000ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005731_))) 
                                                                                << 2U)) 
                                                                            | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127585___O)))))))))))) 
                                                  & (IData)(
                                                            (0xffeefff0fff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017175_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017174_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0xff3333f0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058696_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                                ? 
                                                                               (0xbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017183_)))
                                                                                : 
                                                                               ((IData)(vlSelf->wasmetal_core__DOT___017185_)
                                                                                 ? (IData)(
                                                                                (0xb0000000b000bULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017183_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017182_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005731_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xd0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013672_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))))))
                                                                                 : 
                                                                                (0x45U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017183_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017182_)))))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017171_))))))))));
    vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h8fcc0329__0))) 
                 & (7U >> (IData)(vlSelf->__VdfgTmp_h60102cdd__0))));
    vlSelf->wasmetal_core__DOT___057732_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015651_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051535_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d)))));
    vlSelf->__VdfgTmp_hd5a7b943__0 = (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015828_));
    vlSelf->__VdfgTmp_h310e5162__0 = (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015763_));
    vlSelf->__VdfgTmp_h513c757b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017794_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015656_));
    vlSelf->__VdfgTmp_hafd7ea26__0 = (((IData)(vlSelf->wasmetal_core__DOT___017756_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015657_));
    vlSelf->wasmetal_core__DOT___057711_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017794_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017756_))));
    vlSelf->wasmetal_core__DOT___017599_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017756_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013621_))));
    vlSelf->wasmetal_core__DOT___017600_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057694_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057725_))));
    vlSelf->__VdfgTmp_h4e8a0148__0 = (((IData)(vlSelf->wasmetal_core__DOT___057694_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051535_));
    vlSelf->wasmetal_core__DOT___057710_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057695_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057701_))));
    wasmetal_core__DOT___013506_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___057695_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057699_))));
    vlSelf->wasmetal_core__DOT___017716_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017640_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___017652_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017623_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057717_)))));
    vlSelf->wasmetal_core__DOT___017610_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017701_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___017691_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057699_))));
    wasmetal_core__DOT___042795_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  ((0x30U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                       << 3U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O)) 
                                                      | ((6U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128792___O) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O))))))));
    wasmetal_core__DOT___042791_ = (1U & (IData)((0xffff8000ULL 
                                                  >> 
                                                  ((0x30U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128792___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                          << 3U)) 
                                                      | (7U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                            >> 1U)))))));
    wasmetal_core__DOT___048954_ = (1U & (0x44f0U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___042760_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(
                                                             (0x8000000000000000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                                   << 2U)) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                                      << 4U)) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                                         << 2U)) 
                                                                     | ((6U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                                            >> 1U)) 
                                                                        | (1U 
                                                                           & (~ (IData)(vlSelf->wasmetal_core__DOT___035721_))))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (1ULL 
                                                               >> 
                                                               ((0x30U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                                    << 4U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O))))))))));
    vlSelf->wasmetal_core__DOT___006117_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___042760_)) 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___035721_))));
    vlSelf->wasmetal_core__DOT___042754_ = ((IData)(vlSelf->wasmetal_core__DOT___042760_) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___042756_));
    vlSelf->wasmetal_core__DOT___019805_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053254_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053008_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052862_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h554fca93__0))))))));
    vlSelf->wasmetal_core__DOT___053102_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053008_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053007_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053006_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051217_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053005_)))))));
    vlSelf->wasmetal_core__DOT___046424_ = (1U & (IData)(
                                                         (0x88880f0f00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063433_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf33ffffffffff55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063408_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053343_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)))))))))));
    wasmetal_core__DOT___053623_ = (1U & (IData)((0xdf00000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053506_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053622_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053502_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053621_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___053572_)))))))));
    __VdfgTmp_h1432c284__0 = (((IData)(vlSelf->wasmetal_core__DOT___009292_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hbd36bb7c__0));
    vlSelf->__VdfgTmp_h48a07a7e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hbd36bb7c__0));
    wasmetal_core__DOT___055622_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_ha16fbbbf__0))));
    vlSelf->wasmetal_core__DOT___055921_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055618_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055617_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd2b13b0f__0))))))));
    vlSelf->wasmetal_core__DOT___055614_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2b13b0f__0))));
    vlSelf->__VdfgTmp_h8ad90c85__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6e24fc79__0)))));
    vlSelf->wasmetal_core__DOT___009275_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055567_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055566_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6e24fc79__0))))))));
    vlSelf->wasmetal_core__DOT___009465_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055570_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055567_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb785bdc8__0))))))));
    __VdfgTmp_h5311778a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hb785bdc8__0));
    vlSelf->wasmetal_core__DOT___009459_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b31618a__0))));
    vlSelf->wasmetal_core__DOT___008878_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055543_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055544_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1ccd197a__0))))))));
    vlSelf->wasmetal_core__DOT___009405_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055544_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009771_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf7b90195__0))))))));
    vlSelf->wasmetal_core__DOT___055538_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7b90195__0))));
    vlSelf->wasmetal_core__DOT___009460_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009770_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd1825153__0))))))));
    vlSelf->__VdfgTmp_hbd15e417__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd1825153__0));
    vlSelf->wasmetal_core__DOT___009400_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051500_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbf11cfc1__0))))))));
    __VdfgTmp_h74a36385__0 = (((IData)(vlSelf->wasmetal_core__DOT___009187_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hd63c68ee__0));
    vlSelf->__VdfgTmp_hb1de0cec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd63c68ee__0));
    vlSelf->wasmetal_core__DOT___009956_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055448_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he1badc2d__0))))))));
    wasmetal_core__DOT___055449_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_he1badc2d__0))));
    vlSelf->wasmetal_core__DOT___009175_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he6145195__0))));
    vlSelf->wasmetal_core__DOT___009923_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055445_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055444_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h52b8127f__0))))))));
    vlSelf->wasmetal_core__DOT___055451_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h52b8127f__0))));
    vlSelf->wasmetal_core__DOT___009441_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055444_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009254_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h416357e2__0))))))));
    __VdfgTmp_h0c69b60f__0 = (((IData)(vlSelf->wasmetal_core__DOT___009253_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h53c22b41__0));
    vlSelf->__VdfgTmp_h3f55ca01__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h53c22b41__0));
    wasmetal_core__DOT___056008_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_ha9c0231a__0))));
    vlSelf->wasmetal_core__DOT___009233_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009241_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009240_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h10a22e24__0))))))));
    vlSelf->__VdfgTmp_hfc35c726__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a22e24__0));
    vlSelf->wasmetal_core__DOT___009434_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055407_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009241_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha4fdb8c7__0))))))));
    vlSelf->wasmetal_core__DOT___056079_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h381f02c3__0))));
    vlSelf->wasmetal_core__DOT___009927_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055408_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055407_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h381f02c3__0))))))));
    vlSelf->wasmetal_core__DOT___009224_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055236_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0eab1d01__0))))))));
    vlSelf->wasmetal_core__DOT___009147_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0b92bce8__0))));
    wasmetal_core__DOT___055238_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_hef4c4e2a__0))));
    vlSelf->wasmetal_core__DOT___009930_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055235_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055234_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hef4c4e2a__0))))))));
    vlSelf->wasmetal_core__DOT___009427_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055234_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055229_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haccd68b9__0))))))));
    __VdfgTmp_h58490cb9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_haccd68b9__0));
    vlSelf->wasmetal_core__DOT___055359_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055229_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055228_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0dc57e5a__0))))))));
    __VdfgTmp_hf9513718__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h0dc57e5a__0));
    vlSelf->wasmetal_core__DOT___056147_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd3eaf9cd__0))));
    vlSelf->wasmetal_core__DOT___009422_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055696_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055695_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd3eaf9cd__0))))))));
    vlSelf->wasmetal_core__DOT___009478_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h567718cf__0))));
    vlSelf->wasmetal_core__DOT___009479_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055695_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009304_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h74bdf3b8__0))))))));
    wasmetal_core__DOT___055851_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h74bdf3b8__0))));
    vlSelf->wasmetal_core__DOT___009296_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009304_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009303_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4ba92f5a__0))))))));
    vlSelf->wasmetal_core__DOT___055689_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4ba92f5a__0))));
    wasmetal_core__DOT___055850_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h2fcb0063__0))));
    wasmetal_core__DOT___056148_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h3832b0f6__0))));
    vlSelf->wasmetal_core__DOT___062324_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062195_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008809_)))));
    vlSelf->wasmetal_core__DOT___009473_ = (1U & (IData)(
                                                         (0xffff8000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009290_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4ad8a46a__0)))))));
    vlSelf->__VdfgTmp_hd3ee6e40__0 = (((IData)(vlSelf->wasmetal_core__DOT___009185_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h4ad8a46a__0));
    vlSelf->wasmetal_core__DOT___062488_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055983_))));
    vlSelf->wasmetal_core__DOT___009181_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___055984_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009472_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055983_)))));
    __VdfgTmp_he55661b3__0 = (((IData)(vlSelf->wasmetal_core__DOT___055953_) 
                               << 1U) | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h416357e2__0)))));
    __VdfgTmp_h4bc07745__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055953_));
    vlSelf->wasmetal_core__DOT___009323_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055768_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he6145195__0))))));
    vlSelf->wasmetal_core__DOT___009309_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055718_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0b92bce8__0))))));
    vlSelf->wasmetal_core__DOT___009357_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009471_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055617_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009293_)))))));
    vlSelf->__VdfgTmp_h7bd92bc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009463_));
    vlSelf->wasmetal_core__DOT___009346_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x35U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb307080d__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055822_)))));
    vlSelf->wasmetal_core__DOT___009979_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055822_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xcaU 
                                                            >> (IData)(vlSelf->__VdfgTmp_hb307080d__0)))))));
    __VdfgTmp_h073f9b05__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008877_));
    vlSelf->wasmetal_core__DOT___009330_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_ha296f98c__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h23e0654e__0))))));
    vlSelf->wasmetal_core__DOT___009317_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x35U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055738_)))));
    vlSelf->__VdfgTmp_h3eec0328__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055736_));
    vlSelf->__VdfgTmp_h243a5897__0 = ((2U & ((0x35U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_ha4fdb8c7__0))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___055736_));
    vlSelf->__VdfgTmp_hf516e409__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055719_));
    vlSelf->wasmetal_core__DOT___009945_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7d874977__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha16fbbbf__0))))));
    vlSelf->wasmetal_core__DOT___009939_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009745_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xcaU 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha295f108__0)))))));
    vlSelf->__VdfgTmp_h282170d2__0 = ((2U & ((0x35U 
                                              >> (IData)(vlSelf->__VdfgTmp_ha295f108__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009745_));
    vlSelf->__VdfgTmp_heeb9424e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009091_));
    vlSelf->wasmetal_core__DOT___009267_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009091_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055544_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009771_)))))));
    vlSelf->wasmetal_core__DOT___056089_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6ca56fa1__0)))))));
    vlSelf->wasmetal_core__DOT___009258_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009069_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051500_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009189_)))))));
    vlSelf->wasmetal_core__DOT___009972_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_hecc250a9__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha9c0231a__0))))));
    vlSelf->wasmetal_core__DOT___009967_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6b0a05f6__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0eab1d01__0))))));
    vlSelf->wasmetal_core__DOT___056170_ = (1U & (0xff80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009477_)))))));
    vlSelf->__VdfgTmp_h7ca1d027__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009477_));
    vlSelf->wasmetal_core__DOT___009295_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_he25b62bf__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3832b0f6__0))))));
    vlSelf->__VdfgTmp_h2567a16a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007864_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007863_))));
    __VdfgTmp_heeb49de9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007863_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007862_));
    __VdfgTmp_h66d4b740__0 = (((IData)(vlSelf->wasmetal_core__DOT___007862_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007905_));
    vlSelf->__VdfgTmp_hb7c4f884__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007905_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007904_))));
    vlSelf->__VdfgTmp_h422b1f0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007903_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007902_));
    __VdfgTmp_h45767413__0 = (((IData)(vlSelf->wasmetal_core__DOT___007902_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007942_));
    __VdfgTmp_h3043729e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007942_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007941_));
    __VdfgTmp_h78ab269f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007941_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007940_));
    __VdfgTmp_h984be98a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007940_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007939_));
    vlSelf->__VdfgTmp_h4bfa77b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007939_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007981_));
    vlSelf->__VdfgTmp_ha9e5b07a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007981_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007980_));
    __VdfgTmp_ha94b79fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007980_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007979_));
    __VdfgTmp_hcf6d3894__0 = (((IData)(vlSelf->wasmetal_core__DOT___007979_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007978_));
    __VdfgTmp_h509cc1df__0 = (((IData)(vlSelf->wasmetal_core__DOT___007978_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008028_));
    __VdfgTmp_h86440ee1__0 = (((IData)(vlSelf->wasmetal_core__DOT___008028_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008027_));
    __VdfgTmp_h62a41e7a__0 = (((IData)(vlSelf->wasmetal_core__DOT___008027_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008026_));
    __VdfgTmp_hc8a1f90d__0 = (((IData)(vlSelf->wasmetal_core__DOT___008026_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008025_));
    vlSelf->__VdfgTmp_hc20acf35__0 = (((IData)(vlSelf->wasmetal_core__DOT___008025_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008067_));
    __VdfgTmp_he9adc993__0 = (((IData)(vlSelf->wasmetal_core__DOT___008067_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008066_));
    __VdfgTmp_h23e62674__0 = (((IData)(vlSelf->wasmetal_core__DOT___008066_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008065_));
    __VdfgTmp_h6bf7b02b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008065_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008064_));
    __VdfgTmp_hb0c1ca1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___008064_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008104_));
    __VdfgTmp_hba82f58f__0 = (((IData)(vlSelf->wasmetal_core__DOT___008104_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008103_));
    __VdfgTmp_h36eed793__0 = (((IData)(vlSelf->wasmetal_core__DOT___008103_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008102_));
    __VdfgTmp_h003583a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008102_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008101_));
    __VdfgTmp_h39517120__0 = (((IData)(vlSelf->wasmetal_core__DOT___008101_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008142_));
    __VdfgTmp_h6f4dbdf9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008142_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008141_));
    __VdfgTmp_hf92edf21__0 = (((IData)(vlSelf->wasmetal_core__DOT___008141_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008140_));
    __VdfgTmp_h1a11d128__0 = (((IData)(vlSelf->wasmetal_core__DOT___008140_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008139_));
    __VdfgTmp_h9087e671__0 = (((IData)(vlSelf->wasmetal_core__DOT___008139_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008179_));
    __VdfgTmp_h281b8ab1__0 = (((IData)(vlSelf->wasmetal_core__DOT___008179_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008178_));
    __VdfgTmp_h7ae355e5__0 = (((IData)(vlSelf->wasmetal_core__DOT___008178_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008177_));
    __VdfgTmp_hae4042e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___008177_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008176_));
    __VdfgTmp_h029c8a85__0 = (((IData)(vlSelf->wasmetal_core__DOT___008176_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008217_));
    __VdfgTmp_hea01e0cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___008217_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008216_));
    __VdfgTmp_h6bd09dd8__0 = (((IData)(vlSelf->wasmetal_core__DOT___008216_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008215_));
    __VdfgTmp_he0f5bdf9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008215_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008214_));
    __VdfgTmp_h004771e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___008214_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008254_));
    __VdfgTmp_hb3c8072f__0 = (((IData)(vlSelf->wasmetal_core__DOT___008254_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008253_));
    __VdfgTmp_hd226433b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008253_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008252_));
    __VdfgTmp_h6e85e3ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___008252_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008251_));
    __VdfgTmp_ha3cbecc2__0 = (((IData)(vlSelf->wasmetal_core__DOT___008251_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008292_));
    __VdfgTmp_h8255702a__0 = (((IData)(vlSelf->wasmetal_core__DOT___008292_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008291_));
    __VdfgTmp_h8a1e5cea__0 = (((IData)(vlSelf->wasmetal_core__DOT___008291_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008290_));
    __VdfgTmp_h7cc8bc90__0 = (((IData)(vlSelf->wasmetal_core__DOT___008290_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008289_));
    __VdfgTmp_h31ba5af5__0 = (((IData)(vlSelf->wasmetal_core__DOT___008289_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008329_));
    __VdfgTmp_h77b03a4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___008329_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008328_));
    __VdfgTmp_hc49bb9d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___008328_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008327_));
    __VdfgTmp_h038396ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___008327_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008326_));
    __VdfgTmp_hfb882020__0 = (((IData)(vlSelf->wasmetal_core__DOT___008326_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008368_));
    __VdfgTmp_h7fe0949a__0 = (((IData)(vlSelf->wasmetal_core__DOT___008368_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008367_));
    __VdfgTmp_h09e28282__0 = (((IData)(vlSelf->wasmetal_core__DOT___008367_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008366_));
    __VdfgTmp_h199a7061__0 = (((IData)(vlSelf->wasmetal_core__DOT___008366_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008365_));
    __VdfgTmp_h4e0b8941__0 = (((IData)(vlSelf->wasmetal_core__DOT___008365_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008405_));
    __VdfgTmp_hf34c8dd6__0 = (((IData)(vlSelf->wasmetal_core__DOT___008405_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008404_));
    __VdfgTmp_h8b5fdfca__0 = (((IData)(vlSelf->wasmetal_core__DOT___008404_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008403_));
    __VdfgTmp_h524558f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___008403_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008402_));
    vlSelf->__VdfgTmp_h94861db4__0 = (((IData)(vlSelf->wasmetal_core__DOT___008402_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008443_));
    __VdfgTmp_he9911376__0 = (((IData)(vlSelf->wasmetal_core__DOT___008443_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008442_));
    __VdfgTmp_h6299ef40__0 = (((IData)(vlSelf->wasmetal_core__DOT___008442_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008441_));
    vlSelf->__VdfgTmp_h1ab3b1fe__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008440_))));
    vlSelf->__VdfgTmp_h79214203__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008440_));
    vlSelf->wasmetal_core__DOT___009016_ = (1U & (IData)(
                                                         (0xff330f5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008441_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008440_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008442_)))))))));
    __VdfgTmp_hc1229de7__0 = (((IData)(vlSelf->wasmetal_core__DOT___008440_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007854_))));
    vlSelf->wasmetal_core__DOT___055709_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008440_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007858_)))))));
    __VdfgTmp_h1f1491ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___008441_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008440_));
    wasmetal_core__DOT____Vcellout___127528___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023186_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023185_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023184_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023183_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023246_)))));
    vlSelf->wasmetal_core__DOT___023250_ = ((IData)(vlSelf->wasmetal_core__DOT___023186_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b34__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035963_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128803___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b13__05d));
    wasmetal_core__DOT___127495___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h8f31d0f1__0)) 
           & (IData)(wasmetal_core__DOT___127495___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___018503_ = (1U & ((
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058295_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058297_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058296_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058294_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015597_)))))) 
                                                   & (IData)(
                                                             (0x8000000000000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016452_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016451_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016450_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016449_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016448_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___016447_))))))))) 
                                                  & ((0x80U 
                                                      >> 
                                                      ((4U 
                                                        & ((0xf00088U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058249_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058241_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058248_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___058242_)))))) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058234_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___058225_)))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___016433_) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___016432_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016431_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((8U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___058332_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058328_))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016429_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(
                                                                                (0x10ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058309_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058308_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf5238d18__0))))))) 
                                                                                & (IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016444_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016443_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016442_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016441_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heb95d931__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036315_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h6a49916d__0 = (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h513c757b__0));
    vlSelf->wasmetal_core__DOT___057696_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4e8a0148__0))));
    vlSelf->wasmetal_core__DOT___017601_ = ((IData)(wasmetal_core__DOT___013506_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___013508_));
    vlSelf->wasmetal_core__DOT___017728_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___013506_))));
    vlSelf->__VdfgTmp_haf20b36b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017716_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015666_));
    vlSelf->__VdfgTmp_h77210e87__0 = (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015665_));
    vlSelf->wasmetal_core__DOT___057726_ = (1U & ((4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017716_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017640_))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                      ? 
                                                     (0x55330f00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he88fe03e__0))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___006178_)))));
    vlSelf->__VdfgTmp_hf223abb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015668_));
    vlSelf->__VdfgTmp_h2f0f6f72__0 = (((IData)(vlSelf->wasmetal_core__DOT___017623_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015667_));
    vlSelf->wasmetal_core__DOT___057719_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017623_))));
    vlSelf->__VdfgTmp_h692ab415__0 = (((IData)(vlSelf->wasmetal_core__DOT___017610_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015673_));
    vlSelf->wasmetal_core__DOT___013611_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017701_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015671_))))));
    vlSelf->__VdfgTmp_h219534f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017701_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015672_));
    vlSelf->__VdfgTmp_hb3fd333a__0 = (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015671_));
    vlSelf->wasmetal_core__DOT___017676_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057710_))));
    vlSelf->wasmetal_core__DOT___017576_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___013519_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017589_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017561_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057717_)))));
    vlSelf->wasmetal_core__DOT___017548_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017531_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___042788_ = ((IData)(wasmetal_core__DOT___042795_) 
                                            | (IData)(wasmetal_core__DOT___042791_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b49__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_ha1f1e621__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b33__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hc322cfc1__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b28__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b27__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b23__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b22__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b12__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b11__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b10__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h7c001b5f__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b8__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b7__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b6__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b5__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d)))));
    vlSelf->__VdfgTmp_hce64fd81__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d)));
    vlSelf->__VdfgTmp_hf76f8bb1__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d)));
    vlSelf->__VdfgTmp_h90b8d623__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d)));
    vlSelf->__VdfgTmp_h3f89240a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)));
    vlSelf->__VdfgTmp_h65d009ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d)));
    vlSelf->__VdfgTmp_h7dbcfedb__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006117_));
    vlSelf->__VdfgTmp_h95d04b06__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006117_));
    vlSelf->__VdfgTmp_h04542857__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcc37b29f__0));
    vlSelf->__VdfgTmp_h9195d647__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d)));
    vlSelf->__VdfgTmp_h70d6e582__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d)));
    vlSelf->__VdfgTmp_hf5a62b29__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d)));
    vlSelf->__VdfgTmp_h84f7054c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d)));
    vlSelf->__VdfgTmp_hdf4ff5ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d)));
    vlSelf->__VdfgTmp_h767f4755__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d)));
    vlSelf->__VdfgTmp_h93626d60__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d)));
    vlSelf->__VdfgTmp_hc5b0708b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d)));
    vlSelf->__VdfgTmp_hff1a4828__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)));
    vlSelf->__VdfgTmp_h105c18f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)));
    vlSelf->__VdfgTmp_h3dc01c55__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d)));
    vlSelf->__VdfgTmp_h2bde81d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d)));
    vlSelf->__VdfgTmp_h7297059c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d)));
    vlSelf->__VdfgTmp_h1b003ae2__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d)));
    vlSelf->__VdfgTmp_h89d2961b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d)));
    vlSelf->__VdfgTmp_hf97b813d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d)));
    vlSelf->__VdfgTmp_h15d2d521__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)));
    vlSelf->__VdfgTmp_hf30cf57d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d)));
    vlSelf->__VdfgTmp_h9cb72e5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d)));
    vlSelf->__VdfgTmp_h5721c23b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)));
    vlSelf->__VdfgTmp_h7d7923ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d)));
    vlSelf->__VdfgTmp_h7f56c529__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d)));
    vlSelf->__VdfgTmp_h16c6eb53__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d)));
    vlSelf->__VdfgTmp_he5f506d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d)));
    vlSelf->__VdfgTmp_h885d0717__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d)));
    vlSelf->__VdfgTmp_h1caccec5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d)));
    vlSelf->__VdfgTmp_h4b8dd412__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d)));
    vlSelf->__VdfgTmp_h6a2ef1d7__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d)));
    vlSelf->__VdfgTmp_h030e49d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d)));
    vlSelf->__VdfgTmp_h77324dc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d)));
    vlSelf->__VdfgTmp_hfd12f0c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d)));
    vlSelf->__VdfgTmp_heb875033__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he488fa83__0));
    vlSelf->__VdfgTmp_h04659776__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d)));
    vlSelf->__VdfgTmp_hc17e62e9__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d)));
    vlSelf->wasmetal_core__DOT___048955_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128780___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048957_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128780___O))))));
    vlSelf->wasmetal_core__DOT___048958_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128779___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___048956_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128779___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___014455_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048954_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128779___O)))))));
    vlSelf->wasmetal_core__DOT___014456_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048954_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128779___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___035398_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  | ((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                     | (IData)(
                                                               (0x80000000ffffffffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006116_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006115_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006114_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006113_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006112_)))))))))));
    vlSelf->wasmetal_core__DOT___057899_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d))));
    vlSelf->wasmetal_core__DOT___057918_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d))));
    vlSelf->wasmetal_core__DOT___057938_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d))));
    vlSelf->wasmetal_core__DOT___058018_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d))));
    vlSelf->wasmetal_core__DOT___058000_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d))));
    vlSelf->wasmetal_core__DOT___057955_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d))));
    vlSelf->wasmetal_core__DOT___057954_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d))));
    vlSelf->wasmetal_core__DOT___057965_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d))));
    vlSelf->wasmetal_core__DOT___057968_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d))));
    vlSelf->wasmetal_core__DOT___057959_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d))));
    vlSelf->wasmetal_core__DOT___057961_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b46__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b25__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b20__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b19__05d 
        = (1U & (IData)((0xfcccfaaaf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b18__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b17__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b16__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b15__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b14__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b13__05d 
        = (1U & (IData)((0xfcccfaaaf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b10__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b9__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b4__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b3__05d 
        = (1U & (IData)((0xfcccfaaaf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b2__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hbb788d21__0))))))));
    vlSelf->__VdfgTmp_h1cbe113f__0 = (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O)));
    vlSelf->wasmetal_core__DOT___019806_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053103_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053101_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h554fca93__0))))));
    vlSelf->wasmetal_core__DOT___019801_ = (1U & (IData)(
                                                         (0x7f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053516_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___053623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053250_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053247_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053017_)))))))));
    vlSelf->wasmetal_core__DOT___009285_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009293_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h1432c284__0)))))));
    vlSelf->__VdfgTmp_ha91317d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h1432c284__0)));
    vlSelf->wasmetal_core__DOT___009419_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0)))))));
    vlSelf->wasmetal_core__DOT___009284_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x35U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7d874977__0)) 
                                                          << 1U)) 
                                                      | (IData)(wasmetal_core__DOT___055622_)))));
    vlSelf->wasmetal_core__DOT___009110_ = (1U & (IData)(
                                                         (0xfff0ff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055921_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0)))))))))));
    vlSelf->wasmetal_core__DOT___009417_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055622_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055614_)))));
    vlSelf->__VdfgTmp_h35ac7889__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h8ad90c85__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009412_));
    vlSelf->__VdfgTmp_h9f90b4cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h8ad90c85__0))));
    vlSelf->__VdfgTmp_h5e622f55__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009275_));
    vlSelf->__VdfgTmp_h9685faf4__0 = ((2U & ((0x35U 
                                              >> (IData)(__VdfgTmp_h5311778a__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009463_));
    vlSelf->wasmetal_core__DOT___009333_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009459_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1ccd197a__0))))));
    vlSelf->wasmetal_core__DOT___009701_ = (1U & (IData)(
                                                         (0xff0fff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009405_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6ca56fa1__0)))))))))));
    vlSelf->__VdfgTmp_h7856ed04__0 = (((IData)(vlSelf->wasmetal_core__DOT___009405_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x35U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6ca56fa1__0)))));
    vlSelf->__VdfgTmp_h45aa792f__0 = (((IData)(vlSelf->wasmetal_core__DOT___055538_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6ca56fa1__0))));
    vlSelf->__VdfgTmp_had646e7f__0 = ((2U & ((0x35U 
                                              >> (IData)(vlSelf->__VdfgTmp_hbd15e417__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___008877_));
    vlSelf->wasmetal_core__DOT___009259_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009188_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h74a36385__0)))))));
    vlSelf->wasmetal_core__DOT___009329_ = (1U & (0xf5533ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h74a36385__0)))));
    vlSelf->wasmetal_core__DOT___009402_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hb1de0cec__0)))))));
    vlSelf->wasmetal_core__DOT___009050_ = (1U & (IData)(
                                                         (0xff0fff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009400_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb1de0cec__0)))))))))));
    vlSelf->wasmetal_core__DOT___009245_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009035_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___055449_)))));
    vlSelf->wasmetal_core__DOT___009997_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055768_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009175_)))));
    vlSelf->wasmetal_core__DOT___009396_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055449_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055451_)))));
    vlSelf->wasmetal_core__DOT___009246_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009254_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h0c69b60f__0)))))));
    vlSelf->wasmetal_core__DOT___009322_ = (1U & (0xf5533ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h0c69b60f__0)))));
    vlSelf->wasmetal_core__DOT___056162_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xccaaf0f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)) 
                                                                            << 2U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h52b8127f__0))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009956_)))))));
    vlSelf->wasmetal_core__DOT___009397_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)))))));
    vlSelf->wasmetal_core__DOT___009027_ = (1U & (IData)(
                                                         (0xfff0ff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009923_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)))))))))));
    vlSelf->wasmetal_core__DOT___009232_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x35U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hecc250a9__0)) 
                                                          << 1U)) 
                                                      | (IData)(wasmetal_core__DOT___056008_)))));
    vlSelf->wasmetal_core__DOT___009973_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009233_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___009388_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0)))))));
    vlSelf->wasmetal_core__DOT___009386_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___056008_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056079_)))));
    vlSelf->wasmetal_core__DOT___009988_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055718_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009147_)))));
    vlSelf->wasmetal_core__DOT___009375_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___055238_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0eab1d01__0))))));
    vlSelf->__VdfgTmp_h38f150ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___055719_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> (IData)(__VdfgTmp_h58490cb9__0))));
    vlSelf->__VdfgTmp_h1125b1e9__0 = ((2U & ((0x35U 
                                              >> (IData)(__VdfgTmp_h58490cb9__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___055719_));
    vlSelf->wasmetal_core__DOT___009374_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x35U 
                                                         >> (IData)(__VdfgTmp_hf9513718__0))))));
    vlSelf->__VdfgTmp_h6b56eebb__0 = (((IData)(wasmetal_core__DOT___055238_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(__VdfgTmp_hf9513718__0))));
    vlSelf->__VdfgTmp_hb294466b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> (IData)(__VdfgTmp_hf9513718__0))));
    vlSelf->__VdfgTmp_h748d3c0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009477_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055851_)));
    vlSelf->wasmetal_core__DOT___009952_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009296_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->__VdfgTmp_h584d0366__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055689_));
    vlSelf->wasmetal_core__DOT___056169_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055851_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___055850_)))));
    vlSelf->wasmetal_core__DOT___009984_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___055850_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h567718cf__0))))));
    vlSelf->wasmetal_core__DOT___009920_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056147_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___056148_)))));
    vlSelf->wasmetal_core__DOT___009951_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___056148_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xcaU 
                                                            >> (IData)(vlSelf->__VdfgTmp_he25b62bf__0)))))));
    vlSelf->wasmetal_core__DOT___062378_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009400_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hb1de0cec__0)))))))));
    vlSelf->wasmetal_core__DOT___009708_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055984_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___009998_ = (1U & (IData)(
                                                         (0xfafcf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_he55661b3__0))))))));
    vlSelf->wasmetal_core__DOT___056221_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he55661b3__0))));
    vlSelf->wasmetal_core__DOT___062396_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(__VdfgTmp_h4bc07745__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009441_)))));
    vlSelf->__VdfgTmp_h52168cf5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(__VdfgTmp_h4bc07745__0))));
    vlSelf->wasmetal_core__DOT___009170_ = (1U & (IData)(
                                                         (0xff0fff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009441_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h4bc07745__0))))))));
    vlSelf->wasmetal_core__DOT___062485_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7bd92bc0__0))))));
    vlSelf->__VdfgTmp_h16f25fe1__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h7bd92bc0__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009465_));
    vlSelf->wasmetal_core__DOT___055825_ = (1U & (IData)(
                                                         (0xf0f00005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009979_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009463_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> (IData)(__VdfgTmp_h5311778a__0)))))))))));
    vlSelf->wasmetal_core__DOT___062401_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(__VdfgTmp_h073f9b05__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009460_)))));
    vlSelf->__VdfgTmp_h18926335__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(__VdfgTmp_h073f9b05__0))));
    vlSelf->wasmetal_core__DOT___009199_ = (1U & (IData)(
                                                         (0xff0fff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009460_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h073f9b05__0))))))));
    vlSelf->__VdfgTmp_h3dedcb44__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h3eec0328__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009434_));
    vlSelf->__VdfgTmp_h20f110d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3eec0328__0))));
    vlSelf->wasmetal_core__DOT___055739_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h243a5897__0))));
    vlSelf->__VdfgTmp_heabab031__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf516e409__0))));
    vlSelf->wasmetal_core__DOT___009728_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xccaaf0f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0)) 
                                                                            << 2U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hd2b13b0f__0))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009945_)))))));
    vlSelf->wasmetal_core__DOT___009276_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h282170d2__0))));
    vlSelf->__VdfgTmp_h7c9afb82__0 = (((IData)(vlSelf->wasmetal_core__DOT___009258_) 
                                       << 1U) | (1U 
                                                 & (0x3355f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((0x35U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb1de0cec__0)) 
                                                               << 2U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbf11cfc1__0)))))));
    vlSelf->wasmetal_core__DOT___011285_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xccaaf0f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0)) 
                                                                            << 2U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h381f02c3__0))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009972_)))))));
    vlSelf->wasmetal_core__DOT___055362_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009967_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055359_)))));
    vlSelf->wasmetal_core__DOT___062491_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7ca1d027__0))))));
    vlSelf->wasmetal_core__DOT___009219_ = (1U & (IData)(
                                                         (0xff0fff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009479_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7ca1d027__0))))))));
    vlSelf->wasmetal_core__DOT___055710_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009295_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x3355f0f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055689_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hd3eaf9cd__0))))))))));
    vlSelf->__VdfgTmp_h4d366d59__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_heeb49de9__0)));
    vlSelf->__VdfgTmp_hd4d63a34__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h66d4b740__0)));
    vlSelf->wasmetal_core__DOT___007906_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007905_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007904_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h422b1f0e__0))))))));
    vlSelf->__VdfgTmp_hae568380__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007904_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007903_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h45767413__0)))));
    vlSelf->__VdfgTmp_h3068c687__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h45767413__0)));
    vlSelf->__VdfgTmp_h3ba3f00e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h3043729e__0)));
    vlSelf->__VdfgTmp_h7737ac68__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007903_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007902_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h3043729e__0)))));
    vlSelf->wasmetal_core__DOT___055481_ = (1U & (0xf0f055ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007902_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007942_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h78ab269f__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x53U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                   << 2U) 
                                                                  | (IData)(__VdfgTmp_h66d4b740__0))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xacU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007904_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___007903_)))))))))));
    vlSelf->__VdfgTmp_hf33cf413__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h78ab269f__0)));
    vlSelf->wasmetal_core__DOT___008639_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007941_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h984be98a__0))))))));
    vlSelf->__VdfgTmp_h935ba97a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h984be98a__0)));
    vlSelf->__VdfgTmp_h21ecfb21__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4bfa77b1__0)));
    vlSelf->__VdfgTmp_h83c5326a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha9e5b07a__0)));
    vlSelf->__VdfgTmp_h8c5bf8f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_ha94b79fc__0)));
    vlSelf->__VdfgTmp_h85f1be24__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007939_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007981_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_ha94b79fc__0)))));
    vlSelf->__VdfgTmp_haff0ba2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007981_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007980_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hcf6d3894__0)))));
    vlSelf->__VdfgTmp_hae7eba08__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hcf6d3894__0)));
    vlSelf->__VdfgTmp_hc719aa4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007980_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007979_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h509cc1df__0)))));
    vlSelf->__VdfgTmp_hdb0e0153__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h509cc1df__0)));
    vlSelf->__VdfgTmp_h0d1d68d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007979_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007978_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h86440ee1__0)))));
    vlSelf->__VdfgTmp_hf5a39c51__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h86440ee1__0)));
    vlSelf->__VdfgTmp_hee048ece__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007978_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008028_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h62a41e7a__0)))));
    vlSelf->__VdfgTmp_hc903ec6a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h62a41e7a__0)));
    vlSelf->wasmetal_core__DOT___008642_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008028_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008027_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hc8a1f90d__0))))))));
    vlSelf->__VdfgTmp_ha30079fd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hc8a1f90d__0)));
    vlSelf->__VdfgTmp_hab9b53a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc20acf35__0)));
    vlSelf->__VdfgTmp_hab3491b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008026_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008025_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_he9adc993__0)))));
    vlSelf->wasmetal_core__DOT___008558_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_he9adc993__0)))));
    vlSelf->__VdfgTmp_h09c5f4e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h23e62674__0)));
    vlSelf->__VdfgTmp_hc229347b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008025_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008067_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h23e62674__0)))));
    vlSelf->__VdfgTmp_h0de86ccc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008067_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008066_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6bf7b02b__0)))));
    vlSelf->__VdfgTmp_hc1f7329f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h6bf7b02b__0)));
    vlSelf->__VdfgTmp_hd3e9a659__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008066_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008065_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hb0c1ca1e__0)))));
    vlSelf->__VdfgTmp_hbb21088e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hb0c1ca1e__0)));
    vlSelf->wasmetal_core__DOT___055459_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008065_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008064_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_hba82f58f__0))))))));
    vlSelf->__VdfgTmp_hb1634503__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hba82f58f__0)));
    vlSelf->__VdfgTmp_h3429c82f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008064_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008104_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h36eed793__0)))));
    vlSelf->__VdfgTmp_h04ff5b07__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h36eed793__0)));
    vlSelf->wasmetal_core__DOT___055550_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008104_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008103_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h003583a9__0))))))));
    vlSelf->__VdfgTmp_h6bb5c719__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h003583a9__0)));
    vlSelf->__VdfgTmp_hfb017b9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008103_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008102_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h39517120__0)))));
    vlSelf->__VdfgTmp_h3c51f194__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h39517120__0)));
    vlSelf->__VdfgTmp_ha22ec9f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008101_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6f4dbdf9__0)))));
    vlSelf->__VdfgTmp_hce5d0ce9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h6f4dbdf9__0)));
    vlSelf->__VdfgTmp_h7cb0a391__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hf92edf21__0)));
    vlSelf->__VdfgTmp_hb46d48f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008101_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008142_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hf92edf21__0)))));
    vlSelf->__VdfgTmp_h7092c9cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008142_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008141_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h1a11d128__0)))));
    vlSelf->__VdfgTmp_h1390519c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h1a11d128__0)));
    vlSelf->__VdfgTmp_hefb478a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008141_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008140_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h9087e671__0)))));
    vlSelf->__VdfgTmp_h9b67b4e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h9087e671__0)));
    vlSelf->__VdfgTmp_h855995cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008140_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008139_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h281b8ab1__0)))));
    vlSelf->__VdfgTmp_h158bc821__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h281b8ab1__0)));
    vlSelf->__VdfgTmp_h114e86e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008139_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008179_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h7ae355e5__0)))));
    vlSelf->__VdfgTmp_hf0c32555__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h7ae355e5__0)));
    vlSelf->__VdfgTmp_h91c21bf0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008179_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008178_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hae4042e0__0)))));
    vlSelf->__VdfgTmp_h8daf8054__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hae4042e0__0)));
    vlSelf->__VdfgTmp_hed13b60d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008178_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008177_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h029c8a85__0)))));
    vlSelf->__VdfgTmp_h690ec875__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h029c8a85__0)));
    vlSelf->__VdfgTmp_h0c7e8da3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008177_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008176_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hea01e0cb__0)))));
    vlSelf->__VdfgTmp_h43e1a2bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hea01e0cb__0)));
    vlSelf->__VdfgTmp_hc1d26d4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h6bd09dd8__0)));
    vlSelf->__VdfgTmp_h3418aecb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008176_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008217_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6bd09dd8__0)))));
    vlSelf->__VdfgTmp_h051dc5dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008217_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008216_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_he0f5bdf9__0)))));
    vlSelf->__VdfgTmp_h4af50ce9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he0f5bdf9__0)));
    vlSelf->__VdfgTmp_hf618fe17__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008216_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008215_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h004771e7__0)))));
    vlSelf->__VdfgTmp_h6ba7f15b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h004771e7__0)));
    vlSelf->__VdfgTmp_h2ada8d2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008215_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008214_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hb3c8072f__0)))));
    vlSelf->wasmetal_core__DOT___008255_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hb3c8072f__0)))));
    vlSelf->__VdfgTmp_he5945a68__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008214_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008254_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hd226433b__0)))));
    vlSelf->__VdfgTmp_h5985862f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hd226433b__0)));
    vlSelf->__VdfgTmp_ha8c0c19d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008254_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008253_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6e85e3ea__0)))));
    vlSelf->__VdfgTmp_hcd65a75a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h6e85e3ea__0)));
    vlSelf->wasmetal_core__DOT___055577_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008253_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008252_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_ha3cbecc2__0))))))));
    vlSelf->__VdfgTmp_h89da7eb2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_ha3cbecc2__0)));
    vlSelf->wasmetal_core__DOT___055627_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008252_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008251_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h8255702a__0))))))));
    vlSelf->__VdfgTmp_he955f29a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h8255702a__0)));
    vlSelf->__VdfgTmp_he1802e5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h8a1e5cea__0)));
    vlSelf->__VdfgTmp_hefdefca0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008251_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008292_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h8a1e5cea__0)))));
    vlSelf->wasmetal_core__DOT___051933_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008292_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008291_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h7cc8bc90__0))))))));
    vlSelf->__VdfgTmp_hfeda0e04__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h7cc8bc90__0)));
    vlSelf->__VdfgTmp_h91b07825__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008291_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008290_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h31ba5af5__0)))));
    vlSelf->__VdfgTmp_h042cd865__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h31ba5af5__0)));
    vlSelf->__VdfgTmp_he2ba4454__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008290_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008289_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h77b03a4f__0)))));
    vlSelf->__VdfgTmp_hc63fb8c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h77b03a4f__0)));
    vlSelf->__VdfgTmp_hc2ad9167__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008289_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008329_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hc49bb9d8__0)))));
    vlSelf->__VdfgTmp_hb70b394c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hc49bb9d8__0)));
    vlSelf->__VdfgTmp_h70bc0e9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008329_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008328_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h038396ba__0)))));
    vlSelf->__VdfgTmp_h6a6364aa__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h038396ba__0)));
    vlSelf->__VdfgTmp_hf74c6a47__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008328_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008327_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hfb882020__0)))));
    vlSelf->__VdfgTmp_h7267e294__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hfb882020__0)));
    vlSelf->__VdfgTmp_hf4d4c7d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008327_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008326_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h7fe0949a__0)))));
    vlSelf->__VdfgTmp_hfdc2660a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h7fe0949a__0)));
    vlSelf->__VdfgTmp_h63c4c072__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h09e28282__0)));
    vlSelf->__VdfgTmp_h70291c6e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008326_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008368_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h09e28282__0)))));
    vlSelf->__VdfgTmp_h850327e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008368_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008367_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h199a7061__0)))));
    vlSelf->__VdfgTmp_h1c0cf2d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h199a7061__0)));
    vlSelf->__VdfgTmp_h950f0cb0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008367_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008366_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h4e0b8941__0)))));
    vlSelf->__VdfgTmp_h2f9bc831__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h4e0b8941__0)));
    vlSelf->__VdfgTmp_hd89c9b51__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008366_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008365_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hf34c8dd6__0)))));
    vlSelf->__VdfgTmp_h7a5e1d46__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hf34c8dd6__0)));
    vlSelf->__VdfgTmp_hdd777bec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008365_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008405_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h8b5fdfca__0)))));
    vlSelf->__VdfgTmp_he24fa3ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h8b5fdfca__0)));
    vlSelf->__VdfgTmp_h69785613__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008405_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008404_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h524558f7__0)))));
    vlSelf->__VdfgTmp_hd9a5d9eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h524558f7__0)));
    vlSelf->__VdfgTmp_h2c35a4fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008404_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008403_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h94861db4__0)))));
    vlSelf->__VdfgTmp_h6405266c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h94861db4__0));
    vlSelf->__VdfgTmp_hf17c2029__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008403_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008402_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_he9911376__0)))));
    vlSelf->__VdfgTmp_h4c1297e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he9911376__0)));
    vlSelf->__VdfgTmp_h0dadf452__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h6299ef40__0))));
    vlSelf->__VdfgTmp_h5629f5f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 2U) | (IData)(__VdfgTmp_h6299ef40__0));
    vlSelf->__VdfgTmp_hee6f9dc2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008402_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008443_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6299ef40__0)))));
    vlSelf->wasmetal_core__DOT___055932_ = (1U & (0xfeffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_hc1229de7__0))));
    vlSelf->wasmetal_core__DOT___009480_ = ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                            & (IData)(
                                                      (0x1000100ffff0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008962_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_hc1229de7__0))))));
    vlSelf->__VdfgTmp_h08b4abe6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 4U) | (IData)(__VdfgTmp_hc1229de7__0));
    vlSelf->__VdfgTmp_hca6b58ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h1f1491ac__0)))));
    vlSelf->__VdfgTmp_h637d46f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h1f1491ac__0))));
    vlSelf->__VdfgTmp_h5618ebf3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008443_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008442_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h1f1491ac__0)))));
    vlSelf->__VdfgTmp_h9bf7e2f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                       << 2U) | (IData)(__VdfgTmp_h1f1491ac__0));
    if (vlSelf->wasmetal_core__DOT___007866_) {
        vlSelf->wasmetal_core__DOT___007853_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_heeb49de9__0))));
        vlSelf->wasmetal_core__DOT___007856_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0)));
        vlSelf->wasmetal_core__DOT___055545_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hae7eba08__0)));
        vlSelf->wasmetal_core__DOT___051315_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha30079fd__0)));
        vlSelf->wasmetal_core__DOT___055744_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0)));
        vlSelf->wasmetal_core__DOT___055458_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008558_));
        vlSelf->wasmetal_core__DOT___055474_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0)));
        vlSelf->wasmetal_core__DOT___055549_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1f7329f__0)));
        vlSelf->wasmetal_core__DOT___055818_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0)));
        vlSelf->wasmetal_core__DOT___055630_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb1634503__0)));
        vlSelf->wasmetal_core__DOT___055845_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0)));
        vlSelf->wasmetal_core__DOT___051313_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)));
        vlSelf->wasmetal_core__DOT___055353_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)));
        vlSelf->wasmetal_core__DOT___055742_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055395_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055456_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0)));
        vlSelf->wasmetal_core__DOT___055898_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0)));
        vlSelf->wasmetal_core__DOT___055472_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0)));
        vlSelf->wasmetal_core__DOT___055547_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1390519c__0)));
        vlSelf->wasmetal_core__DOT___055925_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h158bc821__0)));
        vlSelf->wasmetal_core__DOT___055701_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0)));
        vlSelf->wasmetal_core__DOT___051934_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055358_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055945_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055391_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055885_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055454_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1d26d4c__0)));
        vlSelf->wasmetal_core__DOT___055470_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1d26d4c__0)));
        vlSelf->wasmetal_core__DOT___055804_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4af50ce9__0)));
        vlSelf->wasmetal_core__DOT___055530_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4af50ce9__0)));
        vlSelf->wasmetal_core__DOT___055576_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ba7f15b__0)));
        vlSelf->wasmetal_core__DOT___055626_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008255_));
        vlSelf->wasmetal_core__DOT___055844_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___055699_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___051932_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd65a75a__0)));
        vlSelf->wasmetal_core__DOT___055947_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)));
        vlSelf->wasmetal_core__DOT___055389_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)));
        vlSelf->wasmetal_core__DOT___055887_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___055452_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___009878_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0)));
        vlSelf->wasmetal_core__DOT___008856_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___009338_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___009353_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h042cd865__0)));
        vlSelf->wasmetal_core__DOT___009860_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0)));
        vlSelf->wasmetal_core__DOT___008930_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0)));
        vlSelf->wasmetal_core__DOT___009368_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0)));
        vlSelf->wasmetal_core__DOT___009381_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0)));
        vlSelf->wasmetal_core__DOT___009392_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7267e294__0)));
        vlSelf->wasmetal_core__DOT___009031_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0)));
        vlSelf->wasmetal_core__DOT___009067_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___008831_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___008859_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___009090_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___009352_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___008900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___009124_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___008929_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___009017_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h94861db4__0)))));
        vlSelf->wasmetal_core__DOT___008958_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he24fa3ba__0)));
        vlSelf->wasmetal_core__DOT___009367_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he24fa3ba__0)));
        vlSelf->wasmetal_core__DOT___009380_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0)));
        vlSelf->wasmetal_core__DOT___008990_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0)));
        vlSelf->wasmetal_core__DOT___009034_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4c1297e6__0)));
        vlSelf->wasmetal_core__DOT___009101_ = (1U 
                                                & (0x3331U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1ab3b1fe__0)));
        vlSelf->wasmetal_core__DOT___055575_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1ab3b1fe__0)));
        vlSelf->wasmetal_core__DOT___008861_ = (1U 
                                                & (0xa0cU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9bf7e2f7__0))));
    } else {
        vlSelf->wasmetal_core__DOT___007853_ = (1U 
                                                & (0xfeeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007864_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & (((IData)(vlSelf->wasmetal_core__DOT___007874_)
                                                                ? 
                                                               (0x5333U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007883_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))))))
                                                                : 
                                                               (1U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007883_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___007881_)))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0x8f00U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb0e57990__0))))))))));
        vlSelf->wasmetal_core__DOT___007856_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3ba3f00e__0)));
        vlSelf->wasmetal_core__DOT___055545_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h83c5326a__0)));
        vlSelf->wasmetal_core__DOT___051315_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0)));
        vlSelf->wasmetal_core__DOT___055744_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0)));
        vlSelf->wasmetal_core__DOT___055458_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha30079fd__0)));
        vlSelf->wasmetal_core__DOT___055474_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0)));
        vlSelf->wasmetal_core__DOT___055549_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008558_));
        vlSelf->wasmetal_core__DOT___055818_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0)));
        vlSelf->wasmetal_core__DOT___055630_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1f7329f__0)));
        vlSelf->wasmetal_core__DOT___055845_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0)));
        vlSelf->wasmetal_core__DOT___051313_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb1634503__0)));
        vlSelf->wasmetal_core__DOT___055353_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb1634503__0)));
        vlSelf->wasmetal_core__DOT___055742_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0)));
        vlSelf->wasmetal_core__DOT___055395_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0)));
        vlSelf->wasmetal_core__DOT___055456_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)));
        vlSelf->wasmetal_core__DOT___055898_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055472_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c51f194__0)));
        vlSelf->wasmetal_core__DOT___055547_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0)));
        vlSelf->wasmetal_core__DOT___055925_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1390519c__0)));
        vlSelf->wasmetal_core__DOT___055701_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0)));
        vlSelf->wasmetal_core__DOT___051934_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h158bc821__0)));
        vlSelf->wasmetal_core__DOT___055358_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h158bc821__0)));
        vlSelf->wasmetal_core__DOT___055945_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0)));
        vlSelf->wasmetal_core__DOT___055391_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0)));
        vlSelf->wasmetal_core__DOT___055885_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055454_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8daf8054__0)));
        vlSelf->wasmetal_core__DOT___055900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055470_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690ec875__0)));
        vlSelf->wasmetal_core__DOT___055804_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055530_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h43e1a2bf__0)));
        vlSelf->wasmetal_core__DOT___055576_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc1d26d4c__0)));
        vlSelf->wasmetal_core__DOT___055626_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4af50ce9__0)));
        vlSelf->wasmetal_core__DOT___055844_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ba7f15b__0)));
        vlSelf->wasmetal_core__DOT___055699_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ba7f15b__0)));
        vlSelf->wasmetal_core__DOT___051932_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___008255_));
        vlSelf->wasmetal_core__DOT___055947_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___055389_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5985862f__0)));
        vlSelf->wasmetal_core__DOT___055887_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd65a75a__0)));
        vlSelf->wasmetal_core__DOT___055452_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd65a75a__0)));
        vlSelf->wasmetal_core__DOT___009878_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)));
        vlSelf->wasmetal_core__DOT___008856_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___009338_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he955f29a__0)));
        vlSelf->wasmetal_core__DOT___009353_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0)));
        vlSelf->wasmetal_core__DOT___009860_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___008930_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeda0e04__0)));
        vlSelf->wasmetal_core__DOT___009368_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h042cd865__0)));
        vlSelf->wasmetal_core__DOT___009381_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0)));
        vlSelf->wasmetal_core__DOT___009392_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0)));
        vlSelf->wasmetal_core__DOT___009031_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0)));
        vlSelf->wasmetal_core__DOT___009067_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7267e294__0)));
        vlSelf->wasmetal_core__DOT___008831_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7267e294__0)));
        vlSelf->wasmetal_core__DOT___008859_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0)));
        vlSelf->wasmetal_core__DOT___009090_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0)));
        vlSelf->wasmetal_core__DOT___009352_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___008900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___009124_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___008929_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___009017_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he24fa3ba__0)));
        vlSelf->wasmetal_core__DOT___008958_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___009367_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___009380_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___008990_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___009034_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0)));
        vlSelf->wasmetal_core__DOT___009101_ = (1U 
                                                & (0xf050f03U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0dadf452__0)));
        vlSelf->wasmetal_core__DOT___055575_ = (1U 
                                                & (0xa000cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0dadf452__0)));
        vlSelf->wasmetal_core__DOT___008861_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4c1297e6__0)));
    }
    if (vlSelf->wasmetal_core__DOT___007858_) {
        vlSelf->wasmetal_core__DOT___008901_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                    ? 
                                                   (0xfdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___008440_))))
                                                    : 
                                                   (0xf5f3U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h6299ef40__0))))));
        vlSelf->wasmetal_core__DOT___008932_ = (1U 
                                                & (0xfff5fff3U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9bf7e2f7__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___008901_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008904_)));
        vlSelf->wasmetal_core__DOT___008932_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008935_)));
    }
    vlSelf->wasmetal_core__DOT___005916_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127528___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xff03fe02ff03aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hd9cc8b65__0))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hd9cc8b65__0))))));
    vlSelf->wasmetal_core__DOT___005850_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127528___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h18c745e6__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h18c745e6__0)))))));
    vlSelf->wasmetal_core__DOT___005780_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127528___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2c009b21__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7136f53f__0)))));
    vlSelf->wasmetal_core__DOT___005781_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127528___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he5d5d55b__0)))
                                                        : 
                                                       (0x302U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8057b5__0)))));
    vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023187_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023250_));
    vlSelf->wasmetal_core__DOT____Vcellout___128884___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b35__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b34__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b33__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b32__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036490_)))));
    vlSelf->wasmetal_core__DOT___036494_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b35__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035964_)
            ? (IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b14__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127495___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b3__05d) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h8f31d0f1__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hba6f19f8__0)) 
                                                << 1U)) 
                                         | (1U & (9U 
                                                  >> (IData)(vlSelf->__VdfgTmp_had1ad578__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127495___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127495___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_had1ad578__0))) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023013_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b3__05d) 
                                            & (IData)(wasmetal_core__DOT___127495___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___017938_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018505_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018507_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018503_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))));
    vlSelf->wasmetal_core__DOT___017937_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058532_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058531_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018503_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (((1U 
                                                                    & (0xe000U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)))
                                                                    ? 
                                                                   (1U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                                    : (IData)(
                                                                              (0xffffff8fffffffULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___015964_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015954_))))))))) 
                                                                  & (IData)(
                                                                            (0x8000000000000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___016460_) 
                                                                               << 5U) 
                                                                              | (((IData)(wasmetal_core__DOT___016459_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016458_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfff1ff00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058242_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058233_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbec899f6__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058342_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058341_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfff1ff00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058248_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058255_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc888fbf4__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058346_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058345_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058521_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058338_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058350_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058349_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058348_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058347_))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___013612_ = (1U & (0xeU 
                                                  >> 
                                                  ((((~ (IData)(vlSelf->wasmetal_core__DOT___013621_)) 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___013508_)) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017728_)))));
    vlSelf->__VdfgTmp_h25476d0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___017728_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015765_));
    vlSelf->wasmetal_core__DOT___013381_ = (1U & (IData)(
                                                         (0xefefef00efefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017701_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015671_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017728_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf20b36b__0))))))));
    vlSelf->wasmetal_core__DOT___013379_ = (1U & (IData)(
                                                         (0xefefef00efefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017623_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h692ab415__0))))))));
    vlSelf->wasmetal_core__DOT___058982_ = (1U & (0xeeeef0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017610_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017623_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h219534f4__0))))));
    vlSelf->__VdfgTmp_h7594c868__0 = (((IData)(vlSelf->wasmetal_core__DOT___017676_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015674_));
    vlSelf->wasmetal_core__DOT___013613_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017576_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015656_))))));
    vlSelf->__VdfgTmp_h46466860__0 = (((IData)(vlSelf->wasmetal_core__DOT___017576_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013520_));
    vlSelf->__VdfgTmp_h8c0ae79e__0 = (((IData)(vlSelf->wasmetal_core__DOT___013519_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015677_));
    vlSelf->wasmetal_core__DOT___057712_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017599_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013519_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017576_)))))));
    vlSelf->wasmetal_core__DOT___057722_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017676_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013519_))));
    vlSelf->__VdfgTmp_h9ce496ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015678_));
    vlSelf->wasmetal_core__DOT___013524_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017561_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015676_))))));
    vlSelf->__VdfgTmp_h3d32f603__0 = (((IData)(vlSelf->wasmetal_core__DOT___017561_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015676_));
    vlSelf->wasmetal_core__DOT___013380_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017600_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015676_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017561_)))))));
    vlSelf->wasmetal_core__DOT___013522_ = (1U & (0xe0eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xefU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017548_))))));
    vlSelf->__VdfgTmp_h9110e1f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___017548_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015681_));
    vlSelf->wasmetal_core__DOT___017598_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017548_))));
    vlSelf->__VdfgTmp_h0bc68a5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___017531_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015776_));
    vlSelf->wasmetal_core__DOT___057703_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017531_))));
    vlSelf->wasmetal_core__DOT___057707_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017548_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017531_))));
    vlSelf->__VdfgTmp_h56cb633a__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0))));
    vlSelf->__VdfgTmp_ha3ec838c__0 = ((4U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x53U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0)) 
                                                << 1U)) 
                                         | (1U & (0x53U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)))));
    vlSelf->__VdfgTmp_hed9f0c33__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0))));
    vlSelf->wasmetal_core__DOT___058043_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x53U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h93626d60__0))))))));
    vlSelf->wasmetal_core__DOT___058044_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hff1a4828__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0))))));
    vlSelf->__VdfgTmp_hff1952b3__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_hff1a4828__0))));
    vlSelf->__VdfgTmp_he122bc0f__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h9cb72e5a__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0))));
    vlSelf->__VdfgTmp_hdb52a936__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0))));
    vlSelf->wasmetal_core__DOT___057787_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77324dc0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0))))));
    vlSelf->__VdfgTmp_h91cdf6cd__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h77324dc0__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0))));
    vlSelf->wasmetal_core__DOT___013631_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048955_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048954_))));
    vlSelf->wasmetal_core__DOT___014360_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048957_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048954_))));
    vlSelf->wasmetal_core__DOT___014358_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048958_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048954_))));
    vlSelf->wasmetal_core__DOT___014357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048956_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048954_))));
    vlSelf->wasmetal_core__DOT___057957_ = (1U & (0xf0f05533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9195d647__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7c001b5f__0))))));
    vlSelf->wasmetal_core__DOT___057934_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)))))));
    vlSelf->wasmetal_core__DOT___014453_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9cb72e5a__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf30cf57d__0)))))));
    vlSelf->wasmetal_core__DOT___057935_ = (1U & (0x5533f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf30cf57d__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc322cfc1__0))))));
    vlSelf->wasmetal_core__DOT___014460_ = (1U & (0x5533f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcc37b29f__0))))));
    vlSelf->wasmetal_core__DOT___057914_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0)))))));
    vlSelf->wasmetal_core__DOT___057913_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h77324dc0__0)))))));
    vlSelf->wasmetal_core__DOT___057929_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)))))));
    vlSelf->wasmetal_core__DOT___057911_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0))))));
    vlSelf->wasmetal_core__DOT___057912_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha1f1e621__0)))));
    vlSelf->wasmetal_core__DOT___057909_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h04659776__0))))));
    vlSelf->wasmetal_core__DOT___057910_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0))))));
    vlSelf->wasmetal_core__DOT___057928_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_heb875033__0))))));
    vlSelf->wasmetal_core__DOT___057930_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)))))));
    vlSelf->wasmetal_core__DOT___057931_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0)))))));
    vlSelf->wasmetal_core__DOT___057933_ = (1U & (0x5533f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h04659776__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha1f1e621__0))))));
    vlSelf->wasmetal_core__DOT___057932_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_heb875033__0)))))));
    vlSelf->wasmetal_core__DOT___057976_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x53U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0))))))));
    vlSelf->wasmetal_core__DOT___058057_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0)))))))))));
    vlSelf->wasmetal_core__DOT___058029_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hff1a4828__0)))))))))));
    vlSelf->wasmetal_core__DOT___058034_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)))))))))));
    vlSelf->wasmetal_core__DOT___058025_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)))))))))));
    vlSelf->wasmetal_core__DOT___014446_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)))))))))));
    vlSelf->wasmetal_core__DOT___014354_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h04542857__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0)))))))))));
    vlSelf->wasmetal_core__DOT___014353_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)))))))))));
    vlSelf->wasmetal_core__DOT___014959_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048958_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048957_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048956_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048955_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___014456_)))))));
    vlSelf->wasmetal_core__DOT___057908_ = (1U & (IData)(
                                                         (0xb00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x53U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0x53U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057899_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h95d04b06__0))))))));
    vlSelf->wasmetal_core__DOT___057916_ = (1U & (0xf0f000bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057899_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h95d04b06__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b33__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057899_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___057926_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057918_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT___057939_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057938_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT___058019_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058018_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b23__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___058018_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___058010_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058000_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b22__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___058000_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___058031_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006117_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b12__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___058046_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he29625ac__0))))));
    vlSelf->wasmetal_core__DOT___057978_ = (1U & (IData)(
                                                         (0x5555333300ff000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7c001b5f__0))))))));
    vlSelf->wasmetal_core__DOT___057956_ = (1U & (IData)(
                                                         (0xf0f030300ff0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he29625ac__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b11__05d 
        = (1U & (0xfcfaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___057969_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057965_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b8__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057965_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d)))))));
    vlSelf->__VdfgTmp_ha1cc8027__0 = (((IData)(vlSelf->wasmetal_core__DOT___057968_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7dbcfedb__0));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b7__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057968_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___057963_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057959_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b6__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057959_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___057962_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057961_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b5__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057961_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___035659_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d))));
    vlSelf->wasmetal_core__DOT___035636_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d))));
    vlSelf->wasmetal_core__DOT___035630_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d))));
    vlSelf->wasmetal_core__DOT___035629_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d))));
    vlSelf->wasmetal_core__DOT___035628_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d))));
    vlSelf->wasmetal_core__DOT___035627_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d))));
    vlSelf->wasmetal_core__DOT___035626_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d))));
    vlSelf->wasmetal_core__DOT___035625_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d))));
    vlSelf->wasmetal_core__DOT___035624_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d))));
    vlSelf->wasmetal_core__DOT___035623_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d))));
    vlSelf->wasmetal_core__DOT___035673_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d))));
    vlSelf->wasmetal_core__DOT___035672_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d))));
    vlSelf->wasmetal_core__DOT___035653_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d))));
    vlSelf->wasmetal_core__DOT___035642_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d))));
    vlSelf->wasmetal_core__DOT___035631_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b54__05d 
        = (1U & (8U >> ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b53__05d 
        = (1U & (0xf888U >> ((8U & ((8U >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b52__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b51__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b50__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b49__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b48__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b47__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b45__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b44__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b43__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b42__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b41__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b40__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b39__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b38__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b37__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b36__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b35__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b34__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b32__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b31__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b30__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b29__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b28__05d 
        = (1U & (0xfffff888U >> (((IData)(vlSelf->wasmetal_core__DOT___057918_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d) 
                                             << 3U) 
                                            | ((4U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                   << 2U)) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b27__05d 
        = (1U & (0xfffff888U >> (((IData)(vlSelf->wasmetal_core__DOT___057938_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                             << 3U) 
                                            | ((4U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                   << 2U)) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b26__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b24__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b21__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b1__05d 
        = (1U & (0xf888U >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0))))))));
    vlSelf->wasmetal_core__DOT___009946_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009285_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___056219_ = (1U & (0xf3faU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009357_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf0aacc00U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha91317d0__0)))))))));
    vlSelf->wasmetal_core__DOT___009358_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf0aacc00U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha91317d0__0))))));
    vlSelf->wasmetal_core__DOT___055837_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009357_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha91317d0__0)))))));
    vlSelf->__VdfgTmp_h890a41f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___009284_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055614_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0))))))));
    vlSelf->wasmetal_core__DOT___062388_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009417_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h48a07a7e__0)))))))));
    vlSelf->wasmetal_core__DOT___061165_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h35ac7889__0))));
    vlSelf->wasmetal_core__DOT___009940_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e622f55__0)))));
    vlSelf->wasmetal_core__DOT___062362_ = (1U & (IData)(
                                                         (0xf0f33aa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009346_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9685faf4__0))))))));
    vlSelf->wasmetal_core__DOT___009348_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9685faf4__0)))));
    vlSelf->wasmetal_core__DOT___062381_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7856ed04__0)))));
    vlSelf->wasmetal_core__DOT___009083_ = (1U & (0xf0044U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7856ed04__0)))));
    vlSelf->wasmetal_core__DOT___009935_ = (1U & (IData)(
                                                         (0xf3faf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h45aa792f__0))))))));
    vlSelf->wasmetal_core__DOT___009757_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h45aa792f__0))));
    vlSelf->wasmetal_core__DOT___061031_ = (1U & (0xf0f0cc55U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009333_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_had646e7f__0))))));
    vlSelf->wasmetal_core__DOT___009335_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had646e7f__0)))));
    vlSelf->wasmetal_core__DOT___009962_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009259_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___062442_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009329_))));
    vlSelf->__VdfgTmp_h792a3800__0 = (((IData)(vlSelf->wasmetal_core__DOT___009330_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009329_));
    vlSelf->wasmetal_core__DOT___055464_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009245_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055451_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)))))))));
    vlSelf->wasmetal_core__DOT___062375_ = (1U & (0xf440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009396_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3f55ca01__0)))))))));
    vlSelf->wasmetal_core__DOT___009398_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009397_)))));
    vlSelf->__VdfgTmp_h3b5a0ff3__0 = (((IData)(vlSelf->wasmetal_core__DOT___009232_) 
                                       << 1U) | (1U 
                                                 & (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056079_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0))))))));
    vlSelf->wasmetal_core__DOT___009389_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009388_)))));
    vlSelf->wasmetal_core__DOT___060828_ = (1U & (0xf0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009386_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0))))))));
    vlSelf->__VdfgTmp_h32990406__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h38f150ef__0))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009988_));
    vlSelf->wasmetal_core__DOT___060752_ = (1U & (0xf055ccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055718_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1125b1e9__0))))));
    vlSelf->wasmetal_core__DOT___009308_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1125b1e9__0))));
    vlSelf->wasmetal_core__DOT___062453_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009374_))));
    vlSelf->__VdfgTmp_h41d1df16__0 = (((IData)(vlSelf->wasmetal_core__DOT___009375_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009374_));
    vlSelf->wasmetal_core__DOT___009225_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6b56eebb__0))));
    vlSelf->wasmetal_core__DOT___008975_ = (1U & (IData)(
                                                         (0xfff0ff88ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009930_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb294466b__0))))))));
    vlSelf->wasmetal_core__DOT___009363_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h748d3c0c__0))));
    vlSelf->wasmetal_core__DOT___062469_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h584d0366__0))))));
    vlSelf->wasmetal_core__DOT___009425_ = (1U & (0x200U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h584d0366__0))))))));
    vlSelf->wasmetal_core__DOT___062410_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7ca1d027__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056169_)))));
    vlSelf->__VdfgTmp_he74af19b__0 = ((2U & ((0xacU 
                                              >> (IData)(vlSelf->__VdfgTmp_h748d3c0c__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009984_));
    vlSelf->wasmetal_core__DOT___061316_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h584d0366__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009920_)))));
    vlSelf->wasmetal_core__DOT___009727_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xa3U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055689_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___056147_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009951_)))))));
    vlSelf->wasmetal_core__DOT___062437_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056221_))));
    vlSelf->__VdfgTmp_hb864fb42__0 = (((IData)(vlSelf->wasmetal_core__DOT___056221_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009997_));
    vlSelf->wasmetal_core__DOT___062404_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h16f25fe1__0))));
    vlSelf->wasmetal_core__DOT___009710_ = (1U & (0xf5fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h16f25fe1__0))))));
    vlSelf->wasmetal_core__DOT___060840_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3dedcb44__0))));
    vlSelf->wasmetal_core__DOT___056042_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055739_))));
    vlSelf->__VdfgTmp_h27200c45__0 = (((IData)(vlSelf->wasmetal_core__DOT___009317_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055739_));
    vlSelf->__VdfgTmp_ha3cb0627__0 = (((IData)(vlSelf->wasmetal_core__DOT___009276_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009275_));
    vlSelf->wasmetal_core__DOT___062332_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7c9afb82__0))));
    vlSelf->wasmetal_core__DOT___055491_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7c9afb82__0)))));
    vlSelf->wasmetal_core__DOT___007857_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007906_));
    vlSelf->wasmetal_core__DOT___055636_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h7737ac68__0))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007940_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007939_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_ha9e5b07a__0))))))))))));
    vlSelf->wasmetal_core__DOT___008549_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h7737ac68__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hb7c4f884__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h4d366d59__0)))))));
    vlSelf->wasmetal_core__DOT___055355_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3ba3f00e__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_haff0ba2f__0)))))));
    vlSelf->wasmetal_core__DOT___007855_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_haff0ba2f__0))));
    vlSelf->wasmetal_core__DOT___009659_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc719aa4c__0)))))));
    vlSelf->wasmetal_core__DOT___055747_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc719aa4c__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0)))))));
    vlSelf->__VdfgTmp_hc3aac618__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0xaaaaccccf0f0ff00ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008027_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008026_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc20acf35__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hdb0e0153__0))
                                                     : 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h8c5bf8f0__0)))));
    vlSelf->wasmetal_core__DOT___056157_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h83c5326a__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h0d1d68d2__0)))))));
    vlSelf->wasmetal_core__DOT___008548_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h0d1d68d2__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h83c5326a__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h935ba97a__0)))))));
    vlSelf->wasmetal_core__DOT___009870_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8c5bf8f0__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hee048ece__0)))))));
    vlSelf->wasmetal_core__DOT___008824_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hee048ece__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h8c5bf8f0__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h21ecfb21__0)))))));
    vlSelf->wasmetal_core__DOT___055546_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___008642_));
    vlSelf->wasmetal_core__DOT___009851_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hae7eba08__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hab3491b0__0)))))));
    vlSelf->wasmetal_core__DOT___008920_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                     & (IData)(
                                                               (0xaaaaccccf0f0ff00ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hab3491b0__0)))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                          ? 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0))
                                                          : 
                                                         (0xa0cU 
                                                          >> (IData)(vlSelf->__VdfgTmp_hae7eba08__0)))))));
    vlSelf->wasmetal_core__DOT___008938_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                         ? 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0))
                                                         : 
                                                        (0x503U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdb0e0153__0))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc229347b__0)))))));
    vlSelf->wasmetal_core__DOT___051316_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0de86ccc__0))));
    vlSelf->__VdfgTmp_ha33784b5__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_ha30079fd__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hf5a39c51__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0de86ccc__0)))));
    vlSelf->wasmetal_core__DOT___055745_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd3e9a659__0))));
    vlSelf->__VdfgTmp_h63940f3b__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hd3e9a659__0)))));
    vlSelf->__VdfgTmp_hddf47e90__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hab9b53a5__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3429c82f__0)))));
    vlSelf->wasmetal_core__DOT___055475_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3429c82f__0))));
    vlSelf->wasmetal_core__DOT___055817_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hfb017b9d__0))));
    vlSelf->__VdfgTmp_h5e3623a6__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb1634503__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc1f7329f__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha22ec9f2__0)))));
    vlSelf->wasmetal_core__DOT___055631_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha22ec9f2__0))));
    vlSelf->wasmetal_core__DOT___055846_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hb46d48f1__0))));
    vlSelf->wasmetal_core__DOT___055704_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hb46d48f1__0))));
    vlSelf->wasmetal_core__DOT___051314_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7092c9cd__0))));
    vlSelf->wasmetal_core__DOT___055354_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7092c9cd__0))));
    vlSelf->wasmetal_core__DOT___055743_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefb478a1__0))));
    vlSelf->wasmetal_core__DOT___055396_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefb478a1__0))));
    vlSelf->__VdfgTmp_h33e7f237__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0x555533330f0f00ffULL 
                                                   >> (IData)(vlSelf->__VdfgTmp_h855995cd__0)))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0x503U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0))
                                                     : 
                                                    (0x503U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h6bb5c719__0)))));
    vlSelf->wasmetal_core__DOT___055457_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h855995cd__0))));
    vlSelf->wasmetal_core__DOT___055897_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h114e86e1__0))));
    vlSelf->wasmetal_core__DOT___055473_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h114e86e1__0))));
    vlSelf->__VdfgTmp_hb6e33d53__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h1390519c__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hce5d0ce9__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h91c21bf0__0)))));
    vlSelf->wasmetal_core__DOT___055548_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h91c21bf0__0))));
    vlSelf->__VdfgTmp_h1eb86efd__0 = ((2U & ((1U >> 
                                              ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                 & (IData)(
                                                           (0xaaaaccccf0f0ff00ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_hfb017b9d__0)))) 
                                                << 1U) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                      ? 
                                                     (0xa0cU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0))
                                                      : 
                                                     (0xa0cU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h09c5f4e8__0)))))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                  & (IData)(
                                                            (0xaaaaccccf0f0ff00ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hed13b60d__0)))) 
                                                 << 1U) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                       ? 
                                                      (0xa0cU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0))
                                                       : 
                                                      (0xa0cU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0))))))));
    vlSelf->__VdfgTmp_h16df2209__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7cb0a391__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hed13b60d__0)))));
    vlSelf->wasmetal_core__DOT___055924_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0c7e8da3__0))));
    vlSelf->__VdfgTmp_hfa157860__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0xaaaaccccf0f0ff00ULL 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0c7e8da3__0)))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h158bc821__0))
                                                     : 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h1390519c__0)))));
    vlSelf->__VdfgTmp_h7e1fafed__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hf0c32555__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9b67b4e1__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3418aecb__0)))));
    vlSelf->wasmetal_core__DOT___055702_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3418aecb__0))));
    vlSelf->wasmetal_core__DOT___051935_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h051dc5dd__0))));
    vlSelf->wasmetal_core__DOT___055357_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h051dc5dd__0))));
    vlSelf->wasmetal_core__DOT___055392_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf618fe17__0))));
    vlSelf->wasmetal_core__DOT___055884_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2ada8d2f__0))));
    vlSelf->wasmetal_core__DOT___055455_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2ada8d2f__0))));
    vlSelf->wasmetal_core__DOT___055899_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he5945a68__0))));
    vlSelf->wasmetal_core__DOT___055471_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he5945a68__0))));
    vlSelf->wasmetal_core__DOT___055803_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha8c0c19d__0))));
    vlSelf->wasmetal_core__DOT___055531_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha8c0c19d__0))));
    vlSelf->wasmetal_core__DOT___055843_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefdefca0__0))));
    vlSelf->wasmetal_core__DOT___055700_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hefdefca0__0))));
    vlSelf->wasmetal_core__DOT___055390_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h91b07825__0))));
    vlSelf->wasmetal_core__DOT___055886_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he2ba4454__0))));
    vlSelf->wasmetal_core__DOT___055453_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he2ba4454__0))));
    vlSelf->wasmetal_core__DOT___009877_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc2ad9167__0))));
    vlSelf->__VdfgTmp_hb6a6380e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                        & (IData)((0xaaaaccccf0f0ff00ULL 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc2ad9167__0)))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                     ? 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0))
                                                     : 
                                                    (0xa0cU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h89da7eb2__0)))));
    vlSelf->wasmetal_core__DOT___008857_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h70bc0e9e__0))));
    vlSelf->wasmetal_core__DOT___009339_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h70bc0e9e__0))));
    vlSelf->wasmetal_core__DOT___009354_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf74c6a47__0))));
    vlSelf->__VdfgTmp_h900f682d__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h042cd865__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_he1802e5a__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf74c6a47__0)))));
    vlSelf->wasmetal_core__DOT___009861_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf4d4c7d0__0))));
    vlSelf->wasmetal_core__DOT___008931_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf4d4c7d0__0))));
    vlSelf->__VdfgTmp_h12f500a7__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h042cd865__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h70291c6e__0)))));
    vlSelf->wasmetal_core__DOT___009369_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h70291c6e__0))));
    vlSelf->wasmetal_core__DOT___009382_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h850327e3__0))));
    vlSelf->__VdfgTmp_hd77eff94__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h850327e3__0)))));
    vlSelf->wasmetal_core__DOT___009391_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h950f0cb0__0))));
    vlSelf->__VdfgTmp_h37c9f429__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7267e294__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h950f0cb0__0)))));
    vlSelf->wasmetal_core__DOT___009032_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd89c9b51__0))));
    vlSelf->wasmetal_core__DOT___009066_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hdd777bec__0))));
    vlSelf->wasmetal_core__DOT___008832_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hdd777bec__0))));
    vlSelf->wasmetal_core__DOT___008858_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h69785613__0))));
    vlSelf->wasmetal_core__DOT___009089_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h69785613__0))));
    vlSelf->wasmetal_core__DOT___009351_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2c35a4fb__0))));
    vlSelf->wasmetal_core__DOT___008899_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2c35a4fb__0))));
    vlSelf->wasmetal_core__DOT___009123_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf17c2029__0))));
    vlSelf->wasmetal_core__DOT___008928_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf17c2029__0))));
    if (vlSelf->wasmetal_core__DOT___007847_) {
        if (vlSelf->wasmetal_core__DOT___007844_) {
            vlSelf->wasmetal_core__DOT___056124_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___008901_) 
                                                << 1U) 
                                               | (1U 
                                                  & (0x35U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hb307080d__0))))))));
            vlSelf->wasmetal_core__DOT___056133_ = 
                (1U & (0xcdU >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___009480_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___009478_))))));
        } else {
            vlSelf->wasmetal_core__DOT___056124_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h7bd92bc0__0))));
            vlSelf->wasmetal_core__DOT___056133_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h7ca1d027__0))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___056124_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009465_)))));
        vlSelf->wasmetal_core__DOT___056133_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009479_)))));
    }
    vlSelf->wasmetal_core__DOT___009204_ = (1U & (0xc05U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008901_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xcaU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb307080d__0))))))));
    if (vlSelf->wasmetal_core__DOT___007854_) {
        vlSelf->wasmetal_core__DOT___009068_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007866_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h79214203__0))));
        vlSelf->wasmetal_core__DOT___008836_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                   | (0xdU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h79214203__0))));
        vlSelf->wasmetal_core__DOT___008959_ = (1U 
                                                & (IData)(
                                                          (0x555533330f0f00ffULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hee6f9dc2__0))));
        vlSelf->wasmetal_core__DOT___009366_ = (1U 
                                                & (IData)(
                                                          (0xaaaaccccf0f0ff00ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hee6f9dc2__0))));
    } else {
        if (vlSelf->wasmetal_core__DOT___007866_) {
            vlSelf->wasmetal_core__DOT___009068_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_h5629f5f8__0)));
            vlSelf->wasmetal_core__DOT___008836_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h5629f5f8__0)));
        } else {
            vlSelf->wasmetal_core__DOT___009068_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_h6405266c__0)));
            vlSelf->wasmetal_core__DOT___008836_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h6405266c__0)));
        }
        vlSelf->wasmetal_core__DOT___008959_ = 0U;
        vlSelf->wasmetal_core__DOT___009366_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___009218_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009480_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009478_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007846_)))));
    vlSelf->wasmetal_core__DOT___009379_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5618ebf3__0))));
    vlSelf->wasmetal_core__DOT___008991_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5618ebf3__0))));
    vlSelf->wasmetal_core__DOT___006194_ = (1U & ((~ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127519___O) 
                                                     >> 1U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf9e966c8__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf9e966c8__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006232_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006039_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006038_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005783_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005782_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005781_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005780_)))))))))));
    vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023188_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___060270_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058496_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128884___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b36__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036494_));
    vlSelf->wasmetal_core__DOT____Vcellout___128803___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035965_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035964_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035963_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035962_)))) 
           ^ (((IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128803___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035905_)))));
    vlSelf->wasmetal_core__DOT___035909_ = ((IData)(vlSelf->wasmetal_core__DOT___035965_)
                                             ? (IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b15__05d));
    vlSelf->__VdfgTmp_he6069ba9__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h69683dae__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h42022071__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__0__KET__ 
        = ((0xf10eU >> (IData)(vlSelf->__VdfgTmp_ha1b196f5__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023013_));
    vlSelf->wasmetal_core__DOT___059445_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff00aaaafc0cfc0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0x3500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058241_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058242_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O) 
                                                                                >> 3U))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                ? 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e80d283__0))))
                                                                : 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e80d283__0)))))))))));
    vlSelf->wasmetal_core__DOT___017482_ = (1U & ((0xeee0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017794_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017623_))))) 
                                                  & ((0xeee0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017676_))))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___013613_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013612_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013611_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xeee0U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015665_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017716_))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((0xeee0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017610_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017652_))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0xeee0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057694_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017756_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015658_))))))))))))))));
    vlSelf->wasmetal_core__DOT___058980_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057710_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057719_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057722_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015677_)))))))));
    vlSelf->wasmetal_core__DOT___013378_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057722_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6a49916d__0)))));
}
