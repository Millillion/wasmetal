#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__14(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__14\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___044616_;
    wasmetal_core__DOT___044616_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044636_;
    wasmetal_core__DOT___044636_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044645_;
    wasmetal_core__DOT___044645_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044655_;
    wasmetal_core__DOT___044655_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044717_;
    wasmetal_core__DOT___044717_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044724_;
    wasmetal_core__DOT___044724_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044725_;
    wasmetal_core__DOT___044725_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045615_;
    wasmetal_core__DOT___045615_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___046803_;
    wasmetal_core__DOT___046803_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___046936_;
    wasmetal_core__DOT___046936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065578_;
    wasmetal_core__DOT___065578_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069655_;
    wasmetal_core__DOT___069655_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128704___O;
    wasmetal_core__DOT____Vcellout___128704___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___135458___O;
    wasmetal_core__DOT____Vcellout___135458___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127827___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127827___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127996___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127996___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128148___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128148___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128157___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128157___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128164___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128164___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128190___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128190___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128197___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128197___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128207___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128207___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128214___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128214___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128224___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128224___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128276___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128276___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128330___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128330___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128354___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128354___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128372___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128372___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128427___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128427___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128442___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128442___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128672___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128672___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128688___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128688___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128711___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128711___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128721___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128721___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135451___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135451___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135467___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135467___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h598a1bee__0;
    __VdfgTmp_h598a1bee__0 = 0;
    CData/*4:0*/ __VdfgTmp_h5fe12ba6__0;
    __VdfgTmp_h5fe12ba6__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027812_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b1__05d));
    vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026368_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b1__05d));
    vlSelf->wasmetal_core__DOT___044260_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044274_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044273_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044272_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044271_) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___044263_))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044272_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044273_)))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044274_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128034___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028019_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053263_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045590_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045586_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___045585_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___045583_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h58222fb0__0)) 
                                                                               << 5U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___045587_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045582_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he13e3256__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045589_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___045581_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcd6b7a1f__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___038870_ = ((IData)(vlSelf->wasmetal_core__DOT___045581_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045590_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045589_)
                                                  ? 
                                                 ((1U 
                                                   & (0x80U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcd6b7a1f__0)))
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045587_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045586_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045585_)
                                                      ? 
                                                     ((1U 
                                                       & (0x80U 
                                                          >> (IData)(vlSelf->__VdfgTmp_he13e3256__0)))
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045583_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045582_)
                                                         ? 
                                                        ((~ 
                                                          (8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h58222fb0__0))) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045568_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045570_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045571_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045572_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045573_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045574_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045575_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045576_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045577_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045578_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045569_));
    vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__1__KET__ 
        = ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hbf5bedf6__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128498___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032988_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128721___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128721___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b5__05d) {
        vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b5__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__1__KET__ = 0U;
        vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128163___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029407_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029404_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029393_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029382_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029375_ = ((IData)(vlSelf->wasmetal_core__DOT___029407_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b3__05d));
    vlSelf->wasmetal_core__DOT___065590_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065582_))));
    __VdfgTmp_h5fe12ba6__0 = (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b2__05d) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b3__05d) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065565_) 
                                            << 1U) 
                                           | (1U & 
                                              (0x40U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___065562_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065563_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b4__05d)))))))));
    vlSelf->__VdfgTmp_hd2f701d9__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064093_));
    vlSelf->wasmetal_core__DOT___066372_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064087_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066365_))));
    vlSelf->wasmetal_core__DOT___070190_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067556_))));
    vlSelf->wasmetal_core__DOT___069258_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065553_))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066367_))));
    vlSelf->wasmetal_core__DOT___066368_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066367_)))));
    vlSelf->wasmetal_core__DOT___065566_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064452_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065558_))));
    vlSelf->wasmetal_core__DOT___067561_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065558_))));
    vlSelf->wasmetal_core__DOT___067557_ = (1U & (0x7fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065558_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064992_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0))))));
    vlSelf->wasmetal_core__DOT___067565_ = (1U & (IData)(
                                                         (0x7f7f7fffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065565_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064973_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1cU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065559_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064091_)))))))));
    wasmetal_core__DOT___065578_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064973_))));
    vlSelf->wasmetal_core__DOT___067563_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066366_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065556_))));
    vlSelf->wasmetal_core__DOT___065560_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065557_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065556_))));
    vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128147___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029246_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029243_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029232_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029221_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029214_ = ((IData)(vlSelf->wasmetal_core__DOT___029246_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d));
    vlSelf->wasmetal_core__DOT___026158_ = ((IData)(vlSelf->wasmetal_core__DOT___026190_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127826___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026190_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026187_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026176_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026165_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT____Vcellout___128534___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b5__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b4__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b3__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b2__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b5__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___128814___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d));
    vlSelf->wasmetal_core__DOT___061598_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x17U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 8U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x11U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___061602_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x18U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 9U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x12U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___061616_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x19U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 0xaU)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x13U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 4U))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    vlSelf->wasmetal_core__DOT___061588_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x15U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 6U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0xfU)) 
                                                                       | (1U 
                                                                          & vlSelf->insn_imm[3U])))))))));
    vlSelf->wasmetal_core__DOT___061592_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x16U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 7U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x10U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    wasmetal_core__DOT____Vcellout___128704___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035117_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035106_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((9U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hff2c11ba__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035084_)))) 
                                                   ^ 
                                                   (1U 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__0__KET__) 
                                                             << 1U)))));
    vlSelf->wasmetal_core__DOT___035053_ = ((IData)(vlSelf->wasmetal_core__DOT___035117_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d));
    vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128941___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___031214_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046933_))));
    vlSelf->wasmetal_core__DOT___031502_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___046933_)))));
    vlSelf->wasmetal_core__DOT___032525_ = (1U & (IData)(
                                                         (0x4000ff00bfff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___032397_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046933_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b4__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9fa2de6d__0))))))));
    vlSelf->wasmetal_core__DOT___046800_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046933_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___046932_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b3__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5e419f7__0))));
    vlSelf->wasmetal_core__DOT___046931_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b2__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5e419f7__0))));
    vlSelf->wasmetal_core__DOT___046930_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b1__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5e419f7__0))));
    vlSelf->wasmetal_core__DOT___063358_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5e419f7__0))));
    wasmetal_core__DOT___128688___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128688___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___053308_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x9000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053305_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053304_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053303_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((9U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b5__05d))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b1__05d)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x9009000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___053295_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053294_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b21__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b17__05d))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128213___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029939_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029936_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029925_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029914_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029907_ = ((IData)(vlSelf->wasmetal_core__DOT___029939_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d));
    vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029756_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d));
    vlSelf->wasmetal_core__DOT___026290_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b7__05d))));
    vlSelf->wasmetal_core__DOT___026289_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b6__05d))));
    vlSelf->wasmetal_core__DOT___026288_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b5__05d))));
    vlSelf->wasmetal_core__DOT___026287_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b4__05d))));
    vlSelf->wasmetal_core__DOT___026286_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b3__05d))));
    wasmetal_core__DOT___044717_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___032696_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052868_))));
    vlSelf->wasmetal_core__DOT___026285_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b31__05d))));
    vlSelf->wasmetal_core__DOT___026284_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b30__05d))));
    vlSelf->wasmetal_core__DOT___026282_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b29__05d))));
    vlSelf->wasmetal_core__DOT___026281_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b28__05d))));
    vlSelf->wasmetal_core__DOT___026280_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b27__05d))));
    wasmetal_core__DOT___044725_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___032692_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052867_))));
    vlSelf->wasmetal_core__DOT___026279_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b26__05d))));
    vlSelf->wasmetal_core__DOT___026278_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b25__05d))));
    vlSelf->wasmetal_core__DOT___026277_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b24__05d))));
    wasmetal_core__DOT___044724_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___032689_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h42a8fe82__0))));
    vlSelf->wasmetal_core__DOT___026276_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b23__05d))));
    vlSelf->wasmetal_core__DOT___026275_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b22__05d))));
    vlSelf->wasmetal_core__DOT___026274_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b21__05d))));
    vlSelf->wasmetal_core__DOT___026273_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b20__05d))));
    vlSelf->wasmetal_core__DOT___026271_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b19__05d))));
    vlSelf->wasmetal_core__DOT___026270_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b18__05d))));
    vlSelf->wasmetal_core__DOT___026269_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b17__05d))));
    vlSelf->wasmetal_core__DOT___026268_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b16__05d))));
    vlSelf->wasmetal_core__DOT___026267_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b15__05d))));
    vlSelf->wasmetal_core__DOT___026266_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b14__05d))));
    vlSelf->wasmetal_core__DOT___026264_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b12__05d))));
    vlSelf->wasmetal_core__DOT___026263_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b11__05d))));
    vlSelf->wasmetal_core__DOT___026262_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b10__05d))));
    vlSelf->wasmetal_core__DOT___026292_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b9__05d))));
    vlSelf->wasmetal_core__DOT___026291_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b8__05d))));
    vlSelf->wasmetal_core__DOT___044630_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d))));
    vlSelf->__VdfgTmp_h73c641ae__0 = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048272_));
    vlSelf->wasmetal_core__DOT___026261_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d))));
    vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032877_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032685_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___026283_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b2__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___128255___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___026272_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b1__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___128018___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                    << 1U))));
    if (vlSelf->wasmetal_core__DOT__sp__05b3__05d) {
        vlSelf->wasmetal_core__DOT___027890_ = vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031898_ = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
        vlSelf->wasmetal_core__DOT___033933_ = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
        vlSelf->wasmetal_core__DOT___032955_ = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
    } else {
        vlSelf->wasmetal_core__DOT___027890_ = 0U;
        vlSelf->wasmetal_core__DOT___031898_ = vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033933_ = vlSelf->wasmetal_core__DOT___128593___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032955_ = vlSelf->wasmetal_core__DOT___128490___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128394___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_hc50f84f8__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                          << 1U)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b4__05d) {
        vlSelf->wasmetal_core__DOT___032633_ = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
    } else {
        vlSelf->wasmetal_core__DOT___032633_ = vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031898_;
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033933_;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032955_;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b5__05d) {
        vlSelf->wasmetal_core__DOT___030370_ = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030370_ = vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032633_;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128458___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128593___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                               << 2U) | (IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_h1702059a__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128593___DOT__CO__BRA__2__KET__) 
                     << 3U) | ((IData)(vlSelf->__VdfgTmp_h58bd40ba__0) 
                               << 1U))));
    vlSelf->wasmetal_core__DOT____Vcellout___128490___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_h1702059a__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128490___DOT__CO__BRA__2__KET__) 
                     << 3U) | ((IData)(vlSelf->__VdfgTmp_h58bd40ba__0) 
                               << 1U))));
    vlSelf->wasmetal_core__DOT___026265_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b13__05d))));
    vlSelf->wasmetal_core__DOT___063375_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052991_))));
    vlSelf->wasmetal_core__DOT___063391_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                            << 5U) 
                                                           | (0x1fU 
                                                              & vlSelf->function_locals)))));
    vlSelf->wasmetal_core__DOT___044720_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032676_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf0d31b4__0))));
    vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027823_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b2__05d));
    vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026379_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d));
    vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___028019_));
    vlSelf->__VdfgTmp_h0ff1168c__0 = (((IData)(vlSelf->wasmetal_core__DOT___038870_) 
                                       << 1U) | (IData)(vlSelf->mem_fault));
    vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032216_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___032827_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032824_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032813_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032802_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O)))));
    vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032988_));
    vlSelf->wasmetal_core__DOT____Vcellout___128721___O 
        = (((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d)) 
                   << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d)) 
                                     << 1U)) | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d)
                 : (IData)(wasmetal_core__DOT___128721___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128721___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128721___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035215_)))));
    vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b6__05d) {
        vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b6__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__2__KET__ = 0U;
        vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029408_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029375_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b4__05d));
    vlSelf->wasmetal_core__DOT___066197_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065590_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065584_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 0xeU))))));
    vlSelf->wasmetal_core__DOT___066364_ = (1U & (IData)(
                                                         (0x5ff3ffffffffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                               << 5U)) 
                                                           | (IData)(__VdfgTmp_h5fe12ba6__0)))));
    vlSelf->wasmetal_core__DOT___065568_ = (1U & (IData)(
                                                         (0x5ff3ffffffffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                               << 5U)) 
                                                           | (IData)(__VdfgTmp_h5fe12ba6__0)))));
    vlSelf->wasmetal_core__DOT___064097_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064095_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2f701d9__0))));
    vlSelf->wasmetal_core__DOT___064244_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2f701d9__0))));
    vlSelf->wasmetal_core__DOT___069653_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066372_))));
    vlSelf->__VdfgTmp_h7eff58ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___066368_) 
                                       << 1U) | (1U 
                                                 & (vlSelf->mem_rdata[0U] 
                                                    >> 8U)));
    vlSelf->wasmetal_core__DOT___066456_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067039_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067262_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067215_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067426_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067108_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067359_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___066669_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->__VdfgTmp_h7e1b7882__0 = (((IData)(vlSelf->wasmetal_core__DOT___066368_) 
                                       << 1U) | (1U 
                                                 & (vlSelf->mem_rdata[0U] 
                                                    >> 0xfU)));
    vlSelf->wasmetal_core__DOT___066808_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___066479_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___065647_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___065842_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->__VdfgTmp_h04a3d61f__0 = (((IData)(vlSelf->wasmetal_core__DOT___065566_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___066368_));
    vlSelf->wasmetal_core__DOT___065572_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___066020_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___066218_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___066176_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___065975_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___065755_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___069996_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067561_))));
    vlSelf->wasmetal_core__DOT___070246_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1dU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066372_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067561_)))));
    vlSelf->wasmetal_core__DOT___067562_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067561_))));
    vlSelf->wasmetal_core__DOT___069675_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069720_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069807_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069698_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069742_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069654_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___067568_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067565_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 4U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065557_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065565_)))))));
    vlSelf->wasmetal_core__DOT___065581_ = (1U & (IData)(
                                                         (0xffff800000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065579_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___065578_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065554_)))))))));
    vlSelf->wasmetal_core__DOT___066370_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064087_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066365_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___065578_)))));
    vlSelf->wasmetal_core__DOT___068869_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068912_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069172_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068537_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068979_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069010_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069211_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068773_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068675_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069059_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068576_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069105_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->__VdfgTmp_hb1936621__0 = (((IData)(vlSelf->wasmetal_core__DOT___067563_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___066368_));
    vlSelf->__VdfgTmp_hfed1012b__0 = (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067563_));
    vlSelf->wasmetal_core__DOT___069471_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065560_))));
    vlSelf->wasmetal_core__DOT___069828_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xdU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066372_)))));
    vlSelf->wasmetal_core__DOT___070129_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065560_))));
    vlSelf->wasmetal_core__DOT___065567_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065559_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065558_))))));
    vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029247_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029214_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d));
    vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026191_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026158_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128568___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b6__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b5__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b4__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b3__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b6__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128814___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                & (IData)(vlSelf->wasmetal_core__DOT___128814___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128814___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                    << 1U))));
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__state__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_next__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__state__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__state__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__state__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b57__05d = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___019808_) {
            vlSelf->wasmetal_core__DOT__divider__02edividend__05b60__05d 
                = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b59__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054570_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128646___O) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___034339_)))))))))));
            vlSelf->wasmetal_core__DOT__divider__02edividend__05b59__05d 
                = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b58__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054569_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128645___O) 
                                                            >> 2U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___034337_)))))))))));
            vlSelf->wasmetal_core__DOT__divider__02edividend__05b58__05d 
                = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b57__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054568_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128645___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___034336_)))))))))));
            vlSelf->wasmetal_core__DOT__divider__02edividend__05b57__05d 
                = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b56__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054567_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128645___O)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___034335_)))))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019799_) {
            vlSelf->wasmetal_core__DOT__state__05b1__05d 
                = (1U & (IData)((0xbbbbff0fff0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063413_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063412_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xff00ff007070ffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063407_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063378_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__copy_next__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063377_)))))))) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf72c75d5__0))))))));
            vlSelf->wasmetal_core__DOT__state__05b2__05d 
                = (1U & (IData)((0xcc00ff55550f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063425_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063424_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063423_)))))))));
            vlSelf->wasmetal_core__DOT__state__05b3__05d 
                = vlSelf->wasmetal_core__DOT___046424_;
            vlSelf->wasmetal_core__DOT__state__05b4__05d 
                = vlSelf->wasmetal_core__DOT___046425_;
        }
        if (vlSelf->wasmetal_core__DOT___019778_) {
            vlSelf->wasmetal_core__DOT__copy_next__05b1__05d 
                = vlSelf->wasmetal_core__DOT___046418_;
        }
    }
    vlSelf->wasmetal_core__DOT___061607_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061598_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x17U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 8U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x11U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 2U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x17U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 8U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x11U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 2U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x17U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 8U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x11U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 2U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061608_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061602_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x18U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 9U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x12U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 3U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x18U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 9U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x12U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 3U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x18U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 9U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x12U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 3U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061619_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061616_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x19U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0xaU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x13U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 4U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x19U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xaU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x13U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 4U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x19U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0xaU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x13U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 4U))))))))))))))))));
    vlSelf->__VdfgTmp_hd461afd0__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02erunning) 
                                       << 1U) | (1U 
                                                 & (0x8000U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI))));
    vlSelf->wasmetal_core__DOT___061593_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061588_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x15U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 6U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0xfU)) 
                                                                                | (1U 
                                                                                & vlSelf->insn_imm[2U])))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x15U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 6U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xfU)) 
                                                                                | (1U 
                                                                                & vlSelf->insn_imm[1U])))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x15U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 6U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0xfU)) 
                                                                                | (1U 
                                                                                & vlSelf->insn_imm[0U])))))))))))))))));
    vlSelf->wasmetal_core__DOT___061594_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x16U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 7U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x10U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 1U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x16U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 7U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x10U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 1U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x16U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 7U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x10U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 1U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___034669_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128704___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___034658_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128704___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___034647_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128704___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__ 
        = (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                            << 2U) | ((2U & ((IData)(wasmetal_core__DOT____Vcellout___128704___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b63__05d)))));
    vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035128_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035053_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d));
    vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128942___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___031203_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046932_))));
    vlSelf->wasmetal_core__DOT___031491_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___046932_)))));
    vlSelf->wasmetal_core__DOT___032514_ = (1U & (0x4f00b0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032386_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___046932_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063361_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill)))))));
    vlSelf->wasmetal_core__DOT___046799_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063361_))));
    vlSelf->wasmetal_core__DOT___031192_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046931_))));
    vlSelf->wasmetal_core__DOT___031480_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___046931_)))));
    vlSelf->wasmetal_core__DOT___032503_ = (1U & (0x4f00b0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032375_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___046931_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063360_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill)))))));
    vlSelf->wasmetal_core__DOT___046798_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046931_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063360_))));
    vlSelf->wasmetal_core__DOT___031181_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046930_))));
    vlSelf->wasmetal_core__DOT___031469_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___046930_)))));
    vlSelf->wasmetal_core__DOT___032492_ = (1U & (IData)(
                                                         (0x4000ff00bfff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___032364_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046930_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b1__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9fa2de6d__0))))))));
    vlSelf->wasmetal_core__DOT___046797_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046930_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__ 
        = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___063357_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063358_))));
    vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__ 
        = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063358_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128688___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d)))))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128688___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128688___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___034925_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d)) 
                                            & (IData)(wasmetal_core__DOT___128688___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063408_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d))));
    vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029940_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029907_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d));
    vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029767_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d));
    vlSelf->wasmetal_core__DOT___052870_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___032692_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___032681_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052868_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h74a82ee2__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052867_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___032696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___032679_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___032680_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___044723_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___044724_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___044722_)))))))))))))))));
    if (vlSelf->wasmetal_core__DOT___044627_) {
        if (vlSelf->wasmetal_core__DOT___044626_) {
            if (vlSelf->wasmetal_core__DOT___044625_) {
                if (vlSelf->wasmetal_core__DOT___044630_) {
                    wasmetal_core__DOT___044655_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044624_)));
                    if (vlSelf->wasmetal_core__DOT___044624_) {
                        wasmetal_core__DOT___044645_ 
                            = (1U & ((~ (4U >> (IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_hc50f84f8__0))) 
                                     & (8U >> (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0))));
                        wasmetal_core__DOT___044636_ 
                            = (1U & ((~ (4U >> (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0))) 
                                     & (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d)));
                    } else {
                        wasmetal_core__DOT___044645_ 
                            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044624_)));
                        wasmetal_core__DOT___044636_ 
                            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044624_)));
                    }
                    wasmetal_core__DOT___044616_ = 
                        (1U & (IData)(vlSelf->wasmetal_core__DOT___135298___DOT__CO__BRA__1__KET__));
                } else {
                    wasmetal_core__DOT___044655_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044630_)));
                    wasmetal_core__DOT___044645_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044630_)));
                    wasmetal_core__DOT___044636_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044630_)));
                    wasmetal_core__DOT___044616_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044630_)));
                }
                vlSelf->wasmetal_core__DOT___044819_ 
                    = (1U & ((1U & (8U >> (IData)(vlSelf->__VdfgTmp_h73c641ae__0)))
                              ? (IData)(vlSelf->wasmetal_core__DOT___135298___DOT__CO__BRA__1__KET__)
                              : (4U >> (IData)(vlSelf->__VdfgTmp_h73c641ae__0))));
            } else {
                wasmetal_core__DOT___044655_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044625_)));
                wasmetal_core__DOT___044645_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044625_)));
                wasmetal_core__DOT___044636_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044625_)));
                wasmetal_core__DOT___044616_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044625_)));
                vlSelf->wasmetal_core__DOT___044819_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044625_)));
            }
        } else {
            wasmetal_core__DOT___044655_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044626_)));
            wasmetal_core__DOT___044645_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044626_)));
            wasmetal_core__DOT___044636_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044626_)));
            wasmetal_core__DOT___044616_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044626_)));
            vlSelf->wasmetal_core__DOT___044819_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044626_)));
        }
    } else {
        wasmetal_core__DOT___044655_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044627_)));
        wasmetal_core__DOT___044645_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044627_)));
        wasmetal_core__DOT___044636_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044627_)));
        wasmetal_core__DOT___044616_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044627_)));
        vlSelf->wasmetal_core__DOT___044819_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044627_)));
    }
    vlSelf->wasmetal_core__DOT___048286_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___044626_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___044627_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044624_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044625_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h73c641ae__0)))))))))));
    wasmetal_core__DOT___045615_ = ((IData)(vlSelf->wasmetal_core__DOT___044627_) 
                                    & ((IData)(vlSelf->wasmetal_core__DOT___044626_) 
                                       & ((IData)(vlSelf->wasmetal_core__DOT___044625_) 
                                          & ((1U & 
                                              (8U >> (IData)(vlSelf->__VdfgTmp_h73c641ae__0)))
                                              ? ((IData)(vlSelf->wasmetal_core__DOT___044624_) 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0)))
                                              : (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d))))));
    vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026261_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b0__05d));
    vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032888_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032696_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b6__05d) {
        vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
        vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030370_;
        vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027890_));
    vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x78U >> (7U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))) 
                 | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                    >> 2U)));
    vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__0__KET__ 
        = (1U & ((6U >> (3U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                               >> 1U))) | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                           >> 2U)));
    vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x1eU >> (7U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))) 
                 | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                    >> 2U)));
    vlSelf->wasmetal_core__DOT___044693_ = ((IData)(vlSelf->wasmetal_core__DOT___044716_)
                                             ? ((IData)(wasmetal_core__DOT___044725_)
                                                 ? 
                                                ((IData)(wasmetal_core__DOT___044724_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044723_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044722_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044721_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044720_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044719_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044718_)
                                                        ? 
                                                       ((IData)(wasmetal_core__DOT___044717_)
                                                         ? 
                                                        ((~ 
                                                          (8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h74a82ee2__0))) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___044703_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044705_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044706_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044707_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044708_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044709_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044710_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044711_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044712_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044713_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044704_));
    vlSelf->wasmetal_core__DOT____Vcellout___128010___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027826_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027823_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027812_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027801_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027794_ = ((IData)(vlSelf->wasmetal_core__DOT___027826_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b3__05d));
    vlSelf->wasmetal_core__DOT___026350_ = ((IData)(vlSelf->wasmetal_core__DOT___026382_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127842___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026382_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026379_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026368_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026357_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128426___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032219_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032216_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h58222fb0__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032187_ = ((IData)(vlSelf->wasmetal_core__DOT___032219_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d));
    vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032802_) 
                 | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O)));
    vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128189___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029672_)))));
    vlSelf->wasmetal_core__DOT___029676_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128275___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030584_)))));
    vlSelf->wasmetal_core__DOT___030588_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128003___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027729_)))));
    vlSelf->wasmetal_core__DOT___027733_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128419___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032092_)))));
    vlSelf->wasmetal_core__DOT___032096_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128371___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031611_)))));
    vlSelf->wasmetal_core__DOT___031615_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128223___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030010_)))));
    vlSelf->wasmetal_core__DOT___030014_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029409_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b5__05d));
    vlSelf->wasmetal_core__DOT___065573_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065568_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065560_)))));
    vlSelf->wasmetal_core__DOT___066374_ = (1U & (0x4404ff0fU 
                                                  >> 
                                                  ((0x10U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065568_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066364_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066372_)))))));
    vlSelf->wasmetal_core__DOT___066369_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065568_))));
    vlSelf->wasmetal_core__DOT___066457_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___067042_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067039_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___067216_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065842_))));
    vlSelf->wasmetal_core__DOT___066943_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___066375_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___066556_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___066724_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___066996_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7eff58ec__0))));
    vlSelf->wasmetal_core__DOT___067360_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067359_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066020_))));
    vlSelf->wasmetal_core__DOT___067504_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7e1b7882__0))));
    vlSelf->wasmetal_core__DOT___067428_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067426_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___066809_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___067264_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067262_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065975_))));
    vlSelf->wasmetal_core__DOT___066670_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066669_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065975_))));
    vlSelf->wasmetal_core__DOT___067110_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067108_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___066480_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066479_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___070014_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___069997_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065572_))));
    vlSelf->wasmetal_core__DOT___070053_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065842_))));
    vlSelf->wasmetal_core__DOT___070112_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066218_))));
    vlSelf->wasmetal_core__DOT___070036_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___070350_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[1U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___067623_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___067935_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___067772_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065842_))));
    vlSelf->wasmetal_core__DOT___067704_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___067569_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065572_))));
    vlSelf->wasmetal_core__DOT___067833_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065975_))));
    vlSelf->wasmetal_core__DOT___067986_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066218_))));
    vlSelf->wasmetal_core__DOT___067864_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066020_))));
    vlSelf->wasmetal_core__DOT___068051_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___068492_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066372_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[0U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___065586_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065581_))));
    vlSelf->wasmetal_core__DOT___067558_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067557_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066370_))));
    vlSelf->wasmetal_core__DOT___070365_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068912_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___070377_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068979_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___070389_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069010_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___070439_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069211_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[1U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___067622_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))))));
    vlSelf->wasmetal_core__DOT___067703_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))))));
    vlSelf->wasmetal_core__DOT___067567_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))))));
    vlSelf->__VdfgTmp_h76d711b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))));
    vlSelf->__VdfgTmp_h625a9757__0 = (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))));
    vlSelf->wasmetal_core__DOT___069676_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))));
    vlSelf->wasmetal_core__DOT___069699_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))));
    vlSelf->wasmetal_core__DOT___069743_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))));
    vlSelf->__VdfgTmp_haa81a95c__0 = (((IData)(vlSelf->wasmetal_core__DOT___067557_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))));
    vlSelf->wasmetal_core__DOT___069260_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___069585_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066020_))));
    vlSelf->wasmetal_core__DOT___069608_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___070130_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 8U))))));
    vlSelf->wasmetal_core__DOT___070191_ = (1U & (IData)(
                                                         (0x503000305030f030ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x47U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065566_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 4U))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->mem_rdata[1U] 
                                                                           >> 0x1bU)) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0xcU))))))))));
    vlSelf->wasmetal_core__DOT___070203_ = (1U & (0x7707U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xbU)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0xcU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070218_ = (1U & (0x7707U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xcU)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0xdU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070144_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 9U))))));
    vlSelf->wasmetal_core__DOT___070171_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0xbU))))));
    vlSelf->wasmetal_core__DOT___070158_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0xaU))))));
    vlSelf->wasmetal_core__DOT___070232_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0xfU))))));
    vlSelf->wasmetal_core__DOT___070248_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065567_))));
    vlSelf->wasmetal_core__DOT___069765_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xaU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x14U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067557_))))));
    vlSelf->wasmetal_core__DOT___069786_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xbU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x15U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067557_))))));
    vlSelf->wasmetal_core__DOT___068494_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065567_))));
    vlSelf->__VdfgTmp_hede308eb__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065567_));
    vlSelf->wasmetal_core__DOT___067566_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065567_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128206___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029841_)))));
    vlSelf->wasmetal_core__DOT___029845_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128156___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029310_)))));
    vlSelf->wasmetal_core__DOT___029314_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029248_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d));
    vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026192_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128577___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b7__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___034222_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034647_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035139_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127995___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128943___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128942___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128941___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128940___Q)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027664_)))));
    vlSelf->wasmetal_core__DOT___027668_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128943___Q) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___046797_) 
           & (IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___031170_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__))));
    vlSelf->wasmetal_core__DOT___031458_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__)))));
    vlSelf->wasmetal_core__DOT___032481_ = (1U & (0x5030afcfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032353_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__)))))));
    vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___046930_) 
           & (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034925_));
    vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029941_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128196___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029770_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029767_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029756_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029745_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029738_ = ((IData)(vlSelf->wasmetal_core__DOT___029770_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d));
    vlSelf->wasmetal_core__DOT___019414_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052940_))));
    vlSelf->wasmetal_core__DOT___052114_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___044655_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___045615_))));
    vlSelf->wasmetal_core__DOT___003145_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___044645_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___045615_))));
    vlSelf->wasmetal_core__DOT___000416_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___044636_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___045615_))));
    vlSelf->wasmetal_core__DOT___000417_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___045615_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___044616_))));
    vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026272_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b1__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128482___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032891_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032888_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032877_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032866_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032859_ = ((IData)(vlSelf->wasmetal_core__DOT___032891_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128466___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032699_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032696_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h74a82ee2__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032667_ = ((IData)(vlSelf->wasmetal_core__DOT___032699_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b7__05d) {
        vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
        wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
        vlSelf->wasmetal_core__DOT___031902_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
        vlSelf->wasmetal_core__DOT___033937_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
        vlSelf->wasmetal_core__DOT___032959_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___031902_ = vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033937_ = vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032959_ = vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__0__KET__));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))) {
        vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                     >> 3U));
    } else {
        vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__0__KET__));
    }
    vlSelf->__VdfgTmp_h17c4848e__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d));
    vlSelf->wasmetal_core__DOT___048111_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d))));
    vlSelf->wasmetal_core__DOT___052871_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->function_valid) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044693_))));
    vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027827_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027794_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b4__05d));
    vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026383_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026350_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d));
    vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045535_ = (1U & (0x7150U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b1__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___045547_ = (1U & (0x9009U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b1__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032220_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032187_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032813_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                     >> 1U)));
    vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029676_));
    vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030588_));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b8__05d) {
        vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027733_;
        vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b8__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__0__KET__ = 0U;
        vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032096_;
    }
    vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031615_));
    vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___030014_));
    wasmetal_core__DOT___128164___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029410_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b6__05d));
    vlSelf->wasmetal_core__DOT___066179_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___066997_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 0xfU))))));
    vlSelf->wasmetal_core__DOT___067555_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066369_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065565_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064973_)))));
    vlSelf->wasmetal_core__DOT___070263_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066457_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068537_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x11U))))))));
    vlSelf->wasmetal_core__DOT___069808_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066943_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___070337_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066943_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067563_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0x15U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x16U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070249_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066375_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xdU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))))));
    wasmetal_core__DOT___069655_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___066375_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___069721_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066556_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___070287_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066556_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067563_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0x11U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x12U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___069764_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066724_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___070313_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066724_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x12U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x13U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))))));
    vlSelf->wasmetal_core__DOT___070325_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066809_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068773_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x16U))))))));
    vlSelf->wasmetal_core__DOT___070402_ = (1U & (0x700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067264_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069059_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[1U] 
                                                               >> 0x1cU)))))));
    vlSelf->wasmetal_core__DOT___070299_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066670_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068675_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x14U))))))));
    vlSelf->wasmetal_core__DOT___070275_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066480_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068576_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x12U))))))));
    vlSelf->wasmetal_core__DOT___070056_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070053_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070115_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070112_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 5U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___067775_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___069061_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069059_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067262_)))));
    vlSelf->wasmetal_core__DOT___067989_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 7U)))))));
    vlSelf->wasmetal_core__DOT___067867_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 5U)))))));
    vlSelf->wasmetal_core__DOT___068539_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068537_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066456_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x19U))))))))));
    vlSelf->wasmetal_core__DOT___068777_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068773_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066808_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT___068495_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068580_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068576_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066479_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x1aU))))))))));
    vlSelf->wasmetal_core__DOT___068680_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068675_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066669_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x1cU))))))))));
    vlSelf->wasmetal_core__DOT___068619_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & vlSelf->mem_rdata[0U]) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x11U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068716_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 2U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x13U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068816_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 4U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x15U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068870_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[0U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___069473_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067558_))));
    vlSelf->wasmetal_core__DOT___067560_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065567_))));
    vlSelf->wasmetal_core__DOT___067626_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067622_)))));
    vlSelf->wasmetal_core__DOT___070100_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066176_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 4U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76d711b0__0))))))));
    vlSelf->wasmetal_core__DOT___070070_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065975_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76d711b0__0))))))));
    vlSelf->wasmetal_core__DOT___070086_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066020_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 2U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 3U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76d711b0__0))))))));
    vlSelf->wasmetal_core__DOT___068124_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x17U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068447_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xcU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068378_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xbU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1cU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068182_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x18U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068209_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068316_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xaU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1bU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068055_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 5U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068269_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 9U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1aU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___069748_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066670_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069743_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069742_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0xcU))))))))));
    vlSelf->wasmetal_core__DOT___069831_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066996_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x15U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))));
    vlSelf->wasmetal_core__DOT___069285_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065647_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___069342_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065842_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___069392_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066020_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 5U))))));
    vlSelf->wasmetal_core__DOT___069418_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066176_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT___069315_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065755_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___069474_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 8U)))))));
    vlSelf->__VdfgTmp_h753cf8b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___067558_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___069260_));
    vlSelf->wasmetal_core__DOT___070132_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070130_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 5U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___070147_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070014_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070144_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x17U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___070174_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070053_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070171_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___070161_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070036_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070158_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x18U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___070235_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070112_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070232_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xcU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___067774_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070055_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070114_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070099_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070069_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___067866_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070085_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___067625_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___067574_ = (1U & (0xd000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067567_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067566_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x10U))))))));
    vlSelf->wasmetal_core__DOT___067708_ = (1U & (0xd000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067703_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067566_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x12U))))))));
    vlSelf->wasmetal_core__DOT___067988_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->__VdfgTmp_hf22e2068__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___067566_));
    vlSelf->__VdfgTmp_h84a22723__0 = (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067566_));
    vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029845_));
    vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029314_));
    wasmetal_core__DOT___128148___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029249_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d));
    wasmetal_core__DOT___127827___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026193_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128586___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b8__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b7__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b6__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b5__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b8__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128632___O 
        = ((8U | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)) 
                         << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d)) 
                                           << 1U)) 
                                    | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___034222_) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (1U & 
                                               (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)))))));
    vlSelf->__VdfgTmp_h6f508139__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                             << 1U)) 
                                      | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___034222_))));
    vlSelf->__VdfgTmp_hf123769f__0 = ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                             << 2U)) 
                                      | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                << 1U)) 
                                         | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___034222_)))));
    wasmetal_core__DOT___128672___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034658_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128711___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035144_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d));
    vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128944___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027668_));
    wasmetal_core__DOT___135451___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___046798_) 
           & (IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031170_) 
           | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b0__05d));
    vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031458_) 
           | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d));
    vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032481_) 
           | (IData)(vlSelf->wasmetal_core__DOT___032353_));
    wasmetal_core__DOT___135467___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___046931_) 
           & (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128214___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029942_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d));
    vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029771_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029738_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d));
    vlSelf->__VdfgTmp_h56fc5986__0 = (((IData)(vlSelf->wasmetal_core__DOT___052939_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019414_));
    vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026283_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b2__05d));
    vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032892_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032859_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___070633_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b1__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___070634_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b3__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032700_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032667_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b8__05d) {
        vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b8__05d;
        vlSelf->wasmetal_core__DOT___032637_ = vlSelf->wasmetal_core__DOT__sp__05b8__05d;
        vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b8__05d;
        vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b8__05d;
        vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b8__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___032637_ = wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031902_;
        vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033937_;
        vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032959_;
    }
    vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h13477f5c__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->insn_valid));
    vlSelf->wasmetal_core__DOT___063377_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045941_))));
    vlSelf->wasmetal_core__DOT___052873_ = (1U & (IData)(
                                                         (0x8000ffff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052871_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052870_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044716_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044720_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___044719_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___044718_))))))))))));
    vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027828_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b5__05d));
    vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026384_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128035___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028019_)))));
    vlSelf->wasmetal_core__DOT___028023_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032221_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032824_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128499___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032988_)))));
    vlSelf->wasmetal_core__DOT___032992_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b9__05d) {
        vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b9__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__1__KET__ = 0U;
        vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128164___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029411_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029410_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029409_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029408_)))) 
           ^ (((IData)(wasmetal_core__DOT___128164___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029375_)))));
    vlSelf->wasmetal_core__DOT___029379_ = ((IData)(vlSelf->wasmetal_core__DOT___029411_)
                                             ? (IData)(wasmetal_core__DOT___128164___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b7__05d));
    vlSelf->wasmetal_core__DOT___067559_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067556_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067555_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065566_)))));
    vlSelf->wasmetal_core__DOT___069657_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___069655_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069654_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 5U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hede308eb__0))))))));
    vlSelf->wasmetal_core__DOT___068874_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068869_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7eff58ec__0))))));
    vlSelf->wasmetal_core__DOT___069215_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069211_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7e1b7882__0))))));
    vlSelf->wasmetal_core__DOT___069284_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[1U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069341_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069391_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069417_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069449_ = (1U & (0xbb0bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067560_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 5U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069260_)))))));
    vlSelf->wasmetal_core__DOT___069264_ = (1U & (0xbb0bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067560_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069260_)))))));
    vlSelf->wasmetal_core__DOT___069497_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065647_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 7U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069517_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065755_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 8U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069543_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065842_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 9U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069569_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065975_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 9U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xaU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069634_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xcU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xdU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___067836_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x11U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf22e2068__0))))))));
    vlSelf->wasmetal_core__DOT___067939_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x13U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 4U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf22e2068__0))))))));
    vlSelf->wasmetal_core__DOT___070018_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070014_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067622_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xeU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84a22723__0))))))));
    vlSelf->wasmetal_core__DOT___070040_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070036_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067703_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xfU)) 
                                                                 | ((4U 
                                                                     & vlSelf->mem_rdata[1U]) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84a22723__0))))))));
    vlSelf->wasmetal_core__DOT___070001_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067567_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xdU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84a22723__0))))))));
    vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128148___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029250_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029249_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029248_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029247_)))) 
           ^ (((IData)(wasmetal_core__DOT___128148___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029214_)))));
    vlSelf->wasmetal_core__DOT___029218_ = ((IData)(vlSelf->wasmetal_core__DOT___029250_)
                                             ? (IData)(wasmetal_core__DOT___128148___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127827___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026194_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026193_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026192_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026191_)))) 
           ^ (((IData)(wasmetal_core__DOT___127827___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026158_)))));
    vlSelf->wasmetal_core__DOT___026162_ = ((IData)(vlSelf->wasmetal_core__DOT___026194_)
                                             ? (IData)(wasmetal_core__DOT___127827___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128535___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b9__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b8__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b7__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b6__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b9__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->__VdfgTmp_h891b440b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                      | (1U & (8U >> 
                                               (3U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                   >> 2U)))));
    vlSelf->__VdfgTmp_h91551c13__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)));
    vlSelf->wasmetal_core__DOT___019577_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (3U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                             >> 1U)))))));
    vlSelf->__VdfgTmp_h5035dc07__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___019418_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x5ffffffffffffff3ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                     << 5U)) 
                                                                 | ((0x10U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                        << 4U)) 
                                                                    | ((8U 
                                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                           << 3U)) 
                                                                       | ((4U 
                                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (~ 
                                                                                (- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_)))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x8000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (~ 
                                                                                (- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_)))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5ffffffffffffff3ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf123769f__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf123769f__0)))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5ffffffffffffff3ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                         << 5U)) 
                                                                     | ((0x10U 
                                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f508139__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (~ 
                                                                                (3U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_))) 
                                                                                >> 2U))))) 
                                                                                << 4U)) 
                                                                                | ((0xcU 
                                                                                & ((~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_))) 
                                                                                >> 1U))) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___034222_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_))) 
                                                                                >> 1U))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f508139__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & (~ 
                                                                                (3U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_))) 
                                                                                >> 2U)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128672___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034669_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034658_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034647_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128672___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___034733_ = ((IData)(vlSelf->wasmetal_core__DOT___034669_) 
                                            & (IData)(wasmetal_core__DOT___128672___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128711___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035145_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035144_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035139_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035128_)))) 
           ^ (((IData)(wasmetal_core__DOT___128711___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035053_)))));
    vlSelf->wasmetal_core__DOT___035081_ = ((IData)(vlSelf->wasmetal_core__DOT___035145_)
                                             ? (IData)(wasmetal_core__DOT___128711___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d));
    vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128945___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___135451___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___046799_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___046798_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___046797_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___135451___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___046834_ = ((IData)(vlSelf->wasmetal_core__DOT___046799_) 
                                            & (IData)(wasmetal_core__DOT___135451___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031181_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b1__05d));
    vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031469_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d));
    vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032492_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___032364_));
    vlSelf->wasmetal_core__DOT____Vcellout___135467___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___046932_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___046931_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___046930_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___135467___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___046967_ = ((IData)(vlSelf->wasmetal_core__DOT___046932_) 
                                            & (IData)(wasmetal_core__DOT___135467___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128214___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029943_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029942_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029941_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029940_)))) 
           ^ (((IData)(wasmetal_core__DOT___128214___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029907_)))));
    vlSelf->wasmetal_core__DOT___029911_ = ((IData)(vlSelf->wasmetal_core__DOT___029943_)
                                             ? (IData)(wasmetal_core__DOT___128214___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d));
    vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029772_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d));
    vlSelf->wasmetal_core__DOT___026254_ = ((IData)(vlSelf->wasmetal_core__DOT___026286_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127834___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026286_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026283_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026272_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026261_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032893_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032701_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128256___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030370_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b9__05d) {
        vlSelf->wasmetal_core__DOT___030374_ = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
        vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
        vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
        vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
        vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030374_ = vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032637_;
        vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128019___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027890_)))));
    vlSelf->wasmetal_core__DOT___027894_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128395___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031898_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128459___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032633_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128594___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033933_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128491___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032955_)))));
    vlSelf->wasmetal_core__DOT___128230___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d));
    vlSelf->wasmetal_core__DOT___063379_ = (1U & (IData)(
                                                         (0x5500cc000f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052949_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052954_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->mem_fault)))))))));
    vlSelf->__VdfgTmp_h9a5fea4e__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d));
    vlSelf->__VdfgTmp_h673d32f0__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d));
    vlSelf->wasmetal_core__DOT___062994_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052873_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052872_)))));
    vlSelf->wasmetal_core__DOT___062981_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052873_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027829_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b6__05d));
    vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026385_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b6__05d));
    vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___028023_));
    wasmetal_core__DOT___128427___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032222_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128474___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032827_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032824_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032813_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032802_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032795_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032827_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___032831_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032830_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032829_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032828_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O)))));
    vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032992_));
    wasmetal_core__DOT___128190___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128276___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b10__05d) {
        wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b10__05d;
    } else {
        wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__ = 0U;
        wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128372___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128224___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029412_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029379_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b8__05d));
    wasmetal_core__DOT___128207___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128157___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029251_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029218_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d));
    vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026195_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026162_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128569___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b10__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b9__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b8__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b7__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b10__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->__VdfgTmp_h53b39b5e__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5035dc07__0));
    vlSelf->wasmetal_core__DOT___071578_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___034222_))))));
    vlSelf->wasmetal_core__DOT___071583_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019418_))));
    vlSelf->wasmetal_core__DOT___034697_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128711___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d)))));
    vlSelf->wasmetal_core__DOT___034696_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128711___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d)))));
    vlSelf->wasmetal_core__DOT___034691_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128711___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___034680_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128711___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035146_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035081_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d));
    wasmetal_core__DOT___127996___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128946___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___030820_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b3__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135451___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046799_))))));
    vlSelf->wasmetal_core__DOT___030809_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135451___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046798_))))));
    vlSelf->wasmetal_core__DOT___030798_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135451___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046797_))))));
    vlSelf->wasmetal_core__DOT___030787_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135451___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__))))));
    wasmetal_core__DOT___046803_ = ((IData)(vlSelf->wasmetal_core__DOT___046800_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___046834_));
    wasmetal_core__DOT___128330___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031192_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b2__05d));
    wasmetal_core__DOT___128354___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031480_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d));
    wasmetal_core__DOT___128442___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032503_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___032375_));
    vlSelf->wasmetal_core__DOT___031778_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135467___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046932_))))));
    vlSelf->wasmetal_core__DOT___031767_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135467___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046931_))))));
    vlSelf->wasmetal_core__DOT___031756_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135467___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046930_))))));
    vlSelf->wasmetal_core__DOT___031745_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135467___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__))))));
    wasmetal_core__DOT___046936_ = ((IData)(vlSelf->wasmetal_core__DOT___046933_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___046967_));
    vlSelf->wasmetal_core__DOT____Vcellout___128695___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034925_)))));
    vlSelf->wasmetal_core__DOT___034953_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029944_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029911_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d));
    wasmetal_core__DOT___128197___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029773_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d));
    vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026287_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026254_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b4__05d));
    vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032894_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032702_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b10__05d) {
        vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
        vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030374_;
        vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027894_));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))) {
        vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O));
        vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O));
        vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O));
    } else {
        vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___063382_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063379_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128011___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027830_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027829_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027828_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027827_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027794_)))));
    vlSelf->wasmetal_core__DOT___027798_ = ((IData)(vlSelf->wasmetal_core__DOT___027830_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127843___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026386_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026385_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026384_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026383_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026350_)))));
    vlSelf->wasmetal_core__DOT___026354_ = ((IData)(vlSelf->wasmetal_core__DOT___026386_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d));
    vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128427___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032223_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032222_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032221_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032220_)))) 
           ^ (((IData)(wasmetal_core__DOT___128427___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032187_)))));
    vlSelf->wasmetal_core__DOT___032191_ = ((IData)(vlSelf->wasmetal_core__DOT___032223_)
                                             ? (IData)(wasmetal_core__DOT___128427___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d));
    vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032828_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032795_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O)));
    vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128190___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b8__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128190___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029676_)))));
    vlSelf->wasmetal_core__DOT___029649_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128190___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128276___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128276___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030588_)))));
    vlSelf->wasmetal_core__DOT___030561_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___128276___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128004___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b10__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h5a9aeb48__0))) 
           ^ (((IData)(wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027733_)))));
    vlSelf->wasmetal_core__DOT___027706_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128004___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128420___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032096_)))));
    vlSelf->wasmetal_core__DOT___032069_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___128420___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128372___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128372___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031615_)))));
    vlSelf->wasmetal_core__DOT___031588_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___128372___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128224___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128224___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030014_)))));
    vlSelf->wasmetal_core__DOT___029987_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128224___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029413_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128207___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128207___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029845_)))));
    vlSelf->wasmetal_core__DOT___029818_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128207___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128157___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128157___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029314_)))));
    vlSelf->wasmetal_core__DOT___029287_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d) 
                                            & (IData)(wasmetal_core__DOT___128157___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029252_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d));
    vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026196_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128578___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b8__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b11__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___071582_ = (1U & (1U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h53b39b5e__0))));
    vlSelf->wasmetal_core__DOT___071588_ = (1U & (0xc5U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x8fU 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                         << 2U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071578_))));
    vlSelf->wasmetal_core__DOT___019592_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b68__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfffe7fffffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h53b39b5e__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___071677_ = (1U & (0xbffdffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h53b39b5e__0))));
    vlSelf->__VdfgTmp_hb8bcf48d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                      | (1U & (0xbdffU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h91551c13__0)))));
    vlSelf->wasmetal_core__DOT___071594_ = (1U & (IData)(
                                                         (0xe000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                                 << 2U))))));
    vlSelf->wasmetal_core__DOT___071587_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x80U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___071583_)))))));
    vlSelf->wasmetal_core__DOT___071606_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x80U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___071583_)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___071583_))))))));
    vlSelf->wasmetal_core__DOT___071616_ = (1U & (IData)(
                                                         (0xfe00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (8U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                    << 3U)))))));
    vlSelf->wasmetal_core__DOT___071642_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    vlSelf->wasmetal_core__DOT___071656_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x10U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                         << 2U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    vlSelf->__VdfgTmp_h79139d38__0 = (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                     << 4U)) 
                                                 | (0xfU 
                                                    & (~ 
                                                       (7U 
                                                        | (8U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                              << 3U)))))));
    vlSelf->wasmetal_core__DOT___071602_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071583_))));
    vlSelf->__VdfgTmp_he7466e08__0 = (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                  << 4U) 
                                                 | (8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 3U))));
    vlSelf->__VdfgTmp_hce5a5a6e__0 = ((2U & ((8U >> 
                                              (1U & 
                                               (8U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___071583_)))) 
                                             << 1U)) 
                                      | (1U & (0x8fU 
                                               >> ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                   << 2U))));
    vlSelf->wasmetal_core__DOT___071610_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___071583_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___071583_))))));
    vlSelf->__VdfgTmp_h3a1fe2e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                       << 4U) | (0xfU 
                                                 & (~ 
                                                    (7U 
                                                     | (8U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                           << 3U))))));
    vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034680_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034733_));
    vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035147_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127996___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128947___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128946___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128945___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128944___Q)))) 
           ^ (((IData)(wasmetal_core__DOT___127996___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027668_)))));
    vlSelf->wasmetal_core__DOT___027641_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128947___Q) 
                                            & (IData)(wasmetal_core__DOT___127996___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030787_) 
           | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b0__05d));
    wasmetal_core__DOT____Vcellout___135458___O = (
                                                   (0xeU 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___046800_)) 
                                                   ^ 
                                                   ((0xeU 
                                                     & ((- (IData)((IData)(wasmetal_core__DOT___046803_))) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___046834_)));
    __VdfgTmp_h598a1bee__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046803_)) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_h54bac186__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046803_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_he0338233__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046803_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_he536c7ea__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046803_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->wasmetal_core__DOT____Vcellout___128330___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031203_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031192_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031181_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031170_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128330___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031139_ = ((IData)(vlSelf->wasmetal_core__DOT___031203_)
                                             ? (IData)(wasmetal_core__DOT___128330___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128354___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031491_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031480_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031469_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031458_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128354___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031427_ = ((IData)(vlSelf->wasmetal_core__DOT___031491_)
                                             ? (IData)(wasmetal_core__DOT___128354___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128442___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032514_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032503_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032492_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032481_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128442___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032450_ = ((IData)(vlSelf->wasmetal_core__DOT___032514_)
                                             ? (IData)(wasmetal_core__DOT___128442___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___032386_));
    vlSelf->wasmetal_core__DOT___128378___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031745_) 
           | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___135474___O 
        = ((0xeU | (IData)(vlSelf->wasmetal_core__DOT___046933_)) 
           ^ ((0xeU & ((- (IData)((IData)(wasmetal_core__DOT___046936_))) 
                       << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___046967_)));
    vlSelf->__VdfgTmp_h9a63e080__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046936_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_ha1f5c117__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046936_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_hf3cdd6fc__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046936_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->__VdfgTmp_hf01f7256__0 = ((2U & ((~ (IData)(wasmetal_core__DOT___046936_)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards));
    vlSelf->wasmetal_core__DOT___128696___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034953_));
    vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029945_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128215___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128197___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029774_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029773_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029772_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029771_)))) 
           ^ (((IData)(wasmetal_core__DOT___128197___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029738_)))));
    vlSelf->wasmetal_core__DOT___029742_ = ((IData)(vlSelf->wasmetal_core__DOT___029774_)
                                             ? (IData)(wasmetal_core__DOT___128197___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d));
    vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026288_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128483___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032895_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032894_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032893_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032892_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032859_)))));
    vlSelf->wasmetal_core__DOT___032863_ = ((IData)(vlSelf->wasmetal_core__DOT___032895_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128467___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032703_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032702_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032701_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032700_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032667_)))));
    vlSelf->wasmetal_core__DOT___032671_ = ((IData)(vlSelf->wasmetal_core__DOT___032703_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128516___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                       >> 1U)) << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                   >> 3U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (0x78U 
                                                   >> 
                                                   (7U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))) {
        vlSelf->wasmetal_core__DOT___033129_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033223_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033995_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033129_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033223_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033995_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128524___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                       >> 1U)) << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                   >> 3U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (6U 
                                                   >> 
                                                   (3U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       >> 1U))))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128601___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                       >> 1U)) << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                   >> 3U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (0x1eU 
                                                   >> 
                                                   (7U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___062506_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___063441_ = (1U & (0xff8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__copy_next__05b4__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063377_)))))));
    vlSelf->__VdfgTmp_hf72c75d5__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0))));
    vlSelf->wasmetal_core__DOT___019355_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d))));
    vlSelf->__VdfgTmp_hb5e2654e__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128230___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d)))) 
           ^ (1U | ((((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)
                       ? (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)
                       : (IData)(vlSelf->wasmetal_core__DOT___128230___DOT__CO__BRA__1__KET__)) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128230___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___062982_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___062983_ = (1U & (0xfecf05ecU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___062996_ = (1U & (IData)(
                                                         (0xfff44ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->mem_fault) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02etrap__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___054474_ = (1U & (0x35006bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))))));
    vlSelf->__VdfgTmp_h1a7964bb__0 = (((IData)(vlSelf->insn_valid) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d));
    vlSelf->wasmetal_core__DOT___000158_ = (1U & (0xbfffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))))));
    vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027831_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027798_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b8__05d));
    vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026387_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026354_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d));
    vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045538_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b7__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b6__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045537_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b3__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O))))))))));
    vlSelf->wasmetal_core__DOT___045550_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b5__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b6__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b7__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045549_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b2__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b3__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b4__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128427___O))))))))));
    vlSelf->wasmetal_core__DOT___128428___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032224_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032191_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032829_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                     >> 1U)));
    vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128191___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029649_));
    vlSelf->wasmetal_core__DOT___128277___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030561_));
    vlSelf->wasmetal_core__DOT___128005___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027706_));
    vlSelf->wasmetal_core__DOT____Vcellinp__frames_memory__02e0__02e0__ADDRARDADDR 
        = (0x803fU | ((0x4000U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128420___O) 
                                  << 0xeU)) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128419___O) 
                                                << 0xaU) 
                                               | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128418___O) 
                                                  << 6U))));
    vlSelf->wasmetal_core__DOT___128421___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032069_));
    vlSelf->wasmetal_core__DOT___128373___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031588_));
    vlSelf->wasmetal_core__DOT___128225___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029987_));
    vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029383_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128165___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b10__05d));
    vlSelf->wasmetal_core__DOT___128208___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029818_));
    vlSelf->wasmetal_core__DOT___128158___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029287_));
    vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029222_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128149___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d));
    vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026166_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127828___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128587___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b12__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b11__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b10__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b9__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128570___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128588___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b12__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128579___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___071595_ = (1U & (0x1f000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                    << 4U) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                      << 3U))));
    vlSelf->wasmetal_core__DOT___071593_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x7000U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                           << 3U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                             << 2U)))))));
    vlSelf->wasmetal_core__DOT___071601_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071578_))));
    vlSelf->wasmetal_core__DOT___071678_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b36__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071677_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071711_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b100__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071677_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071653_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b20__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb8bcf48d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071691_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b52__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb8bcf48d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071708_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b84__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb8bcf48d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071714_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b116__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb8bcf48d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019434_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071588_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071587_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h891b440b__0))))))));
    vlSelf->__VdfgTmp_hce6e76ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___071587_) 
                                       << 1U) | (1U 
                                                 & (0x4fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                      << 4U) 
                                                     | ((8U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                            << 3U)) 
                                                        | ((4U 
                                                            & ((0x8fU 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                                 << 2U)) 
                                                               << 2U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                              << 1U)))))));
    vlSelf->wasmetal_core__DOT___071607_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b5__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                                    << 1U)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((0x8fU 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                                       << 2U)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071606_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h891b440b__0))))))));
    vlSelf->__VdfgTmp_h9972469d__0 = (((IData)(vlSelf->wasmetal_core__DOT___071606_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x700000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                 << 3U) 
                                                                | (4U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                      << 2U))))))));
    vlSelf->wasmetal_core__DOT___071618_ = (1U & (IData)(
                                                         (0x7f007f7f7f7f7f7fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                                 << 1U)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                                    << 1U)) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071616_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                              >> 2U)))))))))));
    vlSelf->__VdfgTmp_hb635a29b__0 = (((IData)(vlSelf->wasmetal_core__DOT___071616_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x100000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                 << 3U) 
                                                                | (4U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                      << 2U))))))));
    vlSelf->__VdfgTmp_hc7c7e46f__0 = (((IData)(vlSelf->wasmetal_core__DOT___071642_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)));
    vlSelf->__VdfgTmp_h35a843b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___071602_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)));
    vlSelf->__VdfgTmp_hfffbe48f__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                      | (1U & (IData)(
                                                      (0xff7f80ffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he7466e08__0)))));
    vlSelf->__VdfgTmp_hd1e6ff3c__0 = (((IData)(vlSelf->wasmetal_core__DOT___071594_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x1f00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_he7466e08__0)))));
    vlSelf->wasmetal_core__DOT___071673_ = (1U & (0xfffa3fffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hce5a5a6e__0))))));
    vlSelf->__VdfgTmp_hd54e1937__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hce5a5a6e__0));
    vlSelf->__VdfgTmp_h5b134ff6__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071610_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x10U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                             << 2U))))))));
    vlSelf->wasmetal_core__DOT___071611_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071610_))));
    vlSelf->__VdfgTmp_h017bc299__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & (0x807fffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h3a1fe2e7__0))));
    vlSelf->__VdfgTmp_hce90a299__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & (0xf807ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h3a1fe2e7__0))));
    vlSelf->__VdfgTmp_h79503a99__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & (0xfe01ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h3a1fe2e7__0))));
    vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034691_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128679___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035085_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128712___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d));
    vlSelf->wasmetal_core__DOT___127997___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128948___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027641_));
    vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030798_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128298___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b1__05d));
    vlSelf->wasmetal_core__DOT___030848_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b7__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___135458___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___030847_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b6__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___135458___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___030842_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b5__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___135458___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_backwards)))));
    vlSelf->wasmetal_core__DOT___030831_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b4__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___135458___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046800_))))));
    vlSelf->wasmetal_core__DOT___030846_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b63__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030841_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b59__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030837_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b55__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030833_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b51__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030828_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b47__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030824_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b43__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030819_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b39__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030815_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b35__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030811_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b31__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030806_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b27__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030802_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b23__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030797_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b19__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030793_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b15__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030789_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b11__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h598a1bee__0))));
    vlSelf->wasmetal_core__DOT___030845_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b62__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030840_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b58__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030836_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b54__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030832_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b50__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030827_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b46__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030823_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b42__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030818_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b38__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
    vlSelf->wasmetal_core__DOT___030814_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b34__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54bac186__0))));
}
