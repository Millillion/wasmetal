#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__0(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__0\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___020842_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049938_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___020584_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___021480_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049422_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___021222_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048537_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___019818_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___020203_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___039850_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039834_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039833_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & vlSelf->function_locals) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039832_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039831_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039822_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039823_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039830_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039828_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 6U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039827_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 7U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039826_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 8U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039825_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128276___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 9U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039835_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xaU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039836_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xbU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039837_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xcU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039851_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128277___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xdU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039847_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xeU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039846_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xfU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039845_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x10U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039844_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x11U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039829_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x12U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039838_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x13U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039824_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x14U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039842_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x15U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039841_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x16U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039840_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x17U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039839_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x18U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039848_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x19U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039849_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128281___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x1aU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039853_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128281___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x1bU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039852_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128281___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x1cU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039843_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128281___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x1dU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___036619_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d))));
    vlSelf->wasmetal_core__DOT___070064_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b99__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b99__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070108_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b102__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b102__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070140_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b104__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 6U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b104__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070198_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b108__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xaU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b108__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070213_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b109__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xbU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b109__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070228_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b110__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xcU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b110__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070309_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b116__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x12U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b116__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070361_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b120__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x16U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b120__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___065266_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064249_))));
    vlSelf->__VdfgTmp_hf9e7c209__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1dU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d));
    vlSelf->wasmetal_core__DOT___069277_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b64__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & vlSelf->mem_rdata[2U]))))));
    vlSelf->wasmetal_core__DOT___069307_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b65__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___069334_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b66__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___069358_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b67__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___069383_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b68__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 4U)))))));
    vlSelf->wasmetal_core__DOT___069409_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b69__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 5U)))))));
    vlSelf->wasmetal_core__DOT___069433_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b70__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 6U)))))));
    vlSelf->wasmetal_core__DOT___069459_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b71__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 7U)))))));
    vlSelf->wasmetal_core__DOT___069487_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b72__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 8U)))))));
    vlSelf->wasmetal_core__DOT___069554_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b75__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xbU)))))));
    vlSelf->wasmetal_core__DOT___069623_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b78__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xeU)))))));
    vlSelf->wasmetal_core__DOT___069669_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b80__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x10U)))))));
    vlSelf->wasmetal_core__DOT___069675_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069676_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))));
    vlSelf->wasmetal_core__DOT___069843_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b88__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x18U)))))));
    vlSelf->wasmetal_core__DOT___069864_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b89__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x19U)))))));
    vlSelf->wasmetal_core__DOT___069884_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b90__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1aU)))))));
    vlSelf->wasmetal_core__DOT___069905_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b91__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1bU)))))));
    vlSelf->wasmetal_core__DOT___069925_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b92__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1cU)))))));
    vlSelf->wasmetal_core__DOT___069946_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b93__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1dU)))))));
    vlSelf->wasmetal_core__DOT___070007_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b96__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & vlSelf->mem_rdata[3U]))))));
    vlSelf->wasmetal_core__DOT___063422_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063408_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048478_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->mem_fault)))))));
    vlSelf->wasmetal_core__DOT___067774_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070055_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070114_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070190_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067556_))));
    vlSelf->wasmetal_core__DOT___064717_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064715_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b1__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065284_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065282_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065281_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b5__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065724_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065721_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b9__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065885_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065883_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065882_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066203_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066200_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xbU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b14__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066299_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066297_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xdU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b15__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067721_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067719_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->mem_rdata[1U]) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b34__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067803_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067801_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b35__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067856_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067854_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b36__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067890_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067888_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b37__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068068_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068066_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 6U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b40__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068142_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068140_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 7U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b41__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068228_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068226_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 9U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b43__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068467_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068465_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xdU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b47__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068810_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068808_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068807_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b54__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___068956_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068954_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068953_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b57__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069005_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069003_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069002_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b58__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069054_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069052_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b59__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069081_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069079_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x1aU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b60__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069198_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069196_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069195_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x1bU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b62__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069229_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069227_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x1dU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069284_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[1U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069341_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069391_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069417_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069506_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b73__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 9U)))))));
    vlSelf->wasmetal_core__DOT___069530_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b74__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xaU)))))));
    vlSelf->wasmetal_core__DOT___069578_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b76__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xcU)))))));
    vlSelf->wasmetal_core__DOT___069599_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b77__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xdU)))))));
    vlSelf->wasmetal_core__DOT___069691_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b81__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x11U)))))));
    vlSelf->wasmetal_core__DOT___070077_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b100__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b100__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070099_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070122_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b103__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b103__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070093_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b101__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070153_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b105__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 7U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b105__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070166_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b106__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 8U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b106__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070180_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b107__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 9U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b107__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070241_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b111__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b111__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070270_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b113__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xfU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b113__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070282_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b114__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x10U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b114__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070294_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b115__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x11U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b115__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070320_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b117__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x13U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b117__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070332_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b118__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x14U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b118__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070344_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b119__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x15U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b119__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070372_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b121__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x17U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b121__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070384_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b122__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x18U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b122__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070396_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b123__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x19U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b123__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070409_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b124__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1aU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b124__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070421_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b125__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1bU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b125__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070434_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b126__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1cU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b126__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070446_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b127__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1dU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b127__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___068376_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067570_))));
    vlSelf->wasmetal_core__DOT___068180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067570_))));
    vlSelf->wasmetal_core__DOT___069584_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069607_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069746_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___069365_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[2U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___070202_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___070217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___070349_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___064440_ = (1U & (0xf5f3ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___064882_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064880_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->mem_rdata[0U]) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b2__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065395_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065393_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065501_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065499_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b7__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067951_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067949_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b38__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068194_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068192_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 8U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b42__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068390_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068388_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xcU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b46__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___070256_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->cmd_data[3U] 
                                                       >> 0xfU)) 
                                                   | (1U 
                                                      & (0xf38f2779U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he557a56d__0))))));
    vlSelf->__VdfgTmp_h586b57d5__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1cU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    vlSelf->wasmetal_core__DOT___068543_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068541_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xfU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b49__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068594_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068592_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x10U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b50__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068693_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x12U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b52__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069130_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069128_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x1bU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b61__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069964_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b94__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1eU)))))));
    vlSelf->wasmetal_core__DOT___070248_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065567_))));
    vlSelf->wasmetal_core__DOT___069720_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069807_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___070046_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b98__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___070069_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___065789_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065787_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065786_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b10__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066066_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066064_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066063_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b13__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069765_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xaU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x14U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067557_))))));
    vlSelf->wasmetal_core__DOT___062996_ = (1U & (IData)(
                                                         (0xfff44ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->mem_fault) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02etrap__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___067866_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___069698_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069699_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))));
    vlSelf->wasmetal_core__DOT___069742_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069743_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))));
    vlSelf->wasmetal_core__DOT___069786_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xbU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x15U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067557_))))));
    vlSelf->wasmetal_core__DOT___070085_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___067625_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___068013_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068011_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b39__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___064451_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064449_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___066003_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066001_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xaU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b12__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___064690_ = (1U & (0xf5f3ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 4U)))))));
    vlSelf->wasmetal_core__DOT___067585_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067583_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b32__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068509_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068507_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xeU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b48__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___070414_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___070426_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[3U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069262_))));
    vlSelf->wasmetal_core__DOT___068494_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065567_))));
    vlSelf->wasmetal_core__DOT___068886_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068884_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x16U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068641_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068639_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x11U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b51__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068738_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068736_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x13U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b53__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068838_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068836_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x15U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b55__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->type_actual = (((0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                   << 1U) 
                                                  | (vlSelf->function_type 
                                                     >> 0x1fU)))) 
                            << 0x1fU) | ((0x40000000U 
                                          & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (vlSelf->function_type 
                                                           >> 0x1eU))))) 
                                             << 0x1eU)) 
                                         | ((0x20000000U 
                                             & ((0xacU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (vlSelf->function_type 
                                                           >> 0x1dU))))) 
                                                << 0x1dU)) 
                                            | ((0x10000000U 
                                                & ((0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (vlSelf->function_type 
                                                              >> 0x1cU))))) 
                                                   << 0x1cU)) 
                                               | ((0x8000000U 
                                                   & ((0xacU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (vlSelf->function_type 
                                                                 >> 0x1bU))))) 
                                                      << 0x1bU)) 
                                                  | ((0x4000000U 
                                                      & ((0xacU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->function_type 
                                                                    >> 0x1aU))))) 
                                                         << 0x1aU)) 
                                                     | ((0x2000000U 
                                                         & ((0xacU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                                  << 1U) 
                                                                 | (1U 
                                                                    & (vlSelf->function_type 
                                                                       >> 0x19U))))) 
                                                            << 0x19U)) 
                                                        | ((0x1000000U 
                                                            & ((0xacU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (vlSelf->function_type 
                                                                          >> 0x18U))))) 
                                                               << 0x18U)) 
                                                           | ((0x800000U 
                                                               & ((0xacU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->function_type 
                                                                             >> 0x17U))))) 
                                                                  << 0x17U)) 
                                                              | ((0x400000U 
                                                                  & ((0xacU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (vlSelf->function_type 
                                                                                >> 0x16U))))) 
                                                                     << 0x16U)) 
                                                                 | ((0x200000U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x15U))))) 
                                                                        << 0x15U)) 
                                                                    | ((0x100000U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x14U))))) 
                                                                           << 0x14U)) 
                                                                       | ((0x80000U 
                                                                           & ((0xacU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x13U))))) 
                                                                              << 0x13U)) 
                                                                          | ((0x40000U 
                                                                              & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x12U))))) 
                                                                                << 0x12U)) 
                                                                             | ((0x20000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x11U))))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x10U))))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xfU))))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xeU))))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xdU))))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xcU))))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xbU))))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xaU))))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 9U))))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 8U))))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 7U))))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 6U))))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 5U))))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 4U))))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 3U))))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 2U))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 1U))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & vlSelf->function_type))))))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___069473_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067558_))));
    vlSelf->wasmetal_core__DOT___065156_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065154_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b4__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069654_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->__VdfgTmp_h364ba349__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1bU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    vlSelf->wasmetal_core__DOT___067622_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))))));
    vlSelf->wasmetal_core__DOT___067988_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___068678_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067570_))));
    vlSelf->wasmetal_core__DOT___065043_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065041_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___045785_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->cmd_index 
                                                            >> 0x1aU))) 
                                                  & ((IData)(
                                                             (1ULL 
                                                              >> 
                                                              (0x3fU 
                                                               & (vlSelf->cmd_index 
                                                                  >> 0x14U)))) 
                                                     & ((IData)(
                                                                (1ULL 
                                                                 >> 
                                                                 (0x3fU 
                                                                  & (vlSelf->cmd_index 
                                                                     >> 0xeU)))) 
                                                        & ((~ (IData)(
                                                                      (0x100000000ULL 
                                                                       >> 
                                                                       (0x3fU 
                                                                        & (vlSelf->cmd_index 
                                                                           >> 8U))))) 
                                                           & (~ 
                                                              (vlSelf->cmd_index 
                                                               >> 0xdU)))))));
    vlSelf->wasmetal_core__DOT___032890_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d))));
    vlSelf->wasmetal_core__DOT___032889_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d))));
    vlSelf->wasmetal_core__DOT___068869_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___067703_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))))));
    vlSelf->wasmetal_core__DOT___067567_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))))));
    vlSelf->wasmetal_core__DOT___068912_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->__VdfgTmp_h13477f5c__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->insn_valid));
    vlSelf->wasmetal_core__DOT___069172_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->__VdfgTmp_hd2526c88__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1aU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    vlSelf->wasmetal_core__DOT___068537_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068979_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069010_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___066943_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->__VdfgTmp_h0ff1168c__0 = (((IData)(vlSelf->wasmetal_core__DOT___038870_) 
                                       << 1U) | (IData)(vlSelf->mem_fault));
    vlSelf->wasmetal_core__DOT___069211_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___066375_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___068773_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068675_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069059_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___052984_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0x17U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 9U)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[0U] 
                                                                    >> 5U)))))));
    vlSelf->wasmetal_core__DOT___052959_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x10U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[2U] 
                                                                  >> 0xcU)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[2U] 
                                                                    >> 8U)))))));
    vlSelf->wasmetal_core__DOT___052960_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 0xeU)) 
                                                           | ((6U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 5U)) 
                                                              | (1U 
                                                                 & vlSelf->mem_rdata[3U]))))));
    vlSelf->wasmetal_core__DOT___052977_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0x11U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0xdU)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[0U] 
                                                                    >> 9U)))))));
    vlSelf->wasmetal_core__DOT___052978_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & (vlSelf->mem_rdata[1U] 
                                                               >> 0xeU)) 
                                                           | ((6U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 5U)) 
                                                              | (1U 
                                                                 & vlSelf->mem_rdata[1U]))))));
    vlSelf->wasmetal_core__DOT___052969_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & (vlSelf->mem_rdata[1U] 
                                                                    >> 0xeU))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & (vlSelf->mem_rdata[1U] 
                                                                       >> 0x14U))) 
                                                                  << 4U)) 
                                                              | ((0xcU 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xaU)) 
                                                                 | (3U 
                                                                    & (vlSelf->mem_rdata[1U] 
                                                                       >> 8U))))))));
    vlSelf->wasmetal_core__DOT___052970_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xeU)) 
                                                           | ((6U 
                                                               & (vlSelf->mem_rdata[2U] 
                                                                  >> 5U)) 
                                                              | (1U 
                                                                 & vlSelf->mem_rdata[2U]))))));
    vlSelf->wasmetal_core__DOT___027825_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b31__05d) 
                                                    << 1U) 
                                                   | (vlSelf->function_params 
                                                      >> 0x1fU))));
    vlSelf->wasmetal_core__DOT___027824_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b30__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1eU)))));
    vlSelf->wasmetal_core__DOT___052957_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               << 5U)) 
                                                           | ((0x1cU 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x1bU)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[0U] 
                                                                    >> 0x19U)))))));
    vlSelf->wasmetal_core__DOT___052967_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1cU)) 
                                                   | (3U 
                                                      & (vlSelf->mem_rdata[1U] 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___052964_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x3cU 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1aU)) 
                                                           | (3U 
                                                              & (vlSelf->mem_rdata[2U] 
                                                                 >> 0x18U))))));
    vlSelf->__VdfgTmp_h7eff58ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___066368_) 
                                       << 1U) | (1U 
                                                 & (vlSelf->mem_rdata[0U] 
                                                    >> 8U)));
    vlSelf->wasmetal_core__DOT___052973_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x3cU 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 0x1aU)) 
                                                           | (3U 
                                                              & (vlSelf->mem_rdata[3U] 
                                                                 >> 0x18U))))));
    vlSelf->wasmetal_core__DOT___052974_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 0x10U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0xcU)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[3U] 
                                                                    >> 8U)))))));
    vlSelf->wasmetal_core__DOT___068576_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___052961_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 0x16U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 8U)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[3U] 
                                                                    >> 4U)))))));
    vlSelf->wasmetal_core__DOT___052962_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0xfU)) 
                                                           | ((6U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 6U)) 
                                                              | (1U 
                                                                 & (vlSelf->mem_rdata[0U] 
                                                                    >> 1U)))))));
    vlSelf->wasmetal_core__DOT___052963_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[1U] 
                                                               >> 0x16U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 8U)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[1U] 
                                                                    >> 4U)))))));
    vlSelf->wasmetal_core__DOT___069105_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___066456_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___045803_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->cmd_index 
                                                       >> 7U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (0x1fU 
                                                          & (vlSelf->cmd_index 
                                                             >> 9U)))))));
    vlSelf->wasmetal_core__DOT___066556_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___066724_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___067039_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___032887_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d))));
    vlSelf->__VdfgTmp_h93f91ca8__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x19U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    vlSelf->wasmetal_core__DOT___067262_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067215_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067426_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067108_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067359_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___066669_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___063379_ = (1U & (IData)(
                                                         (0x5500cc000f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052949_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052954_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->mem_fault)))))))));
    vlSelf->__VdfgTmp_h7e1b7882__0 = (((IData)(vlSelf->wasmetal_core__DOT___066368_) 
                                       << 1U) | (1U 
                                                 & (vlSelf->mem_rdata[0U] 
                                                    >> 0xfU)));
    vlSelf->wasmetal_core__DOT___066808_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___045744_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->result_index 
                                                            >> 0x1aU))) 
                                                  & ((IData)(
                                                             (1ULL 
                                                              >> 
                                                              (0x3fU 
                                                               & (vlSelf->result_index 
                                                                  >> 0x14U)))) 
                                                     & ((IData)(
                                                                (1ULL 
                                                                 >> 
                                                                 (0x3fU 
                                                                  & (vlSelf->result_index 
                                                                     >> 0xeU)))) 
                                                        & ((~ (IData)(
                                                                      (0x100000000ULL 
                                                                       >> 
                                                                       (0x3fU 
                                                                        & (vlSelf->result_index 
                                                                           >> 8U))))) 
                                                           & (~ 
                                                              (vlSelf->result_index 
                                                               >> 0xdU)))))));
    vlSelf->wasmetal_core__DOT___032886_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d))));
    vlSelf->wasmetal_core__DOT___066479_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___063390_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & (vlSelf->function_locals 
                                                                    >> 0x17U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & (vlSelf->function_locals 
                                                                       >> 0x19U))) 
                                                                  << 4U)) 
                                                              | ((0xcU 
                                                                  & (vlSelf->function_locals 
                                                                     >> 0x19U)) 
                                                                 | (3U 
                                                                    & (vlSelf->function_locals 
                                                                       >> 0x15U))))))));
    vlSelf->wasmetal_core__DOT___063391_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                            << 5U) 
                                                           | (0x1fU 
                                                              & vlSelf->function_locals)))));
    vlSelf->wasmetal_core__DOT___063385_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & (vlSelf->function_locals 
                                                                    >> 0x13U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & (vlSelf->function_locals 
                                                                       >> 0x11U))) 
                                                                  << 4U)) 
                                                              | (0xfU 
                                                                 & (vlSelf->function_locals 
                                                                    >> 0xdU)))))));
    vlSelf->__VdfgTmp_h4835143f__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x18U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT___027822_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b29__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1dU)))));
    vlSelf->wasmetal_core__DOT___069471_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065560_))));
    vlSelf->wasmetal_core__DOT___069828_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xdU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066372_)))));
    vlSelf->wasmetal_core__DOT___065587_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065585_))));
    vlSelf->__VdfgTmp_h26309c84__0 = ((2U & (vlSelf->function_params 
                                             >> 0xcU)) 
                                      | (1U & (1U >> 
                                               (0x1fU 
                                                & (vlSelf->function_params 
                                                   >> 8U)))));
    vlSelf->wasmetal_core__DOT___032885_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d))));
    vlSelf->wasmetal_core__DOT___069653_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066372_))));
    vlSelf->__VdfgTmp_hf6334cf8__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x17U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___070129_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065560_))));
    vlSelf->wasmetal_core__DOT___052872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__check_type) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->type_matches))));
    vlSelf->__VdfgTmp_h2b80e318__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x16U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    vlSelf->wasmetal_core__DOT___032884_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d))));
    vlSelf->wasmetal_core__DOT___027821_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1cU)))));
    vlSelf->__VdfgTmp_h17547017__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x15U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    vlSelf->wasmetal_core__DOT___054471_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6c590b04__0))));
    vlSelf->wasmetal_core__DOT___065573_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065568_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065560_)))));
    vlSelf->__VdfgTmp_hed077be7__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x14U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___050399_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->__VdfgTmp_h1872cc15__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x13U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    vlSelf->wasmetal_core__DOT___044703_ = (1U & (0x7150U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->function_params 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (vlSelf->function_params 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0)))));
    vlSelf->wasmetal_core__DOT___044708_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 6U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 8U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha938949d__0))))))));
    vlSelf->wasmetal_core__DOT___044712_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0x12U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x14U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd225b533__0))))))));
    vlSelf->wasmetal_core__DOT___044684_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (vlSelf->cmd_aux 
                                                                >> 0xdU)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (7U 
                                                            & (IData)(
                                                                      (vlSelf->cmd_aux 
                                                                       >> 0xaU)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0xeU)))))))));
    vlSelf->wasmetal_core__DOT___044672_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (IData)(
                                                                   (vlSelf->cmd_aux 
                                                                    >> 0xeU)))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (vlSelf->cmd_aux 
                                                                   >> 0xdU)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (7U 
                                                             & (IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0xaU)))))))));
    vlSelf->wasmetal_core__DOT___044689_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x28U)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x29U)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x2aU)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x2bU)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x2cU)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x2dU)))))))))));
    vlSelf->wasmetal_core__DOT___044688_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x22U)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x23U)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x24U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x25U)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x26U)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x27U)))))))))));
    vlSelf->wasmetal_core__DOT___044687_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x20U)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x21U)) 
                                                                  << 4U)) 
                                                              | (0xfU 
                                                                 & (IData)(
                                                                           (vlSelf->cmd_aux 
                                                                            >> 0x1cU))))))));
    vlSelf->wasmetal_core__DOT___044682_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x3aU)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x3cU)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x3dU)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x3eU)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x3bU)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x3fU)))))))))));
    vlSelf->wasmetal_core__DOT___044691_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x34U)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x37U)) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x38U)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x36U)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x39U))))))))));
    vlSelf->wasmetal_core__DOT___044690_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x2eU)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x2fU)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x30U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x31U)) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x32U))))))))));
    vlSelf->wasmetal_core__DOT___044707_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 5U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 7U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___044706_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & vlSelf->function_params) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 2U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___044705_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___044711_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0xfU)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x11U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___044710_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0xcU)) 
                                                           | ((0x18U 
                                                               & (vlSelf->function_params 
                                                                  >> 0xfU)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d))))))));
    vlSelf->wasmetal_core__DOT___044709_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 9U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0xbU)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___044704_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0x18U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x1aU)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x1cU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___044713_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0x15U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x17U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___032883_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d))));
    vlSelf->__VdfgTmp_h9473bd37__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x12U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT___065647_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___065842_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___128026___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & vlSelf->insn_z)));
    vlSelf->wasmetal_core__DOT___128266___DOT__CO__BRA__1__KET__ 
        = (1U & ((2U & vlSelf->mem_rdata[0U]) ? (vlSelf->mem_rdata[0U] 
                                                 >> 1U)
                  : vlSelf->mem_rdata[0U]));
    vlSelf->wasmetal_core__DOT___027820_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1bU)))));
    vlSelf->wasmetal_core__DOT___065572_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___032882_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d))));
    vlSelf->wasmetal_core__DOT___069996_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067561_))));
    vlSelf->wasmetal_core__DOT___066020_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->__VdfgTmp_hfd696a08__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x11U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    vlSelf->wasmetal_core__DOT___066374_ = (1U & (0x4404ff0fU 
                                                  >> 
                                                  ((0x10U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065568_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066364_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066372_)))))));
    vlSelf->wasmetal_core__DOT___066218_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___066176_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___032881_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d))));
    vlSelf->wasmetal_core__DOT___065975_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___053074_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045623_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044026_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->type_matches)))));
    vlSelf->__VdfgTmp_hb0a19382__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x10U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___027819_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1aU)))));
    vlSelf->wasmetal_core__DOT___032880_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d))));
    vlSelf->__VdfgTmp_h959d8796__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xfU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___065755_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___032879_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d))));
    vlSelf->__VdfgTmp_h6d2d9567__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xeU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT___027818_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x19U)))));
    vlSelf->wasmetal_core__DOT___070246_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1dU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066372_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067561_)))));
    vlSelf->__VdfgTmp_h291433ac__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xdU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    vlSelf->__VdfgTmp_hbd028268__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xcU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT___032878_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d))));
    vlSelf->__VdfgTmp_h6265db41__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xbU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->__VdfgTmp_h7b2f5a0d__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xaU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT___027817_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___032876_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d))));
    vlSelf->wasmetal_core__DOT___026381_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b31__05d) 
                                                    << 1U) 
                                                   | (vlSelf->insn_x 
                                                      >> 0x1fU))));
    vlSelf->wasmetal_core__DOT___026380_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b30__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1eU)))));
    vlSelf->__VdfgTmp_h73f978ac__0 = ((2U & ((IData)(vlSelf->cmd_kind) 
                                             >> 1U)) 
                                      | (1U & ((IData)(vlSelf->cmd_kind) 
                                               >> 3U)));
    vlSelf->__VdfgTmp_h86617c98__0 = ((2U & (vlSelf->insn_x 
                                             >> 9U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    vlSelf->wasmetal_core__DOT___032875_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d))));
    vlSelf->wasmetal_core__DOT___027816_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x17U)))));
    vlSelf->__VdfgTmp_h20c332a4__0 = ((2U & (vlSelf->insn_x 
                                             >> 8U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___032874_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d))));
    vlSelf->__VdfgTmp_h1c8d20fd__0 = ((2U & (vlSelf->insn_x 
                                             >> 7U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___053317_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b90__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1aU)))));
    vlSelf->wasmetal_core__DOT___053318_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b88__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___053325_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b76__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0xcU)))));
    vlSelf->wasmetal_core__DOT___053326_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b91__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1bU)))));
    vlSelf->wasmetal_core__DOT___053313_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b72__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 8U)))));
    vlSelf->wasmetal_core__DOT___053314_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b74__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0xaU)))));
    vlSelf->wasmetal_core__DOT___053322_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b83__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x11U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b82__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x12U)))))));
    vlSelf->wasmetal_core__DOT___053323_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b68__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b64__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & vlSelf->insn_y))))));
    vlSelf->wasmetal_core__DOT___053324_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b69__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b65__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_y 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___032873_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d))));
    vlSelf->wasmetal_core__DOT___027815_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x16U)))));
    vlSelf->wasmetal_core__DOT___053311_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b71__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 5U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b70__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_y 
                                                               >> 6U)))))));
    vlSelf->__VdfgTmp_h5736dc67__0 = ((2U & (vlSelf->insn_x 
                                             >> 6U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT___053310_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b93__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1dU)))));
    vlSelf->__VdfgTmp_hc49c7557__0 = (((IData)(vlSelf->cmd_valid) 
                                       << 1U) | (IData)(vlSelf->busy));
    vlSelf->__VdfgTmp_h13987860__0 = ((2U & (vlSelf->insn_x 
                                             >> 5U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->__VdfgTmp_haa7ff968__0 = ((2U & (vlSelf->insn_x 
                                             >> 4U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___032872_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d))));
    vlSelf->__VdfgTmp_h85ffa972__0 = ((2U & (vlSelf->insn_x 
                                             >> 3U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->__VdfgTmp_h83e5aafb__0 = ((2U & (vlSelf->insn_x 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->__VdfgTmp_hcb9fc16c__0 = ((2U & (vlSelf->insn_x 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___027814_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b21__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x15U)))));
    vlSelf->wasmetal_core__DOT___032871_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d))));
    vlSelf->__VdfgTmp_h8befad22__0 = ((2U & vlSelf->insn_x) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___032870_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d))));
    vlSelf->wasmetal_core__DOT___027813_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x14U)))));
    vlSelf->wasmetal_core__DOT___032869_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d))));
    vlSelf->wasmetal_core__DOT___032868_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d))));
    vlSelf->wasmetal_core__DOT___027811_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b19__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x13U)))));
    vlSelf->wasmetal_core__DOT___067565_ = (1U & (IData)(
                                                         (0x7f7f7fffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065565_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064973_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1cU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065559_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064091_)))))))));
    vlSelf->wasmetal_core__DOT___032867_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d))));
    vlSelf->wasmetal_core__DOT___067562_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067561_))));
    vlSelf->wasmetal_core__DOT___027810_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b18__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x12U)))));
    vlSelf->wasmetal_core__DOT___032897_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d))));
    vlSelf->wasmetal_core__DOT___032896_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d))));
    vlSelf->wasmetal_core__DOT___027809_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x11U)))));
    vlSelf->wasmetal_core__DOT___032895_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d))));
    vlSelf->wasmetal_core__DOT___026378_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1dU)))));
    vlSelf->wasmetal_core__DOT___032894_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d))));
    vlSelf->wasmetal_core__DOT___027808_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b16__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x10U)))));
    vlSelf->wasmetal_core__DOT___032893_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d))));
    vlSelf->wasmetal_core__DOT___027807_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xfU)))));
    vlSelf->wasmetal_core__DOT___032892_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d))));
    vlSelf->wasmetal_core__DOT___032891_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d))));
    vlSelf->wasmetal_core__DOT___064698_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    vlSelf->wasmetal_core__DOT___027806_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xeU)))));
    vlSelf->__VdfgTmp_h4b91004e__0 = (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                       << 1U) | (IData)(vlSelf->insn_valid));
    vlSelf->wasmetal_core__DOT___032888_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d))));
    vlSelf->wasmetal_core__DOT___065143_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064267_)))));
    vlSelf->wasmetal_core__DOT___065026_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064267_)))));
    vlSelf->wasmetal_core__DOT___064437_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064431_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___032877_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_y) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d))));
    vlSelf->wasmetal_core__DOT___027805_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b13__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xdU)))));
    vlSelf->wasmetal_core__DOT___064430_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064433_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___032866_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d))));
    vlSelf->wasmetal_core__DOT___064432_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064409_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064413_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064412_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064418_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064419_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064422_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064423_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064362_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___027804_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b12__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xcU)))));
    vlSelf->wasmetal_core__DOT___064351_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064366_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064367_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064372_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___036716_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1eU)) 
                                                   | (vlSelf->function_locals 
                                                      >> 0x1fU))));
    vlSelf->wasmetal_core__DOT___064373_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064376_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064377_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064384_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064385_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064388_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064347_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064389_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064394_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064346_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064395_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___027803_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xbU)))));
    vlSelf->wasmetal_core__DOT___064398_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064340_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064337_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064399_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064268_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064336_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064269_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[1U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064329_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064328_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064319_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064325_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064324_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064278_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064279_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064282_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064283_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064294_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064318_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064290_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064295_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064291_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064300_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064315_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064301_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064314_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064304_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064305_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___027802_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xaU)))));
    vlSelf->__VdfgTmp_h14e88ecb__0 = (((IData)(vlSelf->mem_ready) 
                                       << 1U) | (IData)(vlSelf->mem_fault));
    vlSelf->__VdfgTmp_hc52368c6__0 = ((2U & vlSelf->insn_x) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___027832_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 9U)))));
    vlSelf->wasmetal_core__DOT___026377_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1cU)))));
    vlSelf->wasmetal_core__DOT___027831_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 8U)))));
    vlSelf->wasmetal_core__DOT___027830_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 7U)))));
    vlSelf->wasmetal_core__DOT___027829_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 6U)))));
    vlSelf->__VdfgTmp_hd0f5eb35__0 = ((2U & (vlSelf->insn_x 
                                             >> 6U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 7U)));
    vlSelf->wasmetal_core__DOT___027828_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 5U)))));
    vlSelf->wasmetal_core__DOT___027827_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 4U)))));
    vlSelf->__VdfgTmp_hd6f0d46f__0 = ((2U & (vlSelf->insn_x 
                                             >> 4U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 5U)));
    vlSelf->wasmetal_core__DOT___064589_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064588_))));
    vlSelf->wasmetal_core__DOT___027826_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___064616_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064127_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064189_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064190_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064126_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___027823_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___064179_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064123_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064183_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064122_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064184_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064117_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064113_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064116_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064157_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064161_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064112_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064158_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064162_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064149_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064167_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064148_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064172_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064171_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064168_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064139_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064145_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064134_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064138_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064144_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___027812_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___064135_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___027801_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & vlSelf->function_params))));
    vlSelf->wasmetal_core__DOT___064544_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064543_))));
    vlSelf->wasmetal_core__DOT___064050_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064049_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064071_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064067_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064046_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064068_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064045_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->__VdfgTmp_hefae6eba__0 = ((2U & (vlSelf->insn_x 
                                             >> 1U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT___064057_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064040_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->__VdfgTmp_hec90fad7__0 = ((2U & (vlSelf->insn_x 
                                             >> 2U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 3U)));
    vlSelf->wasmetal_core__DOT___064039_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064058_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064061_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064036_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064035_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___064062_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064034_))));
    vlSelf->wasmetal_core__DOT___032698_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d))));
    vlSelf->wasmetal_core__DOT___032697_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d))));
    vlSelf->__VdfgTmp_ha0b2a3dd__0 = ((2U & (vlSelf->insn_z 
                                             >> 0x19U)) 
                                      | (1U & (vlSelf->insn_x 
                                               >> 0x1aU)));
    vlSelf->__VdfgTmp_h1ce9b3c5__0 = ((2U & (vlSelf->insn_z 
                                             >> 0x16U)) 
                                      | (1U & (vlSelf->insn_x 
                                               >> 0x17U)));
    vlSelf->wasmetal_core__DOT___026376_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1bU)))));
    vlSelf->wasmetal_core__DOT___064571_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064570_))));
    vlSelf->wasmetal_core__DOT___064225_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064234_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064233_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064220_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064229_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064230_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->wasmetal_core__DOT___064221_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064219_))));
    vlSelf->__VdfgTmp_hc3828814__0 = ((2U & (vlSelf->insn_x 
                                             << 1U)) 
                                      | (1U & vlSelf->insn_y));
    vlSelf->wasmetal_core__DOT___026375_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1aU)))));
    vlSelf->__VdfgTmp_hd3ff3db1__0 = ((2U & (vlSelf->insn_x 
                                             >> 5U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 6U)));
    vlSelf->__VdfgTmp_he98db662__0 = ((2U & (vlSelf->insn_x 
                                             >> 3U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 4U)));
    vlSelf->__VdfgTmp_h08c26bfc__0 = ((2U & (vlSelf->function_params 
                                             >> 0x1dU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x1eU)));
    vlSelf->wasmetal_core__DOT___026374_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x19U)))));
    vlSelf->wasmetal_core__DOT___032695_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d))));
    vlSelf->wasmetal_core__DOT___026373_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___061598_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x17U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 8U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x11U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___061602_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x18U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 9U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x12U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___061616_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x19U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 0xaU)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x13U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 4U))))))))));
    vlSelf->__VdfgTmp_h09206f3f__0 = ((2U & (vlSelf->function_params 
                                             >> 0x1cU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x1dU)));
    vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & vlSelf->insn_x)));
    vlSelf->wasmetal_core__DOT___026372_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x17U)))));
    vlSelf->wasmetal_core__DOT___026371_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x16U)))));
    vlSelf->wasmetal_core__DOT___032694_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d))));
    vlSelf->wasmetal_core__DOT___026370_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b21__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x15U)))));
    vlSelf->wasmetal_core__DOT___045819_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 3U)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 6U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4b9179fb__0))))));
    vlSelf->wasmetal_core__DOT___045818_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & vlSelf->insn_y) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 2U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 4U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hbe9a07d7__0)))))));
    vlSelf->wasmetal_core__DOT___045817_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc7b853f6__0)))))));
    vlSelf->wasmetal_core__DOT___045815_ = (1U & (0x7150U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_y 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h644f4591__0)))));
    vlSelf->wasmetal_core__DOT___045823_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xfU)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x12U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbb13730a__0))))));
    vlSelf->wasmetal_core__DOT___045822_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xcU)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0xfU)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4c89c552__0))))));
    vlSelf->wasmetal_core__DOT___045821_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 9U)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0xcU)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc87c06e6__0))))));
    vlSelf->wasmetal_core__DOT___045820_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 6U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 8U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xaU)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdd349d37__0)))))));
    vlSelf->wasmetal_core__DOT___045825_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x15U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x17U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x19U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h22be3b3b__0)))))));
    vlSelf->wasmetal_core__DOT___045824_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x12U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x14U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x16U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3948b92c__0)))))));
    vlSelf->wasmetal_core__DOT___045816_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x18U)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x1bU)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_had9a86ff__0)))))));
    vlSelf->__VdfgTmp_h946ed16f__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x1eU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->__VdfgTmp_h17df9f02__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x19U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000564_));
    vlSelf->__VdfgTmp_hd5d86514__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x16U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000498_));
    vlSelf->__VdfgTmp_hd7080d55__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x13U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000432_));
    vlSelf->__VdfgTmp_hfe93be6e__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x12U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000419_));
    vlSelf->__VdfgTmp_h8243d19d__0 = ((2U & (vlSelf->insn_y 
                                             >> 0xdU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->__VdfgTmp_he8f67c93__0 = ((2U & (vlSelf->insn_y 
                                             >> 0xaU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->__VdfgTmp_haf096c00__0 = ((2U & (vlSelf->insn_y 
                                             >> 9U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->__VdfgTmp_hfcd21fa2__0 = ((2U & (vlSelf->insn_y 
                                             >> 4U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->__VdfgTmp_h4104a354__0 = ((2U & (vlSelf->insn_y 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->__VdfgTmp_h521b28ea__0 = ((2U & (vlSelf->insn_y 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___026369_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x14U)))));
    vlSelf->wasmetal_core__DOT___026367_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x13U)))));
    vlSelf->wasmetal_core__DOT___044291_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 7U)) 
                                                   | (1U 
                                                      & (0xfffffffeU 
                                                         >> 
                                                         (0x1fU 
                                                          & (vlSelf->insn_y 
                                                             >> 9U)))))));
    vlSelf->wasmetal_core__DOT___026366_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b18__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x12U)))));
    vlSelf->wasmetal_core__DOT___032693_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d))));
    vlSelf->wasmetal_core__DOT___026365_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x11U)))));
    vlSelf->wasmetal_core__DOT___026364_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x10U)))));
    vlSelf->__VdfgTmp_hbc309d1b__0 = ((2U & (vlSelf->function_params 
                                             >> 0x1bU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x1cU)));
    vlSelf->wasmetal_core__DOT___026363_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xfU)))));
    vlSelf->wasmetal_core__DOT___032692_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d))));
    vlSelf->wasmetal_core__DOT___026362_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xeU)))));
    vlSelf->wasmetal_core__DOT___026361_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xdU)))));
    vlSelf->wasmetal_core__DOT___032691_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d))));
    vlSelf->wasmetal_core__DOT___026360_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b12__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xcU)))));
    vlSelf->__VdfgTmp_h4312483e__0 = ((2U & (vlSelf->function_params 
                                             >> 0x1aU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x1bU)));
    vlSelf->wasmetal_core__DOT___026359_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xbU)))));
    vlSelf->wasmetal_core__DOT___061588_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x15U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 6U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0xfU)) 
                                                                       | (1U 
                                                                          & vlSelf->insn_imm[3U])))))))));
    vlSelf->wasmetal_core__DOT___061592_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x16U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 7U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x10U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___026358_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xaU)))));
    vlSelf->wasmetal_core__DOT___032690_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d))));
    vlSelf->wasmetal_core__DOT___026388_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 9U)))));
    vlSelf->wasmetal_core__DOT___026387_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 8U)))));
    vlSelf->wasmetal_core__DOT___032689_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d))));
    vlSelf->wasmetal_core__DOT___026386_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 7U)))));
    vlSelf->wasmetal_core__DOT___026385_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 6U)))));
    vlSelf->wasmetal_core__DOT___026384_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 5U)))));
    vlSelf->__VdfgTmp_h4679be83__0 = ((2U & (vlSelf->function_params 
                                             >> 0x19U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x1aU)));
    vlSelf->wasmetal_core__DOT___026383_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 4U)))));
    vlSelf->wasmetal_core__DOT___032688_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d))));
    vlSelf->wasmetal_core__DOT___032687_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d))));
    vlSelf->__VdfgTmp_h137eceb9__0 = ((2U & (vlSelf->function_params 
                                             >> 0x18U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x19U)));
    vlSelf->wasmetal_core__DOT___032686_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d))));
    vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (3U & vlSelf->function_params)));
    vlSelf->wasmetal_core__DOT___032684_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d))));
    vlSelf->wasmetal_core__DOT___032683_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d))));
    vlSelf->__VdfgTmp_h590821b5__0 = ((2U & (vlSelf->function_params 
                                             >> 0x17U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x18U)));
    vlSelf->wasmetal_core__DOT___032682_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d))));
    vlSelf->wasmetal_core__DOT___032681_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d))));
    vlSelf->__VdfgTmp_h5a255a66__0 = ((2U & (vlSelf->function_params 
                                             >> 0x16U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x17U)));
    vlSelf->wasmetal_core__DOT___032680_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d))));
    vlSelf->__VdfgTmp_hbc3091a9__0 = ((2U & (vlSelf->function_params 
                                             >> 0x15U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x16U)));
    vlSelf->wasmetal_core__DOT___032679_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d))));
    vlSelf->wasmetal_core__DOT___032678_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d))));
    vlSelf->__VdfgTmp_h092cd911__0 = ((2U & (vlSelf->function_params 
                                             >> 0x14U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x15U)));
    vlSelf->wasmetal_core__DOT___032677_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d))));
    vlSelf->__VdfgTmp_h2d9d1f69__0 = ((2U & (vlSelf->function_params 
                                             << 1U)) 
                                      | (1U & vlSelf->function_locals));
    vlSelf->wasmetal_core__DOT___032676_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d))));
    vlSelf->__VdfgTmp_h0817f177__0 = ((2U & (vlSelf->function_params 
                                             >> 0x13U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x14U)));
    vlSelf->wasmetal_core__DOT___032675_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d))));
    vlSelf->wasmetal_core__DOT___032705_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d))));
    vlSelf->__VdfgTmp_h1274aae9__0 = ((2U & (vlSelf->function_params 
                                             >> 0x12U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x13U)));
    vlSelf->wasmetal_core__DOT___032704_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d))));
    vlSelf->wasmetal_core__DOT___032703_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d))));
    vlSelf->__VdfgTmp_h148285ae__0 = ((2U & (vlSelf->function_params 
                                             >> 0x11U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x12U)));
    vlSelf->wasmetal_core__DOT___032702_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d))));
    vlSelf->wasmetal_core__DOT___032701_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d))));
    vlSelf->__VdfgTmp_h0dd4dc97__0 = ((2U & (vlSelf->function_params 
                                             >> 0x10U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x11U)));
    vlSelf->wasmetal_core__DOT___032700_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d))));
    vlSelf->wasmetal_core__DOT___032699_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d))));
    vlSelf->__VdfgTmp_h5f5f5b59__0 = ((2U & (vlSelf->function_params 
                                             >> 0xfU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x10U)));
    vlSelf->wasmetal_core__DOT___032696_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d))));
    vlSelf->wasmetal_core__DOT___032685_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->function_params) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d))));
    vlSelf->wasmetal_core__DOT___032674_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d))));
    vlSelf->__VdfgTmp_h54e5e4c4__0 = ((2U & (vlSelf->function_params 
                                             >> 0xeU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xfU)));
    vlSelf->__VdfgTmp_h558b9029__0 = ((2U & (vlSelf->function_params 
                                             >> 0xdU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xeU)));
    vlSelf->wasmetal_core__DOT___026382_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 3U)))));
    vlSelf->__VdfgTmp_h629179e3__0 = ((2U & (vlSelf->function_params 
                                             >> 0xcU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xdU)));
    vlSelf->__VdfgTmp_h638a3747__0 = ((2U & (vlSelf->function_params 
                                             >> 0xbU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xcU)));
    vlSelf->__VdfgTmp_h68654253__0 = ((2U & (vlSelf->function_params 
                                             >> 0xaU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xbU)));
    vlSelf->__VdfgTmp_h6978beee__0 = ((2U & (vlSelf->function_params 
                                             >> 9U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xaU)));
    vlSelf->__VdfgTmp_h14007945__0 = ((2U & (vlSelf->function_params 
                                             >> 8U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 9U)));
    vlSelf->__VdfgTmp_h13ef8f89__0 = ((2U & (vlSelf->function_params 
                                             >> 7U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 8U)));
    vlSelf->__VdfgTmp_h0e12a4a2__0 = ((2U & (vlSelf->function_params 
                                             >> 6U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 7U)));
    vlSelf->__VdfgTmp_h0d1b5516__0 = ((2U & (vlSelf->function_params 
                                             >> 5U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 6U)));
    vlSelf->__VdfgTmp_h5afc8767__0 = ((2U & (vlSelf->function_params 
                                             >> 4U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 5U)));
    vlSelf->__VdfgTmp_h5b0f43f4__0 = ((2U & (vlSelf->function_params 
                                             >> 3U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 4U)));
    vlSelf->__VdfgTmp_h60140cd4__0 = ((2U & (vlSelf->function_params 
                                             >> 2U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 3U)));
    vlSelf->__VdfgTmp_h61cb7e30__0 = ((2U & (vlSelf->function_params 
                                             >> 1U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 2U)));
    vlSelf->__VdfgTmp_h2cd56cce__0 = ((2U & vlSelf->function_params) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___026379_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___026368_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h1a8ff62f__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xdU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xeU)));
    vlSelf->__VdfgTmp_h19a3d105__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xeU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xfU)));
    vlSelf->__VdfgTmp_h134dac5a__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xfU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x10U)));
    vlSelf->__VdfgTmp_h3c4e434c__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x11U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x12U)));
    vlSelf->__VdfgTmp_h3d708201__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x12U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x13U)));
    vlSelf->__VdfgTmp_h2660b6cc__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x13U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x14U)));
    vlSelf->__VdfgTmp_h273da3c5__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x14U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x15U)));
    vlSelf->__VdfgTmp_he4692376__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x17U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x18U)));
    vlSelf->__VdfgTmp_h3a2be217__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x19U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x1aU)));
    vlSelf->__VdfgTmp_h26a9e557__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1eU)) 
                                      | (vlSelf->insn_y 
                                         >> 0x1fU));
    vlSelf->__VdfgTmp_h16f85c0c__0 = ((2U & (vlSelf->insn_x 
                                             >> 9U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xaU)));
    vlSelf->__VdfgTmp_hedbed4ea__0 = ((2U & (vlSelf->insn_x 
                                             >> 7U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 8U)));
    vlSelf->__VdfgTmp_he08305af__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x15U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x16U)));
    vlSelf->__VdfgTmp_h272aca04__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1cU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x1dU)));
    vlSelf->__VdfgTmp_heb8306fa__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x18U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x19U)));
    vlSelf->__VdfgTmp_h265c757d__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1dU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x1eU)));
    vlSelf->__VdfgTmp_he580b887__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x16U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x17U)));
    vlSelf->__VdfgTmp_he366744c__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x10U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x11U)));
    vlSelf->__VdfgTmp_he16c95bc__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1aU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x1bU)));
    vlSelf->__VdfgTmp_he081d797__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1bU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x1cU)));
    vlSelf->__VdfgTmp_heb713746__0 = ((2U & (vlSelf->insn_x 
                                             >> 8U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 9U)));
    vlSelf->__VdfgTmp_h10bdd4bc__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xbU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xcU)));
    vlSelf->__VdfgTmp_h1fc2f2ef__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xcU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xdU)));
    vlSelf->__VdfgTmp_h1585cf87__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xaU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xbU)));
    vlSelf->__VdfgTmp_h94eb0193__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x12U)) 
                                      | (1U & (vlSelf->insn_x 
                                               >> 0x13U)));
    vlSelf->wasmetal_core__DOT___026357_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & vlSelf->insn_x))));
    vlSelf->wasmetal_core__DOT___054679_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 7U)) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 5U)))));
    vlSelf->wasmetal_core__DOT___043130_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & vlSelf->insn_op))));
    vlSelf->wasmetal_core__DOT___048500_ = (1U & (0x1000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x14U)))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> 
                                                           (7U 
                                                            & (vlSelf->insn_x 
                                                               >> 9U))) 
                                                          << 3U)) 
                                                      | ((6U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x11U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_x 
                                                               >> 8U)))))));
    vlSelf->wasmetal_core__DOT___048499_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_x 
                                                            >> 6U))) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (vlSelf->insn_x 
                                                         >> 4U)))));
    vlSelf->wasmetal_core__DOT___048426_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (1ULL 
                                                                        >> 
                                                                        (0x3fU 
                                                                         & (vlSelf->insn_y 
                                                                            >> 0xeU)))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_y 
                                                                            >> 0x1aU))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (1ULL 
                                                                              >> 
                                                                              (0x3fU 
                                                                               & (vlSelf->insn_y 
                                                                                >> 2U)))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (0x3fU 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x14U)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((4U 
                                                                              & (vlSelf->insn_y 
                                                                                >> 6U)) 
                                                                             | (3U 
                                                                                & vlSelf->insn_y))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfffffffeU 
                                                                             >> 
                                                                             (0x1fU 
                                                                              & (vlSelf->insn_y 
                                                                                >> 9U))))))))))));
    vlSelf->__VdfgTmp_h1a7964bb__0 = (((IData)(vlSelf->insn_valid) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d));
    vlSelf->wasmetal_core__DOT___070576_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 6U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (3U 
                                                          & (vlSelf->insn_op 
                                                             >> 8U)))))));
    vlSelf->wasmetal_core__DOT___042539_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (1ULL 
                                                                 >> 
                                                                 (vlSelf->insn_op 
                                                                  >> 0x1aU)))))));
    vlSelf->wasmetal_core__DOT___003042_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003043_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003044_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003045_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___042590_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xeU 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 0x18U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___048346_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (vlSelf->insn_op 
                                                         >> 4U)))));
    vlSelf->wasmetal_core__DOT___003014_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___000375_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | ((6U 
                                                       & (vlSelf->insn_op 
                                                          >> 5U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 4U))))));
    vlSelf->wasmetal_core__DOT___048302_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (7U 
                                                      & (vlSelf->insn_op 
                                                         >> 5U)))));
    vlSelf->__VdfgTmp_ha3f5bbbb__0 = ((2U & ((IData)(
                                                     (1ULL 
                                                      >> 
                                                      (vlSelf->insn_op 
                                                       >> 0x1aU))) 
                                             << 1U)) 
                                      | (1U & (0xeU 
                                               >> (3U 
                                                   & (vlSelf->insn_op 
                                                      >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___001241_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & vlSelf->insn_op) 
                                                      | ((2U 
                                                          & (vlSelf->insn_op 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___002988_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 4U)) 
                                                      | ((2U 
                                                          & (vlSelf->insn_op 
                                                             >> 6U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 4U)))))));
    vlSelf->wasmetal_core__DOT___000366_ = (1U & (0x100U 
                                                  >> 
                                                  ((0xcU 
                                                    & (vlSelf->insn_op 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (vlSelf->insn_op 
                                                         >> 2U)))));
    vlSelf->__VdfgTmp_h682c3842__0 = ((8U & (vlSelf->insn_op 
                                             >> 4U)) 
                                      | ((4U & (vlSelf->insn_op 
                                                >> 2U)) 
                                         | (3U & (vlSelf->insn_op 
                                                  >> 5U))));
    vlSelf->wasmetal_core__DOT___002994_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 4U)) 
                                                      | ((2U 
                                                          & (vlSelf->insn_op 
                                                             >> 3U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 7U)))))));
    vlSelf->wasmetal_core__DOT___001231_ = (1U & (IData)(
                                                         ((0x10U 
                                                           == 
                                                           (0x11U 
                                                            & vlSelf->insn_op)) 
                                                          & (1ULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  << 4U)) 
                                                              | ((0x1cU 
                                                                  & (vlSelf->insn_op 
                                                                     >> 3U)) 
                                                                 | (3U 
                                                                    & (vlSelf->insn_op 
                                                                       >> 2U))))))));
    vlSelf->__VdfgTmp_h97facc1b__0 = ((0xcU & (vlSelf->insn_op 
                                               << 1U)) 
                                      | ((2U & (vlSelf->insn_op 
                                                >> 2U)) 
                                         | (1U & vlSelf->insn_op)));
    vlSelf->wasmetal_core__DOT___047786_ = (1U & (0x1000U 
                                                  >> 
                                                  ((0xeU 
                                                    & (vlSelf->insn_op 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___047783_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & vlSelf->insn_op) 
                                                   | ((6U 
                                                       & (vlSelf->insn_op 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___001240_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       << 1U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & vlSelf->insn_op) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 3U)))))));
    vlSelf->__VdfgTmp_h3fee6eff__0 = ((8U & (vlSelf->insn_op 
                                             << 3U)) 
                                      | ((6U & vlSelf->insn_op) 
                                         | (1U & (vlSelf->insn_op 
                                                  >> 3U))));
    vlSelf->__VdfgTmp_h20102633__0 = ((2U & vlSelf->insn_op) 
                                      | (1U & (vlSelf->insn_op 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT___044249_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (0xfU 
                                                         & (vlSelf->insn_x 
                                                            >> 0xfU))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (vlSelf->insn_x 
                                                          >> 0x12U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xeU))))));
    vlSelf->wasmetal_core__DOT___044243_ = (1U & (0xefU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (7U 
                                                         & (vlSelf->insn_x 
                                                            >> 9U))) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xcU)))));
    vlSelf->wasmetal_core__DOT___135386___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (vlSelf->insn_op >> 1U)) | (4U 
                                                >> 
                                                (3U 
                                                 & vlSelf->insn_op))));
    vlSelf->__VdfgTmp_h3fefcec1__0 = ((8U & (vlSelf->insn_op 
                                             << 3U)) 
                                      | ((4U & (vlSelf->insn_op 
                                                << 1U)) 
                                         | (3U & (vlSelf->insn_op 
                                                  >> 2U))));
    vlSelf->__VdfgTmp_h8e88a732__0 = ((0x20U & (vlSelf->insn_op 
                                                >> 9U)) 
                                      | ((0x10U & (vlSelf->insn_op 
                                                   >> 0xbU)) 
                                         | ((8U & (vlSelf->insn_op 
                                                   >> 6U)) 
                                            | ((4U 
                                                & (vlSelf->insn_op 
                                                   >> 8U)) 
                                               | ((2U 
                                                   & (vlSelf->insn_op 
                                                      >> 0xaU)) 
                                                  | (1U 
                                                     & (vlSelf->insn_op 
                                                        >> 8U)))))));
    vlSelf->wasmetal_core__DOT___000371_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & (vlSelf->insn_op 
                                                       >> 0xeU)) 
                                                   | (3U 
                                                      & (vlSelf->insn_op 
                                                         >> 0x12U)))));
    vlSelf->__VdfgTmp_h2780d718__0 = ((2U & (vlSelf->insn_op 
                                             << 1U)) 
                                      | (1U & (vlSelf->insn_op 
                                               >> 1U)));
    vlSelf->__VdfgTmp_h7a4c1007__0 = ((2U & (vlSelf->insn_op 
                                             >> 1U)) 
                                      | (1U & (vlSelf->insn_op 
                                               >> 3U)));
    vlSelf->__VdfgTmp_h3ca161df__0 = ((2U & (vlSelf->insn_op 
                                             >> 3U)) 
                                      | (1U & (vlSelf->insn_op 
                                               >> 5U)));
    vlSelf->wasmetal_core__DOT___000378_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 3U)) 
                                                      | (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT___045705_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 0x12U))) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (vlSelf->insn_op 
                                                         >> 0x10U)))));
}
