#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__47(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__47\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___019013_;
    wasmetal_core__DOT___019013_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022998_;
    wasmetal_core__DOT___022998_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023003_;
    wasmetal_core__DOT___023003_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023007_;
    wasmetal_core__DOT___023007_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023081_;
    wasmetal_core__DOT___023081_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023085_;
    wasmetal_core__DOT___023085_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023090_;
    wasmetal_core__DOT___023090_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023268_;
    wasmetal_core__DOT___023268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023272_;
    wasmetal_core__DOT___023272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023276_;
    wasmetal_core__DOT___023276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023285_;
    wasmetal_core__DOT___023285_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023290_;
    wasmetal_core__DOT___023290_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023294_;
    wasmetal_core__DOT___023294_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024137_;
    wasmetal_core__DOT___024137_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024141_;
    wasmetal_core__DOT___024141_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024145_;
    wasmetal_core__DOT___024145_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024154_;
    wasmetal_core__DOT___024154_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024159_;
    wasmetal_core__DOT___024159_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024268_;
    wasmetal_core__DOT___024268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024272_;
    wasmetal_core__DOT___024272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024276_;
    wasmetal_core__DOT___024276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024285_;
    wasmetal_core__DOT___024285_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024290_;
    wasmetal_core__DOT___024290_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024403_;
    wasmetal_core__DOT___024403_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024407_;
    wasmetal_core__DOT___024407_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024411_;
    wasmetal_core__DOT___024411_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024420_;
    wasmetal_core__DOT___024420_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024425_;
    wasmetal_core__DOT___024425_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024569_;
    wasmetal_core__DOT___024569_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024573_;
    wasmetal_core__DOT___024573_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024577_;
    wasmetal_core__DOT___024577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024586_;
    wasmetal_core__DOT___024586_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024591_;
    wasmetal_core__DOT___024591_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024824_;
    wasmetal_core__DOT___024824_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024828_;
    wasmetal_core__DOT___024828_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024837_;
    wasmetal_core__DOT___024837_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024841_;
    wasmetal_core__DOT___024841_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024884_;
    wasmetal_core__DOT___024884_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035284_;
    wasmetal_core__DOT___035284_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035288_;
    wasmetal_core__DOT___035288_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035297_;
    wasmetal_core__DOT___035297_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035301_;
    wasmetal_core__DOT___035301_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035306_;
    wasmetal_core__DOT___035306_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035336_;
    wasmetal_core__DOT___035336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035455_;
    wasmetal_core__DOT___035455_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035459_;
    wasmetal_core__DOT___035459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035463_;
    wasmetal_core__DOT___035463_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035472_;
    wasmetal_core__DOT___035472_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035477_;
    wasmetal_core__DOT___035477_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035571_;
    wasmetal_core__DOT___035571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035575_;
    wasmetal_core__DOT___035575_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035580_;
    wasmetal_core__DOT___035580_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035589_;
    wasmetal_core__DOT___035589_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035593_;
    wasmetal_core__DOT___035593_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035927_;
    wasmetal_core__DOT___035927_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035931_;
    wasmetal_core__DOT___035931_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035935_;
    wasmetal_core__DOT___035935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035940_;
    wasmetal_core__DOT___035940_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035944_;
    wasmetal_core__DOT___035944_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035949_;
    wasmetal_core__DOT___035949_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035953_;
    wasmetal_core__DOT___035953_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036333_;
    wasmetal_core__DOT___036333_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036338_;
    wasmetal_core__DOT___036338_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036360_;
    wasmetal_core__DOT___036360_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036370_;
    wasmetal_core__DOT___036370_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036373_;
    wasmetal_core__DOT___036373_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036374_;
    wasmetal_core__DOT___036374_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036512_;
    wasmetal_core__DOT___036512_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036516_;
    wasmetal_core__DOT___036516_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036520_;
    wasmetal_core__DOT___036520_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___038802_;
    wasmetal_core__DOT___038802_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___042814_;
    wasmetal_core__DOT___042814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043028_;
    wasmetal_core__DOT___043028_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043031_;
    wasmetal_core__DOT___043031_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043032_;
    wasmetal_core__DOT___043032_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051536_;
    wasmetal_core__DOT___051536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053557_;
    wasmetal_core__DOT___053557_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056260_;
    wasmetal_core__DOT___056260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056261_;
    wasmetal_core__DOT___056261_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056907_;
    wasmetal_core__DOT___056907_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ecommon_totalUnderflow;
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ecommon_totalUnderflow = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry;
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d;
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127499___O;
    wasmetal_core__DOT____Vcellout___127499___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127500___O;
    wasmetal_core__DOT____Vcellout___127500___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127520___O;
    wasmetal_core__DOT____Vcellout___127520___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127521___O;
    wasmetal_core__DOT____Vcellout___127521___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127532___O;
    wasmetal_core__DOT____Vcellout___127532___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127534___O;
    wasmetal_core__DOT____Vcellout___127534___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128736___O;
    wasmetal_core__DOT____Vcellout___128736___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128738___O;
    wasmetal_core__DOT____Vcellout___128738___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128739___O;
    wasmetal_core__DOT____Vcellout___128739___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128854___O;
    wasmetal_core__DOT____Vcellout___128854___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128857___O;
    wasmetal_core__DOT____Vcellout___128857___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128858___O;
    wasmetal_core__DOT____Vcellout___128858___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128875___O;
    wasmetal_core__DOT____Vcellout___128875___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127504___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127504___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127504___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127504___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127504___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127504___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127505___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127505___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127505___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127505___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127505___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127505___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127517___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127517___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127517___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127517___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127518___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127518___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127518___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127518___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127518___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127518___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127522___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127522___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127522___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127522___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127522___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127522___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127523___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127523___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127523___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127523___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127523___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127523___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127524___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127524___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127524___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127524___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127524___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127524___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127649___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127649___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127649___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127649___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127650___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127650___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127650___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127650___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127650___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127650___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127651___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127651___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127651___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127651___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127651___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127651___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127666___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127666___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127666___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127666___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127667___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127667___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127667___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127667___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127667___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127667___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127668___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127668___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127668___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127668___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127668___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127668___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127682___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127682___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127682___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127682___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127683___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127683___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127683___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127683___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127683___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127683___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127684___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127684___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127684___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127684___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127684___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127684___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127715___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127715___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127715___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127715___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127716___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127716___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127716___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127716___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127716___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127716___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127717___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127717___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127717___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127717___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127717___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127717___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127727___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127727___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127727___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127727___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127727___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127727___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127728___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127728___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127728___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127728___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127728___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127728___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127729___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127729___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127729___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127729___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127729___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127729___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127730___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127730___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127730___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127730___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127730___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127730___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127731___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127731___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127731___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127731___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127732___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127732___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127732___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127732___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127732___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127732___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127733___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127733___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127733___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127733___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127733___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127733___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128738___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128738___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128739___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128739___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128739___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128739___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128739___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128739___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128740___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128740___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128740___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128740___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128740___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128740___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128741___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128741___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128741___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128741___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128741___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128741___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128753___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128753___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128753___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128753___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128754___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128754___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128754___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128754___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128754___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128754___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128755___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128755___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128755___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128755___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128755___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128755___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128768___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128768___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128768___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128768___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128768___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128768___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128769___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128769___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128769___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128769___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128769___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128769___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128770___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128770___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128770___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128770___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128770___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128770___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128796___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128796___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128796___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128796___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128796___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128796___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128797___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128797___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128797___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128797___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128797___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128797___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128798___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128798___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128798___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128798___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128798___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128798___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128799___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128799___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128799___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128799___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128799___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128799___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128807___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128807___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128807___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128807___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128807___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128807___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128808___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128808___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128808___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128808___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128808___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128808___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128809___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128809___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128809___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128809___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128809___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128809___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128856___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128856___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128856___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128856___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128857___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128857___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128857___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128857___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128857___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128857___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128858___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128858___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128858___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128858___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134162___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134162___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hb9cb0b08__0;
    __VdfgTmp_hb9cb0b08__0 = 0;
    CData/*3:0*/ __VdfgTmp_hf524d067__0;
    __VdfgTmp_hf524d067__0 = 0;
    CData/*2:0*/ __VdfgTmp_h15797db8__0;
    __VdfgTmp_h15797db8__0 = 0;
    CData/*5:0*/ __VdfgTmp_hff06bcdd__0;
    __VdfgTmp_hff06bcdd__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4bfbe6f9__0;
    __VdfgTmp_h4bfbe6f9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0968f04c__0;
    __VdfgTmp_h0968f04c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0c3747f4__0;
    __VdfgTmp_h0c3747f4__0 = 0;
    CData/*1:0*/ __VdfgTmp_hffea5a13__0;
    __VdfgTmp_hffea5a13__0 = 0;
    CData/*1:0*/ __VdfgTmp_h01dc1976__0;
    __VdfgTmp_h01dc1976__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb1f3bce1__0;
    __VdfgTmp_hb1f3bce1__0 = 0;
    // Body
    if (vlSelf->wasmetal_core__DOT___043258_) {
        if (vlSelf->wasmetal_core__DOT___043257_) {
            if (vlSelf->wasmetal_core__DOT___043256_) {
                if (vlSelf->wasmetal_core__DOT___043255_) {
                    if (vlSelf->wasmetal_core__DOT___043254_) {
                        if (vlSelf->wasmetal_core__DOT___010061_) {
                            if (vlSelf->wasmetal_core__DOT___010063_) {
                                if (vlSelf->wasmetal_core__DOT___043253_) {
                                    if (vlSelf->wasmetal_core__DOT___043252_) {
                                        if (vlSelf->wasmetal_core__DOT___043251_) {
                                            if (vlSelf->wasmetal_core__DOT___043250_) {
                                                if (
                                                    (1U 
                                                     & (0x80U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2237a749__0)))) {
                                                    if (vlSelf->wasmetal_core__DOT___043264_) {
                                                        if (vlSelf->wasmetal_core__DOT___043263_) {
                                                            if (vlSelf->wasmetal_core__DOT___043262_) {
                                                                if (vlSelf->wasmetal_core__DOT___043261_) {
                                                                    if (vlSelf->wasmetal_core__DOT___043260_) {
                                                                        if (vlSelf->wasmetal_core__DOT___043259_) {
                                                                            wasmetal_core__DOT___038802_ 
                                                                                = vlSelf->wasmetal_core__DOT___043599_;
                                                                            vlSelf->wasmetal_core__DOT___011068_ 
                                                                                = vlSelf->wasmetal_core__DOT___043690_;
                                                                        } else {
                                                                            wasmetal_core__DOT___038802_ 
                                                                                = vlSelf->wasmetal_core__DOT___043663_;
                                                                            vlSelf->wasmetal_core__DOT___011068_ 
                                                                                = vlSelf->wasmetal_core__DOT___043663_;
                                                                        }
                                                                    } else {
                                                                        wasmetal_core__DOT___038802_ 
                                                                            = vlSelf->wasmetal_core__DOT___043664_;
                                                                        vlSelf->wasmetal_core__DOT___011068_ 
                                                                            = vlSelf->wasmetal_core__DOT___043664_;
                                                                    }
                                                                } else {
                                                                    wasmetal_core__DOT___038802_ 
                                                                        = vlSelf->wasmetal_core__DOT___043665_;
                                                                    vlSelf->wasmetal_core__DOT___011068_ 
                                                                        = vlSelf->wasmetal_core__DOT___043665_;
                                                                }
                                                            } else {
                                                                wasmetal_core__DOT___038802_ 
                                                                    = vlSelf->wasmetal_core__DOT___043666_;
                                                                vlSelf->wasmetal_core__DOT___011068_ 
                                                                    = vlSelf->wasmetal_core__DOT___043666_;
                                                            }
                                                        } else {
                                                            wasmetal_core__DOT___038802_ 
                                                                = vlSelf->wasmetal_core__DOT___043667_;
                                                            vlSelf->wasmetal_core__DOT___011068_ 
                                                                = vlSelf->wasmetal_core__DOT___043667_;
                                                        }
                                                    } else {
                                                        wasmetal_core__DOT___038802_ 
                                                            = vlSelf->wasmetal_core__DOT___043668_;
                                                        vlSelf->wasmetal_core__DOT___011068_ 
                                                            = vlSelf->wasmetal_core__DOT___043668_;
                                                    }
                                                } else {
                                                    wasmetal_core__DOT___038802_ 
                                                        = vlSelf->wasmetal_core__DOT___043651_;
                                                    vlSelf->wasmetal_core__DOT___011068_ 
                                                        = vlSelf->wasmetal_core__DOT___043651_;
                                                }
                                            } else {
                                                wasmetal_core__DOT___038802_ 
                                                    = vlSelf->wasmetal_core__DOT___043652_;
                                                vlSelf->wasmetal_core__DOT___011068_ 
                                                    = vlSelf->wasmetal_core__DOT___043652_;
                                            }
                                        } else {
                                            wasmetal_core__DOT___038802_ 
                                                = vlSelf->wasmetal_core__DOT___043653_;
                                            vlSelf->wasmetal_core__DOT___011068_ 
                                                = vlSelf->wasmetal_core__DOT___043653_;
                                        }
                                    } else {
                                        wasmetal_core__DOT___038802_ 
                                            = vlSelf->wasmetal_core__DOT___043654_;
                                        vlSelf->wasmetal_core__DOT___011068_ 
                                            = vlSelf->wasmetal_core__DOT___043654_;
                                    }
                                } else {
                                    wasmetal_core__DOT___038802_ 
                                        = vlSelf->wasmetal_core__DOT___043655_;
                                    vlSelf->wasmetal_core__DOT___011068_ 
                                        = vlSelf->wasmetal_core__DOT___043655_;
                                }
                            } else {
                                wasmetal_core__DOT___038802_ 
                                    = vlSelf->wasmetal_core__DOT___043656_;
                                vlSelf->wasmetal_core__DOT___011068_ 
                                    = vlSelf->wasmetal_core__DOT___043656_;
                            }
                        } else {
                            wasmetal_core__DOT___038802_ 
                                = vlSelf->wasmetal_core__DOT___043657_;
                            vlSelf->wasmetal_core__DOT___011068_ 
                                = vlSelf->wasmetal_core__DOT___043657_;
                        }
                    } else {
                        wasmetal_core__DOT___038802_ 
                            = vlSelf->wasmetal_core__DOT___043658_;
                        vlSelf->wasmetal_core__DOT___011068_ 
                            = vlSelf->wasmetal_core__DOT___043658_;
                    }
                } else {
                    wasmetal_core__DOT___038802_ = vlSelf->wasmetal_core__DOT___043659_;
                    vlSelf->wasmetal_core__DOT___011068_ 
                        = vlSelf->wasmetal_core__DOT___043659_;
                }
            } else {
                wasmetal_core__DOT___038802_ = vlSelf->wasmetal_core__DOT___043660_;
                vlSelf->wasmetal_core__DOT___011068_ 
                    = vlSelf->wasmetal_core__DOT___043660_;
            }
        } else {
            wasmetal_core__DOT___038802_ = vlSelf->wasmetal_core__DOT___043661_;
            vlSelf->wasmetal_core__DOT___011068_ = vlSelf->wasmetal_core__DOT___043661_;
        }
    } else {
        wasmetal_core__DOT___038802_ = vlSelf->wasmetal_core__DOT___043662_;
        vlSelf->wasmetal_core__DOT___011068_ = vlSelf->wasmetal_core__DOT___043662_;
    }
    vlSelf->wasmetal_core__DOT___057349_ = (1U & (IData)(
                                                         (0xee22fa0a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055826_)))))))));
    vlSelf->wasmetal_core__DOT___057332_ = (1U & (0x1d1d0f55U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056187_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009726_)))))));
    vlSelf->wasmetal_core__DOT___057143_ = (1U & (IData)(
                                                         (0xee22fa0a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056195_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056237_)))))))));
    vlSelf->wasmetal_core__DOT___056996_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                   ? 
                                                  (0x77747777U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009866_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009867_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d))))))
                                                   : 
                                                  (0x77747777U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009866_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009867_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d))))))));
    vlSelf->wasmetal_core__DOT___056318_ = (1U & (IData)(
                                                         (0xee22fa0a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056104_)))))))));
    vlSelf->wasmetal_core__DOT___056488_ = (1U & (IData)(
                                                         (0xee22fa0a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056228_)))))))));
    vlSelf->wasmetal_core__DOT___057569_ = (1U & (IData)(
                                                         (0xee22fa0a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010651_)))))))));
    vlSelf->wasmetal_core__DOT___043846_ = (1U & (0x1001U 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                       << 2U) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                            >> 1U))))));
    vlSelf->__VdfgTmp_ha95c81f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                    >> 3U)));
    if (vlSelf->wasmetal_core__DOT___010024_) {
        wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024197_;
        wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d;
    } else {
        wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d;
        wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024328_;
    }
    if (vlSelf->wasmetal_core__DOT___024258_) {
        wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024197_;
        wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d;
    } else {
        wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d;
        wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024328_;
    }
    vlSelf->wasmetal_core__DOT___057404_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134165___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___043780_ = (1U & (0x1001U 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                       << 2U) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                            >> 1U))))));
    vlSelf->__VdfgTmp_hb920cb05__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                    >> 3U)));
    wasmetal_core__DOT___127727___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024855_));
    wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023203_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b49__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128873___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___042821_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128806___O) 
                                                               << 3U)) 
                                                           | (7U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128805___O) 
                                                                 >> 1U))))));
    wasmetal_core__DOT___128807___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035979_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035922_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b28__05d));
    vlSelf->wasmetal_core__DOT___059717_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hc406f1dc__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hc406f1dc__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058450_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058449_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059769_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h0017edb5__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h0017edb5__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058454_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O)) 
                                                                                | ((2U 
                                                                                & ((0x11000fU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hecea8d31__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059744_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                  ? 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc4afcee8__0))))
                                                                  : 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc4afcee8__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058452_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058451_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_)))))))))))))))))))))));
    wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127499___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_haf20b36b__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036329_));
    wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035388_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0))));
    wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128749___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035623_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035567_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b13__05d));
    vlSelf->wasmetal_core__DOT___009692_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff33330f0f5555ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___038801_) 
                                                                         << 3U) 
                                                                        | (((IData)(wasmetal_core__DOT___038802_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___038803_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___038804_))))))))))));
    vlSelf->wasmetal_core__DOT___057517_ = (1U & (IData)(
                                                         (0xee220000fa0aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056129_)))))))));
    vlSelf->wasmetal_core__DOT___057308_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056238_)))))))));
    vlSelf->wasmetal_core__DOT___057263_ = (1U & (IData)(
                                                         (0xee220000fa0aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2275929a__0)))))))))));
    vlSelf->wasmetal_core__DOT___057187_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010068_)))))))));
    vlSelf->wasmetal_core__DOT___057109_ = (1U & (IData)(
                                                         (0xee220000fa0aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056121_)))))))));
    vlSelf->wasmetal_core__DOT___056957_ = (1U & (0xee22fa0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055964_)))))));
    __VdfgTmp_h15797db8__0 = ((4U & ((7U >> (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                              << 2U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))) 
                                     << 2U)) | ((2U 
                                                 & ((0x70U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011246_)))) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_)));
    vlSelf->wasmetal_core__DOT___056812_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055954_)))))))));
    vlSelf->wasmetal_core__DOT___056675_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056243_)))))))));
    vlSelf->wasmetal_core__DOT___056399_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056242_)))))))));
    vlSelf->wasmetal_core__DOT___057589_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056239_)))))))));
    wasmetal_core__DOT___056260_ = (1U & (IData)((0xff00ccccf0f0aaaaULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___011171_)))))))));
    vlSelf->__VdfgTmp_h786db0b3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011068_));
    if (vlSelf->wasmetal_core__DOT___010025_) {
        wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d;
    } else {
        wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d;
        wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024259_) {
        wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d;
    } else {
        wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d;
        wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127727___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127532___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023204_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023203_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023201_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023200_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023263_)))));
    wasmetal_core__DOT___023268_ = ((IData)(vlSelf->wasmetal_core__DOT___023204_) 
                                    & (IData)(wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b50__05d) 
           & (IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128807___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035980_)
            ? (IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b29__05d));
    wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
           & (IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h25476d0e__0)) 
           & (IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128734___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035389_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035388_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035387_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035380_)))) 
           ^ (((IData)(wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035315_)))));
    wasmetal_core__DOT___035336_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035389_)
                                           ? (IData)(wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0))));
    wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035624_)
            ? (IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b14__05d));
    vlSelf->wasmetal_core__DOT___011074_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009692_))));
    vlSelf->wasmetal_core__DOT___056991_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009866_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (0x54U 
                                                    >> (IData)(__VdfgTmp_h15797db8__0))
                                                    : (IData)(
                                                              (0x5454545454445000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___009867_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                       << 3U) 
                                                                      | (IData)(__VdfgTmp_h15797db8__0)))))))
                                                   : 
                                                  (0x54U 
                                                   >> (IData)(__VdfgTmp_h15797db8__0))));
    vlSelf->wasmetal_core__DOT___056272_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___056260_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010077_))));
    wasmetal_core__DOT___056261_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___056260_))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hef18707b__0)))) {
        wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d;
    } else {
        wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d;
        wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024201_) {
        wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d;
    } else {
        wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d;
        wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127727___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005914_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_he6ade5b0__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he6ade5b0__0)))))));
    vlSelf->wasmetal_core__DOT___005848_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1ea78a97__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h098b01ee__0)))));
    vlSelf->wasmetal_core__DOT___005776_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_he6a1153d__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he6a1153d__0)))))));
    vlSelf->wasmetal_core__DOT___005777_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_he5c4f457__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_he5c4f457__0)))))));
    wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023205_) 
           & (IData)(wasmetal_core__DOT___023268_));
    vlSelf->wasmetal_core__DOT____Vcellout___128873___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b51__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b50__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b49__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b48__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128873___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036507_)))));
    wasmetal_core__DOT___036512_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b51__05d) 
                                    & (IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128807___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035982_)
            ? (IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b30__05d));
    wasmetal_core__DOT____Vcellout___127499___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf599dae9__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127499___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022994_)))));
    wasmetal_core__DOT___022998_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
                                    & (IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h917221d1__0)) 
           & (IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h96193a8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                                >> 3U)))))));
    __VdfgTmp_hff06bcdd__0 = (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                               << 5U) | ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                   << 3U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                        >> 2U)))))));
    vlSelf->__VdfgTmp_he5c2d914__0 = (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                     << 4U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h91abfcdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035390_)
            ? (IData)(wasmetal_core__DOT___035336_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128749___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128749___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035505_)))));
    wasmetal_core__DOT___035455_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035625_)
            ? (IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b15__05d));
    vlSelf->wasmetal_core__DOT___012207_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056272_))));
    vlSelf->__VdfgTmp_hf38792bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___056272_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h54798c59__0));
    vlSelf->wasmetal_core__DOT___012497_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___056261_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009691_)))));
    vlSelf->wasmetal_core__DOT___012018_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___056261_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127678___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024466_) 
             << 3U) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_hef18707b__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___010025_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010024_)))) 
           ^ (((IData)(wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024197_)))));
    if (vlSelf->wasmetal_core__DOT___024466_) {
        wasmetal_core__DOT___024403_ = wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024569_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d;
    } else {
        wasmetal_core__DOT___024403_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d;
        wasmetal_core__DOT___024569_ = wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127645___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024202_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024201_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___024259_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024258_)))) 
           ^ (((IData)(wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024197_)))));
    if (vlSelf->wasmetal_core__DOT___024202_) {
        wasmetal_core__DOT___024137_ = wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024268_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d;
    } else {
        wasmetal_core__DOT___024137_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d;
        wasmetal_core__DOT___024268_ = wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127727___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
           ^ (((IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024855_)))));
    wasmetal_core__DOT___024884_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127662___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024202_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024201_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024259_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024258_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024328_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127695___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024466_)) 
                   << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_hef18707b__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___010025_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___010024_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024328_)))));
    vlSelf->wasmetal_core__DOT___048265_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006039_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006038_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005781_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005780_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005914_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006037_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006036_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006035_)))))))))));
    vlSelf->wasmetal_core__DOT___006121_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005848_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006010_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___023189_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127529___O) 
                                                                  >> 2U))))))));
    __VdfgTmp_hf524d067__0 = (((IData)(vlSelf->wasmetal_core__DOT___005779_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005778_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___005777_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005776_))));
    wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023206_) 
           & (IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___060449_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128873___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1bc2f6b9__0))))))));
    wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b52__05d) 
           & (IData)(wasmetal_core__DOT___036512_));
    vlSelf->wasmetal_core__DOT____Vcellout___128807___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035983_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035982_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035980_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035979_)))) 
           ^ (((IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035922_)))));
    wasmetal_core__DOT___035927_ = ((IData)(vlSelf->wasmetal_core__DOT___035983_)
                                     ? (IData)(wasmetal_core__DOT___128807___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b31__05d));
    vlSelf->__VdfgTmp_h312e1166__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___059910_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00aaaafc0cfc0cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xfef00000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058307_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf5238d18__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                                                >> 3U))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f33aa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf552ae6e__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f000033aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf552ae6e__0))))))))))))));
    vlSelf->wasmetal_core__DOT___059849_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00aaaafc0cfc0cULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016441_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                                                >> 1U))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058461_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O) 
                                                                                >> 1U))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059882_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00aaaafc0cfc0cULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heb95d931__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                                                >> 2U))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058465_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O) 
                                                                                >> 2U))))))))))))))))))))));
    wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)) 
           & (IData)(wasmetal_core__DOT___022998_));
    vlSelf->wasmetal_core__DOT____Vcellout___128852___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_hafd7ea26__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_h917221d1__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h25476d0e__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_haf20b36b__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036329_)))));
    wasmetal_core__DOT___036333_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hafd7ea26__0)) 
                                    & (IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___014970_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                    ? (IData)(
                                                              (0xaaaaaaaa0f8b0088ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0)))
                                                    : (IData)(
                                                              (0xf0f0000aa2eaa22ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                    ? (IData)(
                                                              (0xf0f0000aa2eaa22ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0)))
                                                    : (IData)(
                                                              (0xaaaaaaaa0f8b0088ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0))))));
    wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035391_)
            ? (IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b6__05d));
    wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035455_));
    vlSelf->wasmetal_core__DOT____Vcellout___128764___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035626_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035625_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035624_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035623_)))) 
           ^ (((IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035567_)))));
    wasmetal_core__DOT___035571_ = ((IData)(vlSelf->wasmetal_core__DOT___035626_)
                                     ? (IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b16__05d));
    vlSelf->wasmetal_core__DOT___056739_ = (1U & (IData)(
                                                         (0x3333bffb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012207_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056736_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4b49f700__0))))));
    vlSelf->wasmetal_core__DOT___011075_ = (1U & (IData)(
                                                         (0x3333bffb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012207_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056483_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4b49f700__0))))));
    vlSelf->wasmetal_core__DOT___057318_ = (1U & (IData)(
                                                         (0x7f77777f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___012559_))
                                                                                 : (IData)(vlSelf->wasmetal_core__DOT___012567_))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057286_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha0e20209__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057288_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xf0fdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012576_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h186e290b__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> 
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? 
                                                                                (0xf0fff11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012582_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012581_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcdbca8e0__0)))))
                                                                                 : 
                                                                                (0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012580_)))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))));
    vlSelf->wasmetal_core__DOT___057153_ = (1U & (IData)(
                                                         (0x7f77777f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xfafcU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8267970c__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> 
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? 
                                                                                (0xf0f3355U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012395_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h224cdee6__0)))))
                                                                                 : 
                                                                                (0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012394_))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xf0fdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012407_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h745845c2__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> 
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? 
                                                                                (0xf0fff11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012413_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012412_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c3586c1__0)))))
                                                                                 : 
                                                                                (0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012411_)))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))));
    vlSelf->wasmetal_core__DOT___011737_ = (1U & (IData)(
                                                         (0xdfdddddf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xd00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xf0fdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011550_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc7461e30__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> 
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? 
                                                                                (0xf0fff11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011576_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011749_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011574_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011102_))))))
                                                                                 : 
                                                                                (0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011748_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f3f0f500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6248a2d__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O)) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fff7ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011753_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011752_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011461_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011103_)))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))));
    vlSelf->wasmetal_core__DOT___010908_ = (1U & (IData)(
                                                         (0xefeeeeef00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00fff400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056464_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb4b0ef5__0)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056272_)))))))));
    wasmetal_core__DOT___056907_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012018_))));
    vlSelf->wasmetal_core__DOT___013031_ = (1U & (IData)(
                                                         (0x7f77777f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((~ 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___010376_)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011101_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___013040_))
                                                                                 : (IData)(
                                                                                (0xfff0fffefff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013041_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013040_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057572_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013038_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011102_))))))))))) 
                                                                                & (IData)(
                                                                                (0xff00fff0fffdffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013035_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4aee2d94__0)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfff011111111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057577_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057574_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? (IData)(
                                                                                (0xff00ffaafff0ffccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013064_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6bff4562__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6c83109e__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xfff01111U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012178_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012177_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc338337f__0))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013047_))))))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___013064_))))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))));
    vlSelf->wasmetal_core__DOT___011163_ = (1U & (0x75570000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))));
    vlSelf->wasmetal_core__DOT___012242_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h740b215b__0)))) {
        wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024403_;
        wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d;
    } else {
        wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d;
        wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024569_;
    }
    vlSelf->wasmetal_core__DOT___043823_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O)))));
    vlSelf->wasmetal_core__DOT___043847_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008810_))));
    vlSelf->wasmetal_core__DOT___043519_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    if ((1U & (0xe1U >> (IData)(vlSelf->__VdfgTmp_h3691f72d__0)))) {
        wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024137_;
        wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d;
    } else {
        wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d;
        wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024268_;
    }
    vlSelf->wasmetal_core__DOT___043390_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    vlSelf->wasmetal_core__DOT___043757_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O)))));
    vlSelf->wasmetal_core__DOT___043781_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008810_))));
    vlSelf->wasmetal_core__DOT___043455_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008810_))));
    wasmetal_core__DOT___127728___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
           & (IData)(wasmetal_core__DOT___024884_));
    vlSelf->wasmetal_core__DOT___048158_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005783_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005782_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005781_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005780_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hf524d067__0))))))));
    vlSelf->wasmetal_core__DOT___006193_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006166_)) 
                                                  & ((~ 
                                                      (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127529___O) 
                                                        >> 1U) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                           ? (IData)(
                                                                     (0xf3f0f2e0f3faaaaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde33bda2__0)))))))
                                                           : 
                                                          (0x302U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hde33bda2__0))))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006036_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006035_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hf524d067__0))))))));
    wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023207_) 
           & (IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b53__05d) 
           & (IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128808___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035984_)
            ? (IData)(wasmetal_core__DOT___035927_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b32__05d));
    wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
           & (IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h513c757b__0)) 
           & (IData)(wasmetal_core__DOT___036333_));
    wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035339_)
            ? (IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b7__05d));
    wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O)) 
           & (IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035627_)
            ? (IData)(wasmetal_core__DOT___035571_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b17__05d));
    vlSelf->wasmetal_core__DOT___012063_ = (1U & (IData)(
                                                         (0xfff100000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___056907_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056906_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056905_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xccf0ff55U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056903_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he499e9e8__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011101_)))))))));
    vlSelf->__VdfgTmp_hf0788fad__0 = ((2U & ((0xfe00U 
                                              >> (((IData)(wasmetal_core__DOT___056907_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056916_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0x33000f00000055ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056914_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f0aaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056900_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h758d714e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056899_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012179_))))))))))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf0f000ee00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056909_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056908_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012256_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010085_))))))))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h64128247__0)))) {
        wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d;
    } else {
        wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d;
        wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024204_) {
        wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d;
    } else {
        wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d;
        wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127728___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127533___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023208_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023207_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023206_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023205_)))) 
           ^ (((IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023268_)))));
    wasmetal_core__DOT___023272_ = ((IData)(vlSelf->wasmetal_core__DOT___023208_) 
                                    & (IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b54__05d) 
           & (IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128808___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035985_)
            ? (IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b33__05d));
    wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
           & (IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h310e5162__0)) 
           & (IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128735___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035340_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035339_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035391_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035390_)))) 
           ^ (((IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035336_)))));
    wasmetal_core__DOT___035284_ = ((IData)(vlSelf->wasmetal_core__DOT___035340_)
                                     ? (IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b8__05d));
    wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035628_)
            ? (IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b18__05d));
    if (vlSelf->wasmetal_core__DOT___024469_) {
        wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d;
    } else {
        wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d;
        wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024205_) {
        wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d;
    } else {
        wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d;
        wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127728___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006165_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127533___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006171_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb48e3438__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb48e3438__0))))));
    wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023209_) 
           & (IData)(wasmetal_core__DOT___023272_));
    vlSelf->wasmetal_core__DOT____Vcellout___128874___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b55__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b54__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b53__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b52__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036512_)))));
    wasmetal_core__DOT___036516_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128808___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035986_)
            ? (IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b34__05d));
    wasmetal_core__DOT____Vcellout___127500___O = (
                                                   ((8U 
                                                     & ((0xf40bU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h86dfc376__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((6U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022998_)))));
    wasmetal_core__DOT___023003_ = ((0xf40bU >> (IData)(vlSelf->__VdfgTmp_h86dfc376__0)) 
                                    & (IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hd5a7b943__0)) 
           & (IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hb335ec2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h15de5b2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hbff92af3__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035341_)
                  ? (IData)(wasmetal_core__DOT___035284_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h9195d647__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128750___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035455_)))));
    wasmetal_core__DOT___035459_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035629_)
            ? (IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127679___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024470_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024469_) 
                        << 2U) | ((2U & ((9U >> (IData)(vlSelf->__VdfgTmp_h64128247__0)) 
                                         << 1U)) | 
                                  (1U & (9U >> (IData)(vlSelf->__VdfgTmp_h740b215b__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024403_)))));
    if (vlSelf->wasmetal_core__DOT___024470_) {
        wasmetal_core__DOT___024407_ = wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024573_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d;
    } else {
        wasmetal_core__DOT___024407_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d;
        wasmetal_core__DOT___024573_ = wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127646___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024206_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024205_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___024204_) 
                                   << 1U) | (1U & (0xe1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3691f72d__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024137_)))));
    if (vlSelf->wasmetal_core__DOT___024206_) {
        wasmetal_core__DOT___024141_ = wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024272_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d;
    } else {
        wasmetal_core__DOT___024141_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d;
        wasmetal_core__DOT___024272_ = wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127663___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024206_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024205_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024204_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (0xe1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3691f72d__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024268_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127728___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
           ^ (((IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024884_)))));
    wasmetal_core__DOT___024824_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127696___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024470_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024469_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h64128247__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h740b215b__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024569_)))));
    wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023210_) 
           & (IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b56__05d) 
           & (IData)(wasmetal_core__DOT___036516_));
    vlSelf->wasmetal_core__DOT____Vcellout___128808___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035987_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035986_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035985_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035984_)))) 
           ^ (((IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035927_)))));
    wasmetal_core__DOT___035931_ = ((IData)(vlSelf->wasmetal_core__DOT___035987_)
                                     ? (IData)(wasmetal_core__DOT___128808___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b35__05d));
    vlSelf->wasmetal_core__DOT___060022_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00aaaafc0cfc0cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xf400U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h86dfc376__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127500___O) 
                                                                                >> 3U))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f000ddU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h460f8c4e__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f000ddU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h460f8c4e__0))))))))))));
    __VdfgTmp_h4bfbe6f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127500___O) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    __VdfgTmp_h0c3747f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127500___O) 
                                                    >> 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    __VdfgTmp_h0968f04c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127500___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__ 
        = ((0xf40bU >> (IData)(vlSelf->__VdfgTmp_h6df53282__0)) 
           & (IData)(wasmetal_core__DOT___023003_));
    vlSelf->wasmetal_core__DOT____Vcellout___128853___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h4e8a0148__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_hd5a7b943__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h310e5162__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h513c757b__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036333_)))));
    wasmetal_core__DOT___036338_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h4e8a0148__0)) 
                                    & (IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035342_)
            ? (IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b10__05d));
    wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035459_));
    vlSelf->wasmetal_core__DOT____Vcellout___128765___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035630_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035629_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035628_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035627_)))) 
           ^ (((IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035571_)))));
    wasmetal_core__DOT___035575_ = ((IData)(vlSelf->wasmetal_core__DOT___035630_)
                                     ? (IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b20__05d));
    vlSelf->wasmetal_core__DOT___057606_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hf4167eb1__0)))) {
        wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024407_;
        wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d;
    } else {
        wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d;
        wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024573_;
    }
    vlSelf->wasmetal_core__DOT___043824_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043848_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    vlSelf->wasmetal_core__DOT___043498_ = (1U & (0xfee0f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                          << 2U) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___043497_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043521_ = (1U & (0x14000028U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                       << 3U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hac22065f__0))))));
    vlSelf->wasmetal_core__DOT___043520_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    if (vlSelf->wasmetal_core__DOT___024207_) {
        wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024141_;
        wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d;
    } else {
        wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d;
        wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024272_;
    }
    vlSelf->wasmetal_core__DOT___043369_ = (1U & (0xfee0f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                          << 2U) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___043368_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043758_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043392_ = (1U & (0x14000028U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                       << 3U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hac22065f__0))))));
    vlSelf->wasmetal_core__DOT___043391_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    vlSelf->wasmetal_core__DOT___043782_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    vlSelf->wasmetal_core__DOT___043432_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043456_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    wasmetal_core__DOT___127729___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
           & (IData)(wasmetal_core__DOT___024824_));
    wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023211_) 
           & (IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b57__05d) 
           & (IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___053602_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128808___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128806___O) 
                                                         >> 3U)))));
    wasmetal_core__DOT___128809___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035988_)
            ? (IData)(wasmetal_core__DOT___035931_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b36__05d));
    vlSelf->wasmetal_core__DOT___018808_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h4bfbe6f9__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h4bfbe6f9__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058471_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059991_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0c3747f4__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0c3747f4__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdd0f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058474_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058473_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059963_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0968f04c__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0968f04c__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdd0f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058472_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016278_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006819_)))))))))))))))))))))))));
    wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
           & (IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128854___O = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d) 
                                                      & (IData)(wasmetal_core__DOT___036338_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___036338_)));
    wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035343_)
            ? (IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b11__05d));
    wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O)) 
           & (IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035632_)
            ? (IData)(wasmetal_core__DOT___035575_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b21__05d));
    if (vlSelf->wasmetal_core__DOT___024472_) {
        wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d;
    } else {
        wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d;
        wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024208_) {
        wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d;
    } else {
        wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d;
        wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127729___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127534___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023212_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023211_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023210_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023209_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023272_)))));
    wasmetal_core__DOT___023276_ = ((IData)(vlSelf->wasmetal_core__DOT___023212_) 
                                    & (IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b58__05d) 
           & (IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128809___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035989_)
            ? (IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b37__05d));
    wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h20c89172__0)) 
           & (IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d 
        = (1U & (4U >> ((2U & (IData)(wasmetal_core__DOT____Vcellout___128854___O)) 
                        | (IData)(vlSelf->wasmetal_core__DOT___017533_))));
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry 
        = (1U & (0xb00U >> ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128854___O) 
                                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057694_))))));
    wasmetal_core__DOT____Vcellout___128736___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035344_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035343_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035342_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035341_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035284_)))));
    wasmetal_core__DOT___035288_ = ((IData)(vlSelf->wasmetal_core__DOT___035344_)
                                     ? (IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b12__05d));
    wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035633_)
            ? (IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b22__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h50e83fab__0)))) {
        wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d;
    } else {
        wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d;
        wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h7884e356__0)))) {
        wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d;
    } else {
        wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d;
        wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127729___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005975_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005989_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9937e7c0__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9937e7c0__0))))));
    vlSelf->wasmetal_core__DOT___006009_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006022_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_ha48aeb8e__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_ha48aeb8e__0))))));
    vlSelf->wasmetal_core__DOT___006079_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006099_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9936ac51__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9936ac51__0))))));
    vlSelf->wasmetal_core__DOT___006080_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006106_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h97a6ba37__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h97a6ba37__0))))));
    wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023214_) 
           & (IData)(wasmetal_core__DOT___023276_));
    wasmetal_core__DOT____Vcellout___128875___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b59__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b58__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b57__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b56__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036516_)))));
    wasmetal_core__DOT___036520_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b59__05d) 
                                    & (IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128809___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035990_)
            ? (IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b38__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127501___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h20c89172__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
                                                << 1U)) 
                                         | (1U & (0xf40bU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h6df53282__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023003_)))));
    wasmetal_core__DOT___023007_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
                                    & (IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___036374_ = (1U & (6U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d))));
    wasmetal_core__DOT___036373_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                     << 1U)) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry))));
    vlSelf->__VdfgTmp_h493bd629__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128736___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_haaae3cf9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hbca0145a__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128736___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h532df62e__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035345_)
                  ? (IData)(wasmetal_core__DOT___035288_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128751___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035459_)))));
    wasmetal_core__DOT___035463_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035634_)
            ? (IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127680___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h6850d65a__0)) 
                   << 3U)) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_h50e83fab__0)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___024472_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf4167eb1__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024407_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h6850d65a__0)))) {
        wasmetal_core__DOT___024411_ = wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024577_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d;
    } else {
        wasmetal_core__DOT___024411_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d;
        wasmetal_core__DOT___024577_ = wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127647___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024210_) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h7884e356__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___024208_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024207_)))) 
           ^ (((IData)(wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024141_)))));
    if (vlSelf->wasmetal_core__DOT___024210_) {
        wasmetal_core__DOT___024145_ = wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024276_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d;
    } else {
        wasmetal_core__DOT___024145_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d;
        wasmetal_core__DOT___024276_ = wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127664___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024210_)) 
                   << 3U)) | ((4U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h7884e356__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024208_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024207_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024272_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127729___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
           ^ (((IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024824_)))));
    wasmetal_core__DOT___024828_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127697___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h6850d65a__0))) 
                   << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h50e83fab__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024472_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf4167eb1__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024573_)))));
    vlSelf->wasmetal_core__DOT___006123_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005782_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005781_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006166_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006036_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005778_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005777_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006165_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006080_)))))))))));
    wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023215_) 
           & (IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___060552_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7cadd68e__0))))))));
    vlSelf->wasmetal_core__DOT___060566_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h49fa4f4c__0))))))));
    vlSelf->wasmetal_core__DOT___060584_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058512_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060598_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016491_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                  >> 3U))))))));
    wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b60__05d) 
           & (IData)(wasmetal_core__DOT___036520_));
    vlSelf->wasmetal_core__DOT____Vcellout___128809___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035991_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035990_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035989_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035988_)))) 
           ^ (((IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035931_)))));
    wasmetal_core__DOT___035935_ = ((IData)(vlSelf->wasmetal_core__DOT___035991_)
                                     ? (IData)(wasmetal_core__DOT___128809___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b39__05d));
    __VdfgTmp_hffea5a13__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127501___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_he5a4e99b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127501___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b28__05d) 
           & (IData)(wasmetal_core__DOT___023007_));
    wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036373_)) 
           & (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry));
    wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035346_)
                  ? (IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0))));
    wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035463_));
    vlSelf->wasmetal_core__DOT____Vcellout___128766___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035635_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035634_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035633_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035632_)))) 
           ^ (((IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035575_)))));
    wasmetal_core__DOT___035580_ = ((IData)(vlSelf->wasmetal_core__DOT___035635_)
                                     ? (IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b24__05d));
    vlSelf->wasmetal_core__DOT___011254_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if (vlSelf->wasmetal_core__DOT___024475_) {
        wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024411_;
        wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d;
    } else {
        wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d;
        wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024577_;
    }
    vlSelf->wasmetal_core__DOT___043826_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043825_ = (1U & (0x7f770100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___043850_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043849_ = (1U & (0x90000009U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___008810_)))))));
    vlSelf->wasmetal_core__DOT___043499_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O)))));
    vlSelf->wasmetal_core__DOT___043522_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    if (vlSelf->wasmetal_core__DOT___024211_) {
        wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024145_;
        wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d;
    } else {
        wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d;
        wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024276_;
    }
    vlSelf->wasmetal_core__DOT___043370_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O)))));
    vlSelf->wasmetal_core__DOT___043760_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043759_ = (1U & (0x7f770100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___043393_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043784_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043783_ = (1U & (0x90000009U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___008810_)))))));
    vlSelf->wasmetal_core__DOT___057409_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127729___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___056993_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127729___O))))));
    vlSelf->wasmetal_core__DOT___043434_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043433_ = (1U & (0xfee0f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                          << 2U) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___043458_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043457_ = (1U & (0x14000028U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                       << 2U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hac22065f__0))))));
    wasmetal_core__DOT___127730___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
           & (IData)(wasmetal_core__DOT___024828_));
    wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023216_) 
           & (IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b61__05d) 
           & (IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___053605_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128809___O) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128808___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___053599_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128809___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128808___O) 
                                                         >> 1U)))));
    wasmetal_core__DOT___128796___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035993_)
            ? (IData)(wasmetal_core__DOT___035935_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b40__05d));
    vlSelf->wasmetal_core__DOT___060072_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                          ? 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_hffea5a13__0))))
                                                                          : 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_hffea5a13__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f000ddU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h3056fe7c__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f000ddU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h3056fe7c__0))))))))))));
    wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
           & (IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036374_) ? (IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__)
            : (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d));
    wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035347_)
                  ? (IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0))));
    wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O)) 
           & (IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035636_)
            ? (IData)(wasmetal_core__DOT___035580_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b25__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h26c3fed8__0)))) {
        wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d;
    } else {
        wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d;
        wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__;
    }
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h89795cd5__0)))) {
        wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d;
    } else {
        wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d;
        wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127730___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127520___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023217_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023216_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023215_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023214_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023276_)))));
    vlSelf->wasmetal_core__DOT___023281_ = ((IData)(vlSelf->wasmetal_core__DOT___023217_) 
                                            & (IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128876___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b63__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b62__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b61__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b60__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b62__05d) 
                & (IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036520_)))));
    wasmetal_core__DOT___128796___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035994_)
            ? (IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b41__05d));
    wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
           & (IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128737___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035348_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035347_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035346_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035345_)))) 
           ^ (((IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035288_)))));
    vlSelf->wasmetal_core__DOT___035292_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035348_)
                                                   ? (IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0))));
    wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035637_)
            ? (IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b26__05d));
    if (vlSelf->wasmetal_core__DOT___024477_) {
        wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d;
    } else {
        wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d;
        wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024213_) {
        wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d;
    } else {
        wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d;
        wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127730___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005845_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005868_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb869da0d__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb869da0d__0))))));
    vlSelf->wasmetal_core__DOT___005843_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005855_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_haba8fa43__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_haba8fa43__0))))));
    vlSelf->wasmetal_core__DOT___005706_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005770_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb86fa734__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb86fa734__0))))));
    vlSelf->wasmetal_core__DOT___005705_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___003806_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab9caa42__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab9caa42__0))))));
    vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023218_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023281_));
    vlSelf->wasmetal_core__DOT___060614_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h307b9eba__0))))))));
    vlSelf->wasmetal_core__DOT___060640_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f000003355ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058515_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060624_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f000003355ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058514_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                                >> 1U)))))))))))));
    wasmetal_core__DOT___128796___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035995_)
            ? (IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b42__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127502___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b28__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023007_)))));
    vlSelf->wasmetal_core__DOT___023077_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
                                            & (IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128855___O 
        = (((0xcU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
            | (((IData)(wasmetal_core__DOT___036374_) 
                << 1U) | (IData)(wasmetal_core__DOT___036373_))) 
           ^ (((IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___036366_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_he1094429__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h4c1a1db9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h155aafca__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h6827e815__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035349_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035292_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h93626d60__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128752___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035463_)))));
    vlSelf->wasmetal_core__DOT___035468_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035638_)
            ? (IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127681___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_he07352b1__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024477_) 
                               << 2U) | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h26c3fed8__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___024475_)))) 
           ^ (((IData)(wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024411_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_he07352b1__0)))) {
        vlSelf->wasmetal_core__DOT___024416_ = wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024582_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024416_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d;
        vlSelf->wasmetal_core__DOT___024582_ = wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127648___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024214_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024213_) 
                        << 2U) | ((2U & ((6U >> (IData)(vlSelf->__VdfgTmp_h89795cd5__0)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___024211_)))) 
           ^ (((IData)(wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024145_)))));
    if (vlSelf->wasmetal_core__DOT___024214_) {
        vlSelf->wasmetal_core__DOT___024150_ = wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024281_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024150_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d;
        vlSelf->wasmetal_core__DOT___024281_ = wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127665___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024214_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024213_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h89795cd5__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024211_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024276_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127730___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
           ^ (((IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024828_)))));
    vlSelf->wasmetal_core__DOT___024832_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127698___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_he07352b1__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024477_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h26c3fed8__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024475_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024577_)))));
    vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023219_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128796___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035996_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035995_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035994_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035993_)))) 
           ^ (((IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035935_)))));
    wasmetal_core__DOT___035940_ = ((IData)(vlSelf->wasmetal_core__DOT___035996_)
                                     ? (IData)(wasmetal_core__DOT___128796___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b43__05d));
    __VdfgTmp_h01dc1976__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127502___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    __VdfgTmp_hb1f3bce1__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127502___O) 
                                                    >> 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___019013_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058337_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127502___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___127517___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b32__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___023077_));
    vlSelf->wasmetal_core__DOT___134162___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O))));
    vlSelf->wasmetal_core__DOT___128859___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O))));
    vlSelf->wasmetal_core__DOT___043027_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___043030_ = (1U & (0x40U 
                                                  >> 
                                                  ((6U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___128856___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___036366_));
    vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035350_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h767f4755__0))));
    vlSelf->wasmetal_core__DOT___128753___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035468_));
    vlSelf->wasmetal_core__DOT____Vcellout___128767___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035639_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035638_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035637_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035636_)))) 
           ^ (((IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035580_)))));
    vlSelf->wasmetal_core__DOT___035584_ = ((IData)(vlSelf->wasmetal_core__DOT___035639_)
                                             ? (IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b28__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hc7fb8523__0)))) {
        vlSelf->wasmetal_core__DOT___127682___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024416_;
        vlSelf->wasmetal_core__DOT___127715___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127682___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d;
        vlSelf->wasmetal_core__DOT___127715___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024582_;
    }
    vlSelf->wasmetal_core__DOT___043827_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O)))));
    vlSelf->wasmetal_core__DOT___043851_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043500_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043523_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    if (vlSelf->wasmetal_core__DOT___024215_) {
        vlSelf->wasmetal_core__DOT___127649___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024150_;
        vlSelf->wasmetal_core__DOT___127666___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127649___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d;
        vlSelf->wasmetal_core__DOT___127666___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024281_;
    }
    vlSelf->wasmetal_core__DOT___043371_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043761_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O)))));
    vlSelf->wasmetal_core__DOT___043394_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    vlSelf->wasmetal_core__DOT___043785_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043435_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O)))));
    vlSelf->wasmetal_core__DOT___043459_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___127731___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024832_));
    vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023220_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128797___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035997_)
            ? (IData)(wasmetal_core__DOT___035940_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b44__05d));
    vlSelf->wasmetal_core__DOT___060180_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f335500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                                 ? 
                                                                                (0xc0c5U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h01dc1976__0))))
                                                                                 : 
                                                                                (0xc0c5U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h01dc1976__0))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h78bec42d__0))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h78bec42d__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___060204_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_hb1f3bce1__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_hb1f3bce1__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xbb0f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058493_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128869___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4af9777a__0)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060234_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f335500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                                 ? 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019014_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___019013_))))
                                                                                 : 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___019013_))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060224_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h59bf4fdc__0))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h59bf4fdc__0)))))))))))))))));
    wasmetal_core__DOT___127517___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b33__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127517___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___134162___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                  >> 2U) | (IData)(vlSelf->wasmetal_core__DOT___134162___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___128856___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128856___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128738___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035351_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0))));
    wasmetal_core__DOT___128753___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128753___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128768___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035640_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035584_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b29__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hedda33f4__0)))) {
        wasmetal_core__DOT___127682___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127682___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127715___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d;
    } else {
        wasmetal_core__DOT___127682___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d;
        wasmetal_core__DOT___127715___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127715___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024216_) {
        wasmetal_core__DOT___127649___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127649___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127666___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d;
    } else {
        wasmetal_core__DOT___127649___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d;
        wasmetal_core__DOT___127666___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127666___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127731___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127731___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127521___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023221_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023220_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023219_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023218_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023281_)))));
    wasmetal_core__DOT___023285_ = ((IData)(vlSelf->wasmetal_core__DOT___023221_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128797___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035998_)
            ? (IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b45__05d));
    wasmetal_core__DOT___127517___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b34__05d) 
           & (IData)(wasmetal_core__DOT___127517___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134162___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134162___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134162___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___036819_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                     >> 3U) 
                                                    | (IData)(wasmetal_core__DOT___134162___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___128856___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128856___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128738___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035352_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035351_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035350_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035349_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128738___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035292_)))));
    wasmetal_core__DOT___035297_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035352_)
                                           ? (IData)(wasmetal_core__DOT___128738___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_hff1a4828__0))));
    wasmetal_core__DOT___128753___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128753___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128768___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035641_)
            ? (IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b30__05d));
    if (vlSelf->wasmetal_core__DOT___024481_) {
        wasmetal_core__DOT___127682___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127682___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127715___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d;
    } else {
        wasmetal_core__DOT___127682___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d;
        wasmetal_core__DOT___127715___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127715___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024217_) {
        wasmetal_core__DOT___127649___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127649___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127666___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d;
    } else {
        wasmetal_core__DOT___127649___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d;
        wasmetal_core__DOT___127666___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127666___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127731___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127731___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005912_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127521___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___003805_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6e06acca__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6e06acca__0))))));
    vlSelf->wasmetal_core__DOT___005844_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127521___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___003811_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he245418c__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he245418c__0))))));
    vlSelf->wasmetal_core__DOT___005703_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127521___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___003808_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6f6c5c03__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6f6c5c03__0))))));
    vlSelf->wasmetal_core__DOT___005704_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127521___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___003807_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he137fc3d__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he137fc3d__0))))));
    wasmetal_core__DOT___127522___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023222_) 
           & (IData)(wasmetal_core__DOT___023285_));
    wasmetal_core__DOT___128797___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035999_)
            ? (IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b46__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127517___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b35__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b34__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b33__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b32__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127517___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127517___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127517___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023077_)))));
    wasmetal_core__DOT___023081_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b35__05d) 
                                    & (IData)(wasmetal_core__DOT___127517___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128856___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
           ^ (((IData)(wasmetal_core__DOT___128856___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128856___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128856___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036366_)))));
    wasmetal_core__DOT___036370_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128856___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hddb36baf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128738___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h99b9ed45__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h5c210cc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128738___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hdd9a68de__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128739___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035353_)
                  ? (IData)(wasmetal_core__DOT___035297_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128753___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128753___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128753___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128753___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035468_)))));
    wasmetal_core__DOT___035472_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128753___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128768___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035643_)
            ? (IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b31__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127682___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h33ebc999__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024481_) 
                               << 2U) | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hedda33f4__0)) 
                                                << 1U)) 
                                         | (1U & (9U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc7fb8523__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127682___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127682___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127682___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024416_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h33ebc999__0)))) {
        wasmetal_core__DOT___024420_ = wasmetal_core__DOT___127682___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024586_ = vlSelf->wasmetal_core__DOT___011020_;
    } else {
        wasmetal_core__DOT___024420_ = vlSelf->wasmetal_core__DOT___011020_;
        wasmetal_core__DOT___024586_ = wasmetal_core__DOT___127715___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127649___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hda2ae911__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024217_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___024216_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024215_)))) 
           ^ (((IData)(wasmetal_core__DOT___127649___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127649___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127649___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024150_)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hda2ae911__0)))) {
        wasmetal_core__DOT___024154_ = wasmetal_core__DOT___127649___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024285_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b27__05d;
    } else {
        wasmetal_core__DOT___024154_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b27__05d;
        wasmetal_core__DOT___024285_ = wasmetal_core__DOT___127666___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127666___O 
        = (((8U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_hda2ae911__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024217_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024216_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024215_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127666___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127666___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127666___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024281_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127731___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
           ^ (((IData)(wasmetal_core__DOT___127731___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127731___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127731___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024832_)))));
    wasmetal_core__DOT___024837_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127731___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127699___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h33ebc999__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024481_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hedda33f4__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc7fb8523__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127715___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127715___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127715___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024582_)))));
    vlSelf->wasmetal_core__DOT___006192_ = (1U & ((~ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127533___O) 
                                                     >> 1U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006215_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h584814f6__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h584814f6__0)))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006165_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006080_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006079_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005706_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005705_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005704_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005703_)))))))))));
    wasmetal_core__DOT___127522___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023223_) 
           & (IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128797___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036000_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035999_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035998_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035997_)))) 
           ^ (((IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035940_)))));
    wasmetal_core__DOT___035944_ = ((IData)(vlSelf->wasmetal_core__DOT___036000_)
                                     ? (IData)(wasmetal_core__DOT___128797___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b47__05d));
    wasmetal_core__DOT___127518___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b36__05d) 
           & (IData)(wasmetal_core__DOT___023081_));
    vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036819_)));
    vlSelf->wasmetal_core__DOT____Vcellout___128859___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                       >> 1U)))))) 
           ^ (1U | ((((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                          >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___128859___DOT__CO__BRA__1__KET__)) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128859___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___058937_ = (1U & (1U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                             << 1U)) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                               >> 2U)))))));
    wasmetal_core__DOT___128857___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
           & (IData)(wasmetal_core__DOT___036370_));
    wasmetal_core__DOT___128739___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035354_)
            ? (IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b22__05d));
    wasmetal_core__DOT___128754___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035472_));
    vlSelf->wasmetal_core__DOT____Vcellout___128768___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035644_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035643_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035641_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035640_)))) 
           ^ (((IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035584_)))));
    wasmetal_core__DOT___035589_ = ((IData)(vlSelf->wasmetal_core__DOT___035644_)
                                     ? (IData)(wasmetal_core__DOT___128768___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b32__05d));
    vlSelf->wasmetal_core__DOT___056506_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127682___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h78ac443f__0)))) {
        wasmetal_core__DOT___127683___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024420_;
        wasmetal_core__DOT___127716___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d;
    } else {
        wasmetal_core__DOT___127683___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d;
        wasmetal_core__DOT___127716___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024586_;
    }
    vlSelf->wasmetal_core__DOT___043828_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043852_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    vlSelf->wasmetal_core__DOT___043502_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043501_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043525_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043524_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h5230c890__0)))) {
        wasmetal_core__DOT___127650___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024154_;
        wasmetal_core__DOT___127667___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b28__05d;
    } else {
        wasmetal_core__DOT___127650___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b28__05d;
        wasmetal_core__DOT___127667___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024285_;
    }
    vlSelf->wasmetal_core__DOT___043373_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043372_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043762_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043396_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043395_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    vlSelf->wasmetal_core__DOT___043786_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    vlSelf->wasmetal_core__DOT___011149_ = (1U & (0xf0440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))));
    vlSelf->wasmetal_core__DOT___043436_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043460_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    wasmetal_core__DOT___127732___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
           & (IData)(wasmetal_core__DOT___024837_));
    wasmetal_core__DOT___127522___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023225_) 
           & (IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___042824_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128797___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128796___O) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128809___O) 
                                                                    >> 3U)))))));
    wasmetal_core__DOT___128798___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036001_)
            ? (IData)(wasmetal_core__DOT___035944_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b48__05d));
    wasmetal_core__DOT___127518___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b37__05d) 
           & (IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                  >> 1U) | (IData)(vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___128857___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128739___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035355_)
            ? (IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b23__05d));
    wasmetal_core__DOT___128754___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O)) 
           & (IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128769___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035645_)
            ? (IData)(wasmetal_core__DOT___035589_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b33__05d));
    if (vlSelf->wasmetal_core__DOT___024484_) {
        wasmetal_core__DOT___127683___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127683___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127716___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d;
    } else {
        wasmetal_core__DOT___127683___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d;
        wasmetal_core__DOT___127716___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127716___DOT__CO__BRA__0__KET__;
    }
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_ha141c58a__0)))) {
        wasmetal_core__DOT___127650___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127650___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127667___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b29__05d;
    } else {
        wasmetal_core__DOT___127650___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b29__05d;
        wasmetal_core__DOT___127667___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127667___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127732___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127732___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127522___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023226_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023225_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023223_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023222_)))) 
           ^ (((IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023285_)))));
    wasmetal_core__DOT___023290_ = ((IData)(vlSelf->wasmetal_core__DOT___023226_) 
                                    & (IData)(wasmetal_core__DOT___127522___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128798___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036002_)
            ? (IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b49__05d));
    wasmetal_core__DOT___127518___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b38__05d) 
           & (IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128857___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128739___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035356_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035355_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035354_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035353_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035297_)))));
    wasmetal_core__DOT___035301_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035356_)
                                           ? (IData)(wasmetal_core__DOT___128739___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0))));
    wasmetal_core__DOT___128754___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128769___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035646_)
            ? (IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b34__05d));
    if (vlSelf->wasmetal_core__DOT___024485_) {
        wasmetal_core__DOT___127683___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127683___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127716___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___010972_;
    } else {
        wasmetal_core__DOT___127683___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___010972_;
        wasmetal_core__DOT___127716___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127716___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_ha26e7faa__0)))) {
        wasmetal_core__DOT___127650___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127650___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127667___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b30__05d;
    } else {
        wasmetal_core__DOT___127650___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b30__05d;
        wasmetal_core__DOT___127667___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127667___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127732___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127732___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006397_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127522___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006400_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h201788e1__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h201788e1__0))))));
    vlSelf->wasmetal_core__DOT___006132_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127522___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___003810_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h21955c47__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h21955c47__0))))));
    vlSelf->wasmetal_core__DOT___006199_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127522___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___003809_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3cbf3996__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3cbf3996__0))))));
    wasmetal_core__DOT___127523___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023227_) 
           & (IData)(wasmetal_core__DOT___023290_));
    wasmetal_core__DOT___128798___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036004_)
            ? (IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b50__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127518___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b39__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b38__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b37__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b36__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023081_)))));
    wasmetal_core__DOT___023085_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b39__05d) 
                                    & (IData)(wasmetal_core__DOT___127518___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128857___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036370_)))));
    wasmetal_core__DOT___036360_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128857___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h207e55f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128739___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h328f8271__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hde3a7a63__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128739___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hdc99d11f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128738___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128740___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035357_)
                  ? (IData)(wasmetal_core__DOT___035301_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h7297059c__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128754___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035472_)))));
    wasmetal_core__DOT___035477_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128754___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128769___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035647_)
            ? (IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b35__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127683___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h04c057c0__0)) 
                   << 3U)) | (IData)(vlSelf->__VdfgTmp_h2237a749__0)) 
           ^ (((IData)(wasmetal_core__DOT___127683___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127683___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127683___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024420_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h04c057c0__0)))) {
        wasmetal_core__DOT___024425_ = (1U & (IData)(wasmetal_core__DOT___127683___DOT__CO__BRA__2__KET__));
        wasmetal_core__DOT___024591_ = (1U & (0xfef0U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)));
    } else {
        wasmetal_core__DOT___024425_ = (1U & (0xfef0U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)));
        wasmetal_core__DOT___024591_ = (1U & (IData)(wasmetal_core__DOT___127716___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127650___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024223_) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_ha26e7faa__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_ha141c58a__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h5230c890__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127650___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127650___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127650___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024154_)))));
    if (vlSelf->wasmetal_core__DOT___024223_) {
        wasmetal_core__DOT___024159_ = wasmetal_core__DOT___127650___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024290_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d;
    } else {
        wasmetal_core__DOT___024159_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d;
        wasmetal_core__DOT___024290_ = wasmetal_core__DOT___127667___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127667___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024223_)) 
                   << 3U)) | ((4U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_ha26e7faa__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha141c58a__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5230c890__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127667___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127667___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127667___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024285_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127732___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
           ^ (((IData)(wasmetal_core__DOT___127732___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127732___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127732___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024837_)))));
    wasmetal_core__DOT___024841_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127732___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127700___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h04c057c0__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024485_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024484_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h78ac443f__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127716___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127716___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127716___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024586_)))));
    wasmetal_core__DOT___127523___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023228_) 
           & (IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128798___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036005_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036004_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036002_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036001_)))) 
           ^ (((IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035944_)))));
    wasmetal_core__DOT___035949_ = ((IData)(vlSelf->wasmetal_core__DOT___036005_)
                                     ? (IData)(wasmetal_core__DOT___128798___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b51__05d));
    vlSelf->wasmetal_core__DOT___019112_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff00bb00ff000f00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128885___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9e4b4f68__0))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f0335500000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058346_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127518___O) 
                                                                                >> 3U))))))))))))));
    wasmetal_core__DOT___127504___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b40__05d) 
           & (IData)(wasmetal_core__DOT___023085_));
    wasmetal_core__DOT___043028_ = (1U & (IData)((0x1fffULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128857___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                                     >> 3U))))))))));
    __VdfgTmp_hb9cb0b08__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                     >> 2U)) | (1U 
                                                & (IData)(wasmetal_core__DOT____Vcellout___128857___O)));
    wasmetal_core__DOT___128858___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___036292_)) 
           & (IData)(wasmetal_core__DOT___036360_));
    wasmetal_core__DOT___128740___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035358_)
                  ? (IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0))));
    wasmetal_core__DOT___128755___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035477_));
    vlSelf->wasmetal_core__DOT____Vcellout___128769___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035648_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035647_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035646_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035645_)))) 
           ^ (((IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035589_)))));
    wasmetal_core__DOT___035593_ = ((IData)(vlSelf->wasmetal_core__DOT___035648_)
                                     ? (IData)(wasmetal_core__DOT___128769___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b36__05d));
    vlSelf->wasmetal_core__DOT___057422_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127683___O)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___012480_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127683___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___013162_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127683___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h786db0b3__0)))));
    if (vlSelf->wasmetal_core__DOT___024486_) {
        wasmetal_core__DOT___127684___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024425_;
        wasmetal_core__DOT___127717___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d;
    } else {
        wasmetal_core__DOT___127684___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d;
        wasmetal_core__DOT___127717___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024591_;
    }
    vlSelf->wasmetal_core__DOT___043810_ = (1U & (0x7f0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___033033_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___043829_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043834_ = (1U & (0x81000003U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 3U) 
                                                      | ((6U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___033033_))))));
    vlSelf->wasmetal_core__DOT___043853_ = (1U & (0x8001U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    vlSelf->wasmetal_core__DOT___043484_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O)))));
    vlSelf->wasmetal_core__DOT___043507_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h8511e463__0)))) {
        wasmetal_core__DOT___127651___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024159_;
        wasmetal_core__DOT___127668___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b32__05d;
    } else {
        wasmetal_core__DOT___127651___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b32__05d;
        wasmetal_core__DOT___127668___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024290_;
    }
    vlSelf->wasmetal_core__DOT___043355_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O)))));
    vlSelf->wasmetal_core__DOT___043744_ = (1U & (0x7f0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___033033_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___043763_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043378_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043768_ = (1U & (0x81000003U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 3U) 
                                                      | ((6U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___033033_))))));
    vlSelf->wasmetal_core__DOT___043787_ = (1U & (0x8001U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    vlSelf->wasmetal_core__DOT___057359_ = (1U & (0xfdd0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___043419_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043437_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043443_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043461_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    wasmetal_core__DOT___127733___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
           & (IData)(wasmetal_core__DOT___024841_));
    wasmetal_core__DOT___127523___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023229_) 
           & (IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___053606_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128798___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128797___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___053607_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128798___O) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128797___O) 
                                                         >> 2U)))));
    wasmetal_core__DOT___128799___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036006_)
            ? (IData)(wasmetal_core__DOT___035949_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b52__05d));
    wasmetal_core__DOT___127504___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b41__05d) 
           & (IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___043031_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                       << 2U)) 
                                                   | ((0x1cU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_hb9cb0b08__0))))));
    wasmetal_core__DOT___128858___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___036292_)) 
           & (IData)(wasmetal_core__DOT___128858___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128740___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035359_)
            ? (IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b27__05d));
    wasmetal_core__DOT___128755___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O)) 
           & (IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128770___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035649_)
            ? (IData)(wasmetal_core__DOT___035593_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b37__05d));
    if (vlSelf->wasmetal_core__DOT___024487_) {
        wasmetal_core__DOT___127684___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127684___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127717___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d;
    } else {
        wasmetal_core__DOT___127684___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d;
        wasmetal_core__DOT___127717___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127717___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024225_) {
        wasmetal_core__DOT___127651___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127651___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127668___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d;
    } else {
        wasmetal_core__DOT___127651___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d;
        wasmetal_core__DOT___127668___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127668___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127733___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127733___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127523___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023230_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023229_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023228_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023227_)))) 
           ^ (((IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023290_)))));
    wasmetal_core__DOT___023294_ = ((IData)(vlSelf->wasmetal_core__DOT___023230_) 
                                    & (IData)(wasmetal_core__DOT___127523___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128799___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036007_)
            ? (IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b53__05d));
    wasmetal_core__DOT___127504___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b42__05d) 
           & (IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128858___O = (
                                                   (7U 
                                                    & (- (IData)(
                                                                 (1U 
                                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___036292_)))))) 
                                                   ^ 
                                                   ((((~ (IData)(vlSelf->wasmetal_core__DOT___036292_)) 
                                                      & (IData)(wasmetal_core__DOT___128858___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128858___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128858___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036360_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128740___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035360_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035359_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035358_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035357_)))) 
           ^ (((IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035301_)))));
    wasmetal_core__DOT___035306_ = ((IData)(vlSelf->wasmetal_core__DOT___035360_)
                                     ? (IData)(wasmetal_core__DOT___128740___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b28__05d));
    wasmetal_core__DOT___128755___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128770___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035650_)
            ? (IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b38__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h3e52c1ca__0)))) {
        wasmetal_core__DOT___127684___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127684___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127717___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d;
    } else {
        wasmetal_core__DOT___127684___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d;
        wasmetal_core__DOT___127717___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127717___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h3114cc84__0)))) {
        wasmetal_core__DOT___127651___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127651___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127668___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b34__05d;
    } else {
        wasmetal_core__DOT___127651___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b34__05d;
        wasmetal_core__DOT___127668___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127668___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127733___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127733___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006008_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127523___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006015_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb514b790__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb514b790__0))))));
    vlSelf->wasmetal_core__DOT___006077_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127523___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006085_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h41acf677__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h41acf677__0))))));
    vlSelf->wasmetal_core__DOT___006078_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127523___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006092_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb6ef8d81__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb6ef8d81__0))))));
    wasmetal_core__DOT___127524___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023231_) 
           & (IData)(wasmetal_core__DOT___023294_));
    wasmetal_core__DOT___128799___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036008_)
            ? (IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b54__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127504___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b43__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b42__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b41__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b40__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023085_)))));
    wasmetal_core__DOT___023090_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b43__05d) 
                                    & (IData)(wasmetal_core__DOT___127504___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___051536_ = (1U & (1U >> ((0x10U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128857___O) 
                                                     << 3U)) 
                                                 | ((8U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128858___O) 
                                                        << 2U)) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128857___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128858___O) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___128857___O) 
                                                                >> 3U))))))));
    vlSelf->__VdfgTmp_h13456aa5__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hbc521204__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h57d4c6cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128739___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hd7693faf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128741___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035361_)
                  ? (IData)(wasmetal_core__DOT___035306_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128755___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035477_)))));
    vlSelf->wasmetal_core__DOT___035481_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___128755___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128770___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035651_)
            ? (IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b39__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127684___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024489_) 
             << 3U) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_h3e52c1ca__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___024487_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024486_)))) 
           ^ (((IData)(wasmetal_core__DOT___127684___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127684___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127684___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024425_)))));
    if (vlSelf->wasmetal_core__DOT___024489_) {
        vlSelf->wasmetal_core__DOT___024429_ = wasmetal_core__DOT___127684___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024595_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024429_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d;
        vlSelf->wasmetal_core__DOT___024595_ = wasmetal_core__DOT___127717___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127651___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024227_) 
             << 3U) | ((4U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h3114cc84__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___024225_) 
                                          << 1U) | 
                                         (1U & (0x4fb0U 
                                                >> (IData)(vlSelf->__VdfgTmp_h8511e463__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127651___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127651___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127651___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024159_)))));
    if (vlSelf->wasmetal_core__DOT___024227_) {
        vlSelf->wasmetal_core__DOT___024163_ = wasmetal_core__DOT___127651___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024294_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024163_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d;
        vlSelf->wasmetal_core__DOT___024294_ = wasmetal_core__DOT___127668___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127668___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024227_)) 
                   << 3U)) | ((4U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h3114cc84__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024225_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (0x4fb0U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h8511e463__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127668___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127668___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127668___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024290_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127733___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
           ^ (((IData)(wasmetal_core__DOT___127733___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127733___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127733___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024841_)))));
    vlSelf->wasmetal_core__DOT___024846_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127733___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127701___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024489_)) 
                   << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h3e52c1ca__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024487_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024486_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127717___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127717___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127717___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024591_)))));
    vlSelf->wasmetal_core__DOT___006124_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005705_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005704_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006199_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006078_))))));
    vlSelf->wasmetal_core__DOT___048266_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005777_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005776_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006080_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006079_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005704_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005703_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006078_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006077_)))))))))));
    wasmetal_core__DOT___127524___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023232_) 
           & (IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___035953_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036009_)
                                           ? (IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___036009_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128799___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036009_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036008_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036007_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036006_)))) 
           ^ (((IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128799___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035949_)))));
    wasmetal_core__DOT___127505___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b44__05d) 
           & (IData)(wasmetal_core__DOT___023090_));
    vlSelf->wasmetal_core__DOT___051539_ = (1U & (IData)(
                                                         (0xf0f0f0f0ffffff22ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128858___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051535_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(__VdfgTmp_hb9cb0b08__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(wasmetal_core__DOT___051536_)))))))));
    wasmetal_core__DOT___043032_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___051536_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128858___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___128741___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035362_)
                  ? (IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0))));
    vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035481_));
    vlSelf->wasmetal_core__DOT____Vcellout___128770___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035652_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035651_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035650_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035649_)))) 
           ^ (((IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035593_)))));
    vlSelf->wasmetal_core__DOT___035597_ = ((IData)(vlSelf->wasmetal_core__DOT___035652_)
                                             ? (IData)(wasmetal_core__DOT___128770___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b40__05d));
    vlSelf->wasmetal_core__DOT___012282_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___012003_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h78c69d21__0)))) {
        vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024429_;
        vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d;
        vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024595_;
    }
    vlSelf->wasmetal_core__DOT___043811_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O)))));
    vlSelf->wasmetal_core__DOT___043835_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043485_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043508_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h17e0a363__0)))) {
        vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024163_;
        vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b36__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b36__05d;
        vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024294_;
    }
    vlSelf->wasmetal_core__DOT___043356_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043745_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O)))));
    vlSelf->wasmetal_core__DOT___043379_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___043769_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___056853_ = (1U & (0xfbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010376_))))));
    vlSelf->wasmetal_core__DOT___043420_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O)))));
    vlSelf->wasmetal_core__DOT___043444_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___127734___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024846_));
    wasmetal_core__DOT___127524___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023233_) 
           & (IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___053557_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128799___O) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128798___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___127505___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b45__05d) 
           & (IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ecommon_totalUnderflow 
        = (1U & ((IData)(wasmetal_core__DOT___043032_)
                  ? ((IData)(wasmetal_core__DOT___043031_)
                      ? ((~ (IData)(vlSelf->wasmetal_core__DOT___043030_)) 
                         & (IData)(vlSelf->wasmetal_core__DOT___043027_))
                      : (IData)(wasmetal_core__DOT___043028_))
                  : ((IData)(wasmetal_core__DOT____Vcellout___128858___O) 
                     >> 2U)));
    wasmetal_core__DOT___128741___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035363_)
                  ? (IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0))));
    vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035654_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035597_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b41__05d));
    if (vlSelf->wasmetal_core__DOT___010064_) {
        vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d;
        vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__0__KET__;
    }
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h16107c49__0)))) {
        vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b37__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b37__05d;
        vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127734___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127734___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127524___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023234_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023233_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023232_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023231_)))) 
           ^ (((IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023294_)))));
    vlSelf->wasmetal_core__DOT___023298_ = ((IData)(vlSelf->wasmetal_core__DOT___023234_) 
                                            & (IData)(wasmetal_core__DOT___127524___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___042826_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053557_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(wasmetal_core__DOT___035953_))))));
    wasmetal_core__DOT___042814_ = (1U & (1U >> ((2U 
                                                  & ((~ (IData)(wasmetal_core__DOT___035953_)) 
                                                     << 1U)) 
                                                 | (IData)(wasmetal_core__DOT___053557_))));
    wasmetal_core__DOT___127505___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b46__05d) 
           & (IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___017780_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ecommon_totalUnderflow) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051535_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128741___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035364_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035363_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035362_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035361_)))) 
           ^ (((IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035306_)))));
    vlSelf->wasmetal_core__DOT___035310_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035364_)
                                                   ? (IData)(wasmetal_core__DOT___128741___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0))));
    vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
               >> 1U)) & (IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035655_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b42__05d));
    if (vlSelf->wasmetal_core__DOT___010059_) {
        vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d;
        vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h3d84b27a__0)))) {
        vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b38__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b38__05d;
        vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___127734___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127734___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005846_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127524___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005875_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2a096466__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2a096466__0))))));
    vlSelf->wasmetal_core__DOT___005702_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127524___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005745_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2a29372f__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2a29372f__0))))));
    vlSelf->wasmetal_core__DOT___005701_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127524___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005738_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2bad41f9__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2bad41f9__0))))));
    vlSelf->wasmetal_core__DOT___127525___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023236_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023298_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit 
        = ((IData)(vlSelf->wasmetal_core__DOT___042826_) 
           | (IData)(wasmetal_core__DOT___042814_));
    vlSelf->wasmetal_core__DOT____Vcellout___127505___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b47__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b46__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b45__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b44__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023090_)))));
    vlSelf->wasmetal_core__DOT___023094_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b47__05d) 
                                            & (IData)(wasmetal_core__DOT___127505___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___017785_ = (1U & (0x80888888U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128853___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017780_)))))));
    vlSelf->wasmetal_core__DOT___036825_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051539_))))));
    vlSelf->wasmetal_core__DOT___017480_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018504_))));
    vlSelf->wasmetal_core__DOT___017806_ = (1U & (0x700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051539_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(wasmetal_core__DOT____Vcellout___128857___O)))))));
}
