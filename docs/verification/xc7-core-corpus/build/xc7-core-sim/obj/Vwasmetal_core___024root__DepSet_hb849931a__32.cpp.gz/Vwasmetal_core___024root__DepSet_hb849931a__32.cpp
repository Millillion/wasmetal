#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__42(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__42\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___014770_;
    wasmetal_core__DOT___014770_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014805_;
    wasmetal_core__DOT___014805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014821_;
    wasmetal_core__DOT___014821_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015190_;
    wasmetal_core__DOT___015190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015210_;
    wasmetal_core__DOT___015210_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016558_;
    wasmetal_core__DOT___016558_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016567_;
    wasmetal_core__DOT___016567_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016571_;
    wasmetal_core__DOT___016571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016581_;
    wasmetal_core__DOT___016581_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016593_;
    wasmetal_core__DOT___016593_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016599_;
    wasmetal_core__DOT___016599_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016602_;
    wasmetal_core__DOT___016602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016606_;
    wasmetal_core__DOT___016606_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016615_;
    wasmetal_core__DOT___016615_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016627_;
    wasmetal_core__DOT___016627_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016639_;
    wasmetal_core__DOT___016639_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016647_;
    wasmetal_core__DOT___016647_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016653_;
    wasmetal_core__DOT___016653_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016654_;
    wasmetal_core__DOT___016654_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016671_;
    wasmetal_core__DOT___016671_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016675_;
    wasmetal_core__DOT___016675_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016683_;
    wasmetal_core__DOT___016683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016687_;
    wasmetal_core__DOT___016687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016700_;
    wasmetal_core__DOT___016700_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016701_;
    wasmetal_core__DOT___016701_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016709_;
    wasmetal_core__DOT___016709_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016717_;
    wasmetal_core__DOT___016717_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016721_;
    wasmetal_core__DOT___016721_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016728_;
    wasmetal_core__DOT___016728_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016732_;
    wasmetal_core__DOT___016732_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016739_;
    wasmetal_core__DOT___016739_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016755_;
    wasmetal_core__DOT___016755_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016763_;
    wasmetal_core__DOT___016763_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016767_;
    wasmetal_core__DOT___016767_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016774_;
    wasmetal_core__DOT___016774_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016778_;
    wasmetal_core__DOT___016778_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016779_;
    wasmetal_core__DOT___016779_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016786_;
    wasmetal_core__DOT___016786_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016794_;
    wasmetal_core__DOT___016794_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016800_;
    wasmetal_core__DOT___016800_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016808_;
    wasmetal_core__DOT___016808_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016812_;
    wasmetal_core__DOT___016812_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016819_;
    wasmetal_core__DOT___016819_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016823_;
    wasmetal_core__DOT___016823_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016831_;
    wasmetal_core__DOT___016831_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016835_;
    wasmetal_core__DOT___016835_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016843_;
    wasmetal_core__DOT___016843_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016847_;
    wasmetal_core__DOT___016847_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016854_;
    wasmetal_core__DOT___016854_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016858_;
    wasmetal_core__DOT___016858_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016865_;
    wasmetal_core__DOT___016865_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016869_;
    wasmetal_core__DOT___016869_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016876_;
    wasmetal_core__DOT___016876_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016880_;
    wasmetal_core__DOT___016880_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016887_;
    wasmetal_core__DOT___016887_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016891_;
    wasmetal_core__DOT___016891_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016898_;
    wasmetal_core__DOT___016898_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016902_;
    wasmetal_core__DOT___016902_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016909_;
    wasmetal_core__DOT___016909_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016913_;
    wasmetal_core__DOT___016913_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016914_;
    wasmetal_core__DOT___016914_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016921_;
    wasmetal_core__DOT___016921_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016929_;
    wasmetal_core__DOT___016929_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016941_;
    wasmetal_core__DOT___016941_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016949_;
    wasmetal_core__DOT___016949_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016957_;
    wasmetal_core__DOT___016957_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016961_;
    wasmetal_core__DOT___016961_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016968_;
    wasmetal_core__DOT___016968_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016972_;
    wasmetal_core__DOT___016972_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016973_;
    wasmetal_core__DOT___016973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016980_;
    wasmetal_core__DOT___016980_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016988_;
    wasmetal_core__DOT___016988_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016994_;
    wasmetal_core__DOT___016994_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017001_;
    wasmetal_core__DOT___017001_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017012_;
    wasmetal_core__DOT___017012_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017043_;
    wasmetal_core__DOT___017043_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017050_;
    wasmetal_core__DOT___017050_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017054_;
    wasmetal_core__DOT___017054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017062_;
    wasmetal_core__DOT___017062_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017066_;
    wasmetal_core__DOT___017066_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017067_;
    wasmetal_core__DOT___017067_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017075_;
    wasmetal_core__DOT___017075_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017083_;
    wasmetal_core__DOT___017083_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017089_;
    wasmetal_core__DOT___017089_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017096_;
    wasmetal_core__DOT___017096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017100_;
    wasmetal_core__DOT___017100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017108_;
    wasmetal_core__DOT___017108_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017116_;
    wasmetal_core__DOT___017116_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017123_;
    wasmetal_core__DOT___017123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017461_;
    wasmetal_core__DOT___017461_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017772_;
    wasmetal_core__DOT___017772_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017802_;
    wasmetal_core__DOT___017802_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018051_;
    wasmetal_core__DOT___018051_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018052_;
    wasmetal_core__DOT___018052_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018064_;
    wasmetal_core__DOT___018064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018071_;
    wasmetal_core__DOT___018071_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018072_;
    wasmetal_core__DOT___018072_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018077_;
    wasmetal_core__DOT___018077_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018156_;
    wasmetal_core__DOT___018156_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018223_;
    wasmetal_core__DOT___018223_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018224_;
    wasmetal_core__DOT___018224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018225_;
    wasmetal_core__DOT___018225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018227_;
    wasmetal_core__DOT___018227_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018245_;
    wasmetal_core__DOT___018245_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018247_;
    wasmetal_core__DOT___018247_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018286_;
    wasmetal_core__DOT___018286_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018369_;
    wasmetal_core__DOT___018369_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018370_;
    wasmetal_core__DOT___018370_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018371_;
    wasmetal_core__DOT___018371_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018373_;
    wasmetal_core__DOT___018373_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018429_;
    wasmetal_core__DOT___018429_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018532_;
    wasmetal_core__DOT___018532_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018640_;
    wasmetal_core__DOT___018640_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018643_;
    wasmetal_core__DOT___018643_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018718_;
    wasmetal_core__DOT___018718_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025402_;
    wasmetal_core__DOT___025402_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036108_;
    wasmetal_core__DOT___036108_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036112_;
    wasmetal_core__DOT___036112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036117_;
    wasmetal_core__DOT___036117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036121_;
    wasmetal_core__DOT___036121_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036125_;
    wasmetal_core__DOT___036125_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036128_;
    wasmetal_core__DOT___036128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036138_;
    wasmetal_core__DOT___036138_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036144_;
    wasmetal_core__DOT___036144_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036148_;
    wasmetal_core__DOT___036148_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036151_;
    wasmetal_core__DOT___036151_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036152_;
    wasmetal_core__DOT___036152_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036214_;
    wasmetal_core__DOT___036214_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036218_;
    wasmetal_core__DOT___036218_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036223_;
    wasmetal_core__DOT___036223_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036227_;
    wasmetal_core__DOT___036227_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036232_;
    wasmetal_core__DOT___036232_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036236_;
    wasmetal_core__DOT___036236_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036240_;
    wasmetal_core__DOT___036240_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036241_;
    wasmetal_core__DOT___036241_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036245_;
    wasmetal_core__DOT___036245_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036260_;
    wasmetal_core__DOT___036260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037138_;
    wasmetal_core__DOT___037138_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037144_;
    wasmetal_core__DOT___037144_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043012_;
    wasmetal_core__DOT___043012_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043014_;
    wasmetal_core__DOT___043014_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043015_;
    wasmetal_core__DOT___043015_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043016_;
    wasmetal_core__DOT___043016_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050291_;
    wasmetal_core__DOT___050291_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058118_;
    wasmetal_core__DOT___058118_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058119_;
    wasmetal_core__DOT___058119_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058138_;
    wasmetal_core__DOT___058138_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058139_;
    wasmetal_core__DOT___058139_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058624_;
    wasmetal_core__DOT___058624_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058973_;
    wasmetal_core__DOT___058973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058974_;
    wasmetal_core__DOT___058974_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059002_;
    wasmetal_core__DOT___059002_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059003_;
    wasmetal_core__DOT___059003_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059007_;
    wasmetal_core__DOT___059007_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059008_;
    wasmetal_core__DOT___059008_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059061_;
    wasmetal_core__DOT___059061_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059062_;
    wasmetal_core__DOT___059062_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059064_;
    wasmetal_core__DOT___059064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059579_;
    wasmetal_core__DOT___059579_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059603_;
    wasmetal_core__DOT___059603_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059604_;
    wasmetal_core__DOT___059604_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060193_;
    wasmetal_core__DOT___060193_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eencode32__02ein__05b30__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eencode32__02ein__05b30__05d = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow;
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b24__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b24__05d = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b25__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b25__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128810___O;
    wasmetal_core__DOT____Vcellout___128810___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128818___O;
    wasmetal_core__DOT____Vcellout___128818___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128820___O;
    wasmetal_core__DOT____Vcellout___128820___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128821___O;
    wasmetal_core__DOT____Vcellout___128821___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128822___O;
    wasmetal_core__DOT____Vcellout___128822___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128823___O;
    wasmetal_core__DOT____Vcellout___128823___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128824___O;
    wasmetal_core__DOT____Vcellout___128824___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128825___O;
    wasmetal_core__DOT____Vcellout___128825___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128826___O;
    wasmetal_core__DOT____Vcellout___128826___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128827___O;
    wasmetal_core__DOT____Vcellout___128827___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128829___O;
    wasmetal_core__DOT____Vcellout___128829___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128831___O;
    wasmetal_core__DOT____Vcellout___128831___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128833___O;
    wasmetal_core__DOT____Vcellout___128833___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128834___O;
    wasmetal_core__DOT____Vcellout___128834___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128835___O;
    wasmetal_core__DOT____Vcellout___128835___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128836___O;
    wasmetal_core__DOT____Vcellout___128836___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128837___O;
    wasmetal_core__DOT____Vcellout___128837___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128838___O;
    wasmetal_core__DOT____Vcellout___128838___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128839___O;
    wasmetal_core__DOT____Vcellout___128839___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128840___O;
    wasmetal_core__DOT____Vcellout___128840___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128841___O;
    wasmetal_core__DOT____Vcellout___128841___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134206___O;
    wasmetal_core__DOT____Vcellout___134206___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127772___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127772___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127772___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127772___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127773___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127773___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127773___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127773___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128810___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128810___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128820___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128820___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128820___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128820___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128820___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128820___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128821___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128821___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128821___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128821___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128821___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128821___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128822___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128822___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128822___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128822___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128822___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128822___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128824___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128824___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128824___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128824___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128824___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128824___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128825___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128825___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128825___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128825___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128825___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128825___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128826___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128826___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128826___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128826___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128826___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128826___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128827___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128827___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128827___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128827___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128829___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128829___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128829___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128829___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128829___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128829___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128830___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128830___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128830___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128830___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128830___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128830___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128831___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128831___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128831___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128831___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128831___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128831___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128835___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128835___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128835___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128835___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128836___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128836___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128836___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128836___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128836___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128836___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128837___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128837___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128837___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128837___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128837___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128837___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128838___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128838___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128838___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128838___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128838___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128838___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128839___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128839___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128839___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128839___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128839___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128839___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128840___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128840___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128840___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128840___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128840___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128840___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128841___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128841___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128841___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128841___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128841___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128841___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134206___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134206___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134206___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134206___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134207___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134207___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134207___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134207___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hf3e1ab91__0;
    __VdfgTmp_hf3e1ab91__0 = 0;
    CData/*4:0*/ __VdfgTmp_hbc941cc7__0;
    __VdfgTmp_hbc941cc7__0 = 0;
    CData/*4:0*/ __VdfgTmp_h4ef0e6f0__0;
    __VdfgTmp_h4ef0e6f0__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8cd84d2f__0;
    __VdfgTmp_h8cd84d2f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h166e2223__0;
    __VdfgTmp_h166e2223__0 = 0;
    CData/*5:0*/ __VdfgTmp_hf618fc36__0;
    __VdfgTmp_hf618fc36__0 = 0;
    CData/*4:0*/ __VdfgTmp_h75d85fc5__0;
    __VdfgTmp_h75d85fc5__0 = 0;
    CData/*2:0*/ __VdfgTmp_he63183d7__0;
    __VdfgTmp_he63183d7__0 = 0;
    CData/*2:0*/ __VdfgTmp_he967bd3f__0;
    __VdfgTmp_he967bd3f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h56377d30__0;
    __VdfgTmp_h56377d30__0 = 0;
    CData/*2:0*/ __VdfgTmp_h823d6b3b__0;
    __VdfgTmp_h823d6b3b__0 = 0;
    CData/*5:0*/ __VdfgTmp_h58253077__0;
    __VdfgTmp_h58253077__0 = 0;
    CData/*2:0*/ __VdfgTmp_hea8c747f__0;
    __VdfgTmp_hea8c747f__0 = 0;
    CData/*2:0*/ __VdfgTmp_hed321262__0;
    __VdfgTmp_hed321262__0 = 0;
    CData/*5:0*/ __VdfgTmp_hb9661308__0;
    __VdfgTmp_hb9661308__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc68349d0__0;
    __VdfgTmp_hc68349d0__0 = 0;
    CData/*3:0*/ __VdfgTmp_h5c0f2a5b__0;
    __VdfgTmp_h5c0f2a5b__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb9c3a66a__0;
    __VdfgTmp_hb9c3a66a__0 = 0;
    CData/*1:0*/ __VdfgTmp_hceb98761__0;
    __VdfgTmp_hceb98761__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9ccc8db2__0;
    __VdfgTmp_h9ccc8db2__0 = 0;
    CData/*2:0*/ __VdfgTmp_h29ce91ec__0;
    __VdfgTmp_h29ce91ec__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1bda1915__0;
    __VdfgTmp_h1bda1915__0 = 0;
    CData/*1:0*/ __VdfgTmp_h81ca6039__0;
    __VdfgTmp_h81ca6039__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbf2b62f5__0;
    __VdfgTmp_hbf2b62f5__0 = 0;
    CData/*2:0*/ __VdfgTmp_hdf63e4bf__0;
    __VdfgTmp_hdf63e4bf__0 = 0;
    CData/*2:0*/ __VdfgTmp_h0efadc80__0;
    __VdfgTmp_h0efadc80__0 = 0;
    CData/*2:0*/ __VdfgTmp_h4b6964fc__0;
    __VdfgTmp_h4b6964fc__0 = 0;
    CData/*2:0*/ __VdfgTmp_had793d18__0;
    __VdfgTmp_had793d18__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc3bb2a19__0;
    __VdfgTmp_hc3bb2a19__0 = 0;
    CData/*2:0*/ __VdfgTmp_h336c6eb7__0;
    __VdfgTmp_h336c6eb7__0 = 0;
    CData/*1:0*/ __VdfgTmp_h228f6e73__0;
    __VdfgTmp_h228f6e73__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1118b815__0;
    __VdfgTmp_h1118b815__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf67d9e80__0;
    __VdfgTmp_hf67d9e80__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5778fde6__0;
    __VdfgTmp_h5778fde6__0 = 0;
    CData/*4:0*/ __VdfgTmp_h9aeb2493__0;
    __VdfgTmp_h9aeb2493__0 = 0;
    CData/*1:0*/ __VdfgTmp_he0568e2c__0;
    __VdfgTmp_he0568e2c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6eb6be0b__0;
    __VdfgTmp_h6eb6be0b__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2e1acbd8__0;
    __VdfgTmp_h2e1acbd8__0 = 0;
    // Body
    wasmetal_core__DOT___058624_ = (1U & (0xc5U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0xf0f3355U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hcbc05328__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d)))));
    wasmetal_core__DOT___127772___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025472_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127772___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___017606_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014837_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7054d7e2__0))));
    vlSelf->wasmetal_core__DOT___036191_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015579_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9624abf4__0))));
    vlSelf->wasmetal_core__DOT___036082_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014837_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9624abf4__0))));
    vlSelf->__VdfgTmp_hd6a04253__0 = (((IData)(vlSelf->wasmetal_core__DOT___015574_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_ha028555e__0));
    vlSelf->__VdfgTmp_h3b293f2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014917_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_ha028555e__0));
    vlSelf->wasmetal_core__DOT___058121_ = ((0x10000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | ((8U 
                                                     & ((1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0)) 
                                                        << 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h786a2bba__0))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014813_));
    vlSelf->wasmetal_core__DOT___015221_ = ((4U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___015569_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf715e513__0)))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014778_));
    wasmetal_core__DOT___058119_ = ((0x10000000U >> 
                                     (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb0ec899f__0))))) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___014778_));
    vlSelf->__VdfgTmp_h92569eda__0 = (((IData)(vlSelf->wasmetal_core__DOT___015569_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014838_));
    vlSelf->__VdfgTmp_hdd2d87f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___014886_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014838_));
    vlSelf->__VdfgTmp_he686eaae__0 = (((IData)(vlSelf->wasmetal_core__DOT___015559_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058624_));
    vlSelf->__VdfgTmp_h8afeda64__0 = (((IData)(vlSelf->wasmetal_core__DOT___014845_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058624_));
    wasmetal_core__DOT___014821_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                           ? (0xf0f0ccaaU 
                                              >> (IData)(vlSelf->__VdfgTmp_hcbc05328__0))
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d))));
    vlSelf->wasmetal_core__DOT___058186_ = ((0x40U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058184_)))) 
                                            & (IData)(wasmetal_core__DOT___014821_));
    vlSelf->wasmetal_core__DOT___058122_ = ((0x10000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h8cb25dc3__0))))) 
                                            & (IData)(wasmetal_core__DOT___014821_));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        wasmetal_core__DOT___058138_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014987_)) 
                                              & (0xf0f0ccaaU 
                                                 >> (IData)(vlSelf->__VdfgTmp_hcbc05328__0))));
        wasmetal_core__DOT___014770_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___014772_));
    } else {
        wasmetal_core__DOT___058138_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014987_)) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d))));
        wasmetal_core__DOT___014770_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d)));
    }
    vlSelf->wasmetal_core__DOT___058187_ = ((0x4000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___058175_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc4af22e3__0))) 
                                            & (IData)(wasmetal_core__DOT___014770_));
    wasmetal_core__DOT___058118_ = ((0x1000000U >> 
                                     (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hfd58f84f__0))))) 
                                    & (IData)(wasmetal_core__DOT___014770_));
    wasmetal_core__DOT___127772___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025473_)
                  ? (IData)(wasmetal_core__DOT___127772___DOT__CO__BRA__1__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT____Vcellout___127772___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___025474_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___025473_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___025472_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025471_)))) 
           ^ (((IData)(wasmetal_core__DOT___127772___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127772___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127772___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025398_)))));
    wasmetal_core__DOT___025402_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025474_)
                                           ? (IData)(wasmetal_core__DOT___127772___DOT__CO__BRA__2__KET__)
                                           : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->__VdfgTmp_h4984bec9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127772___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc3230cc7__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc3230cc7__0)))))))));
    wasmetal_core__DOT___127773___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025475_)
                  ? (IData)(wasmetal_core__DOT___025402_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___058132_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014917_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___014772_)));
        vlSelf->wasmetal_core__DOT___014718_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127772___O) 
                                                        >> 2U)))
                                                    : 
                                                   (0x110fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h9f7a6ca7__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h9f7a6ca7__0)))) 
                                                            << 2U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014757_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___014756_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___058132_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014917_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d))));
        vlSelf->wasmetal_core__DOT___014718_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b50__05d)));
    }
    vlSelf->__VdfgTmp_h59ed23b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___015450_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014718_));
    vlSelf->__VdfgTmp_h75855164__0 = (((IData)(vlSelf->wasmetal_core__DOT___014719_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014718_));
    __VdfgTmp_h2e1acbd8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                               << 2U) | ((2U & ((0xf0f3355U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h4984bec9__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d)));
    vlSelf->wasmetal_core__DOT___015264_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127772___O) 
                                                        >> 3U)))
                                                    : 
                                                   (0x110fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf7faa60c__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf7faa60c__0)))) 
                                                            << 2U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014827_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___014826_))))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b51__05d))));
    vlSelf->__VdfgTmp_h7d39981d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015522_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015264_));
    vlSelf->__VdfgTmp_h1a8efff9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014720_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015264_));
    vlSelf->wasmetal_core__DOT___014928_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127772___O) 
                                                        >> 1U)))
                                                    : 
                                                   (0x110fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h7bf8c9f6__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h7bf8c9f6__0)))) 
                                                            << 2U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014792_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___014791_))))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b49__05d))));
    vlSelf->__VdfgTmp_h4e293e30__0 = (((IData)(vlSelf->wasmetal_core__DOT___015454_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014928_));
    vlSelf->wasmetal_core__DOT___014585_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058119_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058118_) 
                                                       << 3U) 
                                                      | ((((0x40000000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058107_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)))))))) 
                                                           & (IData)(vlSelf->wasmetal_core__DOT___014786_)) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014928_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x4000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058106_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d))))))))))));
    vlSelf->__VdfgTmp_h6dc90017__0 = (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014928_));
    wasmetal_core__DOT___127773___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025476_)
                  ? (IData)(wasmetal_core__DOT___127773___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->__VdfgTmp_hcec7f9ed__0 = (((IData)(vlSelf->wasmetal_core__DOT___015584_) 
                                       << 3U) | (IData)(__VdfgTmp_h2e1acbd8__0));
    vlSelf->__VdfgTmp_hfc02ca5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___014987_) 
                                       << 3U) | (IData)(__VdfgTmp_h2e1acbd8__0));
    wasmetal_core__DOT___014805_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                           ? (0xf0f0ccaaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h4984bec9__0))
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d))));
    vlSelf->wasmetal_core__DOT___058185_ = ((0x10000000U 
                                             >> ((0x10U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)) 
                                                     << 4U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)))))))) 
                                            & (IData)(wasmetal_core__DOT___014805_));
    vlSelf->wasmetal_core__DOT___058120_ = ((0x4000U 
                                             >> (IData)(vlSelf->__VdfgTmp_h89d6ed4e__0)) 
                                            & (IData)(wasmetal_core__DOT___014805_));
    vlSelf->wasmetal_core__DOT____Vcellout___127773___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___025479_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___025478_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___025476_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025475_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___025478_)
                       ? (IData)(wasmetal_core__DOT___127773___DOT__CO__BRA__1__KET__)
                       : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___127773___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___127773___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___025402_)))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        wasmetal_core__DOT___058139_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014982_)) 
                                              & (0xf0f0ccaaU 
                                                 >> (IData)(vlSelf->__VdfgTmp_h4984bec9__0))));
        if (vlSelf->wasmetal_core__DOT___005669_) {
            vlSelf->wasmetal_core__DOT___015394_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127773___O) 
                                    >> 2U))));
            vlSelf->wasmetal_core__DOT___014723_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127773___O) 
                                    >> 1U))));
            vlSelf->wasmetal_core__DOT___015523_ = 
                (1U & (1U >> (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127773___O))));
            vlSelf->wasmetal_core__DOT___014592_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127773___O) 
                                    >> 3U))));
        } else {
            vlSelf->wasmetal_core__DOT___015394_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hd481047b__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hd481047b__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014632_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014631_))))));
            vlSelf->wasmetal_core__DOT___014723_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h1c3d35c0__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h1c3d35c0__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014746_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014745_))))));
            vlSelf->wasmetal_core__DOT___015523_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hf5c220e3__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hf5c220e3__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014659_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014658_))))));
            vlSelf->wasmetal_core__DOT___014592_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_ha523ac5f__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_ha523ac5f__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014602_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014601_))))));
        }
    } else {
        wasmetal_core__DOT___058139_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014982_)) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d))));
        vlSelf->wasmetal_core__DOT___015394_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b54__05d)));
        vlSelf->wasmetal_core__DOT___014723_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b53__05d)));
        vlSelf->wasmetal_core__DOT___015523_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b52__05d)));
        vlSelf->wasmetal_core__DOT___014592_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b55__05d)));
    }
    vlSelf->wasmetal_core__DOT___058212_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                     ? 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___015454_)) 
                                                     & (0xf0f0ccaaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4984bec9__0)))
                                                     : 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___015454_)) 
                                                     & (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d))))) 
                                                  & (IData)(
                                                            (0xeee0eee0eee00000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015266_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015394_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015451_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015264_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014928_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___015450_))))))))));
    vlSelf->__VdfgTmp_h34f07943__0 = (((IData)(vlSelf->wasmetal_core__DOT___015263_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015394_));
    vlSelf->wasmetal_core__DOT___036092_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015394_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014722_))));
    vlSelf->wasmetal_core__DOT___014910_ = (1U & (IData)(
                                                         (0xfca8ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058139_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058138_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058108_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf8ffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015264_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015394_)))))))));
    vlSelf->__VdfgTmp_h71404310__0 = (((IData)(vlSelf->wasmetal_core__DOT___015262_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014723_));
    vlSelf->__VdfgTmp_h6f76189e__0 = ((2U & ((0xf8ffU 
                                              >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___014723_));
    vlSelf->wasmetal_core__DOT___014584_ = (1U & ((~ 
                                                   ((0x10000000U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0))))) 
                                                    & (IData)(vlSelf->wasmetal_core__DOT___014732_))) 
                                                  & ((~ 
                                                      ((0x40000000U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0)) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___058096_)))))) 
                                                       & (IData)(vlSelf->wasmetal_core__DOT___014740_))) 
                                                     & (IData)(
                                                               (0xefefefefef00efefULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___014723_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014722_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((0xf8ffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014720_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h75855164__0))))))))));
    vlSelf->__VdfgTmp_ha00e7863__0 = (((IData)(vlSelf->wasmetal_core__DOT___015451_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015523_));
    wasmetal_core__DOT___015210_ = (1U & (IData)((0xfbULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058187_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058186_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058185_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015523_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015262_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015451_)))))))));
    vlSelf->wasmetal_core__DOT___016553_ = (1U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___058216_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058215_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                ? 
                                                               ((~ (IData)(vlSelf->wasmetal_core__DOT___015584_)) 
                                                                & (0xf0f0ccaaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcbc05328__0)))
                                                                : 
                                                               ((~ (IData)(vlSelf->wasmetal_core__DOT___015584_)) 
                                                                & (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d)))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014723_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___015263_)))))) 
                                                  & (((~ 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___015574_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___014772_))
                                                         : 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___015574_)) 
                                                         & (2U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d))))) 
                                                      & (IData)(
                                                                (0xaaaf888cULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___015566_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015565_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014689_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014688_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014686_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___015564_))))))))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015464_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015463_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015462_) 
                                                                        << 3U) 
                                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___015534_)
                                                                             ? (IData)(vlSelf->wasmetal_core__DOT___015537_)
                                                                             : 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014588_) 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___015537_))) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & (((~ 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015526_)) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014926_))
                                                                                 : 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015526_)) 
                                                                                & (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d))))) 
                                                                                & (IData)(
                                                                                (0xeee0eee0eee00000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015262_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015523_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014718_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015134_))))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((~ 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015516_)) 
                                                                                & (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hadaed6e9__0)))
                                                                                 : 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015516_)) 
                                                                                & (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b21__05d))))) 
                                                                                & ((~ 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015511_)) 
                                                                                & (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5047773c__0)))
                                                                                 : 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015511_)) 
                                                                                & (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d))))) 
                                                                                & (IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015475_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015474_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015473_) 
                                                                                << 3U) 
                                                                                | ((((~ (IData)(vlSelf->wasmetal_core__DOT___015491_)) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___015409_)) 
                                                                                << 2U) 
                                                                                | ((((~ (IData)(vlSelf->wasmetal_core__DOT___015486_)) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___015361_)) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015481_)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? (IData)(
                                                                                (0xfff0fffcfff0fffaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015025_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015024_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b356604__0)))))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___015025_)))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h003f7a85__0 = ((2U & ((0xf8ffU 
                                              >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___015523_));
    vlSelf->wasmetal_core__DOT___017470_ = (1U & ((1U 
                                                   >> 
                                                   ((2U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                          ? 
                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___014850_)) 
                                                          & (IData)(vlSelf->wasmetal_core__DOT___014682_))
                                                          : 
                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___014850_)) 
                                                          & (2U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                           ? 
                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT___014845_)) 
                                                           & (0xf0f0ccaaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7c5b2a1d__0)))
                                                           : 
                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT___014845_)) 
                                                           & (2U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d))))))) 
                                                  & (IData)(
                                                            (0xe00000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014842_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014841_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014840_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((0xf8ffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___015523_))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014838_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___014837_))))))))));
    __VdfgTmp_h8cd84d2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___015428_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015427_)));
    vlSelf->wasmetal_core__DOT___036202_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015266_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014592_))));
    wasmetal_core__DOT___016599_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___015204_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014592_))));
    vlSelf->wasmetal_core__DOT___017498_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014593_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014592_))));
    vlSelf->wasmetal_core__DOT___036093_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058108_))));
    vlSelf->wasmetal_core__DOT___016552_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058213_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058212_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058211_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfc00aaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058207_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058206_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xfc00aaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017072_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058205_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058204_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfc00aaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017105_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058203_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058202_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d)))))))))))))));
    __VdfgTmp_h4ef0e6f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015395_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014928_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015266_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_h34f07943__0))));
    vlSelf->wasmetal_core__DOT___017469_ = (((IData)(vlSelf->wasmetal_core__DOT___015134_) 
                                             & ((IData)(vlSelf->wasmetal_core__DOT___015133_) 
                                                & (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015132_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015131_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015130_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015129_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015128_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___015127_)))))))))) 
                                            & (((IData)(vlSelf->wasmetal_core__DOT___015062_) 
                                                & (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015061_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015060_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015059_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015058_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015057_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___015056_))))))))) 
                                               & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014911_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014910_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014909_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___014931_)) 
                                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT___014930_)) 
                                                                            & (IData)(
                                                                                (0xaaaf888cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014929_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014928_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014689_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014719_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014927_)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfca8ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058133_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058132_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014723_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014718_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014720_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014722_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___014588_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014593_))))))))))))));
    __VdfgTmp_hbc941cc7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015265_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015264_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015263_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_h71404310__0))));
    vlSelf->wasmetal_core__DOT___017473_ = (1U & ((IData)(
                                                          (0xfdULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___058122_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058121_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058120_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015264_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014720_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (0xf8ffU 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)))))))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014585_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014584_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014583_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0xaf8cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058114_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058113_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((0xf8ffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf8ffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058108_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015523_)))))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((IData)(
                                                                                (0xfdULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058111_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058110_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015394_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058108_)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & ((1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005670_))))
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___014593_)
                                                                                 ? 
                                                                                (0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7eb9770e__0)))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___014589_)))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___014593_)
                                                                                 ? (IData)(
                                                                                (0xaaaaaaaa3f3f3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014591_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014590_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7eb9770e__0)))))))
                                                                                 : 
                                                                                (0x777fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014591_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014590_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014589_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___016551_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058200_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058199_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015058_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015059_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___016668_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xfff01110U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015056_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9c126c52__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                              ? 
                                                                             (0xfff00bbU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___014872_) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h8cd84d2f__0))))
                                                                              : 
                                                                             (0xff0fbb00U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h8cd84d2f__0))))))))))))));
    vlSelf->__VdfgTmp_h605612ae__0 = (((IData)(wasmetal_core__DOT___016599_) 
                                       << 1U) | (1U 
                                                 & (0xc5U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h09c9c684__0))));
    wasmetal_core__DOT___036128_ = (1U & (0xc500U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017498_) 
                                            << 3U) 
                                           | (IData)(vlSelf->__VdfgTmp_h069b89c3__0))));
    wasmetal_core__DOT___015190_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014592_)
                                           ? (IData)(
                                                     (0xcc0c5505ff0fff0fULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015204_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015203_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015202_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014872_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d))))))))
                                           : (0xdU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015203_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015202_)))));
    vlSelf->wasmetal_core__DOT___016554_ = (1U & ((IData)(
                                                          (0xfff0fff01111ffffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___016644_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015056_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h42abc930__0))))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___015190_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015189_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015188_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0xeeeef0ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___015516_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016805_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014992_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he6b298f6__0))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((0xfff0bbbbU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___016840_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016828_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015130_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015531_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015062_)))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (0xfff0bbbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015501_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015481_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015132_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016760_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014998_))))))))))))))));
    __VdfgTmp_he63183d7__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014589_)));
    __VdfgTmp_he967bd3f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014944_)));
    __VdfgTmp_h56377d30__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014896_)));
    __VdfgTmp_h823d6b3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014860_)));
    __VdfgTmp_hea8c747f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | 
                                         (1U & (0x80ffU 
                                                >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)))));
    __VdfgTmp_hed321262__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | 
                                         (1U & (0x80ffU 
                                                >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)))));
    vlSelf->__VdfgTmp_h624ea096__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014850_)));
    vlSelf->__VdfgTmp_h44742984__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014891_)));
    vlSelf->__VdfgTmp_hb82ac2db__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014901_)));
    vlSelf->__VdfgTmp_h703c2d50__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014927_)));
    vlSelf->__VdfgTmp_hb3e763f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014873_)));
    vlSelf->__VdfgTmp_h0a1cab09__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014881_)));
    vlSelf->__VdfgTmp_h98026846__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014886_)));
    vlSelf->__VdfgTmp_h9f21faf7__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014837_)));
    vlSelf->__VdfgTmp_hba893859__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014917_)));
    vlSelf->__VdfgTmp_h9bcd87c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014845_)));
    vlSelf->__VdfgTmp_h6331a531__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014987_)));
    vlSelf->__VdfgTmp_h155f9d55__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014982_)));
    vlSelf->__VdfgTmp_hb895011c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014719_)));
    vlSelf->__VdfgTmp_heacb01d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014720_)));
    vlSelf->wasmetal_core__DOT___016555_ = (1U & ((1U 
                                                   >> 
                                                   ((8U 
                                                     & (((0x80U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha1ddff2b__0))) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                             ? (IData)(
                                                                       (0xfff0fffcfff0fffaULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015078_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015077_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1a5afed0__0)))))))
                                                             : 
                                                            (2U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___015078_)))) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & (((0x4000U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0)) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___058096_))))) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                ? (IData)(
                                                                          (0xfff0fffcfff0fffaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015032_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015031_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h210df1ee__0)))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___015032_)))) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (((0x80U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))) 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                   ? (IData)(
                                                                             (0xfff0fff3fff0fffaULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015096_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015095_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h39f326f7__0)))))))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015096_)))) 
                                                              << 1U)) 
                                                          | ((0x4000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_ha1ddff2b__0)))) 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___015409_)))))) 
                                                  & (((~ 
                                                       ((0x4000U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058183_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___058098_))))) 
                                                        & (IData)(vlSelf->wasmetal_core__DOT___014813_))) 
                                                      & ((1U 
                                                          & (4U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015522_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015450_))))
                                                          ? (IData)(
                                                                    (0xef00efef00000000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___014718_) 
                                                                       << 5U) 
                                                                      | (IData)(__VdfgTmp_h4ef0e6f0__0))))
                                                          : 
                                                         (0xef00efefU 
                                                          >> (IData)(__VdfgTmp_h4ef0e6f0__0)))) 
                                                     & (IData)(
                                                               (0x4000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015212_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015211_) 
                                                                     << 4U) 
                                                                    | (((IData)(wasmetal_core__DOT___015210_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (((~ 
                                                                                ((0x10000000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h124450b0__0)))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014626_))) 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT___015266_)
                                                                                 ? 
                                                                                (0xef00efefU 
                                                                                >> (IData)(__VdfgTmp_hbc941cc7__0))
                                                                                 : (IData)(
                                                                                (0xef00efef00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 5U) 
                                                                                | (IData)(__VdfgTmp_hbc941cc7__0)))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & (((~ 
                                                                                ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015569_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb78750ce__0))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014645_))) 
                                                                                & (IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015223_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015222_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015221_) 
                                                                                << 3U) 
                                                                                | ((((0x10000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc2843286__0))))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014680_)) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((0x8000U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xf8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058156_))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfd6d7e7__0))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d)))) 
                                                                                << 1U)) 
                                                                                | ((0x80000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058156_)))))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014653_)))))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0x13135f0000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015204_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015432_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014592_)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___058153_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017473_)))));
    wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h605612ae__0))) 
                 & (7U >> (IData)(vlSelf->__VdfgTmp_hc0955a68__0))));
    wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___036128_)) 
                 & (7U >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0))));
    vlSelf->wasmetal_core__DOT___058217_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016555_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016554_))));
    wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036176_) 
           & (IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036094_) 
           & (IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___058218_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058217_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128828___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_hd5ff8c3b__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036176_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hc0955a68__0)) 
                                                << 1U)) 
                                         | (1U & (8U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h605612ae__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h605612ae__0))) 
                                          << 1U)))));
    wasmetal_core__DOT___036241_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hd5ff8c3b__0)) 
                                    & (IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128817___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036094_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0)) 
                                                << 1U)) 
                                         | (IData)(wasmetal_core__DOT___036128_)))) 
           ^ (((IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(wasmetal_core__DOT___036128_)) 
                                          << 1U)))));
    wasmetal_core__DOT___036121_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0)) 
                                    & (IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___016602_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___016599_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016593_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016558_ = (1U & (0xd5555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hefd4f1fe__0)) 
           & (IData)(wasmetal_core__DOT___036241_));
    vlSelf->wasmetal_core__DOT___058948_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                               << 3U)) 
                                                           | ((8U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0)) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___017498_)))))))));
    vlSelf->wasmetal_core__DOT___058942_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017471_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_he63183d7__0)))))));
    wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036096_) 
           & (IData)(wasmetal_core__DOT___036121_));
    wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036203_) 
           & (IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___017473_) {
        vlSelf->wasmetal_core__DOT___058949_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017471_))));
        vlSelf->wasmetal_core__DOT___058943_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___058949_ = (1U 
                                                & (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                           << 1U)) 
                                                       | (IData)(__VdfgTmp_he63183d7__0)))));
        vlSelf->wasmetal_core__DOT___058943_ = (1U 
                                                & (0x7f00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O)) 
                                                       | (IData)(__VdfgTmp_he967bd3f__0)))));
    }
    vlSelf->__VdfgTmp_h74f09674__0 = (((IData)(vlSelf->wasmetal_core__DOT___058942_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058943_));
    wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036097_) 
           & (IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___016555_) {
        if (vlSelf->wasmetal_core__DOT___016554_) {
            vlSelf->wasmetal_core__DOT___058563_ = 
                (1U & (1U >> (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hc0955a68__0)))));
            vlSelf->wasmetal_core__DOT___016585_ = 
                (1U & (1U >> (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___058137_))))));
        } else {
            vlSelf->wasmetal_core__DOT___058563_ = 
                (1U & (IData)(wasmetal_core__DOT___016602_));
            vlSelf->wasmetal_core__DOT___016585_ = 
                (1U & (IData)(wasmetal_core__DOT___016593_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___058563_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016602_));
        vlSelf->wasmetal_core__DOT___016585_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016593_));
    }
    vlSelf->__VdfgTmp_h4cc4790a__0 = (((IData)(vlSelf->wasmetal_core__DOT___058563_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016585_));
    vlSelf->wasmetal_core__DOT___016586_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd5ff8c3b__0))))
                                                    : (IData)(wasmetal_core__DOT___016558_))
                                                   : (IData)(wasmetal_core__DOT___016558_)));
    vlSelf->__VdfgTmp_h6047dcd2__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___016585_))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___016586_)))));
    wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1cf51478__0)) 
           & (IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036098_) 
           & (IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128833___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3aabb4dd__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1cf51478__0)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036203_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hefd4f1fe__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036241_)))));
    wasmetal_core__DOT___036260_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h3aabb4dd__0)) 
                                    & (IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128818___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)) 
                                                        << 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___036098_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036097_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036096_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036121_)))));
    wasmetal_core__DOT___036125_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)) 
                                    & (IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___016567_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016564_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128833___O))))))));
    wasmetal_core__DOT___016581_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128833___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016647_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016644_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128833___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016615_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128833___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h9711c1d2__0)) 
           & (IData)(wasmetal_core__DOT___036260_));
    vlSelf->__VdfgTmp_ha3f8ca93__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff007f7f0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                           << 1U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0)) 
                                                              << 3U)) 
                                                          | (IData)(__VdfgTmp_he967bd3f__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017513_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                             << 3U)) 
                                                         | (IData)(__VdfgTmp_h56377d30__0)))))));
    vlSelf->__VdfgTmp_ha61a6e02__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                           << 4U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017513_) 
                                                           << 3U) 
                                                          | (IData)(__VdfgTmp_h56377d30__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017527_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                             << 2U)) 
                                                         | (IData)(__VdfgTmp_h823d6b3b__0)))))));
    vlSelf->__VdfgTmp_hac5f758c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017527_) 
                                                           << 3U) 
                                                          | (IData)(__VdfgTmp_h823d6b3b__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017544_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                             << 1U)) 
                                                         | (IData)(__VdfgTmp_hea8c747f__0)))))));
    vlSelf->__VdfgTmp_h6c11e1cc__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017544_) 
                                                           << 3U) 
                                                          | (IData)(__VdfgTmp_hea8c747f__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128818___O)) 
                                                         | (IData)(__VdfgTmp_hed321262__0)))))));
    vlSelf->wasmetal_core__DOT___058985_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                               << 1U)) 
                                                           | ((8U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)) 
                                                                  << 3U)) 
                                                              | (IData)(__VdfgTmp_hed321262__0)))))));
    wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036100_) 
           & (IData)(wasmetal_core__DOT___036125_));
    wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h84efc1e5__0)) 
           & (IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hc81f4faf__0)) 
           & (IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___016555_) {
        if (vlSelf->wasmetal_core__DOT___016554_) {
            vlSelf->wasmetal_core__DOT___016572_ = 
                (1U & (1U >> (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hefd4f1fe__0)))));
            wasmetal_core__DOT___016571_ = (1U & (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xe0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9c126c52__0)))));
        } else {
            vlSelf->wasmetal_core__DOT___016572_ = 
                (1U & (IData)(wasmetal_core__DOT___016567_));
            wasmetal_core__DOT___016571_ = (1U & (IData)(wasmetal_core__DOT___016581_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___016572_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016567_));
        wasmetal_core__DOT___016571_ = (1U & (IData)(wasmetal_core__DOT___016581_));
    }
    vlSelf->__VdfgTmp_h52207b53__0 = (((IData)(vlSelf->wasmetal_core__DOT___016572_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016571_));
    wasmetal_core__DOT___016639_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1cf51478__0))))
                                               : (IData)(wasmetal_core__DOT___016647_))
                                           : (IData)(wasmetal_core__DOT___016647_)));
    vlSelf->__VdfgTmp_hc5bb64fc__0 = (((IData)(wasmetal_core__DOT___016571_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016639_));
    vlSelf->wasmetal_core__DOT___016607_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3aabb4dd__0))))
                                                    : (IData)(wasmetal_core__DOT___016615_))
                                                   : (IData)(wasmetal_core__DOT___016615_)));
    vlSelf->__VdfgTmp_he0d8c702__0 = (((IData)(wasmetal_core__DOT___016639_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016607_));
    wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1cfd4ffd__0)) 
           & (IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036078_) 
           & (IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128834___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hee3b5d3c__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1cfd4ffd__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h84efc1e5__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h9711c1d2__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036260_)))));
    vlSelf->wasmetal_core__DOT___036210_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hee3b5d3c__0)) 
                                            & (IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128819___O 
        = (((8U & ((0x3affU >> (IData)(vlSelf->__VdfgTmp_h40a80dc0__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036078_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hc81f4faf__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___036100_)))) 
           ^ (((IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036125_)))));
    vlSelf->wasmetal_core__DOT___036104_ = ((0x3affU 
                                             >> (IData)(vlSelf->__VdfgTmp_h40a80dc0__0)) 
                                            & (IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___016623_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015435_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___128834___O))))))));
    vlSelf->wasmetal_core__DOT___016635_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016632_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128834___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___016694_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015491_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128834___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___016662_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128834___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128835___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1f9a82f6__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036210_));
    wasmetal_core__DOT___058973_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                    & (IData)((0xff00ff00bfbf0000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017569_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h624ea096__0)))))));
    vlSelf->__VdfgTmp_h15aa6b6f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                           << 3U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc81f4faf__0)) 
                                                              << 3U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h44742984__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017660_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb82ac2db__0)))))));
    vlSelf->__VdfgTmp_hdb9ea8ba__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017660_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb82ac2db__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x3a00U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h40a80dc0__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h703c2d50__0)))))));
    wasmetal_core__DOT___128820___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_had382f57__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036104_));
    wasmetal_core__DOT___128835___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h2a76d0fc__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128835___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___058986_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                   ? 
                                                  (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017569_)))
                                                   : 
                                                  (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                           << 3U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h624ea096__0))))));
    vlSelf->__VdfgTmp_hcb62e82f__0 = (((IData)(vlSelf->wasmetal_core__DOT___058985_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058986_));
    wasmetal_core__DOT___058974_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                           ? (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (1U 
                                                  & (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hc81f4faf__0)))))
                                           : (0xbf00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                         << 2U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h44742984__0))))));
    vlSelf->__VdfgTmp_h7385dfc5__0 = (((IData)(wasmetal_core__DOT___058973_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058974_));
    wasmetal_core__DOT___128820___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hdd2d87f1__0)) 
           & (IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___016606_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9711c1d2__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___016623_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___016623_)));
    vlSelf->__VdfgTmp_h27d7faf5__0 = (((IData)(vlSelf->wasmetal_core__DOT___016607_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016606_));
    wasmetal_core__DOT___016627_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h84efc1e5__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___016635_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___016635_)));
    vlSelf->__VdfgTmp_h04ff9270__0 = (((IData)(wasmetal_core__DOT___016606_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016627_));
    wasmetal_core__DOT___016687_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1cfd4ffd__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___016694_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___016694_)));
    vlSelf->__VdfgTmp_hb1afd8c5__0 = (((IData)(wasmetal_core__DOT___016627_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016687_));
    wasmetal_core__DOT___016654_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hee3b5d3c__0))))
                                               : (IData)(vlSelf->wasmetal_core__DOT___016662_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___016662_)));
    vlSelf->__VdfgTmp_h5f559dac__0 = (((IData)(wasmetal_core__DOT___016687_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016654_));
    wasmetal_core__DOT___128835___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hdbf08427__0)) 
           & (IData)(wasmetal_core__DOT___128835___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128820___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036082_) 
           & (IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128835___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1758afa1__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hdbf08427__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2a76d0fc__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1f9a82f6__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128835___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128835___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128835___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036210_)))));
    wasmetal_core__DOT___036214_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h1758afa1__0)) 
                                    & (IData)(wasmetal_core__DOT___128835___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128820___O = (
                                                   ((8U 
                                                     & ((0x3affU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3b293f2f__0)) 
                                                        << 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___036082_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdd2d87f1__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_had382f57__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036104_)))));
    wasmetal_core__DOT___036108_ = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_h3b293f2f__0)) 
                                    & (IData)(wasmetal_core__DOT___128820___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___016671_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016668_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128835___O))))))));
    wasmetal_core__DOT___016683_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016680_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128835___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016739_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015486_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128835___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016709_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016706_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128835___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128836___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hb48d784b__0)) 
           & (IData)(wasmetal_core__DOT___036214_));
    vlSelf->__VdfgTmp_hea1901c2__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                           << 1U)) 
                                                       | ((8U 
                                                           & ((0x3a00U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h40a80dc0__0)) 
                                                              << 3U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h703c2d50__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_had382f57__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb3e763f1__0)))))));
    vlSelf->__VdfgTmp_h214cf44d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                           << 4U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_had382f57__0)) 
                                                              << 3U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb3e763f1__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hdd2d87f1__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0a1cab09__0)))))));
    vlSelf->__VdfgTmp_h11c34da7__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                           << 3U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdd2d87f1__0)) 
                                                              << 3U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h0a1cab09__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017606_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h98026846__0)))))));
    vlSelf->__VdfgTmp_hdf3a557f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017606_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h98026846__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x3a00U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h3b293f2f__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128820___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9f21faf7__0)))))));
    wasmetal_core__DOT___059007_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                    & (IData)((0xff00ff00bfbf0000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128820___O) 
                                                          << 1U)) 
                                                      | ((8U 
                                                          & ((0x3a00U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3b293f2f__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9f21faf7__0)))))));
    wasmetal_core__DOT___128821___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h8afeda64__0)) 
           & (IData)(wasmetal_core__DOT___036108_));
    wasmetal_core__DOT___128836___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hf4473e75__0)) 
           & (IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128821___DOT__CO__BRA__1__KET__ 
        = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hfc02ca5b__0)) 
           & (IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___016653_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1f9a82f6__0))))
                                               : (IData)(wasmetal_core__DOT___016671_))
                                           : (IData)(wasmetal_core__DOT___016671_)));
    vlSelf->__VdfgTmp_hfa0a9622__0 = (((IData)(wasmetal_core__DOT___016654_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016653_));
    wasmetal_core__DOT___016675_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2a76d0fc__0))))
                                               : (IData)(wasmetal_core__DOT___016683_))
                                           : (IData)(wasmetal_core__DOT___016683_)));
    vlSelf->__VdfgTmp_hfccc26d7__0 = (((IData)(wasmetal_core__DOT___016653_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016675_));
    wasmetal_core__DOT___016732_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hdbf08427__0))))
                                               : (IData)(wasmetal_core__DOT___016739_))
                                           : (IData)(wasmetal_core__DOT___016739_)));
    vlSelf->__VdfgTmp_h6fb1c908__0 = (((IData)(wasmetal_core__DOT___016675_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016732_));
    wasmetal_core__DOT___016701_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1758afa1__0))))
                                               : (IData)(wasmetal_core__DOT___016709_))
                                           : (IData)(wasmetal_core__DOT___016709_)));
    vlSelf->__VdfgTmp_h23178df2__0 = (((IData)(wasmetal_core__DOT___016732_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016701_));
    wasmetal_core__DOT___128836___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h112e4f0e__0)) 
           & (IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128821___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h6dc90017__0)) 
           & (IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128836___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he6b298f6__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h112e4f0e__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf4473e75__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb48d784b__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036214_)))));
    wasmetal_core__DOT___036218_ = ((7U >> (IData)(vlSelf->__VdfgTmp_he6b298f6__0)) 
                                    & (IData)(wasmetal_core__DOT___128836___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128821___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h75855164__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6dc90017__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((0x3affU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc02ca5b__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8afeda64__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036108_)))));
    wasmetal_core__DOT___036112_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h75855164__0)) 
                                    & (IData)(wasmetal_core__DOT___128821___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___016717_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015481_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128836___O))))))));
    wasmetal_core__DOT___016728_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015501_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128836___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016763_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016760_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128836___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016774_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015511_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128836___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128837___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h4ee6c9c0__0)) 
           & (IData)(wasmetal_core__DOT___036218_));
    wasmetal_core__DOT___059002_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                    & (IData)((0xff00ff00bfbf0000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8afeda64__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hba893859__0)))))));
    __VdfgTmp_he0568e2c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                & (IData)((0xff00ff00bfbf0000ULL 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                << 5U) 
                                               | ((0x10U 
                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                      << 3U)) 
                                                  | ((8U 
                                                      & ((0x3a00U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hfc02ca5b__0)) 
                                                         << 3U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h9bcd87c8__0))))))) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                ? (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h6dc90017__0)))))
                                                : (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h6331a531__0)))))));
    vlSelf->__VdfgTmp_h64c7108d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                           << 2U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6dc90017__0)) 
                                                              << 3U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6331a531__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h75855164__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128821___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h155f9d55__0)))))));
    vlSelf->wasmetal_core__DOT___059047_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                               << 1U)) 
                                                           | ((8U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h75855164__0)) 
                                                                  << 3U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h155f9d55__0)))))));
    wasmetal_core__DOT___128822___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1a8efff9__0)) 
           & (IData)(wasmetal_core__DOT___036112_));
    wasmetal_core__DOT___128837___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h8a1979d6__0)) 
           & (IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___059008_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                           ? (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (1U 
                                                  & (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h8afeda64__0)))))
                                           : (0xbf00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                         << 3U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_hba893859__0))))));
    vlSelf->__VdfgTmp_hc369107b__0 = (((IData)(wasmetal_core__DOT___059007_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___059008_));
    wasmetal_core__DOT___059003_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                           ? (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (1U 
                                                  & (0x3a00U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hfc02ca5b__0)))))
                                           : (0xbf00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___128821___O) 
                                                         << 2U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h9bcd87c8__0))))));
    vlSelf->__VdfgTmp_h5cb81b0a__0 = (((IData)(wasmetal_core__DOT___059002_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___059003_));
    wasmetal_core__DOT___128822___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h003f7a85__0)) 
           & (IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___016700_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hb48d784b__0))))
                                               : (IData)(wasmetal_core__DOT___016717_))
                                           : (IData)(wasmetal_core__DOT___016717_)));
    vlSelf->__VdfgTmp_hdbda1ab6__0 = (((IData)(wasmetal_core__DOT___016701_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016700_));
    wasmetal_core__DOT___016721_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf4473e75__0))))
                                               : (IData)(wasmetal_core__DOT___016728_))
                                           : (IData)(wasmetal_core__DOT___016728_)));
    vlSelf->__VdfgTmp_h2d6cb346__0 = (((IData)(wasmetal_core__DOT___016700_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016721_));
    wasmetal_core__DOT___016755_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h112e4f0e__0))))
                                               : (IData)(wasmetal_core__DOT___016763_))
                                           : (IData)(wasmetal_core__DOT___016763_)));
    vlSelf->__VdfgTmp_hefec7bb7__0 = (((IData)(wasmetal_core__DOT___016721_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016755_));
    wasmetal_core__DOT___016767_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he6b298f6__0))))
                                               : (IData)(wasmetal_core__DOT___016774_))
                                           : (IData)(wasmetal_core__DOT___016774_)));
    vlSelf->__VdfgTmp_h8b17c158__0 = (((IData)(wasmetal_core__DOT___016755_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016767_));
    wasmetal_core__DOT___128837___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hc38ac7a3__0)) 
           & (IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128822___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h6f76189e__0)) 
           & (IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128837___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hebdd5702__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc38ac7a3__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8a1979d6__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4ee6c9c0__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036218_)))));
    wasmetal_core__DOT___036223_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hebdd5702__0)) 
                                    & (IData)(wasmetal_core__DOT___128837___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128822___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___036092_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6f76189e__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h003f7a85__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1a8efff9__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036112_)))));
    wasmetal_core__DOT___036117_ = ((IData)(vlSelf->wasmetal_core__DOT___036092_) 
                                    & (IData)(wasmetal_core__DOT___128822___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___016786_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015506_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128837___O))))))));
    wasmetal_core__DOT___016794_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015516_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128837___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016808_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016805_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128837___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016819_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015496_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128837___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128838___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h0e9f92ff__0)) 
           & (IData)(wasmetal_core__DOT___036223_));
    vlSelf->wasmetal_core__DOT___059052_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128822___O) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1a8efff9__0)) 
                                                                  << 3U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb895011c__0)))))));
    wasmetal_core__DOT___059061_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                    & (IData)((0xff00ff00bfbf0000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128822___O) 
                                                          << 3U)) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h003f7a85__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_heacb01d3__0)))))));
    __VdfgTmp_h5c0f2a5b__0 = ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128822___O) 
                                     << 1U)) | (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf8ffU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0))))));
    if (vlSelf->wasmetal_core__DOT___017473_) {
        vlSelf->wasmetal_core__DOT___059046_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h1a8efff9__0))))));
        vlSelf->wasmetal_core__DOT___059051_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h003f7a85__0))))));
        wasmetal_core__DOT___018071_ = (1U & (1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (1U 
                                                  & (4U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014722_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___015394_)))))));
        wasmetal_core__DOT___059062_ = (1U & (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (1U 
                                                  & (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h6f76189e__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___059046_ = (1U 
                                                & (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128822___O) 
                                                           << 3U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb895011c__0)))));
        vlSelf->wasmetal_core__DOT___059051_ = (1U 
                                                & (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128822___O) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_heacb01d3__0)))));
        wasmetal_core__DOT___018071_ = (1U & (0x40ffU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & (IData)(wasmetal_core__DOT____Vcellout___128822___O)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (0xf8ffU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)))))))));
        wasmetal_core__DOT___059062_ = (1U & (0xbf00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                   << 4U) 
                                                  | (IData)(__VdfgTmp_h5c0f2a5b__0))));
    }
    wasmetal_core__DOT____Vcellout___128823___O = ((IData)(vlSelf->wasmetal_core__DOT___036093_) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___036093_) 
                                                      & (IData)(wasmetal_core__DOT___036117_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___036117_)));
    wasmetal_core__DOT___128838___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h645aaafb__0)) 
           & (IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h4ab5d99d__0 = (((IData)(vlSelf->wasmetal_core__DOT___059052_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___059051_));
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b25__05d 
        = (1U & (0xb00U >> ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128823___O) 
                                   << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058153_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___058108_))))));
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b24__05d 
        = (1U & (IData)((0x30303030aaff0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128823___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058153_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058108_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014722_)))))))));
    wasmetal_core__DOT___016779_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h4ee6c9c0__0))))
                                               : (IData)(wasmetal_core__DOT___016786_))
                                           : (IData)(wasmetal_core__DOT___016786_)));
    vlSelf->__VdfgTmp_h83a58712__0 = (((IData)(wasmetal_core__DOT___016767_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016779_));
    wasmetal_core__DOT___016778_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8a1979d6__0))))
                                               : (IData)(wasmetal_core__DOT___016794_))
                                           : (IData)(wasmetal_core__DOT___016794_)));
    vlSelf->__VdfgTmp_h44d9a03d__0 = (((IData)(wasmetal_core__DOT___016779_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016778_));
    wasmetal_core__DOT___016800_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hc38ac7a3__0))))
                                               : (IData)(wasmetal_core__DOT___016808_))
                                           : (IData)(wasmetal_core__DOT___016808_)));
    vlSelf->__VdfgTmp_hc66d6698__0 = (((IData)(wasmetal_core__DOT___016778_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016800_));
    wasmetal_core__DOT___016812_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hebdd5702__0))))
                                               : (IData)(wasmetal_core__DOT___016819_))
                                           : (IData)(wasmetal_core__DOT___016819_)));
    vlSelf->__VdfgTmp_hc9aeb4c0__0 = (((IData)(wasmetal_core__DOT___016800_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016812_));
    wasmetal_core__DOT___128838___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h6560f9f5__0)) 
           & (IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__1__KET__));
    __VdfgTmp_h6eb6be0b__0 = (((IData)(wasmetal_core__DOT___059061_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059062_));
    wasmetal_core__DOT___036152_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b25__05d))));
    wasmetal_core__DOT___036151_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b24__05d))));
    wasmetal_core__DOT____Vcellout___128838___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbe619ad7__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6560f9f5__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h645aaafb__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h0e9f92ff__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036223_)))));
    wasmetal_core__DOT___036227_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hbe619ad7__0)) 
                                    & (IData)(wasmetal_core__DOT___128838___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128824___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036151_)) 
           & (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b24__05d));
    wasmetal_core__DOT___016831_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016828_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128838___O))))))));
    wasmetal_core__DOT___016843_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016840_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128838___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016854_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015531_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128838___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016865_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128838___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128839___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h0abefb0b__0)) 
           & (IData)(wasmetal_core__DOT___036227_));
    wasmetal_core__DOT___128824___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036152_) ? (IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__0__KET__)
            : (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02egenblk2__02eroundedSig__05b25__05d));
    wasmetal_core__DOT___128839___DOT__CO__BRA__1__KET__ 
        = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hacb35d4c__0)) 
           & (IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128824___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
           & (IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___016823_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h0e9f92ff__0))))
                                               : (IData)(wasmetal_core__DOT___016831_))
                                           : (IData)(wasmetal_core__DOT___016831_)));
    vlSelf->__VdfgTmp_hfbf01d74__0 = (((IData)(wasmetal_core__DOT___016812_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016823_));
    wasmetal_core__DOT___016835_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h645aaafb__0))))
                                               : (IData)(wasmetal_core__DOT___016843_))
                                           : (IData)(wasmetal_core__DOT___016843_)));
    vlSelf->__VdfgTmp_h5865698c__0 = (((IData)(wasmetal_core__DOT___016823_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016835_));
    wasmetal_core__DOT___016847_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h6560f9f5__0))))
                                               : (IData)(wasmetal_core__DOT___016854_))
                                           : (IData)(wasmetal_core__DOT___016854_)));
    vlSelf->__VdfgTmp_hd7617577__0 = (((IData)(wasmetal_core__DOT___016835_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016847_));
    wasmetal_core__DOT___016858_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hbe619ad7__0))))
                                               : (IData)(wasmetal_core__DOT___016865_))
                                           : (IData)(wasmetal_core__DOT___016865_)));
    vlSelf->__VdfgTmp_h72106b67__0 = (((IData)(wasmetal_core__DOT___016847_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016858_));
    wasmetal_core__DOT___128839___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1ae5646c__0)) 
           & (IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128824___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___036152_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036151_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | ((IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__0__KET__) 
                                                          << 1U))));
    wasmetal_core__DOT___036144_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                    & (IData)(wasmetal_core__DOT___128824___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128839___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h98703c04__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1ae5646c__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((0x3affU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hacb35d4c__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h0abefb0b__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036227_)))));
    wasmetal_core__DOT___036232_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h98703c04__0)) 
                                    & (IData)(wasmetal_core__DOT___128839___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134206___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(wasmetal_core__DOT____Vcellout___128824___O))));
    wasmetal_core__DOT___128810___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(wasmetal_core__DOT____Vcellout___128824___O))));
    vlSelf->wasmetal_core__DOT___018075_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017495_)
                                                   ? 
                                                  (0xcccaccccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((8U 
                                                               >> 
                                                               (2U 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O)))))))
                                                   : 
                                                  (0xcccaccccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((8U 
                                                               >> 
                                                               (2U 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O)))))))));
    wasmetal_core__DOT___043014_ = (1U & (0x40U >> 
                                          ((4U & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                  << 2U)) 
                                           | ((2U & (IData)(wasmetal_core__DOT____Vcellout___128824___O)) 
                                              | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___128825___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
           & (IData)(wasmetal_core__DOT___036144_));
    wasmetal_core__DOT___016876_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015532_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128839___O))))))));
    wasmetal_core__DOT___016887_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015533_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128839___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016898_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015534_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128839___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016909_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015526_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128839___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128840___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h79cf8a49__0)) 
           & (IData)(wasmetal_core__DOT___036232_));
    wasmetal_core__DOT___134206___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134206___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___128825___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
           & (IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128840___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036180_) 
           & (IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___134206___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                          >> 3U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                             >> 2U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ 
                                                               ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                >> 1U)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(wasmetal_core__DOT____Vcellout___128824___O)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134206___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134206___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                             << 1U)))));
    wasmetal_core__DOT___037138_ = (IData)((((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                             >> 3U) 
                                            | (IData)(wasmetal_core__DOT___134206___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___128825___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
           & (IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___016869_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h0abefb0b__0))))
                                               : (IData)(wasmetal_core__DOT___016876_))
                                           : (IData)(wasmetal_core__DOT___016876_)));
    vlSelf->__VdfgTmp_hcacd7e7e__0 = (((IData)(wasmetal_core__DOT___016858_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016869_));
    wasmetal_core__DOT___016880_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0x3a00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hacb35d4c__0))))
                                               : (IData)(wasmetal_core__DOT___016887_))
                                           : (IData)(wasmetal_core__DOT___016887_)));
    vlSelf->__VdfgTmp_h1813ebc7__0 = (((IData)(wasmetal_core__DOT___016869_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016880_));
    wasmetal_core__DOT___016891_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1ae5646c__0))))
                                               : (IData)(wasmetal_core__DOT___016898_))
                                           : (IData)(wasmetal_core__DOT___016898_)));
    vlSelf->__VdfgTmp_ha74c2851__0 = (((IData)(wasmetal_core__DOT___016880_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016891_));
    wasmetal_core__DOT___016902_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h98703c04__0))))
                                               : (IData)(wasmetal_core__DOT___016909_))
                                           : (IData)(wasmetal_core__DOT___016909_)));
    vlSelf->__VdfgTmp_h06719132__0 = (((IData)(wasmetal_core__DOT___016891_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016902_));
    wasmetal_core__DOT___128840___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036181_) 
           & (IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128825___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128825___S) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036144_)))));
    wasmetal_core__DOT___036148_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                    & (IData)(wasmetal_core__DOT___128825___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128840___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___036182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___036181_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036180_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h79cf8a49__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036232_)))));
    wasmetal_core__DOT___036236_ = ((IData)(vlSelf->wasmetal_core__DOT___036182_) 
                                    & (IData)(wasmetal_core__DOT___128840___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134207___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                 | (IData)(wasmetal_core__DOT___037138_)));
    wasmetal_core__DOT____Vcellout___128810___O = (
                                                   ((8U 
                                                     & ((~ (IData)(wasmetal_core__DOT____Vcellout___128825___O)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                             >> 3U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ 
                                                               ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                >> 2U)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ 
                                                                ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                 >> 1U)))))) 
                                                   ^ 
                                                   (1U 
                                                    | ((((~ 
                                                          ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                           >> 3U)) 
                                                         & (IData)(wasmetal_core__DOT___128810___DOT__CO__BRA__1__KET__)) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___128810___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (2U 
                                                             & ((~ 
                                                                 ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                  >> 1U)) 
                                                                << 1U))))));
    wasmetal_core__DOT___128826___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
           & (IData)(wasmetal_core__DOT___036148_));
    wasmetal_core__DOT___016921_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015542_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128840___O))))))));
    wasmetal_core__DOT___016929_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015589_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128840___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___017050_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128840___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___017062_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128840___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128841___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h8ba6f9f1__0)) 
           & (IData)(wasmetal_core__DOT___036236_));
    wasmetal_core__DOT___134207___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                  >> 1U) | (IData)(wasmetal_core__DOT___134207___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___017462_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128810___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127468___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128859___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___017463_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128810___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127468___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128859___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___018066_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128810___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127468___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128859___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___018065_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128810___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127468___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128859___O))))))));
    wasmetal_core__DOT___128826___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128841___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036184_) 
           & (IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h63ea3543__0 = ((2U & ((0xb0U 
                                              >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___017462_));
    vlSelf->__VdfgTmp_h1ab499a5__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___017462_));
    wasmetal_core__DOT___128826___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___016914_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h79cf8a49__0))))
                                               : (IData)(wasmetal_core__DOT___016921_))
                                           : (IData)(wasmetal_core__DOT___016921_)));
    vlSelf->__VdfgTmp_h3bf6c465__0 = (((IData)(wasmetal_core__DOT___016902_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016914_));
    wasmetal_core__DOT___016913_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xfef00000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb8495bec__0)))))
                                               : (IData)(wasmetal_core__DOT___016929_))
                                           : (IData)(wasmetal_core__DOT___016929_)));
    vlSelf->__VdfgTmp_h98ad354c__0 = (((IData)(wasmetal_core__DOT___016914_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016913_));
    wasmetal_core__DOT___017043_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xfef00000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h38acc8e1__0)))))
                                               : (IData)(wasmetal_core__DOT___017050_))
                                           : (IData)(wasmetal_core__DOT___017050_)));
    vlSelf->__VdfgTmp_hd520545b__0 = (((IData)(wasmetal_core__DOT___016913_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017043_));
    wasmetal_core__DOT___017054_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xfef00000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017072_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hab75b8e3__0)))))
                                               : (IData)(wasmetal_core__DOT___017062_))
                                           : (IData)(wasmetal_core__DOT___017062_)));
    vlSelf->__VdfgTmp_h1c39cb98__0 = (((IData)(wasmetal_core__DOT___017043_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017054_));
    wasmetal_core__DOT___128841___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hce52e19d__0)) 
           & (IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128826___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036148_)))));
    wasmetal_core__DOT___036138_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128826___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128841___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha6af91c7__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hce52e19d__0)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036184_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8ba6f9f1__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036236_)))));
    wasmetal_core__DOT___036240_ = ((7U >> (IData)(vlSelf->__VdfgTmp_ha6af91c7__0)) 
                                    & (IData)(wasmetal_core__DOT___128841___DOT__CO__BRA__2__KET__));
    __VdfgTmp_hf3e1ab91__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                     >> 2U)) | (1U 
                                                & (IData)(wasmetal_core__DOT____Vcellout___128826___O)));
    wasmetal_core__DOT___043012_ = (1U & (IData)((0x1fffULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128826___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___128825___O)) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___043015_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                       << 4U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128824___O)) 
                                                         | ((4U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                                >> 1U)) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128826___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128825___O))))))))));
    wasmetal_core__DOT___128827___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128816___O) 
           & (IData)(wasmetal_core__DOT___036138_));
    wasmetal_core__DOT___017075_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017072_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128841___O))))))));
    wasmetal_core__DOT___017083_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015554_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128841___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___017096_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015443_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128841___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___017108_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017105_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128841___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128829___DOT__CO__BRA__0__KET__ 
        = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hd270292e__0)) 
           & (IData)(wasmetal_core__DOT___036240_));
    wasmetal_core__DOT___128827___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128816___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128827___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128829___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h4200eb01__0)) 
           & (IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128827___O = (
                                                   ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128816___O) 
                                                        << 1U)) 
                                                    | (3U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128816___O))) 
                                                   ^ 
                                                   ((0xfffffff8U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128816___O) 
                                                         << 2U) 
                                                        & ((IData)(wasmetal_core__DOT___128827___DOT__CO__BRA__1__KET__) 
                                                           << 3U))) 
                                                    | (((IData)(wasmetal_core__DOT___128827___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128827___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036138_)))));
    wasmetal_core__DOT___017067_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8ba6f9f1__0))))
                                               : (IData)(wasmetal_core__DOT___017075_))
                                           : (IData)(wasmetal_core__DOT___017075_)));
    vlSelf->__VdfgTmp_hde08d0b2__0 = (((IData)(wasmetal_core__DOT___017054_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017067_));
    wasmetal_core__DOT___017066_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xfef00000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015443_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h60abdace__0)))))
                                               : (IData)(wasmetal_core__DOT___017083_))
                                           : (IData)(wasmetal_core__DOT___017083_)));
    vlSelf->__VdfgTmp_he029cbf7__0 = (((IData)(wasmetal_core__DOT___017067_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017066_));
    wasmetal_core__DOT___017089_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hce52e19d__0))))
                                               : (IData)(wasmetal_core__DOT___017096_))
                                           : (IData)(wasmetal_core__DOT___017096_)));
    vlSelf->__VdfgTmp_h398f740d__0 = (((IData)(wasmetal_core__DOT___017066_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017089_));
    wasmetal_core__DOT___017100_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha6af91c7__0))))
                                               : (IData)(wasmetal_core__DOT___017108_))
                                           : (IData)(wasmetal_core__DOT___017108_)));
    vlSelf->__VdfgTmp_h19c83299__0 = (((IData)(wasmetal_core__DOT___017089_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017100_));
    wasmetal_core__DOT___128829___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h92569eda__0)) 
           & (IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___050291_ = (1U & (1U >> ((0x10U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128826___O) 
                                                     << 3U)) 
                                                 | ((8U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128827___O) 
                                                        << 2U)) 
                                                    | ((6U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128826___O) 
                                                           >> 1U)) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128827___O)))))));
    wasmetal_core__DOT____Vcellout___128829___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___036191_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h92569eda__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4200eb01__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0x3affU 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd270292e__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036240_)))));
    wasmetal_core__DOT___036245_ = ((IData)(vlSelf->wasmetal_core__DOT___036191_) 
                                    & (IData)(wasmetal_core__DOT___128829___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___017802_ = (1U & (0x8fU >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128827___O) 
                                                  << 1U)) 
                                           | (((IData)(wasmetal_core__DOT___050291_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_hf3e1ab91__0)))));
    wasmetal_core__DOT___043016_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___050291_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128827___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___017123_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015564_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128829___O))))))));
    wasmetal_core__DOT___016980_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015565_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128829___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016988_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015549_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128829___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016949_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015569_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128829___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128830___DOT__CO__BRA__0__KET__ 
        = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hd6a04253__0)) 
           & (IData)(wasmetal_core__DOT___036245_));
    wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow 
        = (1U & ((IData)(wasmetal_core__DOT___043016_)
                  ? ((IData)(wasmetal_core__DOT___043015_)
                      ? ((~ (IData)(wasmetal_core__DOT___043014_)) 
                         & (7U >> (7U & (IData)(wasmetal_core__DOT____Vcellout___128824___O))))
                      : (IData)(wasmetal_core__DOT___043012_))
                  : ((IData)(wasmetal_core__DOT____Vcellout___128827___O) 
                     >> 2U)));
    wasmetal_core__DOT___128830___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_he686eaae__0)) 
           & (IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT__fpu__02earithmetic__02eencode32__02ein__05b30__05d 
        = (1U & (IData)((0xfffff020ffffffffULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___017802_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___017772_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow))));
    wasmetal_core__DOT___018072_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014592_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                               ? (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___017772_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6f76189e__0)))))
                                               : (0xbf000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___017772_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h5c0f2a5b__0))))
                                           : (2U >> (IData)(wasmetal_core__DOT___017772_))));
    wasmetal_core__DOT___037144_ = (1U & (IData)((0xefffffffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___017802_)))))))));
    wasmetal_core__DOT___059064_ = ((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                    & (IData)((0xfff1ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___017802_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_hf3e1ab91__0))))))));
    vlSelf->wasmetal_core__DOT___058944_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017156_)))));
    wasmetal_core__DOT___017116_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (0x3a00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd270292e__0))))
                                               : (IData)(wasmetal_core__DOT___017123_))
                                           : (IData)(wasmetal_core__DOT___017123_)));
    vlSelf->__VdfgTmp_h776da2e2__0 = (((IData)(wasmetal_core__DOT___017100_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___017116_));
    wasmetal_core__DOT___016973_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h4200eb01__0))))
                                               : (IData)(wasmetal_core__DOT___016980_))
                                           : (IData)(wasmetal_core__DOT___016980_)));
    vlSelf->__VdfgTmp_hb1e20b97__0 = (((IData)(wasmetal_core__DOT___017116_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016973_));
    wasmetal_core__DOT___016972_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                               ? (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h92569eda__0))))
                                               : (IData)(wasmetal_core__DOT___016988_))
                                           : (IData)(wasmetal_core__DOT___016988_)));
    vlSelf->__VdfgTmp_h0184ff22__0 = (((IData)(wasmetal_core__DOT___016973_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016972_));
    vlSelf->wasmetal_core__DOT___016942_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (0xfef00000U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___015579_) 
                                                          << 4U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7054d7e2__0)))))
                                                    : (IData)(wasmetal_core__DOT___016949_))
                                                   : (IData)(wasmetal_core__DOT___016949_)));
    vlSelf->__VdfgTmp_h11dd3326__0 = (((IData)(wasmetal_core__DOT___016972_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016942_));
    wasmetal_core__DOT___128830___DOT__CO__BRA__2__KET__ 
        = ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hcec7f9ed__0)) 
           & (IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___059213_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eencode32__02ein__05b30__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfdf00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___017802_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                                            << 2U) 
                                                                           | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___128826___O)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___134207___O 
        = ((((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eencode32__02ein__05b30__05d) 
             << 3U) | (((IData)(wasmetal_core__DOT___037144_) 
                        << 2U) | ((2U & ((~ ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                             >> 1U)) 
                                         << 1U)) | 
                                  (1U & (~ (IData)(wasmetal_core__DOT____Vcellout___128825___O)))))) 
           ^ ((8U & (((~ (IData)(wasmetal_core__DOT___037144_)) 
                      | (IData)(wasmetal_core__DOT___134207___DOT__CO__BRA__1__KET__)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___134207___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___134207___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___037138_)))));
    vlSelf->wasmetal_core__DOT___018074_ = (1U & (0x3f0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___037144_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___059064_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059065_)))))));
    __VdfgTmp_hc68349d0__0 = ((2U & ((8U >> (((IData)(wasmetal_core__DOT___059064_) 
                                              << 1U) 
                                             | (IData)(wasmetal_core__DOT___037144_))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___059065_));
    vlSelf->wasmetal_core__DOT___018055_ = (1U & (1U 
                                                  >> 
                                                  ((((1U 
                                                      >> 
                                                      ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                           << 3U)) 
                                                       | ((0xcU 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                              << 2U)) 
                                                          | (3U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___128824___O) 
                                                                >> 2U))))) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___017803_) 
                                                        & (IData)(
                                                                  (0xfff1ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                                     << 5U) 
                                                                    | (((IData)(wasmetal_core__DOT___017802_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017801_) 
                                                                           << 3U) 
                                                                          | (((IData)(wasmetal_core__DOT__fpu__02earithmetic__02eround32__02ecommon_totalUnderflow) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128825___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___128826___O))))))))))) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059064_))));
    vlSelf->wasmetal_core__DOT___059944_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h6eb6be0b__0))));
    vlSelf->wasmetal_core__DOT___059830_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he0568e2c__0))));
    vlSelf->__VdfgTmp_h7343b3bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x8800f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058952_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058951_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_ha3f8ca93__0)))));
    vlSelf->wasmetal_core__DOT___059012_ = (1U & (IData)(
                                                         (0x1fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059009_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___059008_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___059007_)))))))));
    vlSelf->wasmetal_core__DOT___059013_ = (1U & (IData)(
                                                         (0x1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059004_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___059003_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___059002_)))))))));
    vlSelf->__VdfgTmp_hfd96674a__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017537_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                                                << 4U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017534_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1e507ca5__0)))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017534_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_ha61a6e02__0)))));
    vlSelf->__VdfgTmp_h4f345a43__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058987_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hcb62e82f__0)))));
    vlSelf->__VdfgTmp_h9f5057e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058975_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h7385dfc5__0)))));
    __VdfgTmp_h58253077__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                           << 3U) | 
                                          ((4U & ((
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT___017551_)
                                                       ? (IData)(
                                                                 (0xff00ff00fffbfff0ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                    << 5U) 
                                                                   | ((0x10U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                                          << 3U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017549_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h6bcf76cf__0)))))))
                                                       : 
                                                      (2U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT___017549_)))) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_hac5f758c__0)))));
    vlSelf->__VdfgTmp_hb666b13b__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___059063_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___059062_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___059061_))))));
    vlSelf->__VdfgTmp_hafe91978__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017564_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017562_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h71876852__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017562_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h6c11e1cc__0)))));
    vlSelf->__VdfgTmp_h4ef846ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017666_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                                << 3U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017664_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8d1d0ffb__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017664_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h15aa6b6f__0)))));
    __VdfgTmp_hb9661308__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                           << 3U) | 
                                          ((4U & ((
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT___017679_)
                                                       ? (IData)(
                                                                 (0xff00ff00fffbfff0ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                    << 5U) 
                                                                   | ((0x10U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017677_) 
                                                                          << 3U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h6171bc25__0))))))
                                                       : 
                                                      (2U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT___017677_)))) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_hdb9ea8ba__0)))));
    vlSelf->__VdfgTmp_h1fd1b68c__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059009_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc369107b__0)))));
    vlSelf->__VdfgTmp_h27aa09ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059004_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h5cb81b0a__0)))));
    vlSelf->__VdfgTmp_h2dfd171f__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x4400f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059023_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___059022_)))))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_hea1901c2__0)))));
    vlSelf->__VdfgTmp_hc67fcbbc__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017704_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                                << 4U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017702_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf11557d__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017702_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h214cf44d__0)))));
    vlSelf->__VdfgTmp_hc60583d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017613_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                                << 3U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017611_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heb003047__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017611_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h11c34da7__0)))));
    vlSelf->__VdfgTmp_hc333bcf7__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059063_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h6eb6be0b__0)))));
    vlSelf->__VdfgTmp_h8c11f975__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017626_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017624_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h43b37fbe__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017624_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_hdf3a557f__0)))));
    vlSelf->__VdfgTmp_h3ae10324__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x4400f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059036_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___059035_)))))) 
                                                           << 2U)) 
                                                       | (IData)(__VdfgTmp_he0568e2c__0)))));
    vlSelf->__VdfgTmp_h2c68bea6__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059053_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h4ab5d99d__0)))));
    vlSelf->__VdfgTmp_he4b52d96__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017731_)
                                                                ? (IData)(
                                                                          (0xff00ff00fffbfff0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                             << 5U) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128852___O) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017729_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h69609ee5__0))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___017729_)))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h64c7108d__0)))));
    vlSelf->__VdfgTmp_hfc3008ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x4400f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059045_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___059044_)))))) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___059047_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___059046_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128830___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h4e293e30__0)) 
                   << 3U)) | ((4U & ((0x3affU >> (IData)(vlSelf->__VdfgTmp_hcec7f9ed__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_he686eaae__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0x3affU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd6a04253__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036245_)))));
    vlSelf->wasmetal_core__DOT___036249_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h4e293e30__0)) 
                                            & (IData)(wasmetal_core__DOT___128830___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h6e41553f__0 = (((IData)(wasmetal_core__DOT___018071_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___018072_));
    vlSelf->__VdfgTmp_h6799374a__0 = (((IData)(vlSelf->wasmetal_core__DOT___018073_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___018072_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___018071_))));
    vlSelf->wasmetal_core__DOT___059534_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hc68349d0__0))))));
    vlSelf->wasmetal_core__DOT___018159_ = (1U & (IData)(
                                                         (0x305000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hc68349d0__0))))))));
    vlSelf->wasmetal_core__DOT___059069_ = (1U & (0x3050000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hc68349d0__0))))));
    vlSelf->wasmetal_core__DOT___059992_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___134206___O))))));
    vlSelf->wasmetal_core__DOT___060049_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134206___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___060121_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134207___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060024_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134206___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060074_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134206___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___060156_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134207___O) 
                                                            >> 2U))))));
    vlSelf->__VdfgTmp_hbba2540d__0 = (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134207___O) 
                                                    >> 3U)));
    vlSelf->wasmetal_core__DOT___059217_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___037144_)))));
    vlSelf->wasmetal_core__DOT___018053_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h7343b3bd__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058945_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h74f09674__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfd96674a__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(__VdfgTmp_h58253077__0))))))))))));
    vlSelf->wasmetal_core__DOT___059488_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xfef0f0f0ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4f345a43__0))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfef0f0f000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hafe91978__0)))))));
    vlSelf->wasmetal_core__DOT___018147_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hfd96674a__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7343b3bd__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(__VdfgTmp_h58253077__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hafe91978__0))))))))))));
    vlSelf->wasmetal_core__DOT___018226_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(__VdfgTmp_h58253077__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfd96674a__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hafe91978__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4f345a43__0))))))))))));
    vlSelf->__VdfgTmp_hde0d3ce6__0 = ((8U & ((IData)(
                                                     (0xfef0f0f000000000ULL 
                                                      >> (IData)(__VdfgTmp_h58253077__0))) 
                                             << 3U)) 
                                      | ((4U & ((IData)(
                                                        (0xfef0f0f0ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_hafe91978__0))) 
                                                << 2U)) 
                                         | ((2U & ((IData)(
                                                           (0x1fff00000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058987_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058986_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___058985_)))))))) 
                                                   << 1U)) 
                                            | (1U & (IData)(
                                                            (0x1fffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058975_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                        << 2U) 
                                                                       | (((IData)(wasmetal_core__DOT___058974_) 
                                                                           << 1U) 
                                                                          | (IData)(wasmetal_core__DOT___058973_))))))))))));
    vlSelf->__VdfgTmp_h7afeeb38__0 = ((2U & ((IData)(
                                                     (0xfef0f0f000000000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9f5057e1__0))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfef0f0f0ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0)))));
    vlSelf->wasmetal_core__DOT___018372_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h9f5057e1__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4f345a43__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(__VdfgTmp_hb9661308__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))))))))))));
    vlSelf->wasmetal_core__DOT___018146_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h9f5057e1__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4f345a43__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(__VdfgTmp_hb9661308__0))))))))))));
    vlSelf->__VdfgTmp_hafdf98d6__0 = ((2U & ((IData)(
                                                     (0xfef0f0f000000000ULL 
                                                      >> (IData)(__VdfgTmp_hb9661308__0))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfef0f0f0ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0)))));
    vlSelf->wasmetal_core__DOT___018285_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(__VdfgTmp_hb9661308__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))))))))))));
    vlSelf->wasmetal_core__DOT___017460_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(__VdfgTmp_hb9661308__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0))))))))))));
    vlSelf->__VdfgTmp_h4e256671__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfef0f0f000000000ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfef0f0f0ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0))))));
    vlSelf->wasmetal_core__DOT___018050_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f0ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(__VdfgTmp_hb9661308__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))))))))))));
    vlSelf->wasmetal_core__DOT___018283_ = (1U & (IData)(
                                                         (0xfff0111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfef0f0f000000000ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8c11f975__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059012_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059013_)))))))));
    __VdfgTmp_h166e2223__0 = ((2U & ((IData)((0xfef0f0f0ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h8c11f975__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfef0f0f000000000ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0)))));
    __VdfgTmp_h1bda1915__0 = ((2U & ((IData)((0xfef0f0f000000000ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h8c11f975__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfef0f0f0ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1fd1b68c__0)))));
    wasmetal_core__DOT___018051_ = (1U & (IData)((0xf00001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1fd1b68c__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h8c11f975__0))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfef0f0f0ULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xfef0f0f000000000ULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h27aa09ab__0))))))))))));
    __VdfgTmp_h0efadc80__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 2U) | ((2U & ((IData)(
                                                        (0xfef0f0f000000000ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h27aa09ab__0))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0xfef0f0f0ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))))));
    wasmetal_core__DOT___018640_ = (1U & (1U >> ((2U 
                                                  & ((IData)(
                                                             (0xfef0f0f0ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc333bcf7__0))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfef0f0f000000000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2c68bea6__0)))))));
    wasmetal_core__DOT___018369_ = (1U & (IData)((0xf111100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h27aa09ab__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h1fd1b68c__0))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfef0f0f0ULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he4b52d96__0))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xfef0f0f000000000ULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))))))))))));
    __VdfgTmp_hb9c3a66a__0 = ((2U & ((IData)((0xfff00000eeeeULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                      << 4U) 
                                                     | ((8U 
                                                         & ((IData)(
                                                                    (0xfef0f0f0ULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h27aa09ab__0))) 
                                                            << 3U)) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xfef0f0f000000000ULL 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h1fd1b68c__0))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xfef0f0f000000000ULL 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xfef0f0f0ULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he4b52d96__0))))))))))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfff00000eeee0000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(
                                                                              (0xfef0f0f0ULL 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))) 
                                                                      << 3U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0))) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8c11f975__0)))))))))))));
    __VdfgTmp_h9ccc8db2__0 = ((2U & ((IData)((0xfef0f0f0ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h2c68bea6__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfef0f0f000000000ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfc3008ab__0)))));
    __VdfgTmp_hf618fc36__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                          << 4U) | 
                                         ((8U & ((IData)(
                                                         (0xfef0f0f0ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_he4b52d96__0))) 
                                                 << 3U)) 
                                          | ((4U & 
                                              ((IData)(
                                                       (0xfef0f0f000000000ULL 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))) 
                                               << 2U)) 
                                             | ((2U 
                                                 & ((IData)(
                                                            (0xfef0f0f000000000ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hfc3008ab__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (IData)(
                                                             (0xfef0f0f0ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2c68bea6__0)))))))));
    __VdfgTmp_h81ca6039__0 = ((2U & ((IData)((0xfef0f0f000000000ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_he4b52d96__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfef0f0f0ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfc3008ab__0)))));
    wasmetal_core__DOT___016957_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015579_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128830___O))))))));
    wasmetal_core__DOT___016968_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015574_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128830___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___017001_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015559_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128830___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___017012_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015584_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128830___O) 
                                                             >> 3U))))))));
    if (vlSelf->wasmetal_core__DOT___016555_) {
        if (vlSelf->wasmetal_core__DOT___016554_) {
            wasmetal_core__DOT___016941_ = (1U & (1U 
                                                  >> 
                                                  (1U 
                                                   & (0x3a00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd6a04253__0)))));
            wasmetal_core__DOT___016961_ = (1U & (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he686eaae__0)))));
            wasmetal_core__DOT___016994_ = (1U & (1U 
                                                  >> 
                                                  (1U 
                                                   & (0x3a00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcec7f9ed__0)))));
            vlSelf->wasmetal_core__DOT___017005_ = 
                (1U & (1U >> (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h4e293e30__0)))));
        } else {
            wasmetal_core__DOT___016941_ = (1U & (IData)(wasmetal_core__DOT___016957_));
            wasmetal_core__DOT___016961_ = (1U & (IData)(wasmetal_core__DOT___016968_));
            wasmetal_core__DOT___016994_ = (1U & (IData)(wasmetal_core__DOT___017001_));
            vlSelf->wasmetal_core__DOT___017005_ = 
                (1U & (IData)(wasmetal_core__DOT___017012_));
        }
    } else {
        wasmetal_core__DOT___016941_ = (1U & (IData)(wasmetal_core__DOT___016957_));
        wasmetal_core__DOT___016961_ = (1U & (IData)(wasmetal_core__DOT___016968_));
        wasmetal_core__DOT___016994_ = (1U & (IData)(wasmetal_core__DOT___017001_));
        vlSelf->wasmetal_core__DOT___017005_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017012_));
    }
    wasmetal_core__DOT___128831___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h59ed23b8__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036249_));
    wasmetal_core__DOT___059579_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6e41553f__0))));
    wasmetal_core__DOT___018156_ = (1U & (IData)((0xfff4ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6799374a__0))))));
    wasmetal_core__DOT___018077_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___018075_)
                                           ? (IData)(
                                                     (0xfffffff4ffffff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018074_) 
                                                           << 4U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6799374a__0)))))
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT___018074_))));
    wasmetal_core__DOT___018373_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___059534_)))));
    __VdfgTmp_h75d85fc5__0 = (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___059069_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                           << 2U) | 
                                          ((2U & ((IData)(
                                                          (0xfdfULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___018073_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h6e41553f__0))))))) 
                                                  << 1U)) 
                                           | (1U & (IData)(
                                                           (0x1fff00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_hb666b13b__0))))))));
    vlSelf->wasmetal_core__DOT___060164_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0fe0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060152_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((IData)(
                                                                                (0x2220a2aaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                           & (IData)(
                                                                                (0x3337f3ff0000ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x555f444cULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060158_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006215_))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060156_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058930_)))))))))))));
    wasmetal_core__DOT___060193_ = (1U & (IData)((0xf0f7ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060190_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hbba2540d__0))))))));
    vlSelf->wasmetal_core__DOT___018339_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hac5f758c__0)))));
    vlSelf->wasmetal_core__DOT___059338_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058948_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058949_))))));
    vlSelf->wasmetal_core__DOT___059810_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5cb81b0a__0)))));
    vlSelf->wasmetal_core__DOT___059924_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4ab5d99d__0)))));
    vlSelf->wasmetal_core__DOT___059536_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6c11e1cc__0)))));
    vlSelf->wasmetal_core__DOT___018570_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hea1901c2__0)))));
    vlSelf->wasmetal_core__DOT___059389_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h74f09674__0)))));
    vlSelf->wasmetal_core__DOT___059431_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha3f8ca93__0)))));
    vlSelf->wasmetal_core__DOT___059862_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h64c7108d__0)))));
    vlSelf->wasmetal_core__DOT___059219_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xff4f4fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0)) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058153_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017498_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x10U 
                                                                            >> 
                                                                            ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058153_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x3a000000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017498_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h069b89c3__0)))))))))))));
    wasmetal_core__DOT___018429_ = (1U & (0xe000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hcb62e82f__0)))));
    vlSelf->wasmetal_core__DOT___059605_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7385dfc5__0)))));
    wasmetal_core__DOT___018532_ = (1U & (0xe000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hdb9ea8ba__0)))));
    wasmetal_core__DOT___018286_ = (1U & (IData)((0xfff0111100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hde0d3ce6__0))))));
    wasmetal_core__DOT___018052_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h4f345a43__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hafe91978__0))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h7afeeb38__0))))))));
    wasmetal_core__DOT___018225_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h9f5057e1__0))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hafdf98d6__0))))))));
    __VdfgTmp_hdf63e4bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hafdf98d6__0));
    wasmetal_core__DOT___018371_ = (1U & (IData)((0xf00001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2dfd171f__0))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h166e2223__0))))))));
    wasmetal_core__DOT___017461_ = (1U & (IData)((0x11110000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059013_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___059012_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h166e2223__0))))))));
    wasmetal_core__DOT___018223_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hc60583d8__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc67fcbbc__0))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h1bda1915__0))))))));
    __VdfgTmp_h4b6964fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 2U) | (IData)(__VdfgTmp_h1bda1915__0));
    vlSelf->__VdfgTmp_heca3be9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018050_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018051_)));
    __VdfgTmp_hbf2b62f5__0 = (((IData)(wasmetal_core__DOT___018640_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018065_));
    vlSelf->wasmetal_core__DOT___018302_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018283_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> (IData)(__VdfgTmp_hf618fc36__0))))))));
    wasmetal_core__DOT___018224_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3ae10324__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h27aa09ab__0))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h81ca6039__0))))))));
    __VdfgTmp_had793d18__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 2U) | (IData)(__VdfgTmp_h81ca6039__0));
    wasmetal_core__DOT___128831___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h7d39981d__0)) 
           & (IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___018718_ = (1U & (IData)((0xfdfULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018074_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018073_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___059579_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017538_)))))))));
    __VdfgTmp_hf67d9e80__0 = (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                               << 2U) | ((2U & ((IData)(
                                                        (0xfef0f0f000000000ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc333bcf7__0))) 
                                                << 1U)) 
                                         | (IData)(wasmetal_core__DOT___018156_)));
    __VdfgTmp_hceb98761__0 = (((IData)(wasmetal_core__DOT___018156_) 
                               << 1U) | (1U & (IData)(
                                                      (0xfef0f0f000000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc333bcf7__0)))));
    wasmetal_core__DOT___018227_ = (1U & (IData)((0xfef0000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                          << 3U) 
                                                         | ((((~ (IData)(vlSelf->wasmetal_core__DOT___018065_)) 
                                                              & (IData)(wasmetal_core__DOT___018077_)) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfef0f0f000000000ULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h2c68bea6__0))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xfef0f0f0ULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc333bcf7__0))))))))))));
    wasmetal_core__DOT___018064_ = ((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                    & (IData)(wasmetal_core__DOT___018077_));
    vlSelf->wasmetal_core__DOT___059982_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___018373_)))));
    vlSelf->wasmetal_core__DOT___059965_ = (1U & (0xbfbf00bfU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059579_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___018373_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018055_)))))));
    vlSelf->wasmetal_core__DOT___059981_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059980_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___018373_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1ab499a5__0))))))));
    vlSelf->wasmetal_core__DOT___018287_ = (1U & (IData)(
                                                         (0xff10000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h75d85fc5__0)))));
    __VdfgTmp_h228f6e73__0 = ((2U & ((IData)((0xfff00000eeee0000ULL 
                                              >> (IData)(__VdfgTmp_hf618fc36__0))) 
                                     << 1U)) | (1U 
                                                & (0xff10U 
                                                   >> (IData)(__VdfgTmp_h75d85fc5__0))));
    vlSelf->wasmetal_core__DOT___018980_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___060193_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060188_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                            & (IData)(
                                                                                (0x3337f3ff0000ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b45c525__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x2220a2aaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018857_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018082_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018081_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___018301_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018285_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___018286_))));
    wasmetal_core__DOT___018245_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___018225_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018226_))));
    wasmetal_core__DOT___059604_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017460_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___017461_)))));
    vlSelf->wasmetal_core__DOT___018428_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xeU 
                                                                      >> (IData)(__VdfgTmp_hdf63e4bf__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h7afeeb38__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xe0U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h4e256671__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> (IData)(__VdfgTmp_h4b6964fc__0)))))))))));
    vlSelf->__VdfgTmp_h450b6bb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                       << 2U) | ((2U 
                                                  & ((0xe0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018053_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___018052_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_heca3be9d__0)))));
    vlSelf->__VdfgTmp_h5acde712__0 = (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___018223_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018224_)));
    vlSelf->__VdfgTmp_ha0bbf0cf__0 = ((2U & ((IData)(
                                                     (0xff00f0f011111111ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059488_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((1U 
                                                                     >> 
                                                                     ((2U 
                                                                       & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4ef846ae__0))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9f5057e1__0)))))) 
                                                                    << 2U)) 
                                                                | ((2U 
                                                                    & ((0xeU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h4e256671__0)) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (0xe0U 
                                                                         >> (IData)(__VdfgTmp_hdf63e4bf__0)))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf000f0000eeeeULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((0xe0U 
                                                                >> (IData)(__VdfgTmp_had793d18__0)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((0xe0U 
                                                                   >> (IData)(__VdfgTmp_h4b6964fc__0)) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((0xeU 
                                                                      >> (IData)(__VdfgTmp_h0efadc80__0)) 
                                                                     << 2U)) 
                                                                 | (IData)(__VdfgTmp_hbf2b62f5__0)))))))));
    vlSelf->__VdfgTmp_hd10ddd3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___016942_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016941_));
    vlSelf->__VdfgTmp_h1c77e7ba__0 = (((IData)(wasmetal_core__DOT___016941_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016961_));
    vlSelf->__VdfgTmp_hb9ae5421__0 = (((IData)(wasmetal_core__DOT___016961_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016994_));
    vlSelf->__VdfgTmp_hbf2def73__0 = (((IData)(wasmetal_core__DOT___016994_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017005_));
    wasmetal_core__DOT___128831___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_ha00e7863__0)) 
           & (IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___018568_ = (1U & (0x70000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___018718_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hbf2b62f5__0))))));
    vlSelf->wasmetal_core__DOT___018427_ = (1U & (IData)(
                                                         (0x11111111fffff000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___018718_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___018640_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(__VdfgTmp_had793d18__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xe0U 
                                                                             >> (IData)(__VdfgTmp_h0efadc80__0)))))))))));
    vlSelf->wasmetal_core__DOT___059781_ = (1U & ((8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017462_))) 
                                                  & (IData)(
                                                            (0xfff0fff000007777ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___018718_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & ((0xe0U 
                                                                         >> (IData)(__VdfgTmp_h0efadc80__0)) 
                                                                        << 3U)) 
                                                                    | ((4U 
                                                                        & ((0xeU 
                                                                            >> (IData)(__VdfgTmp_had793d18__0)) 
                                                                           << 2U)) 
                                                                       | (IData)(__VdfgTmp_hbf2b62f5__0)))))))));
    vlSelf->wasmetal_core__DOT___018613_ = (1U & (IData)(
                                                         (0xfff0444400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018283_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(__VdfgTmp_hf618fc36__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___059069_) 
                                                                               << 3U) 
                                                                              | (IData)(__VdfgTmp_hf67d9e80__0))))))))))));
    __VdfgTmp_h5778fde6__0 = ((4U & ((IData)((0xfff4ff00ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018159_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((0xeU 
                                                                >> (IData)(__VdfgTmp_hf67d9e80__0)) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (1U 
                                                                    >> (IData)(__VdfgTmp_h9ccc8db2__0)))))))))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (1U 
                                                      >> (IData)(__VdfgTmp_hb9c3a66a__0)))));
    wasmetal_core__DOT___018370_ = (1U & (IData)((0xf00001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfef0f0f0ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2c68bea6__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfef0f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hfc3008ab__0))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_hceb98761__0))))))));
    vlSelf->wasmetal_core__DOT___018148_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___018159_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___017463_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___018065_)
                                                    ? 
                                                   (0xe000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h9ccc8db2__0))))
                                                    : 
                                                   (0xe000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_hceb98761__0)))))));
    vlSelf->wasmetal_core__DOT___059895_ = (1U & (IData)(
                                                         (0xbf00bfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___018227_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___059046_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___059047_))))))))))));
    vlSelf->wasmetal_core__DOT___059897_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___018227_))));
    wasmetal_core__DOT___018247_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___018227_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017462_))));
    vlSelf->wasmetal_core__DOT___059628_ = (1U & (IData)(
                                                         (0xff110000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(__VdfgTmp_had793d18__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(wasmetal_core__DOT___018064_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___018640_)))))))));
    vlSelf->wasmetal_core__DOT___018054_ = ((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___018066_)
                                                ? (0xfff01111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(
                                                                   (0xfef0f0f000000000ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_he4b52d96__0))) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xfef0f0f0ULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hfc3008ab__0))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0x1fffULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hb666b13b__0))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0x1fff00000000ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___059053_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059051_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059052_))))))))))))))
                                                : (2U 
                                                   >> (IData)(wasmetal_core__DOT___018064_))));
    vlSelf->__VdfgTmp_h5c50a9b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___018064_));
    vlSelf->wasmetal_core__DOT___059930_ = (1U & (0xdfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059924_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018287_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017462_)))))));
    vlSelf->wasmetal_core__DOT___018303_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018287_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017462_))));
    vlSelf->__VdfgTmp_h14645516__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___017462_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___017463_)
                                                   ? 
                                                  (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___018286_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___018285_))))
                                                   : 
                                                  (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> (IData)(__VdfgTmp_hf618fc36__0))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___018283_)))))
                                               : (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018287_)))) 
                                             << 1U)) 
                                      | (1U & (0xe000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha61a6e02__0))))));
    vlSelf->wasmetal_core__DOT___059809_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h228f6e73__0)))));
    wasmetal_core__DOT___059603_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h228f6e73__0))));
    vlSelf->wasmetal_core__DOT___059218_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017463_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017462_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(
                                                                 (0xfff000001111ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                       << 4U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hde0d3ce6__0))))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x1111fff000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018065_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfef0f0f000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7343b3bd__0))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfef0f0f0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfd96674a__0))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x1fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058950_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058949_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058948_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018075_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058945_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058943_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058942_)))))))))))))))))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((0xff10U 
                                                          >> (IData)(__VdfgTmp_h75d85fc5__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0xfff00000eeee0000ULL 
                                                                   >> (IData)(__VdfgTmp_hf618fc36__0)))))))
                                                   : 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___017462_)) 
                                                   | (0xeU 
                                                      >> 
                                                      (((IData)(wasmetal_core__DOT___017461_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017460_))))));
    vlSelf->wasmetal_core__DOT___059244_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x440f0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___014712_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059235_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059233_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d)))))))))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059218_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h1a828198__0))))))));
    wasmetal_core__DOT____Vcellout___128831___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h71404310__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha00e7863__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7d39981d__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h59ed23b8__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036249_)))));
    vlSelf->wasmetal_core__DOT___036254_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h71404310__0)) 
                                            & (IData)(wasmetal_core__DOT___128831___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hdd3dcee5__0 = ((2U & ((0xe0U 
                                              >> (IData)(vlSelf->__VdfgTmp_h5acde712__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___018568_));
    __VdfgTmp_h336c6eb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___018428_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018427_)));
    vlSelf->wasmetal_core__DOT___059784_ = (1U & (IData)(
                                                         (0xfffff44400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059781_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059005_)))))))));
    vlSelf->__VdfgTmp_hf7efd051__0 = ((4U & ((0xe000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc369107b__0)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___059781_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018055_)));
    vlSelf->__VdfgTmp_h4db98f39__0 = ((4U & ((0xe000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h214cf44d__0)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___018613_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018055_)));
    vlSelf->wasmetal_core__DOT___059707_ = (1U & (IData)(
                                                         (0xfffff44400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018613_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059027_)))))))));
    vlSelf->wasmetal_core__DOT___018521_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xb00ff00ff00ffULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((0xb0U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___059658_) 
                                                                           << 3U) 
                                                                          | (IData)(__VdfgTmp_h5778fde6__0)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016504_)))));
    vlSelf->wasmetal_core__DOT___018536_ = (1U & (IData)(
                                                         (0xb00ff00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059660_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h5778fde6__0)))))));
    vlSelf->__VdfgTmp_h7d1ccc69__0 = (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___018532_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_h5778fde6__0))));
    vlSelf->wasmetal_core__DOT___018683_ = (1U & (IData)(
                                                         (0xf888800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___018369_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___018370_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018066_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059534_)))))))));
    __VdfgTmp_hc3bb2a19__0 = (((IData)(wasmetal_core__DOT___018370_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018369_));
    if (vlSelf->wasmetal_core__DOT___017462_) {
        if (vlSelf->wasmetal_core__DOT___017463_) {
            vlSelf->wasmetal_core__DOT___059432_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018226_) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___018225_)))));
            vlSelf->wasmetal_core__DOT___059390_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018147_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___018146_)))));
        } else {
            vlSelf->wasmetal_core__DOT___059432_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___018224_) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___018223_)))));
            vlSelf->wasmetal_core__DOT___059390_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                 << 2U) | (IData)(__VdfgTmp_hb9c3a66a__0))));
        }
        vlSelf->wasmetal_core__DOT___059339_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___018055_)) 
                                                   & (0xfff01111U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018053_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___018052_) 
                                                              << 2U) 
                                                             | (((IData)(wasmetal_core__DOT___018051_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___018050_))))))));
        vlSelf->wasmetal_core__DOT___059535_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___018055_)) 
                                                   & (0xf1111U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018372_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___018371_) 
                                                              << 2U) 
                                                             | (IData)(__VdfgTmp_hc3bb2a19__0)))))));
    } else {
        vlSelf->wasmetal_core__DOT___059432_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___018227_))));
        vlSelf->wasmetal_core__DOT___059390_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___018148_))));
        vlSelf->wasmetal_core__DOT___059339_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___018055_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___018054_))));
        vlSelf->wasmetal_core__DOT___059535_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___018055_)) 
                                                   & (2U 
                                                      >> (IData)(wasmetal_core__DOT___018373_))));
    }
    vlSelf->wasmetal_core__DOT___059869_ = (1U & (0xff40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059862_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018148_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018055_)))))));
    vlSelf->wasmetal_core__DOT___059868_ = (1U & (0x7f7f007fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059040_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018148_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1ab499a5__0))))));
    __VdfgTmp_h29ce91ec__0 = ((4U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT___018148_) 
                                              << 1U) 
                                             | (IData)(vlSelf->wasmetal_core__DOT___017462_))) 
                                     << 2U)) | ((2U 
                                                 & ((1U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___018146_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___018147_))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (1U 
                                                      >> (IData)(__VdfgTmp_hb9c3a66a__0)))));
    vlSelf->wasmetal_core__DOT___059437_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___059432_))));
    vlSelf->wasmetal_core__DOT___059899_ = (1U & (IData)(
                                                         (0xfffff44400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059044_)))))))));
    vlSelf->wasmetal_core__DOT___059434_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xb0U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___018247_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xeU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h5acde712__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___018245_)))))))));
    vlSelf->wasmetal_core__DOT___059436_ = (1U & ((7U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___058951_)))) 
                                                  & (IData)(
                                                            (0xff00ff0fffdfffULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___018247_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((0xeU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h5acde712__0)) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                        << 2U) 
                                                                       | (((IData)(wasmetal_core__DOT___018245_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017463_))))))))));
    __VdfgTmp_h1118b815__0 = ((2U & ((0x10U >> (IData)(vlSelf->__VdfgTmp_heca3be9d__0)) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___059628_));
    vlSelf->wasmetal_core__DOT___059343_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018054_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017462_))));
    __VdfgTmp_h9aeb2493__0 = (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___059830_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___018054_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___018055_)))));
    vlSelf->wasmetal_core__DOT___059948_ = (1U & (IData)(
                                                         (0xbfffbfffbfffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059944_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5c50a9b1__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018055_)))))))));
    vlSelf->wasmetal_core__DOT___018338_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5c50a9b1__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017462_)))));
    wasmetal_core__DOT___018643_ = (1U & (0xf800U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h5c50a9b1__0)))));
    vlSelf->wasmetal_core__DOT___059729_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017463_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___018066_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___018643_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((0xeU 
                                                             >> (IData)(__VdfgTmp_h0efadc80__0)) 
                                                            << 1U)) 
                                                        | (1U 
                                                           & (0xe0U 
                                                              >> (IData)(__VdfgTmp_h4b6964fc__0))))))
                                                    : 
                                                   (0xf010U 
                                                    >> 
                                                    ((8U 
                                                      & ((0xe0U 
                                                          >> (IData)(__VdfgTmp_had793d18__0)) 
                                                         << 3U)) 
                                                     | (((IData)(wasmetal_core__DOT___018643_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_hbf2b62f5__0)))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(wasmetal_core__DOT___018643_))));
    vlSelf->wasmetal_core__DOT___059473_ = (1U & ((0xbU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___058956_)))) 
                                                  & (IData)(
                                                            (0xff00ff0fffdfffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___018303_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018302_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018301_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017463_))))))))));
    vlSelf->wasmetal_core__DOT___059483_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h14645516__0))));
    vlSelf->__VdfgTmp_h52593617__0 = (((IData)(vlSelf->wasmetal_core__DOT___059809_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018055_));
    vlSelf->wasmetal_core__DOT___018442_ = (1U & (IData)(
                                                         (0xf0fef0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059605_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___059604_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___059603_)))))))));
    vlSelf->__VdfgTmp_h75b7aca4__0 = (((IData)(wasmetal_core__DOT___059603_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___059604_));
    vlSelf->wasmetal_core__DOT___017028_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015454_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___128831___O))))))));
    vlSelf->wasmetal_core__DOT___017039_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015450_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128831___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017136_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015522_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128831___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___017151_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015451_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128831___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128832___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h34f07943__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036254_));
    vlSelf->wasmetal_core__DOT___018549_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0fef0f0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018570_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hdd3dcee5__0)))))))))));
    vlSelf->wasmetal_core__DOT___059687_ = (1U & (IData)(
                                                         (0xef0f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___059022_)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdd3dcee5__0))))))));
    vlSelf->wasmetal_core__DOT___018434_ = (1U & (IData)(
                                                         (0xe00ff00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059588_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h336c6eb7__0)))))));
    vlSelf->__VdfgTmp_hc008d36b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___018429_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_h336c6eb7__0))));
    vlSelf->wasmetal_core__DOT___059785_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7efd051__0))));
    vlSelf->wasmetal_core__DOT___059656_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016506_)) 
                                                  & (IData)(
                                                            (0xff00fff4ff00ff00ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h7d1ccc69__0)))));
    vlSelf->__VdfgTmp_ha2122f26__0 = ((4U & ((0xe000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hdf3a557f__0)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___018683_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018055_)));
    vlSelf->__VdfgTmp_hb1bc7919__0 = (((IData)(wasmetal_core__DOT___018373_) 
                                       << 2U) | ((2U 
                                                  & ((0xe0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___018371_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___018372_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xeU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_hc3bb2a19__0))))));
    vlSelf->wasmetal_core__DOT___059392_ = (1U & (IData)(
                                                         (0xf3f5f0f000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xb0U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h29ce91ec__0)))))));
    vlSelf->wasmetal_core__DOT___059395_ = ((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                            & ((1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)))
                                                ? (IData)(
                                                          (0xf3fff5fff0fff0ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017463_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___018176_) 
                                                                   << 3U) 
                                                                  | (IData)(__VdfgTmp_h29ce91ec__0))))))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___018176_))));
    vlSelf->wasmetal_core__DOT___018510_ = (1U & (IData)(
                                                         (0xfff01110fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059217_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058944_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h15aa6b6f__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_h1118b815__0))))))));
    vlSelf->wasmetal_core__DOT___018490_ = (1U & (IData)(
                                                         (0xef0f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___059014_)))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_h1118b815__0))))))));
    vlSelf->wasmetal_core__DOT___059348_ = (1U & (IData)(
                                                         (0xff1fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059346_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059343_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450b6bb7__0)))))));
    vlSelf->wasmetal_core__DOT___059833_ = (1U & (IData)(
                                                         (0xff404040ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h9aeb2493__0)))));
    vlSelf->wasmetal_core__DOT___059837_ = (1U & (IData)(
                                                         (0xff404040ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h9aeb2493__0)))));
    vlSelf->__VdfgTmp_hf2800fdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___018338_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha0bbf0cf__0));
}
