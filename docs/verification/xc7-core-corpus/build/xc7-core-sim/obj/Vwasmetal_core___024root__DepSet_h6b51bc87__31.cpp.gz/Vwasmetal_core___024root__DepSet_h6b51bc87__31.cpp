#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__38(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__38\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___019250_;
    wasmetal_core__DOT___019250_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019251_;
    wasmetal_core__DOT___019251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025171_;
    wasmetal_core__DOT___025171_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025173_;
    wasmetal_core__DOT___025173_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025174_;
    wasmetal_core__DOT___025174_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025175_;
    wasmetal_core__DOT___025175_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025376_;
    wasmetal_core__DOT___025376_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025380_;
    wasmetal_core__DOT___025380_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025385_;
    wasmetal_core__DOT___025385_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025389_;
    wasmetal_core__DOT___025389_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025393_;
    wasmetal_core__DOT___025393_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025402_;
    wasmetal_core__DOT___025402_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025448_;
    wasmetal_core__DOT___025448_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025449_;
    wasmetal_core__DOT___025449_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025450_;
    wasmetal_core__DOT___025450_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025451_;
    wasmetal_core__DOT___025451_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025452_;
    wasmetal_core__DOT___025452_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025453_;
    wasmetal_core__DOT___025453_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025454_;
    wasmetal_core__DOT___025454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025456_;
    wasmetal_core__DOT___025456_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025457_;
    wasmetal_core__DOT___025457_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025458_;
    wasmetal_core__DOT___025458_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025459_;
    wasmetal_core__DOT___025459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025460_;
    wasmetal_core__DOT___025460_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025461_;
    wasmetal_core__DOT___025461_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025462_;
    wasmetal_core__DOT___025462_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025463_;
    wasmetal_core__DOT___025463_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025464_;
    wasmetal_core__DOT___025464_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025465_;
    wasmetal_core__DOT___025465_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025467_;
    wasmetal_core__DOT___025467_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025468_;
    wasmetal_core__DOT___025468_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025469_;
    wasmetal_core__DOT___025469_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025470_;
    wasmetal_core__DOT___025470_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025673_;
    wasmetal_core__DOT___025673_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025678_;
    wasmetal_core__DOT___025678_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027498_;
    wasmetal_core__DOT___027498_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027502_;
    wasmetal_core__DOT___027502_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027506_;
    wasmetal_core__DOT___027506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027511_;
    wasmetal_core__DOT___027511_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027515_;
    wasmetal_core__DOT___027515_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027520_;
    wasmetal_core__DOT___027520_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027528_;
    wasmetal_core__DOT___027528_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027533_;
    wasmetal_core__DOT___027533_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027537_;
    wasmetal_core__DOT___027537_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027542_;
    wasmetal_core__DOT___027542_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027546_;
    wasmetal_core__DOT___027546_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027550_;
    wasmetal_core__DOT___027550_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027557_;
    wasmetal_core__DOT___027557_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___039333_;
    wasmetal_core__DOT___039333_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060695_;
    wasmetal_core__DOT___060695_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060715_;
    wasmetal_core__DOT___060715_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060722_;
    wasmetal_core__DOT___060722_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060723_;
    wasmetal_core__DOT___060723_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060764_;
    wasmetal_core__DOT___060764_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060777_;
    wasmetal_core__DOT___060777_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060800_;
    wasmetal_core__DOT___060800_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060803_;
    wasmetal_core__DOT___060803_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060805_;
    wasmetal_core__DOT___060805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060810_;
    wasmetal_core__DOT___060810_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060837_;
    wasmetal_core__DOT___060837_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060850_;
    wasmetal_core__DOT___060850_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060854_;
    wasmetal_core__DOT___060854_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060864_;
    wasmetal_core__DOT___060864_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060885_;
    wasmetal_core__DOT___060885_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060891_;
    wasmetal_core__DOT___060891_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060892_;
    wasmetal_core__DOT___060892_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060931_;
    wasmetal_core__DOT___060931_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060936_;
    wasmetal_core__DOT___060936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060942_;
    wasmetal_core__DOT___060942_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060983_;
    wasmetal_core__DOT___060983_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060987_;
    wasmetal_core__DOT___060987_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061003_;
    wasmetal_core__DOT___061003_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061017_;
    wasmetal_core__DOT___061017_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061018_;
    wasmetal_core__DOT___061018_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061021_;
    wasmetal_core__DOT___061021_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061027_;
    wasmetal_core__DOT___061027_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061067_;
    wasmetal_core__DOT___061067_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061077_;
    wasmetal_core__DOT___061077_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061092_;
    wasmetal_core__DOT___061092_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061101_;
    wasmetal_core__DOT___061101_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061103_;
    wasmetal_core__DOT___061103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061112_;
    wasmetal_core__DOT___061112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061132_;
    wasmetal_core__DOT___061132_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061148_;
    wasmetal_core__DOT___061148_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061158_;
    wasmetal_core__DOT___061158_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061184_;
    wasmetal_core__DOT___061184_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061185_;
    wasmetal_core__DOT___061185_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061188_;
    wasmetal_core__DOT___061188_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061194_;
    wasmetal_core__DOT___061194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061214_;
    wasmetal_core__DOT___061214_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061224_;
    wasmetal_core__DOT___061224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061240_;
    wasmetal_core__DOT___061240_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061267_;
    wasmetal_core__DOT___061267_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061268_;
    wasmetal_core__DOT___061268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061271_;
    wasmetal_core__DOT___061271_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061277_;
    wasmetal_core__DOT___061277_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061300_;
    wasmetal_core__DOT___061300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061305_;
    wasmetal_core__DOT___061305_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061310_;
    wasmetal_core__DOT___061310_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061334_;
    wasmetal_core__DOT___061334_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061335_;
    wasmetal_core__DOT___061335_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061338_;
    wasmetal_core__DOT___061338_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061344_;
    wasmetal_core__DOT___061344_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061345_;
    wasmetal_core__DOT___061345_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061351_;
    wasmetal_core__DOT___061351_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061356_;
    wasmetal_core__DOT___061356_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061373_;
    wasmetal_core__DOT___061373_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061383_;
    wasmetal_core__DOT___061383_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061387_;
    wasmetal_core__DOT___061387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061398_;
    wasmetal_core__DOT___061398_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061424_;
    wasmetal_core__DOT___061424_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061433_;
    wasmetal_core__DOT___061433_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061435_;
    wasmetal_core__DOT___061435_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127767___O;
    wasmetal_core__DOT____Vcellout___127767___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127769___O;
    wasmetal_core__DOT____Vcellout___127769___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127771___O;
    wasmetal_core__DOT____Vcellout___127771___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127790___O;
    wasmetal_core__DOT____Vcellout___127790___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127791___O;
    wasmetal_core__DOT____Vcellout___127791___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127979___O;
    wasmetal_core__DOT____Vcellout___127979___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127980___O;
    wasmetal_core__DOT____Vcellout___127980___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127981___O;
    wasmetal_core__DOT____Vcellout___127981___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127982___O;
    wasmetal_core__DOT____Vcellout___127982___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127983___O;
    wasmetal_core__DOT____Vcellout___127983___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127984___O;
    wasmetal_core__DOT____Vcellout___127984___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127985___O;
    wasmetal_core__DOT____Vcellout___127985___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127986___O;
    wasmetal_core__DOT____Vcellout___127986___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127987___O;
    wasmetal_core__DOT____Vcellout___127987___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127988___O;
    wasmetal_core__DOT____Vcellout___127988___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127989___O;
    wasmetal_core__DOT____Vcellout___127989___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127990___O;
    wasmetal_core__DOT____Vcellout___127990___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127991___O;
    wasmetal_core__DOT____Vcellout___127991___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127993___O;
    wasmetal_core__DOT____Vcellout___127993___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127757___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127757___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127766___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127766___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127767___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127767___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127767___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127767___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127767___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127767___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127768___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127768___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127768___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127768___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127768___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127768___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127769___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127769___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127769___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127769___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127769___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127769___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127770___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127770___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127770___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127770___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127770___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127770___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127771___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127771___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127771___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127771___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127771___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127771___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127772___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127772___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127772___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127772___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127773___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127773___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127773___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127773___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127790___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127790___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127790___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127790___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127790___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127790___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127791___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127791___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127791___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127791___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127791___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127791___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127988___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127988___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127988___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127988___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127988___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127988___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127989___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127989___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127989___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127989___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127989___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127989___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127990___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127990___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127990___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127990___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127990___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127990___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127991___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127991___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127991___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127991___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127991___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127991___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127992___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127992___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127992___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127992___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127992___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127992___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128263___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128263___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128263___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128263___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128610___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128610___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128611___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128611___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128611___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128611___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128611___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128611___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128612___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128612___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128612___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128612___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128612___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128612___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128612___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128612___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*2:0*/ __VdfgTmp_h410f7c75__0;
    __VdfgTmp_h410f7c75__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1ff7b9c3__0;
    __VdfgTmp_h1ff7b9c3__0 = 0;
    CData/*4:0*/ __VdfgTmp_h860e6d13__0;
    __VdfgTmp_h860e6d13__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc59b0ae4__0;
    __VdfgTmp_hc59b0ae4__0 = 0;
    CData/*2:0*/ __VdfgTmp_hd985bb83__0;
    __VdfgTmp_hd985bb83__0 = 0;
    CData/*4:0*/ __VdfgTmp_h188a23cd__0;
    __VdfgTmp_h188a23cd__0 = 0;
    CData/*2:0*/ __VdfgTmp_h237a6a81__0;
    __VdfgTmp_h237a6a81__0 = 0;
    // Body
    vlSelf->__VdfgTmp_he998c60f__0 = ((4U & ((IData)(
                                                     (0xfcfaf0f0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xca00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hf89db412__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_hae784e62__0))))))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(
                                                        (0xfe000000ffff0000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___057377_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057376_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((0xf0fdU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((0x11f00000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xeeeeeeeeff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057339_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ff00ffff4040ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057334_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057333_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0ccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134165___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                                >> 1U))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x2e2e0faaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009726_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 5U)))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x101ff01ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057349_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057348_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x44440000f000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057343_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x33aa0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                                >> 1U)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                                >> 1U))))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0faa3300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf044U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055826_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 0xdU)))))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011163_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057330_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x7fff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057328_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22919fe9__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))))))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xf0f0cc5500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___033411_)))))))))))))))) 
                                                << 1U)) 
                                         | (1U & ((IData)(vlSelf->wasmetal_core__DOT___009681_)
                                                   ? 
                                                  (0xdcU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xf0f0fef00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___057319_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057318_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___010092_)) 
                                                                                & (IData)(
                                                                                (0xfffff1111ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012594_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf8f80000ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057299_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x1d1d00000f55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056062_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                                >> 3U))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((0xff8fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057308_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                                >> 3U))))))))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fffeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012604_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012603_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012602_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056196_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056238_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127735___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                                                >> 1U)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                                >> 1U)))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0f030f0f0f05ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127738___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127748___O) 
                                                                                >> 2U))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009691_)))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007364_)))))
                                                   : 
                                                  (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xff00ff00efef0000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057285_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057284_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056601_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfef0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00fff800000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057247_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012644_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011102_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011103_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011026_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf000ee00ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057246_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffefffe0000ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057244_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xffaaccf0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h15546f37__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011101_)))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011163_)))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007366_)))))))));
    vlSelf->wasmetal_core__DOT___019300_ = ((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___011740_)
                                                ? (0xfcfaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h05777dd7__0))))
                                                : (0xfcfaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                ? 
                                                               (2U 
                                                                >> 
                                                                (1U 
                                                                 & (IData)(
                                                                           (0xf0f0ccccff00aaaaULL 
                                                                            >> 
                                                                            ((0x20U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056191_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                >> 2U)))))))))))
                                                                : 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___009693_)
                                                                 ? 
                                                                (0xeU 
                                                                 >> 
                                                                 ((2U 
                                                                   & ((IData)(
                                                                              (0xf0f00000aa33ULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ff0f0f1111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056853_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056240_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xcc0035U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127734___O) 
                                                                                >> 3U)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((~ 
                                                                                (0x4f00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                                                >> 2U))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fffcfff5ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012003_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012002_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012001_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056240_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O))))))))))))))) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & (IData)(
                                                                               (0xf0f0aa3300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff0fff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056841_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056191_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056250_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                                >> 2U))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00bb00ff00f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056836_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056835_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056191_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056250_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O))))))))))))))))))
                                                                 : 
                                                                (0xf1U 
                                                                 >> 
                                                                 ((4U 
                                                                   & ((IData)(
                                                                              (0xdfdddddf00000000ULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xbb0b0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056860_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O)) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fff7ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012008_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012007_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ddf0adc__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fffdULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012012_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012011_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xfafcU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4aad360c__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011103_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdf888c66__0)))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & ((IData)(
                                                                                (0xf0f0f030f0f0f05ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127737___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127747___O) 
                                                                                >> 3U))))))))) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___009691_)))))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                 ? 
                                                                (2U 
                                                                 >> 
                                                                 (1U 
                                                                  & (IData)(
                                                                            (0xff00aaaaf0f0ccccULL 
                                                                             >> 
                                                                             ((0x20U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d))))))))))
                                                                 : 
                                                                (0x7f0fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___012019_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012015_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xafcf0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaf0fbbffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056775_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056778_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d))))))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha6c246b8__0)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___009679_ = (1U & (0xbe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf38792bb__0))));
    vlSelf->__VdfgTmp_h72854726__0 = (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012018_));
    vlSelf->__VdfgTmp_h7c6e85dc__0 = ((4U & ((IData)(
                                                     (0xfcfaf0f0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xca00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hde31b2d5__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_h13e1c0a0__0))))))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(
                                                        (0x11110000000fULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057602_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & (((~ (IData)(vlSelf->wasmetal_core__DOT___011740_)) 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                            ? 
                                                                           (2U 
                                                                            >> (IData)(vlSelf->wasmetal_core__DOT___013002_))
                                                                            : (IData)(
                                                                                (0xffff8fffffff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013002_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013001_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf000ee00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057542_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012559_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0ff7777U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057540_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057539_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010092_)))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xbeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf38792bb__0)))))))))))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((4U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___007417_))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & ((1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0ccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d))))))))))) 
                                                                            & (IData)(
                                                                                (0xff0fff0fff00ffeeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013031_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                                                 ? 
                                                                                (0x1fU 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056247_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127722___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                                                >> 3U)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                                >> 3U))))))))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x1d1d00000f55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056070_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xcfaf0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                                                >> 1U))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((~ 
                                                                                (0x4f00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                                                >> 3U))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fffdULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013078_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013076_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010084_))))))))))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (((0xff8fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057589_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                                >> 1U))))))))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fffeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013083_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013082_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013081_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056239_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                                                >> 3U)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                                >> 3U))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0f030f0f0f05ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127739___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127737___O))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009691_))))))))))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0xffff0000fe000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057676_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057675_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0fdU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf111100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057626_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0faf0f300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xfdd0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                                >> 3U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0x888b8888U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d))))))
                                                                                 : 
                                                                                (0x888b8888U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 0xfU)))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00bb00ff000f00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057618_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057617_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf5fc0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb920cb05__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127728___O))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x2e2e0faa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010043_))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0faa3300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf044U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x2e2e0faaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010043_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 7U)))))))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011163_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xeU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xfc550000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xfff1f100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf218f314__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057635_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                                                & (IData)(
                                                                                (0xff00ffaaff0fff33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013104_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013103_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013047_))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057633_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                                 ? (IData)(vlSelf->wasmetal_core__DOT___013114_)
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8088f5ad__0)))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___013108_))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___009692_)) 
                                                                                & ((1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127743___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h46d848cb__0))))))
                                                                                 ? 
                                                                                (0x40000000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1cb679e9__0))
                                                                                 : (IData)(
                                                                                (0x555555557fffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127741___O) 
                                                                                << 5U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1cb679e9__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009691_)))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0cc5500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010044_)))))))))))))))))));
    wasmetal_core__DOT___127766___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025447_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127766___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127788___O) 
                     >> 3U)));
    wasmetal_core__DOT___025451_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025450_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025449_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025448_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O)))));
    wasmetal_core__DOT___127790___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025743_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___025669_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->wasmetal_core__DOT___061669_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043887_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007060_))));
    wasmetal_core__DOT___061148_ = (1U & (0xb0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___061145_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___043549_)))));
    vlSelf->wasmetal_core__DOT___060991_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xffffb0b0ff00ff00ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060978_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010614_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060977_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019220_))));
    vlSelf->wasmetal_core__DOT___061050_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061049_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___043549_)))));
    vlSelf->wasmetal_core__DOT___061254_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061250_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060737_)))));
    vlSelf->wasmetal_core__DOT___019273_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061258_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060737_)))));
    vlSelf->wasmetal_core__DOT___061172_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061168_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060737_)))));
    vlSelf->wasmetal_core__DOT___019262_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061176_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060737_)))));
    vlSelf->wasmetal_core__DOT___061090_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061086_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060737_)))));
    vlSelf->wasmetal_core__DOT___061001_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060997_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060737_)))));
    vlSelf->wasmetal_core__DOT___060920_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060916_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060737_)))));
    vlSelf->wasmetal_core__DOT___060835_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060831_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060737_)))));
    vlSelf->wasmetal_core__DOT___061324_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061320_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060737_)))));
    vlSelf->wasmetal_core__DOT___019283_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060710_))));
    wasmetal_core__DOT___128610___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027572_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128610___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___027490_));
    vlSelf->__VdfgTmp_h58fc10a4__0 = ((4U & ((IData)(
                                                     (0xfcfaf0f0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xca00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h3226e594__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb6cab41b__0))))))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(
                                                        (0x4fff00ff00000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057236_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057235_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & (((~ (IData)(vlSelf->wasmetal_core__DOT___010092_)) 
                                                                        & (IData)(
                                                                                (0xfdfff0ff00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012472_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012471_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012470_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xd0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012499_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f01111ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057220_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9cfb33d2__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___012476_))
                                                                                 : 
                                                                                (0xfcf5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012477_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h187b70d7__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xfff11ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f0aaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x55550f0fffccff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057187_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 0xcU)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00bb00ff000fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057190_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057189_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf0f055ccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010068_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127729___O) 
                                                                                >> 1U))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0ccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134165___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054929_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010021_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 4U)))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xccaa00000f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ff004444f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057197_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057196_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054929_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010021_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf0f00ddU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127727___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O))))))))))))))))))))))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (0x10U 
                                                                            >> 
                                                                            ((4U 
                                                                              & ((0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                                                 ? 
                                                                                (0x7fffU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127742___O) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h83b9759e__0)))
                                                                                 : 
                                                                                (0x7fffU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127740___O) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h83b9759e__0)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))) 
                                                                                << 2U)) 
                                                                             | ((((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                & (IData)(
                                                                                (0xff00ff33f0f0f5f5ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012451_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf110000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb961a9be__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012449_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012448_))))))))) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011163_)))))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0xf0f0000000ddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057159_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h07c00df2__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00fff100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057154_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057153_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xc000aU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127738___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127748___O) 
                                                                                >> 1U))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009692_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xd0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056195_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009840_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010092_)))))))))))))));
    vlSelf->wasmetal_core__DOT___025135_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2a75aa71__0))));
    vlSelf->wasmetal_core__DOT___025137_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he998c60f__0))));
    vlSelf->wasmetal_core__DOT___025134_ = (1U & (0xfdf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019300_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h09a23322__0)))));
    vlSelf->wasmetal_core__DOT___025133_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011157_)) 
                                                  & (IData)(
                                                            (0xff00ff4fff00ff00ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011155_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011154_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0x3f5fU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf1275c5a__0))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & (((~ (IData)(vlSelf->wasmetal_core__DOT___011740_)) 
                                                                               & (IData)(
                                                                                (0xfff1ffff0000ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011739_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011738_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011737_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0f030f0f0f05ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127737___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127747___O) 
                                                                                >> 2U)))))))))))))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & ((0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff55550f0f3333ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010092_)))) 
                                                                                & (IData)(
                                                                                (0x57775fff57575757ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009679_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011679_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011678_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf5f0f3fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xafcf0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009910_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127722___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                                                >> 1U)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xfbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((~ 
                                                                                (0x4f00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                                                >> 1U))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fffcfffaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011733_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011732_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011731_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x33550f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010646_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                                                >> 3U))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf5f0f3f00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xafcf0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009830_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056107_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127724___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                                                >> 1U)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xfbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011685_))
                                                                                 : 
                                                                                (0xbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011685_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011685_))
                                                                                 : 
                                                                                (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011685_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011684_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011683_))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x33550f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056107_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                                                                >> 2U))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h72854726__0))))))))))))))))))))));
    vlSelf->__VdfgTmp_hefffee35__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                << 1U) 
                                               | (1U 
                                                  & (IData)(
                                                            (0x33035505ff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056542_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054706_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___054699_))))))))))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(
                                                        (0x4fff00ff00000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056540_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056539_) 
                                                                 << 3U) 
                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                     & (IData)(
                                                                               (0xfff4ffff0000ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011076_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011075_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011074_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127741___O) 
                                                                                >> 1U)))))))))))))) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((0xcfafU 
                                                                           >> 
                                                                           ((0x10U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O))))))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & ((0x1fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f553300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f3355U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134164___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055363_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf4f4000000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056471_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff000000f4f4ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127719___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043735_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055363_))))))))))))))))))) 
                                                                            & (IData)(
                                                                                (0xff00ff00fff0fffeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010908_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127736___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012496_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_))))))))))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0xff00ff00ff000e00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056420_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056419_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0fe0000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056411_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0fdULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056394_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056393_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xd0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000000eeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056403_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcfafU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056399_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                                                >> 3U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((~ 
                                                                                (0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0)))) 
                                                                                & (IData)(
                                                                                (0xffccffaaff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010904_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4448f15c__0)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056242_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127734___O)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0f030f0f0f050ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011074_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127737___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127747___O) 
                                                                                >> 1U))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x3333bffb00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012207_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056389_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4b49f700__0))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((~ (IData)(vlSelf->wasmetal_core__DOT___009681_)) 
                                                                             & ((1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                                                 ? 
                                                                                (0xfdfcU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009679_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h72854726__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((0xd0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x335500000f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009833_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056104_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                                                                >> 1U))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0ff44ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))))))) 
                                                                                & (IData)(
                                                                                (0xf0fffeff00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010381_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010380_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010379_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010377_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x55330f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x330f0f0fff55ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011136_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056336_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056335_)))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha73aa920__0))))))))))))
                                                                                 : 
                                                                                (0xfdfcU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009679_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h72854726__0)) 
                                                                                << 2U)) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                & (IData)(
                                                                                (0x5555cccc0f0fff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010076_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009911_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                                                >> 2U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009911_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127722___O)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf044U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))))))))) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x3a00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056334_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x30303000aa0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdeb472fa__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010727_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h62b744ad__0))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056331_)))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___025132_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7c6e85dc__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127766___O 
        = ((((IData)(wasmetal_core__DOT___025448_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___025447_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___025446_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025445_)))) 
           ^ (((IData)(wasmetal_core__DOT___127766___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127766___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127766___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025371_)))));
    wasmetal_core__DOT___025376_ = (1U & ((IData)(wasmetal_core__DOT___025448_)
                                           ? (IData)(wasmetal_core__DOT___127766___DOT__CO__BRA__2__KET__)
                                           : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O)));
    wasmetal_core__DOT___127790___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025744_)
                  ? (IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->wasmetal_core__DOT___061714_ = (1U & (IData)(
                                                         (0xf55ff03037777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061669_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061668_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043528_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xeeee0f0f00ff00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h02d5ce92__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007190_)))))))));
    wasmetal_core__DOT____Vcellout___127985___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___027573_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___027572_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___027571_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027570_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128610___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128610___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128610___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027529_)))));
    wasmetal_core__DOT___027557_ = ((IData)(vlSelf->wasmetal_core__DOT___027573_)
                                     ? (IData)(wasmetal_core__DOT___128610___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___027491_));
    vlSelf->wasmetal_core__DOT___025136_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h58fc10a4__0))));
    vlSelf->wasmetal_core__DOT___025131_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hefffee35__0))));
    wasmetal_core__DOT___039333_ = (1U & (0xfffff888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___057679_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___025132_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___027484_)))))));
    vlSelf->__VdfgTmp_h4eb011e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127766___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h57d4c6cf__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h57d4c6cf__0)))))))));
    vlSelf->__VdfgTmp_h5b73c7a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127766___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hde3a7a63__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hde3a7a63__0)))))))));
    wasmetal_core__DOT___127767___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025449_)
                  ? (IData)(wasmetal_core__DOT___025376_)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                     >> 1U)));
    wasmetal_core__DOT___127790___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025745_)
                  ? (IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    wasmetal_core__DOT___061240_ = (1U & (IData)((0x55cc0f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060718_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                   << 2U) 
                                                                  | (3U 
                                                                     & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127985___O) 
                                                                                >> 2U))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055660_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc326eb38__0))))))))))));
    vlSelf->wasmetal_core__DOT___061162_ = (1U & (0xeU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfaf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___061148_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x55330f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060718_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055606_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h57efbd27__0))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127985___O) 
                                                                                >> 1U))))))))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009726_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007874_))))));
    wasmetal_core__DOT___061067_ = (1U & (IData)((0x55cc0f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060718_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                   << 2U) 
                                                                  | (3U 
                                                                     & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127985___O))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055558_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc9c602ec__0))))))))))));
    wasmetal_core__DOT___061300_ = (1U & (IData)((0x55cc0f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060718_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                   << 2U) 
                                                                  | (3U 
                                                                     & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127985___O) 
                                                                                >> 3U))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055712_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h57d78adc__0))))))))))));
    wasmetal_core__DOT___128611___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027574_)
            ? (IData)(wasmetal_core__DOT___027557_)
            : (IData)(vlSelf->wasmetal_core__DOT___027492_));
    vlSelf->wasmetal_core__DOT____Vcellinp___135196___A 
        = ((0x3fffff80U & ((- (IData)((1U & (8U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___025132_)))))) 
                           << 7U)) | ((0x40U & ((8U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___025138_))) 
                                                << 6U)) 
                                      | ((0x20U & (
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___025137_))) 
                                                   << 5U)) 
                                         | ((0x10U 
                                             & ((8U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___025136_))) 
                                                << 4U)) 
                                            | ((8U 
                                                & ((8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___025135_))) 
                                                   << 3U)) 
                                               | ((4U 
                                                   & ((8U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___025134_))) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___025133_))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (8U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___025131_)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134230___A 
        = ((0x3fff8000U & ((- (IData)((IData)(wasmetal_core__DOT___039333_))) 
                           << 0xfU)) | ((0x4000U & 
                                         ((0xf8U >> 
                                           (((IData)(wasmetal_core__DOT___039333_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)))) 
                                          << 0xeU)) 
                                        | ((0x2000U 
                                            & ((0xf8U 
                                                >> 
                                                (((IData)(wasmetal_core__DOT___039333_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                               << 0xdU)) 
                                           | ((0x1000U 
                                               & ((0xf8U 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___039333_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                  << 0xcU)) 
                                              | ((0x800U 
                                                  & ((0xf8U 
                                                      >> 
                                                      (((IData)(wasmetal_core__DOT___039333_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                     << 0xbU)) 
                                                 | ((0x400U 
                                                     & ((0xf8U 
                                                         >> 
                                                         (((IData)(wasmetal_core__DOT___039333_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                        << 0xaU)) 
                                                    | ((0x200U 
                                                        & ((0xf8U 
                                                            >> 
                                                            (((IData)(wasmetal_core__DOT___039333_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                           << 9U)) 
                                                       | ((0x100U 
                                                           & ((0xf8U 
                                                               >> 
                                                               (((IData)(wasmetal_core__DOT___039333_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                              << 8U)) 
                                                          | ((0x80U 
                                                              & ((0xf8U 
                                                                  >> 
                                                                  (((IData)(wasmetal_core__DOT___039333_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                 << 7U)) 
                                                             | ((0x40U 
                                                                 & ((0xf8U 
                                                                     >> 
                                                                     (((IData)(wasmetal_core__DOT___039333_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                    << 6U)) 
                                                                | ((0x20U 
                                                                    & ((0xf8U 
                                                                        >> 
                                                                        (((IData)(wasmetal_core__DOT___039333_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                       << 5U)) 
                                                                   | ((0x10U 
                                                                       & ((0xf8U 
                                                                           >> 
                                                                           (((IData)(wasmetal_core__DOT___039333_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                          << 4U)) 
                                                                      | ((8U 
                                                                          & ((0xf8U 
                                                                              >> 
                                                                              (((IData)(wasmetal_core__DOT___039333_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                             << 3U)) 
                                                                         | ((4U 
                                                                             & ((0xf8U 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___039333_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                                << 2U)) 
                                                                            | ((2U 
                                                                                & ((0xf8U 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___039333_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (0xf8U 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___039333_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134232___A 
        = ((0x10000U & ((0xf8U >> (((IData)(wasmetal_core__DOT___039333_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                        << 0x10U)) | ((0x8000U & ((0xf8U 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___039333_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xfffffffffffff888ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___057679_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057686_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___025132_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___027483_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xfffffffffffff888ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___057679_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057685_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___025132_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___027482_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xfffffffffffff888ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___057679_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057684_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___025132_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___027481_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xfffffffffffff888ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___057679_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057683_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___025132_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___027480_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffffffffffff888ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___057679_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057682_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___025132_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___027479_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffffffffffff888ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___057679_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057681_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___025132_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___027493_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffffffffffff888ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___057679_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057680_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___025132_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___027492_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((IData)(
                                                                          (0xfffffffffffff888ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___057679_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___057678_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___025132_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___027491_)))))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((0x8fU 
                                                                      >> 
                                                                      ((4U 
                                                                        & ((IData)(
                                                                                (0x777000007770777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055014_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027490_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___025138_)))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((0x8fU 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0x777000007770777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054973_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027489_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___025137_)))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((0x8fU 
                                                                            >> 
                                                                            ((4U 
                                                                              & ((IData)(
                                                                                (0x777000007770777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054931_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027488_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___025136_)))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((0x8fU 
                                                                               >> 
                                                                               ((4U 
                                                                                & ((IData)(
                                                                                (0x777000007770777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054890_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027487_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___025135_)))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((0x8fU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x777000007770777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054844_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027486_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___025134_)))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((0x8fU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x777000007770777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054799_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027485_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___025133_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x77707770777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054748_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027478_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___025131_)))))))))))))))))))));
    wasmetal_core__DOT___127767___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025450_)
                  ? (IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127790___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___025746_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___025745_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___025744_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025743_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025669_)))));
    wasmetal_core__DOT___025673_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025746_)
                                           ? (IData)(wasmetal_core__DOT___127790___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 0x14U))));
    vlSelf->wasmetal_core__DOT___061244_ = (1U & (IData)(
                                                         (0xff440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___061240_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055661_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___061238_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___043549_))))))))))));
    vlSelf->wasmetal_core__DOT___061081_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xffffb0b0ff00ff00ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___061067_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010021_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061066_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019220_))));
    vlSelf->wasmetal_core__DOT___061314_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xffffb0b0ff00ff00ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___061300_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061299_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019220_))));
    wasmetal_core__DOT___128611___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027575_)
            ? (IData)(wasmetal_core__DOT___128611___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___027493_));
    wasmetal_core__DOT___127767___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025451_)
                  ? (IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127789___O) 
                     >> 3U)));
    wasmetal_core__DOT___025456_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0x10U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025454_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025453_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025452_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135067_.__PVT__alu_sum 
                                                              >> 0xdU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127790___O)))));
    wasmetal_core__DOT___127791___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025747_)
                  ? (IData)(wasmetal_core__DOT___025673_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    wasmetal_core__DOT___128611___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027561_)
            ? (IData)(wasmetal_core__DOT___128611___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___027479_));
    wasmetal_core__DOT____Vcellout___127767___O = (
                                                   (((IData)(wasmetal_core__DOT___025452_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025451_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025450_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025449_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025376_)))));
    wasmetal_core__DOT___025380_ = (1U & ((IData)(wasmetal_core__DOT___025452_)
                                           ? (IData)(wasmetal_core__DOT___127767___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127790___O)));
    wasmetal_core__DOT___127791___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025748_)
                  ? (IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    wasmetal_core__DOT____Vcellout___127986___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___027562_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___027561_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___027575_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027574_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128611___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128611___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128611___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___027557_)))));
    wasmetal_core__DOT___027498_ = ((IData)(vlSelf->wasmetal_core__DOT___027562_)
                                     ? (IData)(wasmetal_core__DOT___128611___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___027480_));
    vlSelf->wasmetal_core__DOT___014591_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127767___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015139_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127767___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->__VdfgTmp_h8d338479__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127767___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hbc521204__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hbc521204__0)))))))));
    vlSelf->wasmetal_core__DOT___014926_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127767___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8020f35b__0))))));
    vlSelf->__VdfgTmp_hac6eec7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___127767___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd7693faf__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd7693faf__0)))))))));
    wasmetal_core__DOT___127768___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025453_)
                  ? (IData)(wasmetal_core__DOT___025380_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                     >> 1U)));
    wasmetal_core__DOT___127791___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025750_)
                  ? (IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                             >> 0x14U))));
    vlSelf->__VdfgTmp_h8e4351c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                       << 2U) | ((2U 
                                                  & ((0x4fU 
                                                      >> 
                                                      ((((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                         & (IData)(
                                                                   (0xffeeff000f0f0f0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019245_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127986___O) 
                                                                                >> 3U))))))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019243_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019242_))))))))) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060960_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___043549_))))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___060962_)));
    wasmetal_core__DOT___060885_ = (1U & (IData)((0xfff0ff8800000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060866_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___127986___O)) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127986___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048404_)))))))));
    wasmetal_core__DOT___060800_ = (1U & (IData)((0xfff0ff8800000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060779_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127986___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___127986___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048404_)))))))));
    wasmetal_core__DOT___060695_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0xfff4ff0000000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((0xac00U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_hfd347d5f__0)))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055732_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))))) 
                                                << 1U)) 
                                              | (1U 
                                                 & (0xf088U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127986___O) 
                                                            << 2U)) 
                                                        | ((2U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127986___O) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___048404_))))))))));
    wasmetal_core__DOT___128612___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027563_)
            ? (IData)(wasmetal_core__DOT___027498_)
            : (IData)(vlSelf->wasmetal_core__DOT___027481_));
    wasmetal_core__DOT___127768___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025454_)
                  ? (IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127791___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___025751_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___025750_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___025748_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025747_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025673_)))));
    wasmetal_core__DOT___025678_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025751_)
                                           ? (IData)(wasmetal_core__DOT___127791___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                                      >> 0x14U))));
    vlSelf->wasmetal_core__DOT___060910_ = (1U & (IData)(
                                                         (0x4f4f00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060885_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056708_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060884_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))));
    vlSelf->wasmetal_core__DOT___019219_ = (1U & (IData)(
                                                         (0x4f4f00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060800_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xfef0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hc6176170__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060798_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))));
    vlSelf->wasmetal_core__DOT___060729_ = (1U & (IData)(
                                                         (0x4f4f00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060695_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x1fU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcb50dc13__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060692_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))));
    wasmetal_core__DOT___128612___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027564_)
            ? (IData)(wasmetal_core__DOT___128612___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___027482_));
    wasmetal_core__DOT___127768___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025456_)
                  ? (IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127790___O) 
                     >> 3U)));
    wasmetal_core__DOT___025460_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025459_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025458_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025457_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127791___O)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127792___O 
        = ((IData)(vlSelf->wasmetal_core__DOT___025751_) 
           ^ ((2U & (((IData)(vlSelf->wasmetal_core__DOT___025751_)
                       ? (IData)(wasmetal_core__DOT___025678_)
                       : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135068_.__PVT__alu_sum 
                                  >> 0x14U))) << 1U)) 
              | (IData)(wasmetal_core__DOT___025678_)));
    wasmetal_core__DOT___128612___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027565_)
            ? (IData)(wasmetal_core__DOT___128612___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___027483_));
    vlSelf->wasmetal_core__DOT____Vcellout___127768___O 
        = ((((IData)(wasmetal_core__DOT___025457_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025456_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025454_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025453_)))) 
           ^ (((IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025380_)))));
    wasmetal_core__DOT___025385_ = (1U & ((IData)(wasmetal_core__DOT___025457_)
                                           ? (IData)(wasmetal_core__DOT___127768___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127791___O)));
    vlSelf->wasmetal_core__DOT___025479_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0x14U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025478_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0x13U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025476_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0x12U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025475_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0x11U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025474_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0x10U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025473_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0xfU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025472_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0xeU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    vlSelf->wasmetal_core__DOT___025471_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                                >> 0xdU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025470_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025469_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025468_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025467_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025465_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025464_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025463_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025462_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___025461_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135064_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)))));
    wasmetal_core__DOT___128612___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128612___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128612___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___128612___DOT__CO__BRA__0__KET__)));
    if (vlSelf->wasmetal_core__DOT___027566_) {
        wasmetal_core__DOT___027502_ = wasmetal_core__DOT___128612___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127988___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027502_;
        wasmetal_core__DOT___127988___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127988___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127988___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127988___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027506_ = wasmetal_core__DOT___127988___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127989___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027506_;
        wasmetal_core__DOT___127989___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127989___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127989___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127989___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027511_ = wasmetal_core__DOT___127989___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127990___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027511_;
        wasmetal_core__DOT___127990___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127990___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127990___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127990___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027515_ = wasmetal_core__DOT___127990___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127991___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027515_;
        wasmetal_core__DOT___127991___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127991___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127991___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127991___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027520_ = wasmetal_core__DOT___127991___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127992___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027520_;
        wasmetal_core__DOT___127992___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127992___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127992___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127992___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___027524_ = wasmetal_core__DOT___127992___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027524_;
        wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027528_ = wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027528_;
        wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027533_ = wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027533_;
        wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027537_ = wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027537_;
        wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027542_ = wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027542_;
        wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027546_ = wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027546_;
        wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___027550_ = wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027550_;
        wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__;
    } else {
        wasmetal_core__DOT___027502_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127988___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127988___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127988___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027506_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127989___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127989___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127989___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027511_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127990___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127990___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127990___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027515_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127991___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127991___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127991___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027520_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127992___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127992___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127992___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        vlSelf->wasmetal_core__DOT___027524_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027528_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027533_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027537_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027542_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027546_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___027550_ = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
        wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___027484_;
    }
    vlSelf->wasmetal_core__DOT___058206_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015541_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->__VdfgTmp_hf11accec__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd215401d__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd215401d__0)))))))));
    vlSelf->wasmetal_core__DOT___014788_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_he7d53082__0))))));
    vlSelf->wasmetal_core__DOT___014628_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h943c9679__0))))));
    wasmetal_core__DOT___127769___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025458_)
                  ? (IData)(wasmetal_core__DOT___025385_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                     >> 1U)));
    wasmetal_core__DOT____Vcellout___127987___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___027566_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___027565_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___027564_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027563_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128612___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___027498_)));
    wasmetal_core__DOT___127769___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025459_)
                  ? (IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                     >> 2U)));
    wasmetal_core__DOT___061214_ = ((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                    & (IData)((0xffeeff000f0f0f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019268_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                   << 2U) 
                                                                  | (3U 
                                                                     & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127987___O) 
                                                                                >> 2U))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019266_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))))));
    wasmetal_core__DOT___061132_ = ((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                    & (IData)((0xffeeff000f0f0f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019257_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                   << 2U) 
                                                                  | (3U 
                                                                     & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127987___O) 
                                                                                >> 1U))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019255_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))))));
    vlSelf->wasmetal_core__DOT___061052_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xaaccf0f000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055805_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h413b142d__0))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                    << 2U) 
                                                                   | (3U 
                                                                      & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127987___O))))))))))))));
    vlSelf->__VdfgTmp_h246938f7__0 = ((2U & ((0xf00cf0a8U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___043549_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043923_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048364_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___043541_)))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf0f0335500000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & (((~ (IData)(vlSelf->wasmetal_core__DOT___019202_)) 
                                                                      & (IData)(
                                                                                (0x55ff33ff0fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h69142c13__0)))))))) 
                                                                     << 2U)) 
                                                                 | (3U 
                                                                    & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127987___O) 
                                                                                >> 3U)))))))))))));
    wasmetal_core__DOT___127769___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025460_)
                  ? (IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127791___O) 
                     >> 3U)));
    vlSelf->wasmetal_core__DOT___061215_ = (1U & (IData)(
                                                         (0x4f4f00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___061214_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061213_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061212_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))));
    vlSelf->wasmetal_core__DOT___061133_ = (1U & (IData)(
                                                         (0x4f4f00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___061132_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xdU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hbcde5889__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061130_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))));
    wasmetal_core__DOT____Vcellout___127769___O = (
                                                   (((IData)(wasmetal_core__DOT___025461_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025460_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025459_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025458_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025385_)))));
    wasmetal_core__DOT___025389_ = (1U & ((IData)(wasmetal_core__DOT___025461_)
                                           ? (IData)(wasmetal_core__DOT___127769___DOT__CO__BRA__2__KET__)
                                           : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    wasmetal_core__DOT____Vcellout___127988___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127988___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127988___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127988___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027502_))))));
    vlSelf->wasmetal_core__DOT___058643_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127769___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___058202_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___015438_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___058204_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->wasmetal_core__DOT___014655_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h023f0a12__0))))));
    vlSelf->wasmetal_core__DOT___014674_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7328e0ec__0))))));
    vlSelf->wasmetal_core__DOT___014682_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127769___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5b0d2f75__0))))));
    vlSelf->wasmetal_core__DOT___014742_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127769___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcd6303e8__0))))));
    wasmetal_core__DOT___127770___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025462_)
                  ? (IData)(wasmetal_core__DOT___025389_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___060998_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127988___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___060917_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127988___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___060832_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127988___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060755_ = (1U & (0xf4f400ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060743_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xd0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060738_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___060737_)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x335f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048404_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127988___O) 
                                                                               << 1U)) 
                                                                           | (IData)(wasmetal_core__DOT___027502_)))))) 
                                                                << 1U)) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___019204_)
                                                                   ? (IData)(
                                                                             (0xfff5fffcfff0fff0ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019200_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h84d44246__0)))))))))))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019202_))))))))));
    wasmetal_core__DOT___127770___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025463_)
                  ? (IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    wasmetal_core__DOT___127770___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025464_)
                  ? (IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__1__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT____Vcellout___127770___O 
        = ((((IData)(wasmetal_core__DOT___025465_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025464_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025463_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025462_)))) 
           ^ (((IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025389_)))));
    wasmetal_core__DOT___025393_ = (1U & ((IData)(wasmetal_core__DOT___025465_)
                                           ? (IData)(wasmetal_core__DOT___127770___DOT__CO__BRA__2__KET__)
                                           : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    wasmetal_core__DOT____Vcellout___127989___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127989___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127989___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127989___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027506_))))));
    vlSelf->wasmetal_core__DOT___014713_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127770___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->__VdfgTmp_hd3180128__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127770___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h51de0e2b__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h51de0e2b__0)))))))));
    vlSelf->__VdfgTmp_hdfd6d7e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127770___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdd32c6cf__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdd32c6cf__0)))))))));
    vlSelf->wasmetal_core__DOT___014647_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127770___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7410d216__0))))));
    wasmetal_core__DOT___127771___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025467_)
                  ? (IData)(wasmetal_core__DOT___025393_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___061251_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127989___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___061169_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127989___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___061087_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127989___O))))));
    vlSelf->wasmetal_core__DOT___061321_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127989___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127771___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025468_)
                  ? (IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___019253_ = (1U & (IData)(
                                                         (0xdd0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061090_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061089_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061088_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061087_)))))))));
    wasmetal_core__DOT___127771___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025469_)
                  ? (IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__1__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    wasmetal_core__DOT____Vcellout___127771___O = (
                                                   (((IData)(wasmetal_core__DOT___025470_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025469_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025468_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025467_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025393_)))));
    vlSelf->wasmetal_core__DOT___025398_ = (1U & ((IData)(wasmetal_core__DOT___025470_)
                                                   ? (IData)(wasmetal_core__DOT___127771___DOT__CO__BRA__2__KET__)
                                                   : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    wasmetal_core__DOT____Vcellout___127990___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127990___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127990___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127990___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027511_))))));
    vlSelf->wasmetal_core__DOT___058618_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127771___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005669_))));
    vlSelf->__VdfgTmp_h7c5b2a1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___127771___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hab2a3827__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hab2a3827__0)))))))));
    vlSelf->__VdfgTmp_h8c8b9fc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127771___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4f4cafcf__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4f4cafcf__0)))))))));
    vlSelf->__VdfgTmp_hcbc05328__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127771___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc03ce175__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc03ce175__0)))))))));
    vlSelf->wasmetal_core__DOT___014772_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127771___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3c2f1975__0))))));
    vlSelf->wasmetal_core__DOT___127772___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025471_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___025398_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    wasmetal_core__DOT___061003_ = (1U & (0x70U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127990___O) 
                                                    >> 3U))))));
    vlSelf->__VdfgTmp_hd0027aa1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___060927_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((0xd0U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060924_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___060737_)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & ((0x70U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127990___O) 
                                                                     >> 2U))))) 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___019202_)
                                                              ? 
                                                             (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___019205_))
                                                              : (IData)(
                                                                        (0xffffff1fffffffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xafcf0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h03e9ae47__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019232_))))))))))))));
    wasmetal_core__DOT___060837_ = (1U & (0x70U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127990___O) 
                                                    >> 1U))))));
    vlSelf->wasmetal_core__DOT___060756_ = (1U & (IData)(
                                                         (0xcf45454500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060748_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x70U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127990___O))))) 
                                                                        << 2U)) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT___019204_)
                                                                             ? (IData)(
                                                                                (0xfff5fffcfff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019211_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc63c8631__0)))))))))))
                                                                             : 
                                                                            (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019202_)))) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___060739_)))))))));
    wasmetal_core__DOT___127772___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025472_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127772___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->__VdfgTmp_hb8dfd2b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___061010_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((0xd0U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061007_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___060737_)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xff1fff00000000ULL 
                                                                  >> 
                                                                  (((IData)(wasmetal_core__DOT___061003_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaccf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055967_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2596a796__0))))))) 
                                                                                << 1U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___019201_))))))))))));
    vlSelf->wasmetal_core__DOT___019228_ = (1U & (0x11f00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd0027aa1__0))));
    vlSelf->__VdfgTmp_ha2d50830__0 = (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___060846_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((0xd0U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060843_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___060737_)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xff1fff00000000ULL 
                                                                  >> 
                                                                  (((IData)(wasmetal_core__DOT___060837_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaccf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055950_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6deef1cd__0))))))) 
                                                                                << 1U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___019201_))))))))))));
    vlSelf->wasmetal_core__DOT___060770_ = (1U & (IData)(
                                                         (0xbb0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060756_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060755_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h27adf041__0))))))));
    wasmetal_core__DOT___127772___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025473_)
                  ? (IData)(wasmetal_core__DOT___127772___DOT__CO__BRA__1__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___060858_ = (1U & (0x11f00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha2d50830__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127772___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___025474_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___025473_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___025472_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025471_)))) 
           ^ (((IData)(wasmetal_core__DOT___127772___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127772___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127772___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025398_)))));
    wasmetal_core__DOT___025402_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025474_)
                                           ? (IData)(wasmetal_core__DOT___127772___DOT__CO__BRA__2__KET__)
                                           : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    wasmetal_core__DOT____Vcellout___127991___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127991___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127991___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127991___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027515_))))));
    vlSelf->__VdfgTmp_h4984bec9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127772___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                              ? (IData)(
                                                                        (0xccccf0d8f0f0cce4ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc3230cc7__0)))
                                                              : (IData)(
                                                                        (0xf0f0cce4ccccf0d8ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc3230cc7__0)))))))));
    wasmetal_core__DOT___127773___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025475_)
                  ? (IData)(wasmetal_core__DOT___025402_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->__VdfgTmp_hb7a13343__0 = ((4U & ((0xfef00000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((IData)(
                                                                       (0xaaccf0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055990_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7102b895__0))))))) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                          << 1U) | 
                                         (1U & (8U 
                                                >> 
                                                ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127991___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019280_))))));
    vlSelf->__VdfgTmp_habd86bf6__0 = ((4U & ((0xfef00000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((IData)(
                                                                       (0xaaccf0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055979_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h584cbf3b__0))))))) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                          << 1U) | 
                                         (1U & (8U 
                                                >> 
                                                ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___127991___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019280_))))));
    wasmetal_core__DOT___061092_ = (1U & (0x70U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127991___O))))));
    vlSelf->wasmetal_core__DOT___061328_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127991___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    wasmetal_core__DOT___127773___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025476_)
                  ? (IData)(wasmetal_core__DOT___127773___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)));
    vlSelf->wasmetal_core__DOT___061415_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((0xfb0000U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019273_) 
                                                             << 3U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb7a13343__0)))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd684d3d4__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007874_)))));
    vlSelf->wasmetal_core__DOT___061403_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((0xfb0000U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019262_) 
                                                             << 3U) 
                                                            | (IData)(vlSelf->__VdfgTmp_habd86bf6__0)))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019261_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007874_)))));
    vlSelf->__VdfgTmp_h54394b36__0 = ((2U & ((0xd0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060739_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061096_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___060737_)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xff1fff00000000ULL 
                                                       >> 
                                                       (((IData)(wasmetal_core__DOT___061092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xaaccf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055972_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h169cd931__0))))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___019201_))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127773___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___025479_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___025478_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___025476_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025475_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___025478_)
                       ? (IData)(wasmetal_core__DOT___127773___DOT__CO__BRA__1__KET__)
                       : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127792___O)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___127773___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___127773___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___025402_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127992___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                   ^ (((IData)(wasmetal_core__DOT___127992___DOT__CO__BRA__2__KET__) 
                       << 3U) | (((IData)(wasmetal_core__DOT___127992___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(wasmetal_core__DOT___127992___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(wasmetal_core__DOT___027520_))))));
    wasmetal_core__DOT___060987_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060985_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127992___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060891_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060889_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127992___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060810_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060807_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127992___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060722_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060717_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127992___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061373_ = (1U & (IData)((0xf0faaaaccccff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060910_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___060890_) 
                                                                   << 1U) 
                                                                  | (IData)(wasmetal_core__DOT___060891_))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0xf4f400ffU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060919_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060920_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060917_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___060918_)))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0xee0fU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hd0027aa1__0)))))))))));
    wasmetal_core__DOT___061351_ = (1U & (IData)((0xf0faaaaccccff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060729_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___060721_) 
                                                                   << 1U) 
                                                                  | (IData)(wasmetal_core__DOT___060722_))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0xbU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060756_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h27adf041__0))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___060755_)))))))));
    wasmetal_core__DOT____Vcellout___127993___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127993___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127993___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127993___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___027524_))))));
    wasmetal_core__DOT___061224_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061221_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127993___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061158_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061155_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___127993___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061077_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061075_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127993___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061310_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061307_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127993___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT____Vcellout___127979___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127979___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127979___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127979___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027528_))))));
    wasmetal_core__DOT___060983_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060981_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127979___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060892_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060887_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127979___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060803_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___127979___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    wasmetal_core__DOT___060715_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127979___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    wasmetal_core__DOT___060805_ = (1U & (IData)((0xff1fff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___060803_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfff4ff0000000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9d165bb7__0))))))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019202_)))))))));
    wasmetal_core__DOT___060723_ = (1U & (IData)((0xff1fff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___060715_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfff4ff0000000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb9d2a0bf__0))))))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019202_)))))))));
    vlSelf->wasmetal_core__DOT___060862_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___019222_)
                                                   ? 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xeU 
                                                            >> 
                                                            (((IData)(wasmetal_core__DOT___060810_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h55155be3__0)))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0xe00U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___060805_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060804_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007874_)))))))))
                                                   : 
                                                  (0xc5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019219_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xffffb0b0ff00ff00ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060825_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055410_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060824_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))))))))));
    wasmetal_core__DOT____Vcellout___127980___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127980___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127980___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127980___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027533_))))));
    __VdfgTmp_h237a6a81__0 = ((4U & ((IData)((0x77070000ffff0000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061217_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127980___O) 
                                                                  >> 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___061218_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_)));
    __VdfgTmp_hd985bb83__0 = ((4U & ((IData)((0x77070000ffff0000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061151_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___127980___O)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___061152_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_)));
    __VdfgTmp_hc59b0ae4__0 = ((2U & ((1U >> (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                              << 1U) 
                                             | (IData)(vlSelf->wasmetal_core__DOT___061071_))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0x77070000ffff0000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___061070_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127980___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___019280_))))))))));
    wasmetal_core__DOT___061305_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061303_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127980___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    vlSelf->wasmetal_core__DOT___061275_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___061215_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xe00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                              << 3U) 
                                                                             | (IData)(__VdfgTmp_h237a6a81__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(wasmetal_core__DOT___061224_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb48e4863__0)))))))))))));
    vlSelf->wasmetal_core__DOT___061192_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061162_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___061133_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> 
                                                                            (((IData)(wasmetal_core__DOT___061158_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd485fb84__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xe00U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                               << 3U) 
                                                                              | (IData)(__VdfgTmp_hd985bb83__0))))))))))));
    vlSelf->wasmetal_core__DOT___061110_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061081_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfacc0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061052_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061051_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061050_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> 
                                                                            (((IData)(wasmetal_core__DOT___061077_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061076_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_hc59b0ae4__0))))))))))));
    wasmetal_core__DOT____Vcellout___127981___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127981___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127981___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127981___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027537_))))));
    wasmetal_core__DOT___061017_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061012_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127981___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060931_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060929_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127981___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060850_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060848_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___127981___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    __VdfgTmp_h1ff7b9c3__0 = ((2U & ((IData)((0xfff8888800000000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060758_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127981___O) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___019283_));
    wasmetal_core__DOT___061356_ = (1U & (IData)((0xf0f0f5f5ff00ff33ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___060805_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___060850_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060804_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___060849_)))))))));
    wasmetal_core__DOT____Vcellout___127982___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127982___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127982___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127982___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027542_))))));
    wasmetal_core__DOT___061268_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061260_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127982___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061184_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061178_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___127982___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061101_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127982___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    wasmetal_core__DOT___061334_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061332_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127982___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061103_ = (1U & (IData)((0xff1fffULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061101_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfafcf0f000000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h91f4b3ba__0))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))))));
    wasmetal_core__DOT___061424_ = (1U & (IData)((0xf0f0f5f5ff00ff33ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061305_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___061334_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061304_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061333_)))))))));
    wasmetal_core__DOT___019251_ = (1U & (0xe0eeeeU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___061103_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___061102_)))))));
    wasmetal_core__DOT____Vcellout___127983___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127983___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127983___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127983___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027546_))))));
    __VdfgTmp_h860e6d13__0 = (((IData)(vlSelf->wasmetal_core__DOT___061015_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                           << 2U) | 
                                          ((((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                             & (IData)(
                                                       (0xfffefff0ff00ff00ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (0xac00U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h2577a83c__0))))))))))))) 
                                            << 1U) 
                                           | (1U & 
                                              (8U >> 
                                               ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127983___O) 
                                                    >> 2U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___019280_))))))));
    wasmetal_core__DOT___060936_ = (1U & (IData)((0xeee00000fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060935_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127983___O) 
                                                                         >> 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___019280_))) 
                                                                   << 1U)) 
                                                               | ((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                  & (IData)(
                                                                            (0xfffefff0ff00ff00ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xac00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd69bf43a__0)))))))))))))))))))));
    wasmetal_core__DOT___060854_ = (1U & (IData)((0x77070000ffff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060852_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___127983___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___060764_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127983___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    wasmetal_core__DOT___061383_ = (1U & (IData)((0xef0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061348_) 
                                                    << 5U) 
                                                   | (IData)(__VdfgTmp_h860e6d13__0)))));
    wasmetal_core__DOT___061018_ = (1U & (IData)((0xef0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 5U) 
                                                   | (IData)(__VdfgTmp_h860e6d13__0)))));
    vlSelf->__VdfgTmp_h1772264d__0 = ((2U & ((IData)(
                                                     (0xf0fcf0f5ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((IData)(
                                                                            (0xfff00000eeee0000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060893_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060892_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___060891_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060890_)))))))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060910_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & (IData)(
                                                                                (0xffffb0b0ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060908_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060907_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))))))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___019221_)
                                                ? (IData)(
                                                          (0xeeee0000fff0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019228_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xdd0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060920_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060919_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060918_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060917_)))))))) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((0xeU 
                                                                             >> 
                                                                             (((IData)(wasmetal_core__DOT___060931_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060930_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_))))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (8U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 1U) 
                                                                               | (IData)(wasmetal_core__DOT___060936_)))))))))))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019229_)))));
    vlSelf->wasmetal_core__DOT___060861_ = (1U & (IData)(
                                                         (0x1111000f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xdd0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060835_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060834_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060833_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060832_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xe00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                              << 3U) 
                                                                             | (((IData)(wasmetal_core__DOT___060854_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h798d913c__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(wasmetal_core__DOT___060850_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060849_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_))))))))))))));
    __VdfgTmp_h410f7c75__0 = ((4U & ((IData)((0xff1fff00000000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                   << 5U) 
                                                  | (((IData)(wasmetal_core__DOT___060764_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xfff4ff0000000000ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4a046d69__0))))))))))) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___019202_)))))))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___060766_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_)));
    wasmetal_core__DOT___061387_ = (1U & (0xff1fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                            << 4U) 
                                           | (((IData)(wasmetal_core__DOT___061383_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(
                                                                (0xf0f0f5f5ff00ff33ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___060983_) 
                                                                         << 3U) 
                                                                        | (((IData)(wasmetal_core__DOT___061017_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060982_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___061016_)))))))) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___019221_)))))));
    wasmetal_core__DOT___061021_ = (1U & (IData)((0xfff100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___061018_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061017_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061016_)))))))));
    wasmetal_core__DOT___060942_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060941_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1772264d__0))));
    wasmetal_core__DOT___060864_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060863_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060862_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___060861_))))));
    vlSelf->__VdfgTmp_hc5bdda4d__0 = ((2U & ((IData)(
                                                     (0xf0fcf0faULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((IData)(
                                                                            (0xfff00000eeee0000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060724_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060723_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___060722_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060721_)))))))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060729_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & (IData)(
                                                                                (0x4f4f00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060727_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055239_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043901_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043549_)))))))))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xef0000ffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060770_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060761_) 
                                                                              << 2U) 
                                                                             | (IData)(__VdfgTmp_h1ff7b9c3__0)))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xe00U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                            << 3U) 
                                                                           | (IData)(__VdfgTmp_h410f7c75__0)))))))))))));
    wasmetal_core__DOT____Vcellout___127984___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___027566_))) 
                                                      ^ 
                                                      ((((IData)(vlSelf->wasmetal_core__DOT___027566_)
                                                          ? (IData)(wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__)
                                                          : (IData)(vlSelf->wasmetal_core__DOT___027484_)) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127984___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127984___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___027550_))))));
    vlSelf->__VdfgTmp_h167c6955__0 = ((2U & ((IData)(
                                                     (0x11110000000fULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060991_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0x3a00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                       << 3U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h8e4351c5__0))) 
                                                                    << 2U)) 
                                                                | ((2U 
                                                                    & ((0xeU 
                                                                        >> 
                                                                        (((IData)(wasmetal_core__DOT___060987_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_haf42252b__0)))) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (0xe00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 3U) 
                                                                          | (((IData)(wasmetal_core__DOT___060983_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060982_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_))))))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfe0000ffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___061021_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xdd0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061001_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061000_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060999_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060998_)))))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0x11f00000U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hb8dfd2b5__0)))))))))))));
    wasmetal_core__DOT___025174_ = (1U & (9U >> (((IData)(wasmetal_core__DOT___060942_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025134_))));
    wasmetal_core__DOT___025173_ = (1U & (9U >> (((IData)(wasmetal_core__DOT___060864_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025133_))));
    wasmetal_core__DOT___060777_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060776_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc5bdda4d__0))));
    wasmetal_core__DOT___061433_ = (1U & (0xf00eeU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((0xefefef00U 
                                                         >> 
                                                         (((IData)(wasmetal_core__DOT___061424_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061348_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((0xf7f0000U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019282_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127984___O) 
                                                                                >> 3U))))))) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___019284_)))))) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xf0f0000ccaaULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((0xf4f400ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061323_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061324_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061321_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061322_)))))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h246938f7__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055853_)))))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xeef0f000000000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                          << 4U) 
                                                                         | (((IData)(wasmetal_core__DOT___061310_) 
                                                                             << 3U) 
                                                                            | ((4U 
                                                                                & ((IData)(
                                                                                (0xeee00000fff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061327_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061328_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061329_)))))))) 
                                                                                << 2U)) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h885d71fc__0))))))))))))));
    wasmetal_core__DOT___061267_ = (1U & (IData)((0xffffe0e0ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060710_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061264_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127984___O) 
                                                                         >> 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___019280_))) 
                                                                   << 1U)) 
                                                               | ((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                  & (IData)(
                                                                            (0xfffefff0ff00ff00ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xac00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb79381c2__0)))))))))))))))))))));
    __VdfgTmp_h188a23cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___061181_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                           << 2U) | 
                                          ((((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                             & (IData)(
                                                       (0xfffefff0ff00ff00ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (0xac00U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_hdf1f98b8__0))))))))))))) 
                                            << 1U) 
                                           | (1U & 
                                              (8U >> 
                                               ((2U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127984___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___019280_))))))));
    wasmetal_core__DOT___019250_ = (1U & (IData)((0xffffe0e0ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060710_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056168_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127984___O) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___019280_))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0xfef00000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0xfafcf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1c7a54d6__0))))))) 
                                                                                << 1U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))))))))))));
    wasmetal_core__DOT___061335_ = ((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                    & (IData)((0xf8ff00ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___019284_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019282_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127984___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019280_)))))))));
    wasmetal_core__DOT___061027_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___061026_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h167c6955__0))));
    wasmetal_core__DOT___025171_ = (1U & (9U >> (((IData)(wasmetal_core__DOT___060777_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025131_))));
    wasmetal_core__DOT___061271_ = (1U & (0x33fa0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___061268_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___061267_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___061266_)))))));
    wasmetal_core__DOT___061185_ = (1U & (IData)((0xef0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                    << 5U) 
                                                   | (IData)(__VdfgTmp_h188a23cd__0)))));
    wasmetal_core__DOT___061398_ = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(
                                                                (0xffff0f0f00ffeeeeULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___019251_) 
                                                                         << 3U) 
                                                                        | (((IData)(wasmetal_core__DOT___019250_) 
                                                                            << 2U) 
                                                                           | (IData)(__VdfgTmp_hc59b0ae4__0))))))) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___019222_)))));
    vlSelf->wasmetal_core__DOT___061109_ = ((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                            & (IData)(
                                                      (0x55553333000f000fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019253_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0x11f00000U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061099_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h54394b36__0))))) 
                                                                     << 2U)) 
                                                                 | (((IData)(wasmetal_core__DOT___019251_) 
                                                                     << 1U) 
                                                                    | (IData)(wasmetal_core__DOT___019250_)))))))));
    wasmetal_core__DOT___061338_ = (1U & (IData)((0xfff100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___061335_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061334_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061333_)))))))));
    wasmetal_core__DOT___025175_ = (1U & (9U >> (((IData)(wasmetal_core__DOT___061027_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025135_))));
    wasmetal_core__DOT___127757___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___025171_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___025131_));
    vlSelf->wasmetal_core__DOT___061274_ = (1U & (0xff010000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___061271_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xdd0000f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061254_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061253_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061252_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061251_)))))))) 
                                                                << 1U)) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                               & (IData)(
                                                                         (0xfbfbff00ff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019273_) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd684d3d4__0)) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb7a13343__0)))))))))))));
    wasmetal_core__DOT___061188_ = (1U & (0xfe0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___061185_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___061184_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061183_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___019220_)))))));
    wasmetal_core__DOT___061112_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061111_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061110_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061109_))))));
    vlSelf->__VdfgTmp_h5501e8f9__0 = ((2U & ((IData)(
                                                     (0x11110000000fULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061314_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0x11f00000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055853_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h246938f7__0))))) 
                                                                    << 2U)) 
                                                                | ((2U 
                                                                    & ((0xeU 
                                                                        >> 
                                                                        (((IData)(wasmetal_core__DOT___061310_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h885d71fc__0)))) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (0xe00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                           << 3U) 
                                                                          | (((IData)(wasmetal_core__DOT___061305_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061304_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007874_))))))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfe0000ffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___061338_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xdd0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061324_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061323_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061322_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061321_)))))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xef0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061330_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019283_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061329_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061328_))))))))))))))))));
    wasmetal_core__DOT___128263___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___025173_) ? (IData)(wasmetal_core__DOT___127757___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___025133_));
    wasmetal_core__DOT___061277_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061276_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061275_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061274_))))));
    vlSelf->wasmetal_core__DOT___061191_ = (1U & (0xff010000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___061188_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xdd0000f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061172_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061169_)))))))) 
                                                                << 1U)) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                               & (IData)(
                                                                         (0xfbfbff00ff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019262_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019261_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_habd86bf6__0)))))))))))));
    vlSelf->wasmetal_core__DOT___025176_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061112_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025136_))));
    wasmetal_core__DOT___061344_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___061343_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5501e8f9__0))));
    wasmetal_core__DOT___128263___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___025174_) ? (IData)(wasmetal_core__DOT___128263___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___025134_));
    vlSelf->wasmetal_core__DOT___025178_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025138_))));
    wasmetal_core__DOT___061194_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061193_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061192_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061191_))))));
    vlSelf->wasmetal_core__DOT___025172_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061344_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025132_))));
    wasmetal_core__DOT___061435_ = (1U & (0xb0bbU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___061344_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061299_))))));
    wasmetal_core__DOT___061345_ = (1U & (0xb0bbU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___061344_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061299_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127757___O 
        = ((((IData)(wasmetal_core__DOT___025175_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025174_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025173_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025171_)))) 
           ^ (((IData)(wasmetal_core__DOT___128263___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128263___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___127757___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___025164_ = ((IData)(wasmetal_core__DOT___025175_)
                                             ? (IData)(wasmetal_core__DOT___128263___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___025135_));
    vlSelf->wasmetal_core__DOT___025177_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061194_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025137_))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135195___A 
        = ((0x3fff8000U & ((- (IData)((1U & (0x4fU 
                                             >> (((IData)(wasmetal_core__DOT___061435_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___043541_))))))) 
                           << 0xfU)) | ((0x4000U & 
                                         ((0x4fU >> 
                                           (((IData)(wasmetal_core__DOT___061435_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___061212_)))) 
                                          << 0xeU)) 
                                        | ((0x2000U 
                                            & ((0x4fU 
                                                >> 
                                                (((IData)(wasmetal_core__DOT___061435_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___061130_)))) 
                                               << 0xdU)) 
                                           | ((0x1000U 
                                               & ((0x4fU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___061435_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___061049_)))) 
                                                  << 0xcU)) 
                                              | ((0x800U 
                                                  & ((0x4fU 
                                                      >> 
                                                      (((IData)(wasmetal_core__DOT___061435_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___060960_)))) 
                                                     << 0xbU)) 
                                                 | ((0x400U 
                                                     & ((0x4fU 
                                                         >> 
                                                         (((IData)(wasmetal_core__DOT___061435_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___060884_)))) 
                                                        << 0xaU)) 
                                                    | ((0x200U 
                                                        & ((0x4fU 
                                                            >> 
                                                            (((IData)(wasmetal_core__DOT___061435_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___060798_)))) 
                                                           << 9U)) 
                                                       | ((0x100U 
                                                           & ((0x4fU 
                                                               >> 
                                                               (((IData)(wasmetal_core__DOT___061435_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___060692_)))) 
                                                              << 8U)) 
                                                          | ((0x80U 
                                                              & ((0x4fU 
                                                                  >> 
                                                                  (((IData)(wasmetal_core__DOT___061435_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___061299_)))) 
                                                                 << 7U)) 
                                                             | ((0x40U 
                                                                 & ((0x1f11U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                       << 3U) 
                                                                      | (((IData)(wasmetal_core__DOT___061277_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061238_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                    << 6U)) 
                                                                | ((0x20U 
                                                                    & ((0x1f11U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                          << 3U) 
                                                                         | (((IData)(wasmetal_core__DOT___061194_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061145_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                       << 5U)) 
                                                                   | ((0x10U 
                                                                       & ((0x1f11U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                             << 3U) 
                                                                            | (((IData)(wasmetal_core__DOT___061112_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___061066_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                          << 4U)) 
                                                                      | ((8U 
                                                                          & ((0x1f11U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 3U) 
                                                                               | (((IData)(wasmetal_core__DOT___061027_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060977_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                             << 3U)) 
                                                                         | ((4U 
                                                                             & ((0x1f11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060942_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060907_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                                << 2U)) 
                                                                            | ((2U 
                                                                                & ((0x1f11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060864_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060824_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054744_))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (0x1f11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060777_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043901_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054744_)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135195___B 
        = ((0x38000U & ((- (IData)((1U & (0x4fU >> 
                                          (((IData)(wasmetal_core__DOT___061345_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xcfafU 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___061433_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0x555533330f0f00ffULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055042_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055046_)))))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0x555533330f0f00ffULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055034_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055036_))))))))))))))))))))) 
                        << 0xfU)) | ((0x4000U & ((0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061345_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff0faa0aff0fcc0cULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061421_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061415_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___061224_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb48e4863__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4f400ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061253_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061254_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061251_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061252_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061215_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xffffeeee0f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xeU 
                                                                                >> (IData)(__VdfgTmp_h237a6a81__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(wasmetal_core__DOT___061267_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061266_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___061268_)))))))))))))))))))) 
                                                 << 0xeU)) 
                                     | ((0x2000U & 
                                         ((0x4fU >> 
                                           (((IData)(wasmetal_core__DOT___061345_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                << 1U) 
                                               | (1U 
                                                  & (IData)(
                                                            (0xff0faa0aff0fcc0cULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061410_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(
                                                                                (0xf0fccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061403_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___061158_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd485fb84__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4f400ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061172_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061169_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061170_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061133_)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xffffeeee0f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xeU 
                                                                                >> (IData)(__VdfgTmp_hd985bb83__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xef0fU 
                                                                                >> (IData)(__VdfgTmp_h188a23cd__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061183_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___061184_)))))))))))))))))))) 
                                          << 0xdU)) 
                                        | ((0x1000U 
                                            & ((0x4fU 
                                                >> 
                                                (((IData)(wasmetal_core__DOT___061345_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xcc00ffa0aaf0ffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                       << 4U) 
                                                                      | (((IData)(wasmetal_core__DOT___061398_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xff440f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061090_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010055_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061087_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061088_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061050_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061052_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061051_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff550f0f3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___061077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h54394b36__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061099_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061076_)))))))))))) 
                                                                                << 2U)) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054907_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054909_)))))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054898_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054901_)))))))))))))))))))) 
                                               << 0xcU)) 
                                           | ((0x800U 
                                               & ((0x4fU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___061345_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xcc00ffa0aaf0ffULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                          << 4U) 
                                                                         | (((IData)(wasmetal_core__DOT___061387_) 
                                                                             << 3U) 
                                                                            | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0faaaaccccff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xc5U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8e4351c5__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___060987_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf42252b__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4f400ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061000_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061001_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060998_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060999_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xee0fU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb8dfd2b5__0)))))))))) 
                                                                                << 2U)) 
                                                                               | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054862_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054866_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054861_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054865_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051491_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051496_)))))))))))))))))))) 
                                                  << 0xbU)) 
                                              | ((0x400U 
                                                  & ((0xbU 
                                                      >> 
                                                      (((IData)(wasmetal_core__DOT___061345_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xf3f5f0f000000000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                             << 3U) 
                                                                            | ((4U 
                                                                                & ((IData)(
                                                                                (0xf1f1000000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___061373_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061348_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___060936_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0f5f5ff00ff33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___060892_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060931_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061370_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060930_)))))))))))))))) 
                                                                                << 2U)) 
                                                                               | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054821_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054816_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054820_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054808_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054810_))))))))))))))))))) 
                                                     << 0xaU)) 
                                                 | ((0x200U 
                                                     & ((0xbU 
                                                         >> 
                                                         (((IData)(wasmetal_core__DOT___061345_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf3f5f0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfff01110fff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061348_) 
                                                                                << 5U) 
                                                                                | (((IData)(wasmetal_core__DOT___060854_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___061356_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h798d913c__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0faaaaccccff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019219_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___060810_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h55155be3__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4f400ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060834_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060835_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060832_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060833_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xee0fU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha2d50830__0))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054778_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054782_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054777_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054781_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054768_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054770_))))))))))))))))))) 
                                                        << 9U)) 
                                                    | ((0x100U 
                                                        & ((0xbU 
                                                            >> 
                                                            (((IData)(wasmetal_core__DOT___061345_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xf3f5f0f000000000ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf1f1000000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___061351_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xe00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061348_) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h410f7c75__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xffff2222fff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019220_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060761_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___060723_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060724_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h1ff7b9c3__0))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054675_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054688_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054674_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054706_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054705_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054698_))))))))))))))))))) 
                                                           << 8U)) 
                                                       | ((0x80U 
                                                           & ((0x4fU 
                                                               >> 
                                                               (((IData)(wasmetal_core__DOT___061345_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                    << 1U) 
                                                                   | (IData)(wasmetal_core__DOT___061344_)))) 
                                                              << 7U)) 
                                                          | ((0x40U 
                                                              & ((0x444fU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                    << 3U) 
                                                                   | (((IData)(wasmetal_core__DOT___061277_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___061238_))))) 
                                                                 << 6U)) 
                                                             | ((0x20U 
                                                                 & ((0x444fU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                       << 3U) 
                                                                      | (((IData)(wasmetal_core__DOT___061194_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___061145_))))) 
                                                                    << 5U)) 
                                                                | ((0x10U 
                                                                    & ((0x444fU 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                          << 3U) 
                                                                         | (((IData)(wasmetal_core__DOT___061112_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___061066_))))) 
                                                                       << 4U)) 
                                                                   | ((8U 
                                                                       & ((0x444fU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                             << 3U) 
                                                                            | (((IData)(wasmetal_core__DOT___061027_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060977_))))) 
                                                                          << 3U)) 
                                                                      | ((4U 
                                                                          & ((0x444fU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                                << 3U) 
                                                                               | (((IData)(wasmetal_core__DOT___060942_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060907_))))) 
                                                                             << 2U)) 
                                                                         | ((2U 
                                                                             & ((0x444fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060864_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060824_))))) 
                                                                                << 1U)) 
                                                                            | (1U 
                                                                               & (0x444fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___060777_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043901_)))))))))))))))))))));
}
