#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__20(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__20\n"); );
    // Init
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_6;
    VlWide<3>/*95:0*/ __Vtemp_12;
    VlWide<3>/*95:0*/ __Vtemp_18;
    VlWide<3>/*95:0*/ __Vtemp_24;
    VlWide<3>/*95:0*/ __Vtemp_30;
    VlWide<4>/*127:0*/ __Vtemp_38;
    VlWide<4>/*127:0*/ __Vtemp_44;
    VlWide<4>/*127:0*/ __Vtemp_50;
    VlWide<4>/*127:0*/ __Vtemp_56;
    VlWide<4>/*127:0*/ __Vtemp_62;
    // Body
    vlSelf->__VdfgTmp_h2c2ac443__0 = (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004960_));
    vlSelf->__VdfgTmp_h1d8dd092__0 = (((IData)(vlSelf->wasmetal_core__DOT___000561_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000560_));
    vlSelf->wasmetal_core__DOT___028966_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052236_))));
    vlSelf->wasmetal_core__DOT___067098_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b25__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b25__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___028654_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005368_))));
    vlSelf->__VdfgTmp_hb9b6103f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b25__05d));
    vlSelf->wasmetal_core__DOT___045159_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000565_)))))))));
    vlSelf->wasmetal_core__DOT___028478_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000543_))));
    vlSelf->wasmetal_core__DOT___048242_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005368_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000543_)));
    vlSelf->__VdfgTmp_h27758395__0 = (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005368_));
    vlSelf->__VdfgTmp_h0989e186__0 = (((IData)(vlSelf->wasmetal_core__DOT___000539_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000538_));
    vlSelf->wasmetal_core__DOT___028965_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052237_))));
    vlSelf->wasmetal_core__DOT___067024_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b24__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x18U))))));
    vlSelf->wasmetal_core__DOT___053997_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b26__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005096_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b24__05d))))));
    vlSelf->wasmetal_core__DOT___028653_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005096_))));
    vlSelf->__VdfgTmp_hf95886a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000521_));
    vlSelf->wasmetal_core__DOT___028477_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005096_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000521_))));
    vlSelf->wasmetal_core__DOT___048173_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005096_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000521_)));
    vlSelf->__VdfgTmp_h09cdcbfb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005096_));
    vlSelf->__VdfgTmp_h93789414__0 = (((IData)(vlSelf->wasmetal_core__DOT___000517_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000516_));
    vlSelf->wasmetal_core__DOT___028964_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052527_))));
    vlSelf->wasmetal_core__DOT___066953_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b23__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b23__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___028652_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052527_))));
    vlSelf->wasmetal_core__DOT___044557_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000499_)))))))));
    vlSelf->wasmetal_core__DOT___045454_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052527_)))))))));
    vlSelf->__VdfgTmp_hbaa2fe71__0 = (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000499_));
    vlSelf->wasmetal_core__DOT___028476_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000499_))));
    vlSelf->wasmetal_core__DOT___048068_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005164_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000499_)));
    vlSelf->__VdfgTmp_heec1cc96__0 = (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005164_));
    vlSelf->__VdfgTmp_h62980089__0 = (((IData)(vlSelf->wasmetal_core__DOT___000495_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000494_));
    vlSelf->__VdfgTmp_he4fb154e__0 = (((IData)(vlSelf->wasmetal_core__DOT___052528_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052527_));
    vlSelf->wasmetal_core__DOT___028963_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052528_))));
    vlSelf->wasmetal_core__DOT___066874_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b22__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b22__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x16U))))));
    vlSelf->wasmetal_core__DOT___028651_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052528_))));
    vlSelf->wasmetal_core__DOT___028475_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000477_))));
    vlSelf->wasmetal_core__DOT___048044_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003348_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000477_)));
    vlSelf->__VdfgTmp_h898dd08d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003348_));
    vlSelf->__VdfgTmp_hb2af30db__0 = (((IData)(vlSelf->wasmetal_core__DOT___000473_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000472_));
    vlSelf->wasmetal_core__DOT___028962_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052403_))));
    vlSelf->wasmetal_core__DOT___066792_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b21__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b21__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x15U))))));
    vlSelf->wasmetal_core__DOT___028650_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003416_))));
    vlSelf->wasmetal_core__DOT___028474_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003416_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000465_))));
    vlSelf->wasmetal_core__DOT___048057_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003416_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000465_)));
    vlSelf->__VdfgTmp_h5d92aff2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003416_));
    vlSelf->__VdfgTmp_hba3bfb32__0 = (((IData)(vlSelf->wasmetal_core__DOT___000461_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000460_));
    vlSelf->wasmetal_core__DOT___028961_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052402_))));
    vlSelf->wasmetal_core__DOT___066709_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b20__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b20__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___054006_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003936_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b20__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003348_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b22__05d))))));
    vlSelf->wasmetal_core__DOT___028649_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003936_))));
    vlSelf->wasmetal_core__DOT___044544_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000477_)))))))));
    vlSelf->wasmetal_core__DOT___044556_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000433_)))))))));
    vlSelf->wasmetal_core__DOT___045441_ = (1U & (IData)(
                                                         (0x2baf0a2b2b2b0a0aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052528_)))))))));
    vlSelf->wasmetal_core__DOT___045453_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052528_)))))))));
    vlSelf->wasmetal_core__DOT___028473_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003936_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000433_))));
    vlSelf->wasmetal_core__DOT___048040_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003936_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000433_)));
    vlSelf->__VdfgTmp_h4a3667e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003936_));
    vlSelf->__VdfgTmp_h5a48cd94__0 = (((IData)(vlSelf->wasmetal_core__DOT___000429_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000428_));
    vlSelf->wasmetal_core__DOT___028959_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052555_))));
    vlSelf->wasmetal_core__DOT___066623_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b19__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b19__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x13U))))));
    vlSelf->wasmetal_core__DOT___054010_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003862_))));
    vlSelf->wasmetal_core__DOT___028647_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003862_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052555_))));
    vlSelf->wasmetal_core__DOT___045157_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003862_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003936_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003416_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000433_)))))))));
    vlSelf->wasmetal_core__DOT___028471_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003862_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000420_))));
    vlSelf->wasmetal_core__DOT___048141_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003862_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000420_)));
    vlSelf->__VdfgTmp_hb2653381__0 = (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003862_));
    vlSelf->__VdfgTmp_h76eadb80__0 = (((IData)(vlSelf->wasmetal_core__DOT___000413_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000412_));
    vlSelf->wasmetal_core__DOT___028958_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052560_))));
    vlSelf->wasmetal_core__DOT___066547_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b18__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b18__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x12U))))));
    vlSelf->wasmetal_core__DOT___054019_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b20__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003936_))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b18__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___004078_)))))));
    vlSelf->wasmetal_core__DOT___028646_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004078_))));
    vlSelf->wasmetal_core__DOT___052666_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004078_))));
    vlSelf->wasmetal_core__DOT___028470_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001647_))));
    vlSelf->wasmetal_core__DOT___048018_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004078_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001647_)));
    vlSelf->__VdfgTmp_h68543eec__0 = (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004078_));
    vlSelf->__VdfgTmp_h58ec7cd3__0 = (((IData)(vlSelf->wasmetal_core__DOT___001643_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001642_));
    vlSelf->wasmetal_core__DOT___028957_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052559_))));
    vlSelf->wasmetal_core__DOT___066466_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b17__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b17__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___028645_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004300_))));
    vlSelf->wasmetal_core__DOT___044543_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003876_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000420_)))))))));
    vlSelf->wasmetal_core__DOT___044555_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003876_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000420_)))))))));
    vlSelf->wasmetal_core__DOT___045440_ = (1U & (IData)(
                                                         (0x2baf0a2b2b2b0a0aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052555_)))))))));
    vlSelf->wasmetal_core__DOT___045452_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052555_)))))))));
    vlSelf->wasmetal_core__DOT___052750_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000420_))))));
    vlSelf->wasmetal_core__DOT___028469_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001625_))));
    vlSelf->wasmetal_core__DOT___048072_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004300_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001625_)));
    vlSelf->__VdfgTmp_h57521c49__0 = (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004300_));
    vlSelf->__VdfgTmp_hf275be9a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001621_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001620_));
    vlSelf->wasmetal_core__DOT___028956_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052529_))));
    vlSelf->wasmetal_core__DOT___066384_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b16__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x10U))))));
    vlSelf->wasmetal_core__DOT___053999_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b16__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b17__05d))))));
    vlSelf->wasmetal_core__DOT___054029_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b16__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b18__05d))))));
    vlSelf->wasmetal_core__DOT___028644_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052529_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004004_))));
    vlSelf->wasmetal_core__DOT___045156_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004078_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001647_)))))))));
    vlSelf->wasmetal_core__DOT___028468_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001613_))));
    vlSelf->wasmetal_core__DOT___048008_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004004_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001613_)));
    vlSelf->__VdfgTmp_h0b995397__0 = (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004004_));
    vlSelf->__VdfgTmp_h4781af3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___001609_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001608_));
    vlSelf->wasmetal_core__DOT___028955_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052400_))));
    vlSelf->wasmetal_core__DOT___066298_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0xeU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___028643_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052400_))));
    vlSelf->wasmetal_core__DOT___028467_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001581_))));
    vlSelf->wasmetal_core__DOT___048693_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003706_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001581_)));
    vlSelf->__VdfgTmp_hed5e83f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003706_));
    vlSelf->__VdfgTmp_h808c51bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___001577_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001576_));
    vlSelf->wasmetal_core__DOT___028954_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052401_))));
    vlSelf->wasmetal_core__DOT___066202_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0xdU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___054011_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b14__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b17__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004300_))))));
    vlSelf->wasmetal_core__DOT___028642_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052401_))));
    vlSelf->wasmetal_core__DOT___044542_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004684_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004018_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001613_)))))))));
    vlSelf->wasmetal_core__DOT___044554_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004018_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004684_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001569_)))))))));
    vlSelf->wasmetal_core__DOT___045439_ = (1U & (IData)(
                                                         (0x3bbf02233b3b0202ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052401_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052529_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052400_)))))))));
    vlSelf->wasmetal_core__DOT___045451_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052529_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052401_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052400_)))))))));
    vlSelf->wasmetal_core__DOT___028466_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001569_))));
    vlSelf->wasmetal_core__DOT___048191_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004670_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001569_)));
    vlSelf->__VdfgTmp_h11733417__0 = (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004670_));
    vlSelf->__VdfgTmp_haaaaa9f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___001565_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001564_));
    vlSelf->wasmetal_core__DOT___028953_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052257_))));
    vlSelf->wasmetal_core__DOT___066065_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0xcU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___028641_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052257_))));
    vlSelf->wasmetal_core__DOT___050339_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004226_))));
    vlSelf->wasmetal_core__DOT___045155_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001569_)))))))));
    vlSelf->wasmetal_core__DOT___028465_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001537_))));
    vlSelf->wasmetal_core__DOT___048236_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004226_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001537_)));
    vlSelf->__VdfgTmp_h20a47ce2__0 = (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004226_));
    vlSelf->__VdfgTmp_h60633cb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___001533_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001532_));
    vlSelf->wasmetal_core__DOT___028952_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052255_))));
    vlSelf->wasmetal_core__DOT___066004_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066003_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066002_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[0U] 
                                                                        >> 0xaU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___054012_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004670_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b14__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b12__05d))))));
    vlSelf->wasmetal_core__DOT___028640_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052255_))));
    vlSelf->wasmetal_core__DOT___028464_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001525_))));
    vlSelf->wasmetal_core__DOT___048187_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004152_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001525_)));
    vlSelf->__VdfgTmp_h71467b4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004152_));
    vlSelf->__VdfgTmp_hc1bc9aa3__0 = (((IData)(vlSelf->wasmetal_core__DOT___001521_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001520_));
    vlSelf->wasmetal_core__DOT___028951_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052477_))));
    vlSelf->wasmetal_core__DOT___065884_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0xaU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___053996_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003558_))));
    vlSelf->wasmetal_core__DOT___028639_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052477_))));
    vlSelf->wasmetal_core__DOT___044541_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001525_)))))))));
    vlSelf->wasmetal_core__DOT___044553_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001426_)))))))));
    vlSelf->wasmetal_core__DOT___045438_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052477_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052257_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052255_)))))))));
    vlSelf->wasmetal_core__DOT___045450_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052477_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052257_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052255_)))))))));
    vlSelf->wasmetal_core__DOT___028463_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001426_))));
    vlSelf->wasmetal_core__DOT___048260_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003558_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001426_)));
    vlSelf->__VdfgTmp_h51a5c0e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003558_));
    vlSelf->__VdfgTmp_h38c61391__0 = (((IData)(vlSelf->wasmetal_core__DOT___001422_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001421_));
    vlSelf->wasmetal_core__DOT___028950_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052476_))));
    vlSelf->wasmetal_core__DOT___065788_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 9U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___028638_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052476_))));
    vlSelf->wasmetal_core__DOT___050338_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003484_))));
    vlSelf->wasmetal_core__DOT___045154_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003484_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001426_)))))))));
    vlSelf->wasmetal_core__DOT___028462_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001414_))));
    vlSelf->wasmetal_core__DOT___048199_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003484_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001414_)));
    vlSelf->__VdfgTmp_h11929a69__0 = (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003484_));
    vlSelf->__VdfgTmp_h7b1a2166__0 = (((IData)(vlSelf->wasmetal_core__DOT___001410_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001409_));
    vlSelf->wasmetal_core__DOT___028980_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052398_))));
    vlSelf->wasmetal_core__DOT___065723_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 8U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___028668_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052398_))));
    vlSelf->wasmetal_core__DOT___028492_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001382_))));
    vlSelf->wasmetal_core__DOT___048232_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003632_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001382_)));
    vlSelf->__VdfgTmp_h25819d29__0 = (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003632_));
    vlSelf->__VdfgTmp_h35d7421d__0 = (((IData)(vlSelf->wasmetal_core__DOT___001378_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001377_));
    vlSelf->wasmetal_core__DOT___052451_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052403_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052402_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052401_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052400_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052399_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052398_)))))))));
    vlSelf->wasmetal_core__DOT___028979_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052399_))));
    vlSelf->wasmetal_core__DOT___065592_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 7U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___054024_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003484_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b10__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b8__05d))))));
    vlSelf->wasmetal_core__DOT___028667_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052399_))));
    vlSelf->wasmetal_core__DOT___044540_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003498_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001414_)))))))));
    vlSelf->wasmetal_core__DOT___044552_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003498_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001414_)))))))));
    vlSelf->wasmetal_core__DOT___045437_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052399_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052476_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052398_)))))))));
    vlSelf->wasmetal_core__DOT___045449_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052476_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052399_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052398_)))))))));
    vlSelf->wasmetal_core__DOT___052752_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001569_)))))))));
    vlSelf->wasmetal_core__DOT___028491_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001370_))));
    vlSelf->wasmetal_core__DOT___048193_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003780_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001370_)));
    vlSelf->__VdfgTmp_h3c8de641__0 = (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003780_));
    vlSelf->__VdfgTmp_hd822ef23__0 = (((IData)(vlSelf->wasmetal_core__DOT___001366_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001365_));
    vlSelf->wasmetal_core__DOT___028978_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052557_))));
    vlSelf->wasmetal_core__DOT___065502_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065500_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[0U] 
                                                                        >> 5U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___028666_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052557_))));
    vlSelf->wasmetal_core__DOT___045153_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001382_)))))))));
    vlSelf->wasmetal_core__DOT___028490_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001488_))));
    vlSelf->wasmetal_core__DOT___048064_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004596_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001488_)));
    vlSelf->__VdfgTmp_h01ed509a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004596_));
    vlSelf->__VdfgTmp_hae88697a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001484_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001483_));
    vlSelf->wasmetal_core__DOT___028977_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052556_))));
    vlSelf->wasmetal_core__DOT___065396_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065394_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[0U] 
                                                                        >> 4U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___028665_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052556_))));
    vlSelf->wasmetal_core__DOT___028489_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001476_))));
    vlSelf->wasmetal_core__DOT___048014_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004448_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001476_)));
    vlSelf->__VdfgTmp_h0ad4d6dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004448_));
    vlSelf->__VdfgTmp_h2996e40e__0 = (((IData)(vlSelf->wasmetal_core__DOT___001472_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001471_));
    vlSelf->wasmetal_core__DOT___028976_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052474_))));
    vlSelf->wasmetal_core__DOT___065283_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 4U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___028664_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004374_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052474_))));
    vlSelf->wasmetal_core__DOT___044539_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004388_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001476_)))))))));
    vlSelf->wasmetal_core__DOT___044551_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004388_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001444_)))))))));
    vlSelf->wasmetal_core__DOT___045436_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052474_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052557_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052556_)))))))));
    vlSelf->wasmetal_core__DOT___045448_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052557_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052556_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052474_)))))))));
    vlSelf->wasmetal_core__DOT___028488_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004374_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001444_))));
    vlSelf->wasmetal_core__DOT___048154_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004374_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001444_)));
    vlSelf->__VdfgTmp_hcc6273ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004374_));
    vlSelf->__VdfgTmp_hcab9d929__0 = (((IData)(vlSelf->wasmetal_core__DOT___001440_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001439_));
    vlSelf->__VdfgTmp_h91f69850__0 = (((IData)(vlSelf->wasmetal_core__DOT___052475_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052474_));
    vlSelf->wasmetal_core__DOT___028975_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052475_))));
    vlSelf->wasmetal_core__DOT___065157_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065155_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[0U] 
                                                                        >> 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___028663_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052475_))));
    vlSelf->wasmetal_core__DOT___045152_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004374_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004448_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001444_)))))))));
    vlSelf->wasmetal_core__DOT___028487_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001438_))));
    vlSelf->wasmetal_core__DOT___048028_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004522_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001438_)));
    vlSelf->__VdfgTmp_h04643804__0 = (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004522_));
    vlSelf->__VdfgTmp_h4a4b1d7e__0 = (((IData)(vlSelf->wasmetal_core__DOT___001434_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001433_));
    vlSelf->wasmetal_core__DOT___028974_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052253_))));
    vlSelf->wasmetal_core__DOT___065044_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065043_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065042_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[0U] 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___028662_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004744_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052253_))));
    vlSelf->wasmetal_core__DOT___028486_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004744_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001887_))));
    vlSelf->wasmetal_core__DOT___048150_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004744_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001887_)));
    vlSelf->__VdfgTmp_haf58c538__0 = (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004744_));
    vlSelf->__VdfgTmp_h99694808__0 = (((IData)(vlSelf->wasmetal_core__DOT___001883_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001882_));
    vlSelf->wasmetal_core__DOT___028971_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052254_))));
    vlSelf->wasmetal_core__DOT___064883_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064882_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064881_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->cmd_data[0U]) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___028659_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052254_))));
    vlSelf->wasmetal_core__DOT___044538_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001887_)))))))));
    vlSelf->wasmetal_core__DOT___044550_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001887_)))))))));
    vlSelf->wasmetal_core__DOT___045435_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052254_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052475_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052253_)))))))));
    vlSelf->wasmetal_core__DOT___045447_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052254_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052253_)))))))));
    vlSelf->wasmetal_core__DOT___028483_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001875_))));
    vlSelf->wasmetal_core__DOT___048034_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004818_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001875_)));
    vlSelf->__VdfgTmp_hff7a62d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004818_));
    vlSelf->__VdfgTmp_hb773d3a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___001871_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001870_));
    vlSelf->wasmetal_core__DOT___054025_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b2__05d))))));
    vlSelf->wasmetal_core__DOT___045149_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004744_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001887_)))))))));
    vlSelf->wasmetal_core__DOT___028472_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003269_))));
    vlSelf->wasmetal_core__DOT___048137_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003270_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003269_)));
    vlSelf->__VdfgTmp_h365733f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003270_));
    vlSelf->wasmetal_core__DOT___052256_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he7820a50__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052205_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6a684ffb__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b1__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052205_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6a684ffb__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he7820a50__0))))))));
    vlSelf->__VdfgTmp_h37d1cc77__0 = (((IData)(vlSelf->wasmetal_core__DOT___003279_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001861_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001860_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003277_))));
    vlSelf->wasmetal_core__DOT___054001_ = (1U & (IData)(
                                                         (0xb0bb00000000b0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004374_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004522_)))))))));
    vlSelf->wasmetal_core__DOT___044536_ = (1U & (0x2b22U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003269_))))));
    vlSelf->wasmetal_core__DOT___044548_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003189_))))));
    vlSelf->wasmetal_core__DOT___128640___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003269_)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT___003189_))));
    vlSelf->wasmetal_core__DOT___052753_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001887_)))))))));
    vlSelf->__VdfgTmp_h4ae0787e__0 = (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003189_));
    vlSelf->wasmetal_core__DOT___048020_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003190_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003189_)));
    vlSelf->__VdfgTmp_he3cb924f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003190_));
    vlSelf->wasmetal_core__DOT___052558_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he9245313__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052540_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h173fc958__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b0__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052540_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h173fc958__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he9245313__0))))))));
    vlSelf->__VdfgTmp_hc5249891__0 = (((IData)(vlSelf->wasmetal_core__DOT___003199_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001837_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001836_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003197_))));
    vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_h4c2f98f1__0 
        = (0x1fffU & ((0xfffU & (IData)((vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
                                         >> 0xbU))) 
                      + ((0xfffU & (IData)((vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
                                            >> 0xcU))) 
                         + VL_SHIFTR_III(13,13,32, (IData)(vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_ha5045b21__0), 0xcU))));
    vlSelf->wasmetal_core__DOT____Vcellout___128139___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O)) 
            | (IData)(vlSelf->wasmetal_core__DOT___029156_)) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029149_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053349_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053287_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053286_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053285_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053284_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053283_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053282_)))))))));
    vlSelf->wasmetal_core__DOT___019786_ = (1U & (0xe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053286_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053347_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053282_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052952_)))))));
    vlSelf->wasmetal_core__DOT___053477_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053426_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050456_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x44444447U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___053422_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053421_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___052947_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___052990_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___047995_))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xfa673738U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h673d32f0__0))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053423_)))))));
    vlSelf->wasmetal_core__DOT___019799_ = (1U & (IData)(
                                                         (0x700000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053751_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052956_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053426_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x7fff0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053749_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053745_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h63180e3e__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf90c45d9__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053740_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053739_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heb1fb9b9__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)))))))))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha85820a5__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128322___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031067_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031064_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031053_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031042_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031035_ = ((IData)(vlSelf->wasmetal_core__DOT___031067_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->__VdfgTmp_h79a44c81__0 = (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004802_));
    vlSelf->wasmetal_core__DOT___048178_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004944_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004943_)));
    vlSelf->__VdfgTmp_h79b790c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004944_));
    vlSelf->wasmetal_core__DOT___048184_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004876_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004875_)));
    vlSelf->__VdfgTmp_hc83e3035__0 = (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004876_));
    vlSelf->wasmetal_core__DOT___048239_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005284_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005283_)));
    vlSelf->__VdfgTmp_h4e776e09__0 = (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005284_));
    vlSelf->wasmetal_core__DOT___048172_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005216_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005215_)));
    vlSelf->__VdfgTmp_h77d6a635__0 = (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005216_));
    vlSelf->__VdfgTmp_h5702c3be__0 = (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003252_));
    vlSelf->__VdfgTmp_hffad8cfa__0 = (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003172_));
    vlSelf->wasmetal_core__DOT___048004_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005600_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005599_)));
    vlSelf->__VdfgTmp_h66a2df13__0 = (((IData)(vlSelf->wasmetal_core__DOT___005599_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005600_));
    vlSelf->wasmetal_core__DOT___062418_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b98__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b98__05d)))))));
    vlSelf->__VdfgTmp_h8dbe6334__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004802_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___004801_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hdf4f28bb__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b98__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hdf4f28bb__0))))));
    vlSelf->wasmetal_core__DOT___048177_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h45f8df98__0))))));
    vlSelf->wasmetal_core__DOT__top__05b90__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h45f8df98__0))))));
    vlSelf->wasmetal_core__DOT___048258_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hfaaa855f__0))))));
    vlSelf->wasmetal_core__DOT__top__05b91__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hfaaa855f__0))))));
    vlSelf->wasmetal_core__DOT___048183_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h331e01c9__0))))));
    vlSelf->wasmetal_core__DOT__top__05b92__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h331e01c9__0))))));
    vlSelf->wasmetal_core__DOT___048238_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h62281c26__0))))));
    vlSelf->wasmetal_core__DOT__top__05b93__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h62281c26__0))))));
    vlSelf->wasmetal_core__DOT___048171_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h22e3dba7__0))))));
    vlSelf->wasmetal_core__DOT__top__05b94__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h22e3dba7__0))))));
    vlSelf->wasmetal_core__DOT___062416_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b97__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b97__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & vlSelf->mem_rdata[3U]) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b97__05d)))))));
    vlSelf->wasmetal_core__DOT___070029_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b97__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b97__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[3U] 
                                                                             >> 1U))))))))));
    vlSelf->__VdfgTmp_h09328eec__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003252_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003095_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h0a17a2b0__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b97__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h0a17a2b0__0))))));
    vlSelf->__VdfgTmp_ha59547bb__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003172_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003091_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha1faee4b__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b96__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_ha1faee4b__0))))));
    vlSelf->wasmetal_core__DOT___048003_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf772eecc__0))))));
    vlSelf->wasmetal_core__DOT__top__05b95__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hf772eecc__0))))));
    vlSelf->wasmetal_core__DOT___069988_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069984_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069983_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b95__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___052821_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005265_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001169_))));
    vlSelf->wasmetal_core__DOT___005420_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005266_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005265_)));
    vlSelf->__VdfgTmp_h778ea1a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005265_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005266_));
    vlSelf->wasmetal_core__DOT___005390_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004926_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004925_)));
    vlSelf->__VdfgTmp_h9c9d0618__0 = (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004926_));
    vlSelf->wasmetal_core__DOT___052822_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004857_))));
    vlSelf->wasmetal_core__DOT___005410_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004858_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004857_)));
    vlSelf->__VdfgTmp_hf0d36e17__0 = (((IData)(vlSelf->wasmetal_core__DOT___004857_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004858_));
    vlSelf->wasmetal_core__DOT___051953_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005352_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005334_))));
    vlSelf->wasmetal_core__DOT___052820_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005351_))));
    vlSelf->wasmetal_core__DOT___005447_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005334_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005333_)));
    vlSelf->__VdfgTmp_hb476a254__0 = (((IData)(vlSelf->wasmetal_core__DOT___005333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005334_));
    vlSelf->wasmetal_core__DOT___005477_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003382_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003381_)));
    vlSelf->__VdfgTmp_ha36008d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003382_));
    vlSelf->wasmetal_core__DOT___005487_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003314_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003313_)));
    vlSelf->__VdfgTmp_hab2bfea3__0 = (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003314_));
    vlSelf->wasmetal_core__DOT___051941_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005080_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005062_))));
    vlSelf->wasmetal_core__DOT___005437_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005062_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005061_)));
    vlSelf->__VdfgTmp_h24206284__0 = (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005062_));
    vlSelf->wasmetal_core__DOT___052664_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005148_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005130_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004876_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004858_)))))))));
    vlSelf->wasmetal_core__DOT___005497_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005130_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005129_)));
    vlSelf->__VdfgTmp_hb797e152__0 = (((IData)(vlSelf->wasmetal_core__DOT___005129_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005130_));
    vlSelf->wasmetal_core__DOT___005419_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h13f17749__0))))));
    vlSelf->wasmetal_core__DOT__top__05b125__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h13f17749__0))))));
    vlSelf->wasmetal_core__DOT___005389_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6b4c794b__0))))));
    vlSelf->wasmetal_core__DOT__top__05b122__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6b4c794b__0))))));
    vlSelf->wasmetal_core__DOT___062480_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b123__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b123__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b123__05d)))))));
    vlSelf->wasmetal_core__DOT___005399_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3d9b9896__0))))));
    vlSelf->wasmetal_core__DOT__top__05b123__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h3d9b9896__0))))));
    vlSelf->wasmetal_core__DOT___005409_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h79077a59__0))))));
    vlSelf->wasmetal_core__DOT__top__05b124__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h79077a59__0))))));
    vlSelf->wasmetal_core__DOT___062475_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b121__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b121__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b121__05d)))))));
    vlSelf->wasmetal_core__DOT___005446_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h630336df__0))))));
    vlSelf->wasmetal_core__DOT__top__05b121__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h630336df__0))))));
    vlSelf->wasmetal_core__DOT___005476_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1bb342d2__0))))));
    vlSelf->wasmetal_core__DOT__top__05b117__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1bb342d2__0))))));
    vlSelf->wasmetal_core__DOT___005486_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h90194312__0))))));
    vlSelf->wasmetal_core__DOT__top__05b118__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h90194312__0))))));
    vlSelf->wasmetal_core__DOT___005436_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he61be2d5__0))))));
    vlSelf->wasmetal_core__DOT__top__05b120__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he61be2d5__0))))));
    vlSelf->wasmetal_core__DOT___062470_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b119__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b119__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x16U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b119__05d)))))));
    vlSelf->wasmetal_core__DOT___005496_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3fce9550__0))))));
    vlSelf->wasmetal_core__DOT__top__05b119__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h3fce9550__0))))));
    vlSelf->__VdfgTmp_h1dfe6e3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003542_));
    vlSelf->__VdfgTmp_h45475158__0 = (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003468_));
    vlSelf->wasmetal_core__DOT___051955_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004728_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004710_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004388_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004374_)))))))));
    vlSelf->__VdfgTmp_h103d8e23__0 = (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004728_));
    vlSelf->__VdfgTmp_hbbacc71f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004506_));
    vlSelf->__VdfgTmp_h6b621180__0 = (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004358_));
    vlSelf->__VdfgTmp_h880089dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004432_));
    vlSelf->__VdfgTmp_h350dca3c__0 = (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003764_));
    vlSelf->__VdfgTmp_h903282ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004580_));
    vlSelf->wasmetal_core__DOT___062443_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b107__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b107__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xaU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b107__05d)))))));
    vlSelf->__VdfgTmp_hcde84ebb__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003542_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003107_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h6d082533__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b107__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6d082533__0))))));
    vlSelf->wasmetal_core__DOT___062438_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b106__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b106__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 9U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b106__05d)))))));
    vlSelf->__VdfgTmp_h52266111__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003468_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003105_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h39365f5c__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b106__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h39365f5c__0))))));
    vlSelf->wasmetal_core__DOT___062420_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b99__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b99__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b99__05d)))))));
    vlSelf->__VdfgTmp_h7d4fca25__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004728_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___004727_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h887e5924__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b99__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h887e5924__0))))));
    vlSelf->wasmetal_core__DOT___070081_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b100__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->cmd_data[3U] 
                                                                >> 3U)) 
                                                            | (1U 
                                                               & (0xf38f2779U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))));
    vlSelf->wasmetal_core__DOT___062423_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b100__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b100__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 3U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b100__05d)))))));
    vlSelf->__VdfgTmp_h82d77f97__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004506_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003097_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf8739cbc__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b100__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hf8739cbc__0))))));
    vlSelf->wasmetal_core__DOT___062426_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b101__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b101__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 4U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b101__05d)))))));
    vlSelf->__VdfgTmp_hf0176237__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004358_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003099_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h220272bf__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b101__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h220272bf__0))))));
    vlSelf->wasmetal_core__DOT___062428_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b102__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b102__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 5U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b102__05d)))))));
    vlSelf->__VdfgTmp_hbacded4f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004432_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003101_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h193e1c6c__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b102__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h193e1c6c__0))))));
    vlSelf->wasmetal_core__DOT___062435_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b105__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b105__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 8U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b105__05d)))))));
    vlSelf->__VdfgTmp_hff8a2099__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003616_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003111_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h94e7c39f__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b105__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h94e7c39f__0))))));
    vlSelf->wasmetal_core__DOT___052369_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052340_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052338_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he6df8ac0__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_he04a0e99__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h8b084513__0))))))))))));
    vlSelf->wasmetal_core__DOT___062433_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b104__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b104__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 7U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b104__05d)))))));
    vlSelf->__VdfgTmp_h601dd350__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003764_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003109_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h8103cb90__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b104__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8103cb90__0))))));
    vlSelf->__VdfgTmp_hb7a72eea__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004580_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003103_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h7b80a3df__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b103__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7b80a3df__0))))));
    vlSelf->wasmetal_core__DOT___048016_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004044_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004043_)));
    vlSelf->__VdfgTmp_h2e498b5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004044_));
    vlSelf->wasmetal_core__DOT___048043_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003920_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003919_)));
    vlSelf->__VdfgTmp_h74dbdf51__0 = (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003920_));
    vlSelf->wasmetal_core__DOT___048060_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003400_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003399_)));
    vlSelf->__VdfgTmp_ha6dc66a3__0 = (((IData)(vlSelf->wasmetal_core__DOT___003399_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003400_));
    vlSelf->wasmetal_core__DOT___052811_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003399_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003313_))))));
    vlSelf->wasmetal_core__DOT___048047_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003332_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003331_)));
    vlSelf->__VdfgTmp_h0f5e432a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003332_));
    vlSelf->wasmetal_core__DOT___048075_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004266_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004265_)));
    vlSelf->__VdfgTmp_he315da1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___004265_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004266_));
    vlSelf->wasmetal_core__DOT___048244_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hec648199__0))))));
    vlSelf->wasmetal_core__DOT__top__05b89__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hec648199__0))))));
    vlSelf->wasmetal_core__DOT___048017_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6332189a__0))))));
    vlSelf->wasmetal_core__DOT__top__05b82__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h6332189a__0))))));
    vlSelf->wasmetal_core__DOT___069714_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069710_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069709_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b82__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x10U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069735_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xeU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x10U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x13U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b83__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069732_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b83__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b83__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x13U))))))))));
    vlSelf->wasmetal_core__DOT___048140_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd87a9123__0))))));
    vlSelf->wasmetal_core__DOT__top__05b83__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hd87a9123__0))))));
    vlSelf->wasmetal_core__DOT___048042_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h98759836__0))))));
    vlSelf->wasmetal_core__DOT__top__05b84__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h98759836__0))))));
    vlSelf->wasmetal_core__DOT___069758_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069754_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069753_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b84__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x12U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___048059_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he8c28620__0))))));
    vlSelf->wasmetal_core__DOT__top__05b85__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_he8c28620__0))))));
    vlSelf->wasmetal_core__DOT___069779_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069775_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069774_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b85__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x13U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___048046_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2b07b055__0))))));
    vlSelf->wasmetal_core__DOT__top__05b86__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h2b07b055__0))))));
    vlSelf->wasmetal_core__DOT___069801_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069797_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069796_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b86__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x14U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___048074_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h29035176__0))))));
    vlSelf->wasmetal_core__DOT__top__05b81__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h29035176__0))))));
    vlSelf->wasmetal_core__DOT___048175_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h15796065__0))))));
    vlSelf->wasmetal_core__DOT__top__05b88__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h15796065__0))))));
    vlSelf->wasmetal_core__DOT___062390_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b87__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b87__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x16U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b87__05d)))))));
    vlSelf->wasmetal_core__DOT___069822_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x12U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x14U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x17U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b87__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069819_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b87__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b87__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x17U))))))))));
    vlSelf->wasmetal_core__DOT___048070_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h29fb25ab__0))))));
    vlSelf->wasmetal_core__DOT__top__05b87__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h29fb25ab__0))))));
    vlSelf->wasmetal_core__DOT___005467_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003902_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003901_)));
    vlSelf->__VdfgTmp_h063ae0f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003902_));
    vlSelf->__VdfgTmp_hc85d0f69__0 = (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004136_));
    vlSelf->__VdfgTmp_h9d0797f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004210_));
    vlSelf->__VdfgTmp_he9b54a3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004654_));
    vlSelf->__VdfgTmp_h0fc0fcd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004062_));
    vlSelf->wasmetal_core__DOT___052665_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003828_))));
    vlSelf->__VdfgTmp_hbe45befc__0 = (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003846_));
    vlSelf->wasmetal_core__DOT___050344_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004284_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004266_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004004_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003920_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003902_)))))))));
    vlSelf->wasmetal_core__DOT___052815_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004265_))));
    vlSelf->__VdfgTmp_hcbd0c1b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004284_));
    vlSelf->wasmetal_core__DOT___052370_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052295_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052294_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052293_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> 
                                                                         ((8U 
                                                                           & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbeaa94ef__0)))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22773bc1__0)))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h95c9c2c5__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h00d09e7a__0))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xac00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052282_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052281_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052280_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052279_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0589a813__0)))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d)))))))));
    vlSelf->__VdfgTmp_h154ca593__0 = (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003988_));
    vlSelf->__VdfgTmp_h4b62075b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003690_));
    vlSelf->wasmetal_core__DOT___005466_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha2c9478b__0))))));
    vlSelf->wasmetal_core__DOT__top__05b116__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha2c9478b__0))))));
    vlSelf->__VdfgTmp_h0adea875__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004136_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003117_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hbea96df5__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b108__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbea96df5__0))))));
    vlSelf->__VdfgTmp_h79860539__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004210_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003119_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h01f51344__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b109__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h01f51344__0))))));
    vlSelf->wasmetal_core__DOT___062449_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b110__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b110__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xdU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b110__05d)))))));
    vlSelf->__VdfgTmp_h5978f26f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004654_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003121_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h7ca24d8b__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b110__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7ca24d8b__0))))));
    vlSelf->__VdfgTmp_h31225405__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004062_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___004061_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb807ebfb__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b114__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb807ebfb__0))))));
    vlSelf->__VdfgTmp_h70d2167a__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003846_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003845_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hed09e4ce__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b115__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hed09e4ce__0))))));
    vlSelf->__VdfgTmp_h177129ae__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004284_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003115_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf4fd0700__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b113__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hf4fd0700__0))))));
    vlSelf->wasmetal_core__DOT___062454_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b112__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xfU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b112__05d)))))));
    vlSelf->__VdfgTmp_h71a6f88b__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003988_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003113_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb2ba9050__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b112__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb2ba9050__0))))));
    vlSelf->wasmetal_core__DOT___062451_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b111__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b111__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xeU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b111__05d)))))));
    vlSelf->__VdfgTmp_ha13bce2f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003690_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003689_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_he18e3e19__0)))))));
    vlSelf->wasmetal_core__DOT__top__05b111__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he18e3e19__0))))));
    vlSelf->wasmetal_core__DOT___051940_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___003876_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003862_))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___003988_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003970_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___004018_)))));
    vlSelf->wasmetal_core__DOT___052809_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003969_))));
    vlSelf->wasmetal_core__DOT___048011_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003970_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003969_)));
    vlSelf->__VdfgTmp_hf3cb0d91__0 = (((IData)(vlSelf->wasmetal_core__DOT___003969_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003970_));
    vlSelf->wasmetal_core__DOT___052827_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003449_))));
    vlSelf->wasmetal_core__DOT___048197_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003450_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003449_)));
    vlSelf->__VdfgTmp_hfd746550__0 = (((IData)(vlSelf->wasmetal_core__DOT___003449_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003450_));
    vlSelf->wasmetal_core__DOT___048263_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003524_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003523_)));
    vlSelf->__VdfgTmp_h1b5c1c30__0 = (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003524_));
    vlSelf->wasmetal_core__DOT___051956_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004136_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004118_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003616_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003598_)))))))));
    vlSelf->wasmetal_core__DOT___052812_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004117_))));
    vlSelf->wasmetal_core__DOT___048185_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004118_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004117_)));
    vlSelf->__VdfgTmp_hc2378e95__0 = (((IData)(vlSelf->wasmetal_core__DOT___004117_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004118_));
    vlSelf->wasmetal_core__DOT___052813_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004191_))));
    vlSelf->wasmetal_core__DOT___048234_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004192_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004191_)));
    vlSelf->__VdfgTmp_h3e014765__0 = (((IData)(vlSelf->wasmetal_core__DOT___004191_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004192_));
    vlSelf->wasmetal_core__DOT___050348_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003468_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003450_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004654_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004636_)))))))));
    vlSelf->wasmetal_core__DOT___048189_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004636_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004635_)));
    vlSelf->__VdfgTmp_hb797ade1__0 = (((IData)(vlSelf->wasmetal_core__DOT___004635_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004636_));
    vlSelf->wasmetal_core__DOT___048196_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003746_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003745_)));
    vlSelf->__VdfgTmp_h477043a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___003745_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003746_));
    vlSelf->wasmetal_core__DOT___050340_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003706_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003690_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003672_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004684_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004670_)))))))));
    vlSelf->wasmetal_core__DOT___048696_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003672_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003671_)));
    vlSelf->__VdfgTmp_h5f949c7c__0 = (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003672_));
    vlSelf->wasmetal_core__DOT___048010_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf123ec52__0))))));
    vlSelf->wasmetal_core__DOT__top__05b80__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hf123ec52__0))))));
    vlSelf->wasmetal_core__DOT___048198_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2cf790ef__0))))));
    vlSelf->wasmetal_core__DOT__top__05b74__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h2cf790ef__0))))));
    vlSelf->wasmetal_core__DOT___052109_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052054_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x8888f00000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___052049_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___004273_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___004051_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc280317b__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h559eadff__0)))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x80000000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___052044_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___052043_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052035_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003241_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003161_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcb1226e0__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb6d33cfc__0)))))))))) 
                                                                            << 2U)) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052030_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003977_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003927_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0f7cbf8b__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5c1149ce__0)))))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051979_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003407_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003339_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfb5e938__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hec05375a__0)))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xac00000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___051972_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051971_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051970_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h106a7f5e__0))))))))))))));
    vlSelf->wasmetal_core__DOT___048262_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7482f819__0))))));
    vlSelf->wasmetal_core__DOT__top__05b75__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h7482f819__0))))));
    vlSelf->wasmetal_core__DOT___048186_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf7e0ef4b__0))))));
    vlSelf->wasmetal_core__DOT__top__05b76__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hf7e0ef4b__0))))));
    vlSelf->wasmetal_core__DOT___048235_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h31491600__0))))));
    vlSelf->wasmetal_core__DOT__top__05b77__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h31491600__0))))));
    vlSelf->wasmetal_core__DOT___048190_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h19aa2548__0))))));
    vlSelf->wasmetal_core__DOT__top__05b78__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h19aa2548__0))))));
    vlSelf->wasmetal_core__DOT___048231_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2b63e99d__0))))));
    vlSelf->wasmetal_core__DOT__top__05b73__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h2b63e99d__0))))));
    vlSelf->wasmetal_core__DOT___048195_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h88d138aa__0))))));
    vlSelf->wasmetal_core__DOT__top__05b72__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h88d138aa__0))))));
    vlSelf->wasmetal_core__DOT___048695_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he8484823__0))))));
    vlSelf->wasmetal_core__DOT__top__05b79__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_he8484823__0))))));
    vlSelf->wasmetal_core__DOT___069647_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069642_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b79__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0xdU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___051986_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004580_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004562_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004448_)))))))));
    vlSelf->wasmetal_core__DOT___052808_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004561_))));
    vlSelf->wasmetal_core__DOT___048067_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004562_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004561_)));
    vlSelf->__VdfgTmp_hce00e764__0 = (((IData)(vlSelf->wasmetal_core__DOT___004561_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004562_));
    vlSelf->wasmetal_core__DOT___048031_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004488_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004487_)));
    vlSelf->__VdfgTmp_h9699bb18__0 = (((IData)(vlSelf->wasmetal_core__DOT___004487_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004488_));
    vlSelf->wasmetal_core__DOT___052829_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004339_))));
    vlSelf->wasmetal_core__DOT___048157_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004340_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004339_)));
    vlSelf->__VdfgTmp_h1d34c5b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___004339_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004340_));
    vlSelf->wasmetal_core__DOT___050343_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004802_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004784_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004432_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004414_)))))))));
    vlSelf->wasmetal_core__DOT___048012_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004414_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004413_)));
    vlSelf->__VdfgTmp_h92dd6962__0 = (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004414_));
    vlSelf->wasmetal_core__DOT___050349_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004506_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004488_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003234_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003190_)))))))));
    vlSelf->wasmetal_core__DOT___048135_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003234_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003233_)));
    vlSelf->__VdfgTmp_h5b4e7e80__0 = (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003234_));
    vlSelf->wasmetal_core__DOT___048023_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003151_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003150_)));
    vlSelf->__VdfgTmp_hd0bdda62__0 = (((IData)(vlSelf->wasmetal_core__DOT___003150_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003151_));
    vlSelf->wasmetal_core__DOT___048066_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h41785ae8__0))))));
    vlSelf->wasmetal_core__DOT__top__05b71__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h41785ae8__0))))));
    vlSelf->wasmetal_core__DOT___048039_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_heecb7e70__0))))));
    vlSelf->wasmetal_core__DOT__top__05b66__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_heecb7e70__0))))));
    vlSelf->wasmetal_core__DOT___048152_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd9d86825__0))))));
    vlSelf->wasmetal_core__DOT__top__05b67__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hd9d86825__0))))));
    vlSelf->wasmetal_core__DOT___048030_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hfb5e3b7e__0))))));
    vlSelf->wasmetal_core__DOT__top__05b68__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hfb5e3b7e__0))))));
    vlSelf->wasmetal_core__DOT___048156_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1d47507a__0))))));
    vlSelf->wasmetal_core__DOT__top__05b69__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h1d47507a__0))))));
    vlSelf->wasmetal_core__DOT___048013_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9b6447c0__0))))));
    vlSelf->wasmetal_core__DOT__top__05b70__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h9b6447c0__0))))));
    vlSelf->wasmetal_core__DOT___048136_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5bb31d88__0))))));
    vlSelf->wasmetal_core__DOT__top__05b65__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h5bb31d88__0))))));
    vlSelf->wasmetal_core__DOT___048022_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7e49e6e6__0))))));
    vlSelf->wasmetal_core__DOT__top__05b64__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h7e49e6e6__0))))));
    vlSelf->wasmetal_core__DOT___052193_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052178_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052177_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052176_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052175_))))));
    vlSelf->wasmetal_core__DOT___069231_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069229_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069228_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x1dU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d)))))))));
    vlSelf->wasmetal_core__DOT___069235_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d))));
    vlSelf->__VdfgTmp_hb85239a7__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005636_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001330_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hee23ef9b__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hee23ef9b__0))))));
    vlSelf->wasmetal_core__DOT___050352_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005216_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005198_))));
    vlSelf->wasmetal_core__DOT___005457_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005198_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005197_)));
    vlSelf->__VdfgTmp_ha95ffc90__0 = (((IData)(vlSelf->wasmetal_core__DOT___005197_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005198_));
    vlSelf->wasmetal_core__DOT___051951_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005600_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005582_)))))))));
    vlSelf->wasmetal_core__DOT___047990_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005582_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005581_)));
    vlSelf->__VdfgTmp_hbd4ae96e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005582_));
    vlSelf->wasmetal_core__DOT___005456_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8b941ffe__0))))));
    vlSelf->wasmetal_core__DOT__top__05b126__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8b941ffe__0))))));
    vlSelf->wasmetal_core__DOT___047989_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd2cb6624__0))))));
    vlSelf->wasmetal_core__DOT__top__05b127__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd2cb6624__0))))));
    vlSelf->wasmetal_core__DOT___069201_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069198_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069197_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054245_)))))))));
    vlSelf->wasmetal_core__DOT___005454_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h39540d35__0)))));
    vlSelf->wasmetal_core__DOT___001168_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h39540d35__0))));
    vlSelf->wasmetal_core__DOT___069151_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069132_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069131_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054243_)))))))));
    vlSelf->wasmetal_core__DOT___005417_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hffec0e42__0)))));
    vlSelf->wasmetal_core__DOT___001146_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hffec0e42__0))));
    vlSelf->wasmetal_core__DOT___005407_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h15e8b450__0)))));
    vlSelf->wasmetal_core__DOT___001124_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h15e8b450__0))));
    vlSelf->wasmetal_core__DOT___069057_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069054_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069053_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054239_)))))))));
    vlSelf->__VdfgTmp_h9462500e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005040_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001103_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h638471cc__0))))));
    vlSelf->wasmetal_core__DOT___001102_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h638471cc__0))));
    vlSelf->wasmetal_core__DOT___069008_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069005_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069004_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054237_)))))))));
    vlSelf->wasmetal_core__DOT___005387_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h82a219c8__0)))));
    vlSelf->wasmetal_core__DOT___001080_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82a219c8__0))));
    vlSelf->wasmetal_core__DOT___068959_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068956_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068955_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054235_)))))))));
    vlSelf->__VdfgTmp_hcea60642__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005380_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001059_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h60872440__0))))));
    vlSelf->wasmetal_core__DOT___001058_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h60872440__0))));
    vlSelf->wasmetal_core__DOT___068890_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068887_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054233_)))))));
    vlSelf->wasmetal_core__DOT___052768_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb3e18d1b__0)))));
    vlSelf->wasmetal_core__DOT___045148_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb3e18d1b__0))))))));
    vlSelf->__VdfgTmp_hc3acb233__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005108_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001037_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h881dfff7__0))))));
    vlSelf->wasmetal_core__DOT___001036_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h881dfff7__0))));
    vlSelf->wasmetal_core__DOT___068843_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068839_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054231_)))))));
    vlSelf->__VdfgTmp_he5858a3c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005176_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001015_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h69848182__0))))));
    vlSelf->wasmetal_core__DOT___001014_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h69848182__0))));
    vlSelf->wasmetal_core__DOT___068815_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068810_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054229_)))))))));
    vlSelf->wasmetal_core__DOT___005484_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h426f01c6__0)))));
    vlSelf->wasmetal_core__DOT___000992_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h426f01c6__0))));
    vlSelf->wasmetal_core__DOT___068743_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068739_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054227_)))))));
    vlSelf->wasmetal_core__DOT___005474_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7c65fb3__0)))));
    vlSelf->wasmetal_core__DOT___000980_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha7c65fb3__0))));
    vlSelf->wasmetal_core__DOT___068713_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068695_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068694_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054225_)))))))));
    vlSelf->wasmetal_core__DOT___005464_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3ff94b24__0)))));
    vlSelf->wasmetal_core__DOT___001327_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3ff94b24__0))));
    vlSelf->wasmetal_core__DOT___068642_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x11U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d)))))))));
    vlSelf->__VdfgTmp_h64e10f56__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003876_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000927_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h5f9a0992__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5f9a0992__0))))));
    vlSelf->wasmetal_core__DOT___068596_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068593_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x10U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d)))))))));
    vlSelf->__VdfgTmp_hf93df92c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004092_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000897_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h5172aa32__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5172aa32__0))))));
    vlSelf->wasmetal_core__DOT___052452_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052447_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052446_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052445_)))));
    vlSelf->wasmetal_core__DOT___068556_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d))));
    vlSelf->wasmetal_core__DOT___068545_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068543_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068542_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0xfU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d)))))))));
    vlSelf->__VdfgTmp_h4a9c07e1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004314_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000896_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h56fd8038__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h56fd8038__0))))));
    vlSelf->wasmetal_core__DOT___052776_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052767_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052766_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000873_)))))))));
    vlSelf->wasmetal_core__DOT___068510_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068509_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068508_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0xeU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___068479_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d))));
    vlSelf->__VdfgTmp_hb9ea03dd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004018_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000873_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hde7deab4__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hde7deab4__0))))));
    vlSelf->wasmetal_core__DOT___068466_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0xeU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___068427_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d))));
    vlSelf->__VdfgTmp_h33498483__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003720_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000872_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hca53b37a__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hca53b37a__0))))));
    vlSelf->wasmetal_core__DOT___068391_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068390_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068389_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0xcU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___068403_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d))));
    vlSelf->__VdfgTmp_hbd8e6335__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004684_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000849_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hfa0f79c8__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfa0f79c8__0))))));
    vlSelf->wasmetal_core__DOT___068334_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b13__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[1U] 
                                                            >> 0xdU))))));
    vlSelf->wasmetal_core__DOT___068348_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d))));
    vlSelf->__VdfgTmp_hf0dacca2__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004240_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000848_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h3fc388f6__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3fc388f6__0))))));
    vlSelf->wasmetal_core__DOT___068281_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0xbU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___068294_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d))));
    vlSelf->__VdfgTmp_h2566b586__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004166_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000824_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha15d8995__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha15d8995__0))))));
    vlSelf->wasmetal_core__DOT___068227_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0xaU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___068241_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d))));
    vlSelf->__VdfgTmp_hd5a2b04d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003572_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000825_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_he2dbc386__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_he2dbc386__0))))));
    vlSelf->wasmetal_core__DOT___068195_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 8U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___068156_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d))));
    vlSelf->__VdfgTmp_h7f6ab5bd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003498_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000796_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_haaa3ad0b__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_haaa3ad0b__0))))));
    vlSelf->wasmetal_core__DOT___068141_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 8U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___068105_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d))));
    vlSelf->__VdfgTmp_h2712d491__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003646_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000795_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h3ec183f3__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3ec183f3__0))))));
    vlSelf->wasmetal_core__DOT___068070_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068068_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068067_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 6U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___068080_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d))));
    vlSelf->__VdfgTmp_h2f983ac6__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003794_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000772_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha7c76017__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7c76017__0))))));
    vlSelf->wasmetal_core__DOT___068021_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d))));
    vlSelf->wasmetal_core__DOT___068012_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 6U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_h158a449d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004610_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000771_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h97352ffe__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h97352ffe__0))))));
    vlSelf->wasmetal_core__DOT___067952_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067951_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067950_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 4U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___067964_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d))));
    vlSelf->__VdfgTmp_h2937d10d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004462_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000747_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h01ca3900__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h01ca3900__0))))));
    vlSelf->wasmetal_core__DOT___067889_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 4U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___067898_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d))));
    vlSelf->__VdfgTmp_ha7dc0a46__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004388_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000748_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h2bc911a1__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2bc911a1__0))))));
    vlSelf->wasmetal_core__DOT___052571_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052508_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052507_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052505_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052504_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052503_)))))))));
    vlSelf->wasmetal_core__DOT___067855_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 3U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___067811_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d))));
    vlSelf->__VdfgTmp_h6e7f092f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004536_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000723_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hc61dfdcc__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc61dfdcc__0))))));
    vlSelf->wasmetal_core__DOT___067802_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___067750_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d))));
    vlSelf->__VdfgTmp_hd1b03413__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004758_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000724_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h33ea4c85__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h33ea4c85__0))))));
    vlSelf->wasmetal_core__DOT___067723_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067721_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067720_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->cmd_data[1U]) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___067725_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d))));
    vlSelf->__VdfgTmp_h59e987ab__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004832_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000694_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_heeded769__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_heeded769__0))))));
    vlSelf->wasmetal_core__DOT___067652_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & vlSelf->cmd_data[1U]) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___067660_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d))));
    vlSelf->__VdfgTmp_hf92587e4__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003288_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000693_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h2f17a8a4__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2f17a8a4__0))))));
    vlSelf->wasmetal_core__DOT___052453_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052418_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052417_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052416_)))));
    vlSelf->wasmetal_core__DOT___067586_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067585_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067584_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d)))))))));
    vlSelf->__VdfgTmp_ha8427a44__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003208_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000665_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h51a3fd4e__0)))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51a3fd4e__0))))));
    vlSelf->wasmetal_core__DOT___052779_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052765_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052764_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000796_)))))))));
    vlSelf->wasmetal_core__DOT___045140_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha7f22436__0))))))));
    vlSelf->wasmetal_core__DOT___028661_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052235_))));
    vlSelf->wasmetal_core__DOT___028973_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052235_))));
    vlSelf->wasmetal_core__DOT___045434_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052233_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052235_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052234_)))))))));
    vlSelf->wasmetal_core__DOT___045446_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052234_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052233_)))))))));
    vlSelf->wasmetal_core__DOT___067537_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b31__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (vlSelf->cmd_data[0U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___048007_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbfbeb842__0))))));
    vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbfbeb842__0))))));
    vlSelf->wasmetal_core__DOT__divider__02esign_a 
        = (1U & (0xd0U >> (((IData)(vlSelf->wasmetal_core__DOT___052584_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___052583_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034342_)))));
    vlSelf->wasmetal_core__DOT___045164_ = (1U & (0x41000041U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___028485_)))))));
    vlSelf->wasmetal_core__DOT___067446_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067444_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067443_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1bU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b30__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048170_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb653ab3a__0)))));
    vlSelf->wasmetal_core__DOT___000657_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb653ab3a__0))));
    vlSelf->wasmetal_core__DOT___067397_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067395_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b29__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048241_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3063303a__0)))));
    vlSelf->wasmetal_core__DOT___000635_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3063303a__0))));
    vlSelf->wasmetal_core__DOT___052258_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052235_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052234_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7bad9dec__0))))))));
    vlSelf->wasmetal_core__DOT___067296_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067295_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067294_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b28__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___045163_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028481_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028482_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028484_)))));
    vlSelf->wasmetal_core__DOT___048182_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h69cbf44b__0)))));
    vlSelf->wasmetal_core__DOT___000613_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h69cbf44b__0))));
    vlSelf->wasmetal_core__DOT___067253_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067252_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067251_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b27__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048257_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h81d9a883__0)))));
    vlSelf->wasmetal_core__DOT___000591_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h81d9a883__0))));
    vlSelf->wasmetal_core__DOT___067144_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067142_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067141_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b26__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048180_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1d8dd092__0)))));
    vlSelf->wasmetal_core__DOT___000564_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1d8dd092__0))));
    vlSelf->wasmetal_core__DOT___067099_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067098_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067097_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b25__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___054005_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___003416_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b21__05d))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb9b6103f__0))));
    vlSelf->wasmetal_core__DOT___054018_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b24__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005096_))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb9b6103f__0))));
    vlSelf->wasmetal_core__DOT___045183_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028478_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028479_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028480_)))));
    vlSelf->wasmetal_core__DOT___048243_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0989e186__0)))));
    vlSelf->wasmetal_core__DOT___000542_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0989e186__0))));
    vlSelf->wasmetal_core__DOT___067025_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067024_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067023_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x15U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b24__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___044545_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf95886a6__0))))))));
    vlSelf->wasmetal_core__DOT___045442_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052527_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf95886a6__0))))))));
    vlSelf->wasmetal_core__DOT___048174_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h93789414__0)))));
    vlSelf->wasmetal_core__DOT___000520_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h93789414__0))));
    vlSelf->wasmetal_core__DOT___066954_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066953_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066952_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x14U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___045158_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005096_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbaa2fe71__0))))))));
    vlSelf->wasmetal_core__DOT___048069_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h62980089__0)))));
    vlSelf->wasmetal_core__DOT___000498_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h62980089__0))));
    vlSelf->wasmetal_core__DOT___066875_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066873_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b22__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___045182_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028475_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028476_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028477_)))));
    vlSelf->wasmetal_core__DOT___048045_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb2af30db__0)))));
    vlSelf->wasmetal_core__DOT___000476_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb2af30db__0))));
    vlSelf->wasmetal_core__DOT___066793_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066792_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066791_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x12U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b21__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048058_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hba3bfb32__0)))));
    vlSelf->wasmetal_core__DOT___000464_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hba3bfb32__0))));
    vlSelf->wasmetal_core__DOT___066710_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066709_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066708_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x11U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b20__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048041_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5a48cd94__0)))));
    vlSelf->wasmetal_core__DOT___000432_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5a48cd94__0))));
    vlSelf->wasmetal_core__DOT___066624_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066623_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066622_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x10U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b19__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___045181_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028471_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028473_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028474_)))));
    vlSelf->wasmetal_core__DOT___048142_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h76eadb80__0)))));
    vlSelf->wasmetal_core__DOT___000419_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h76eadb80__0))));
    vlSelf->wasmetal_core__DOT___066548_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066547_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066546_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xfU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b18__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048019_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h58ec7cd3__0)))));
    vlSelf->wasmetal_core__DOT___001646_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h58ec7cd3__0))));
    vlSelf->wasmetal_core__DOT___066467_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066466_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066465_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xeU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b17__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___052751_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052750_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001613_)))))));
    vlSelf->wasmetal_core__DOT___048073_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf275be9a__0)))));
    vlSelf->wasmetal_core__DOT___001624_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf275be9a__0))));
    vlSelf->wasmetal_core__DOT___066385_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066384_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066383_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b16__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___054034_ = (1U & (IData)(
                                                         (0x1001000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054029_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054028_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b27__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005028_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b26__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___004960_))))))))))));
    vlSelf->wasmetal_core__DOT___045180_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028468_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028469_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028470_)))));
    vlSelf->wasmetal_core__DOT___048009_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4781af3e__0)))));
    vlSelf->wasmetal_core__DOT___001612_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4781af3e__0))));
    vlSelf->wasmetal_core__DOT___066302_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066299_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066298_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054095_)))))))));
    vlSelf->wasmetal_core__DOT___048694_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h808c51bd__0)))));
    vlSelf->wasmetal_core__DOT___001580_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h808c51bd__0))));
    vlSelf->wasmetal_core__DOT___066209_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066203_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066202_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054091_)))))))));
    vlSelf->wasmetal_core__DOT___048192_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haaaaa9f9__0)))));
    vlSelf->wasmetal_core__DOT___001568_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haaaaa9f9__0))));
    vlSelf->wasmetal_core__DOT___066069_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066065_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054087_)))))))));
    vlSelf->wasmetal_core__DOT___045179_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028465_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028466_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028467_)))));
    vlSelf->wasmetal_core__DOT___048237_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h60633cb7__0)))));
    vlSelf->wasmetal_core__DOT___001536_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h60633cb7__0))));
    vlSelf->wasmetal_core__DOT___066007_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066004_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054083_)))))));
    vlSelf->wasmetal_core__DOT___048188_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc1bc9aa3__0)))));
    vlSelf->wasmetal_core__DOT___001524_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1bc9aa3__0))));
    vlSelf->wasmetal_core__DOT___065888_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065885_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065884_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054079_)))))))));
    vlSelf->wasmetal_core__DOT___054000_ = (1U & (IData)(
                                                         (0x1001000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053996_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004892_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b4__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___004448_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b6__05d))))))))))));
    vlSelf->wasmetal_core__DOT___048261_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h38c61391__0)))));
    vlSelf->wasmetal_core__DOT___001425_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h38c61391__0))));
    vlSelf->wasmetal_core__DOT___065792_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065789_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065788_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054075_)))))))));
    vlSelf->wasmetal_core__DOT___050341_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050338_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003542_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003524_)))))))));
    vlSelf->wasmetal_core__DOT___045178_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028462_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028463_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028464_)))));
    vlSelf->wasmetal_core__DOT___048200_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7b1a2166__0)))));
    vlSelf->wasmetal_core__DOT___001413_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7b1a2166__0))));
    vlSelf->wasmetal_core__DOT___065732_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065724_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065723_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054071_)))))))));
    vlSelf->wasmetal_core__DOT___048233_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h35d7421d__0)))));
    vlSelf->wasmetal_core__DOT___001381_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h35d7421d__0))));
    vlSelf->wasmetal_core__DOT___065594_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065592_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065591_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b8__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048194_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd822ef23__0)))));
    vlSelf->wasmetal_core__DOT___001369_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd822ef23__0))));
    vlSelf->wasmetal_core__DOT___065505_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065502_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054063_)))))));
    vlSelf->wasmetal_core__DOT___045177_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028490_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028491_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028492_)))));
    vlSelf->wasmetal_core__DOT___048065_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hae88697a__0)))));
    vlSelf->wasmetal_core__DOT___001487_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hae88697a__0))));
    vlSelf->wasmetal_core__DOT___065399_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054059_)))))));
    vlSelf->wasmetal_core__DOT___048015_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2996e40e__0)))));
    vlSelf->wasmetal_core__DOT___001475_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2996e40e__0))));
    vlSelf->wasmetal_core__DOT___065287_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065284_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065283_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054055_)))))))));
    vlSelf->wasmetal_core__DOT___048155_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcab9d929__0)))));
    vlSelf->wasmetal_core__DOT___001443_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcab9d929__0))));
    vlSelf->wasmetal_core__DOT___052570_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052477_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052476_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h91f69850__0)))));
    vlSelf->wasmetal_core__DOT___065160_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065157_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054051_)))))));
    vlSelf->wasmetal_core__DOT___045176_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028487_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028488_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028489_)))));
    vlSelf->wasmetal_core__DOT___048029_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4a4b1d7e__0)))));
    vlSelf->wasmetal_core__DOT___001437_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4a4b1d7e__0))));
    vlSelf->wasmetal_core__DOT___065047_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065044_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054047_)))))));
    vlSelf->wasmetal_core__DOT___048151_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h99694808__0)))));
    vlSelf->wasmetal_core__DOT___001886_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h99694808__0))));
    vlSelf->wasmetal_core__DOT___064887_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064883_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054043_)))))));
    vlSelf->wasmetal_core__DOT___048035_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb773d3a6__0)))));
    vlSelf->wasmetal_core__DOT___001874_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb773d3a6__0))));
    vlSelf->wasmetal_core__DOT___054033_ = (1U & (IData)(
                                                         (0x1001000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054025_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054024_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b1__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___003270_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b8__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___003780_))))))))))));
    vlSelf->wasmetal_core__DOT___045173_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028472_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028483_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028486_)))));
    vlSelf->wasmetal_core__DOT___028648_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052256_))));
    vlSelf->wasmetal_core__DOT___028960_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052256_))));
    vlSelf->wasmetal_core__DOT___064716_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & vlSelf->cmd_data[0U]) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___064463_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d))));
    vlSelf->wasmetal_core__DOT___048138_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h37d1cc77__0))))));
    vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h37d1cc77__0))))));
    vlSelf->wasmetal_core__DOT___128640___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001875_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128640___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___052758_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052753_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052752_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001414_)))))))));
    vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__0__KET__ 
        = ((9U >> (IData)(vlSelf->__VdfgTmp_h4ae0787e__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___003190_));
    vlSelf->wasmetal_core__DOT___045433_ = (1U & (0x2b22U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052558_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052256_))))));
    vlSelf->wasmetal_core__DOT___045445_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052256_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052558_))))));
    vlSelf->wasmetal_core__DOT___028637_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052558_))));
    vlSelf->wasmetal_core__DOT___052569_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052558_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052557_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052556_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052555_)))))))));
    vlSelf->wasmetal_core__DOT___028949_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052558_))));
    vlSelf->wasmetal_core__DOT___064450_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    __Vtemp_1[0U] = (IData)((((QData)((IData)((1U & 
                                               (8U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d)))))) 
                              << 0x3fU) | (((QData)((IData)(
                                                            (1U 
                                                             & (8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d)))))) 
                                            << 0x3eU) 
                                           | (((QData)((IData)(
                                                               (1U 
                                                                & (8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))) 
                                               << 0x3dU) 
                                              | (((QData)((IData)(
                                                                  (1U 
                                                                   & (8U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))) 
                                                  << 0x3cU) 
                                                 | (((QData)((IData)(
                                                                     (1U 
                                                                      & (8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b59__05d)))))) 
                                                     << 0x3bU) 
                                                    | (((QData)((IData)(
                                                                        (1U 
                                                                         & (8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d)))))) 
                                                        << 0x3aU) 
                                                       | (((QData)((IData)(
                                                                           (1U 
                                                                            & (8U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b57__05d)))))) 
                                                           << 0x39U) 
                                                          | (((QData)((IData)(
                                                                              (1U 
                                                                               & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d)))))) 
                                                              << 0x38U) 
                                                             | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d)))))) 
                                                                 << 0x37U) 
                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d)))))) 
                                                                    << 0x36U) 
                                                                   | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d)))))) 
                                                                       << 0x35U) 
                                                                      | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d)))))) 
                                                                          << 0x34U) 
                                                                         | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d)))))) 
                                                                             << 0x33U) 
                                                                            | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d)))))) 
                                                                                << 0x32U) 
                                                                               | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d)))))) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d)))))) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d)))))) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d)))))) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d)))))) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d)))))) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d)))))) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d)))))) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d)))))) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d)))))) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d)))))) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d)))))) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d)))))) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d)))))) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d)))))) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d)))))) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d)))))) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d)))))) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d))) 
                                                                                << 0x1fU) 
                                                                                | ((0x40000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d))) 
                                                                                << 0x1eU)) 
                                                                                | ((0x20000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b29__05d))) 
                                                                                << 0x1dU)) 
                                                                                | ((0x10000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b28__05d))) 
                                                                                << 0x1cU)) 
                                                                                | ((0x8000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b27__05d))) 
                                                                                << 0x1bU)) 
                                                                                | ((0x4000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b26__05d))) 
                                                                                << 0x1aU)) 
                                                                                | ((0x2000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b25__05d))) 
                                                                                << 0x19U)) 
                                                                                | ((0x1000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d))) 
                                                                                << 0x18U)) 
                                                                                | ((0x800000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b23__05d))) 
                                                                                << 0x17U)) 
                                                                                | ((0x400000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b22__05d))) 
                                                                                << 0x16U)) 
                                                                                | ((0x200000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b21__05d))) 
                                                                                << 0x15U)) 
                                                                                | ((0x100000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b20__05d))) 
                                                                                << 0x14U)) 
                                                                                | ((0x80000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b19__05d))) 
                                                                                << 0x13U)) 
                                                                                | ((0x40000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b18__05d))) 
                                                                                << 0x12U)) 
                                                                                | ((0x20000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b17__05d))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b16__05d))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b15__05d))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b7__05d))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b6__05d))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b4__05d))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b3__05d))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    __Vtemp_1[1U] = (IData)(((((QData)((IData)((1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d)))))) 
                               << 0x3fU) | (((QData)((IData)(
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d)))))) 
                                             << 0x3eU) 
                                            | (((QData)((IData)(
                                                                (1U 
                                                                 & (8U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))) 
                                                << 0x3dU) 
                                               | (((QData)((IData)(
                                                                   (1U 
                                                                    & (8U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))) 
                                                   << 0x3cU) 
                                                  | (((QData)((IData)(
                                                                      (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b59__05d)))))) 
                                                      << 0x3bU) 
                                                     | (((QData)((IData)(
                                                                         (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d)))))) 
                                                         << 0x3aU) 
                                                        | (((QData)((IData)(
                                                                            (1U 
                                                                             & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b57__05d)))))) 
                                                            << 0x39U) 
                                                           | (((QData)((IData)(
                                                                               (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d)))))) 
                                                               << 0x38U) 
                                                              | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d)))))) 
                                                                  << 0x37U) 
                                                                 | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d)))))) 
                                                                     << 0x36U) 
                                                                    | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d)))))) 
                                                                        << 0x35U) 
                                                                       | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d)))))) 
                                                                           << 0x34U) 
                                                                          | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d)))))) 
                                                                              << 0x33U) 
                                                                             | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d)))))) 
                                                                                << 0x32U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d)))))) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d)))))) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d)))))) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d)))))) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d)))))) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d)))))) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d)))))) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d)))))) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d)))))) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d)))))) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d)))))) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d)))))) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d)))))) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d)))))) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d)))))) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d)))))) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d)))))) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d)))))) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d))) 
                                                                                << 0x1fU) 
                                                                                | ((0x40000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d))) 
                                                                                << 0x1eU)) 
                                                                                | ((0x20000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b29__05d))) 
                                                                                << 0x1dU)) 
                                                                                | ((0x10000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b28__05d))) 
                                                                                << 0x1cU)) 
                                                                                | ((0x8000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b27__05d))) 
                                                                                << 0x1bU)) 
                                                                                | ((0x4000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b26__05d))) 
                                                                                << 0x1aU)) 
                                                                                | ((0x2000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b25__05d))) 
                                                                                << 0x19U)) 
                                                                                | ((0x1000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d))) 
                                                                                << 0x18U)) 
                                                                                | ((0x800000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b23__05d))) 
                                                                                << 0x17U)) 
                                                                                | ((0x400000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b22__05d))) 
                                                                                << 0x16U)) 
                                                                                | ((0x200000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b21__05d))) 
                                                                                << 0x15U)) 
                                                                                | ((0x100000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b20__05d))) 
                                                                                << 0x14U)) 
                                                                                | ((0x80000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b19__05d))) 
                                                                                << 0x13U)) 
                                                                                | ((0x40000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b18__05d))) 
                                                                                << 0x12U)) 
                                                                                | ((0x20000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b17__05d))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b16__05d))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b15__05d))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b7__05d))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b6__05d))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b4__05d))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b3__05d))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) 
                             >> 0x20U));
    __Vtemp_6[2U] = ((0x20U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                        << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b69__05d))) 
                               << 5U)) | ((0x10U & 
                                           ((8U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b68__05d))) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((8U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b67__05d))) 
                                               << 3U)) 
                                             | ((4U 
                                                 & ((8U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b66__05d))) 
                                                    << 2U)) 
                                                | ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b65__05d))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b64__05d)))))))));
    __Vtemp_12[2U] = ((0x800U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b75__05d))) 
                                 << 0xbU)) | ((0x400U 
                                               & ((8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b74__05d))) 
                                                  << 0xaU)) 
                                              | ((0x200U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d))) 
                                                     << 9U)) 
                                                 | ((0x100U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b72__05d))) 
                                                        << 8U)) 
                                                    | ((0x80U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b71__05d))) 
                                                           << 7U)) 
                                                       | ((0x40U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b70__05d))) 
                                                              << 6U)) 
                                                          | __Vtemp_6[2U]))))));
    __Vtemp_18[2U] = ((0x20000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b81__05d))) 
                                   << 0x11U)) | ((0x10000U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b80__05d))) 
                                                     << 0x10U)) 
                                                 | ((0x8000U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b79__05d))) 
                                                        << 0xfU)) 
                                                    | ((0x4000U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b78__05d))) 
                                                           << 0xeU)) 
                                                       | ((0x2000U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b77__05d))) 
                                                              << 0xdU)) 
                                                          | ((0x1000U 
                                                              & ((8U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b76__05d))) 
                                                                 << 0xcU)) 
                                                             | __Vtemp_12[2U]))))));
    __Vtemp_24[2U] = ((0x800000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b87__05d))) 
                                    << 0x17U)) | ((0x400000U 
                                                   & ((8U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b86__05d))) 
                                                      << 0x16U)) 
                                                  | ((0x200000U 
                                                      & ((8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d))) 
                                                         << 0x15U)) 
                                                     | ((0x100000U 
                                                         & ((8U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b84__05d))) 
                                                            << 0x14U)) 
                                                        | ((0x80000U 
                                                            & ((8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b83__05d))) 
                                                               << 0x13U)) 
                                                           | ((0x40000U 
                                                               & ((8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b82__05d))) 
                                                                  << 0x12U)) 
                                                              | __Vtemp_18[2U]))))));
    __Vtemp_30[2U] = ((0x20000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b93__05d))) 
                                      << 0x1dU)) | 
                      ((0x10000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b92__05d))) 
                                       << 0x1cU)) | 
                       ((0x8000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b91__05d))) 
                                       << 0x1bU)) | 
                        ((0x4000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b90__05d))) 
                                        << 0x1aU)) 
                         | ((0x2000000U & ((8U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b89__05d))) 
                                           << 0x19U)) 
                            | ((0x1000000U & ((8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b88__05d))) 
                                              << 0x18U)) 
                               | __Vtemp_24[2U]))))));
    __Vtemp_38[3U] = ((0x20U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b101__05d))) 
                                << 5U)) | ((0x10U & 
                                            ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b100__05d))) 
                                             << 4U)) 
                                           | ((8U & 
                                               ((8U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b99__05d))) 
                                                << 3U)) 
                                              | ((4U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b97__05d))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b96__05d)))))))));
    __Vtemp_44[3U] = ((0x800U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b107__05d))) 
                                 << 0xbU)) | ((0x400U 
                                               & ((8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b106__05d))) 
                                                  << 0xaU)) 
                                              | ((0x200U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b105__05d))) 
                                                     << 9U)) 
                                                 | ((0x100U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b104__05d))) 
                                                        << 8U)) 
                                                    | ((0x80U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b103__05d))) 
                                                           << 7U)) 
                                                       | ((0x40U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b102__05d))) 
                                                              << 6U)) 
                                                          | __Vtemp_38[3U]))))));
    __Vtemp_50[3U] = ((0x20000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b113__05d))) 
                                   << 0x11U)) | ((0x10000U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d))) 
                                                     << 0x10U)) 
                                                 | ((0x8000U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b111__05d))) 
                                                        << 0xfU)) 
                                                    | ((0x4000U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b110__05d))) 
                                                           << 0xeU)) 
                                                       | ((0x2000U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b109__05d))) 
                                                              << 0xdU)) 
                                                          | ((0x1000U 
                                                              & ((8U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b108__05d))) 
                                                                 << 0xcU)) 
                                                             | __Vtemp_44[3U]))))));
    __Vtemp_56[3U] = ((0x800000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b119__05d))) 
                                    << 0x17U)) | ((0x400000U 
                                                   & ((8U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b118__05d))) 
                                                      << 0x16U)) 
                                                  | ((0x200000U 
                                                      & ((8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b117__05d))) 
                                                         << 0x15U)) 
                                                     | ((0x100000U 
                                                         & ((8U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b116__05d))) 
                                                            << 0x14U)) 
                                                        | ((0x80000U 
                                                            & ((8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b115__05d))) 
                                                               << 0x13U)) 
                                                           | ((0x40000U 
                                                               & ((8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b114__05d))) 
                                                                  << 0x12U)) 
                                                              | __Vtemp_50[3U]))))));
    __Vtemp_62[3U] = ((0x20000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b125__05d))) 
                                      << 0x1dU)) | 
                      ((0x10000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b124__05d))) 
                                       << 0x1cU)) | 
                       ((0x8000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b123__05d))) 
                                       << 0x1bU)) | 
                        ((0x4000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b122__05d))) 
                                        << 0x1aU)) 
                         | ((0x2000000U & ((8U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b121__05d))) 
                                           << 0x19U)) 
                            | ((0x1000000U & ((8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b120__05d))) 
                                              << 0x18U)) 
                               | __Vtemp_56[3U]))))));
    vlSelf->result_data[0U] = __Vtemp_1[0U];
    vlSelf->result_data[1U] = __Vtemp_1[1U];
    vlSelf->result_data[2U] = (((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d))) 
                                << 0x1fU) | ((0x40000000U 
                                              & ((8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d))) 
                                                 << 0x1eU)) 
                                             | __Vtemp_30[2U]));
    vlSelf->result_data[3U] = (((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b127__05d))) 
                                << 0x1fU) | ((0x40000000U 
                                              & ((8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b126__05d))) 
                                                 << 0x1eU)) 
                                             | __Vtemp_62[3U]));
}
