#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__6(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__6\n"); );
    // Body
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT____Vcellout___129095___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129064___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129063___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129062___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129061___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129228___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129204___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129180___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129196___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129212___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129173___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129175___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129229___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129230___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129231___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129232___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129176___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129206___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129207___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129172___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129205___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129181___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129198___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129199___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129182___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129208___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129213___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129214___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129215___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129216___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129220___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129197___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129200___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129171___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129227___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129179___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129195___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129211___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129203___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129174___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129184___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129222___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129223___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129224___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129221___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129191___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129187___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129219___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129226___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129202___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129178___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129194___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129210___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129170___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129186___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129218___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129233___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129201___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129209___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129217___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129225___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129193___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129177___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129060___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129059___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129058___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129057___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129056___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129055___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129054___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129053___Q = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129094___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129052___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129051___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129050___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129049___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129048___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129047___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129046___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129045___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129044___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129043___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129042___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129041___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129040___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129039___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129038___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129037___Q = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129093___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129092___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128899___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129104___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129105___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129103___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129102___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129101___Q = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129091___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129090___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129089___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129088___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129087___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129086___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129085___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129084___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129083___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129082___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129081___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129080___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128967___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128966___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128965___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128964___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128963___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128962___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128961___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128960___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128959___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128958___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128957___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128956___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128955___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128954___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128953___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128952___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128951___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128950___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128949___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128948___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128947___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128946___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128945___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128944___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128943___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128942___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128941___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128940___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128939___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128938___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128937___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128936___Q = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129079___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b42__05d = 0U;
        vlSelf->done = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129078___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129077___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129076___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129075___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129074___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129073___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129072___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b35__05d = 0U;
        vlSelf->mem_valid = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128903___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128902___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128901___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128900___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128898___Q = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129071___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129070___Q = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_left__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edivisor__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b127__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b71__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b103__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b95__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b111__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b119__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_fill_value__05b87__05d = 0U;
        vlSelf->wasmetal_core__DOT__exception_reference__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___019801_) {
            vlSelf->wasmetal_core__DOT____Vcellout___129095___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063344_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063343_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129064___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063262_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063261_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129063___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063256_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063255_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129062___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063250_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063249_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129061___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063244_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063243_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129060___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063238_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063237_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129059___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063232_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063231_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129058___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063226_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063225_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129057___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063220_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063219_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129056___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063214_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063213_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129055___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063208_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063207_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129054___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063202_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063201_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129053___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063196_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063195_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129094___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063342_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063341_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129052___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063190_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063189_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129051___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063184_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063183_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129050___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063178_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063177_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129049___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063172_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063171_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129048___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063166_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063165_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129047___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063160_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063159_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129046___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063154_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063153_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129045___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063148_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063147_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129044___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063142_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063141_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129043___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063136_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063135_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129042___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063130_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063129_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129041___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063124_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063123_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129040___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063118_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063117_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129039___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063112_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063111_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129038___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063106_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063105_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129037___Q 
                = (1U & (0x88f8ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___063100_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___063099_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062961_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129093___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063340_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063339_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129092___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063338_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063337_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129104___Q 
                = (1U & (IData)((0xff000000ff8f8f8fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048485_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__access_size__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___046932_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063361_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063356_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129105___Q 
                = (1U & (IData)((0xfff0bbbbffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___053614_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___048485_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__access_size__05b4__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___046933_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xfeffffff00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___063355_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_kind__05b0__05d) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b4__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_kind__05b2__05d)))))))))))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129103___Q 
                = (1U & (IData)((0xff000000ff8f8f8fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048485_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__access_size__05b2__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___046931_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063360_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063356_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129102___Q 
                = (1U & (IData)((0xffffffffff808080ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___063359_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__access_size__05b1__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063356_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129101___Q 
                = (1U & (IData)((0xffff8f888f888f88ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__access_size__05b0__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048485_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063357_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063356_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129091___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063336_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063335_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129090___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063334_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063333_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129089___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063332_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063331_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129088___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063330_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063329_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129087___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063328_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063327_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129086___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063326_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063325_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129085___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063324_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063323_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129084___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063322_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063321_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129083___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063320_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063319_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129082___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063318_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063317_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129081___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063316_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063315_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129080___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063314_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063313_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129079___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063312_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063311_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129078___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063310_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063309_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129077___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063308_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063307_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129076___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063306_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063305_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129075___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063304_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063303_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129074___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063302_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063301_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129073___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063300_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063299_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129072___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063298_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063297_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129071___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063296_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063295_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129070___Q 
                = (1U & (IData)((0xf444ffff0000ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063294_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063293_)))))))));
        }
        if ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)))) {
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b58__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128661___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001080_))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b57__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128661___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001058_))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b56__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128661___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001036_))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b55__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128660___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001014_))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b54__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128660___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000992_))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b53__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128660___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000980_))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b52__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128660___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001327_))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b51__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128659___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b50__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128659___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b49__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128659___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b48__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128659___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b47__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128658___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b46__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128658___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b45__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128658___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b44__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128658___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b43__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128657___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b42__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128657___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b41__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128657___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b40__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128657___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b39__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128671___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b38__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128671___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b37__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128671___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b36__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128671___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b35__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128670___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b34__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128670___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b33__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128670___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))));
            vlSelf->wasmetal_core__DOT__divider__02edivisor__05b32__05d 
                = (1U & (0xca00U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                      << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128670___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))))));
        }
        if (vlSelf->wasmetal_core__DOT___019787_) {
            vlSelf->wasmetal_core__DOT__exception_reference__05b58__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b26__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b57__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b25__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b56__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b24__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b55__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b23__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b54__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b22__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b53__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b21__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b52__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b20__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b51__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b19__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b50__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b18__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b49__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b17__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b48__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b16__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b47__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b15__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b46__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b14__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b45__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b13__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b44__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b12__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b43__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b11__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b42__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b10__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b41__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b9__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b40__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b8__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b39__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b7__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b38__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b6__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b37__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b5__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b36__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b4__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b35__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b3__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b34__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b2__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b33__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b1__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b32__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b0__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b31__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b31__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b30__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b30__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b29__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b29__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b28__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b28__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b27__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b27__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b26__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b26__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b25__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b25__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b24__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b24__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b23__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b23__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b22__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b22__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b21__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b21__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b20__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b20__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b19__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b19__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b18__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b18__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b17__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b17__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b16__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b16__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b15__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b15__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b14__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b14__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b13__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b13__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b12__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b12__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b11__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b11__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b10__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b10__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b9__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b9__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b8__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b8__05d)))));
            vlSelf->wasmetal_core__DOT__exception_reference__05b7__05d 
                = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b7__05d)))));
        }
        if (vlSelf->wasmetal_core__DOT___019800_) {
            vlSelf->wasmetal_core__DOT____Vcellout___129228___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062477_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h52168cf5__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129204___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062418_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009246_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129180___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062354_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062353_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129196___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062397_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129212___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062438_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062437_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129173___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062333_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062332_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129175___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062338_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062337_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129229___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062480_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd3ee6e40__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129230___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062483_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h18926335__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129231___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062486_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062485_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129232___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062489_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062488_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129176___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062343_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062342_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129206___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062423_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062422_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129207___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062426_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5e622f55__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129172___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062330_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055464_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129205___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062420_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009259_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129181___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062357_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129198___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062402_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062401_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129199___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062405_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062404_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129182___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062359_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___061031_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129208___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062428_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009285_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129213___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062443_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062442_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129214___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062445_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009335_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129215___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062447_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009348_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129216___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062449_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129220___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062458_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009397_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129197___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062399_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055962_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129200___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062407_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055984_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129171___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062328_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062327_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129227___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062475_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h20f110d2__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129179___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062351_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062350_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129195___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062394_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___060840_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129211___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062435_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056042_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129203___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062416_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009233_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129174___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062335_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055555_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129184___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062364_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129222___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062462_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___056089_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129223___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062465_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9f90b4cf__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129224___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062467_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009419_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129221___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062460_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009402_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129191___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062385_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___061165_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129187___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062372_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___060828_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129219___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062456_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009388_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129226___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062472_) 
                                                 << 4U) 
                                                | ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_heabab031__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129202___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062414_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062413_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129178___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062348_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062347_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129194___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062392_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___060752_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129210___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062433_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062432_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129170___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062325_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055362_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129186___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062370_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062369_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129218___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062454_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062453_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129233___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062492_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062491_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129201___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062411_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062410_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129209___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062430_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009296_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129217___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062451_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___009363_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129225___Q 
                = (1U & (IData)((0xfffff444f444ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062470_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062469_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129193___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062390_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___061316_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129177___Q 
                = (1U & (IData)((0xffff44f444f4ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___062345_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055710_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062195_)))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019796_) {
            vlSelf->wasmetal_core__DOT__bulk_source__05b57__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128303___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001059_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b56__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128303___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001037_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b55__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128302___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001015_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b54__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128302___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000993_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b53__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128302___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000981_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b52__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128302___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000926_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b51__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128301___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000927_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b50__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128301___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000897_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b49__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128301___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000896_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b48__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128301___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127896___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000873_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b47__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128300___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000872_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b46__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128300___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000849_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b45__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128300___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000848_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b44__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128300___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127895___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000824_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b43__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128299___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000825_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b42__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128299___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000796_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b41__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128299___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000795_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b40__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128299___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000772_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b39__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128313___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000771_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b38__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128313___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000747_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b37__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128313___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000748_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b36__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128313___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000723_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b35__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128312___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000724_)))))))));
            vlSelf->wasmetal_core__DOT__bulk_source__05b34__05d 
                = (1U & (IData)((0xf0f0f0f0ccaa0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128312___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000694_)))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019795_) {
            vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128335___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128335___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b55__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128334___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b54__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128334___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b53__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128334___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b52__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128334___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b51__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128333___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b50__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128333___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b49__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128333___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b48__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128333___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b47__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128332___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b46__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128332___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b45__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128332___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b44__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128332___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b43__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128331___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b42__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128331___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b41__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128331___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b40__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128331___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b39__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128345___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b38__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128345___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b37__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128345___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b36__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128345___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b35__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128344___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b34__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128344___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b33__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128344___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
            vlSelf->wasmetal_core__DOT__bulk_left__05b32__05d 
                = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128344___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))))));
        }
        if (vlSelf->wasmetal_core__DOT___052916_) {
            vlSelf->wasmetal_core__DOT__load_vector__05b56__05d 
                = vlSelf->wasmetal_core__DOT___001036_;
            vlSelf->wasmetal_core__DOT__load_vector__05b55__05d 
                = vlSelf->wasmetal_core__DOT___001014_;
            vlSelf->wasmetal_core__DOT__load_vector__05b54__05d 
                = vlSelf->wasmetal_core__DOT___000992_;
            vlSelf->wasmetal_core__DOT__load_vector__05b53__05d 
                = vlSelf->wasmetal_core__DOT___000980_;
            vlSelf->wasmetal_core__DOT__load_vector__05b52__05d 
                = vlSelf->wasmetal_core__DOT___001327_;
            vlSelf->wasmetal_core__DOT__load_vector__05b51__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b50__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b49__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b48__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b46__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b44__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b40__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b39__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b34__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b33__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b32__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b31__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b30__05d 
                = vlSelf->wasmetal_core__DOT___000657_;
            vlSelf->wasmetal_core__DOT__load_vector__05b28__05d 
                = vlSelf->wasmetal_core__DOT___000613_;
            vlSelf->wasmetal_core__DOT__load_vector__05b26__05d 
                = vlSelf->wasmetal_core__DOT___000564_;
            vlSelf->wasmetal_core__DOT__load_vector__05b22__05d 
                = vlSelf->wasmetal_core__DOT___000476_;
            vlSelf->wasmetal_core__DOT__load_vector__05b20__05d 
                = vlSelf->wasmetal_core__DOT___000432_;
            vlSelf->wasmetal_core__DOT__load_vector__05b18__05d 
                = vlSelf->wasmetal_core__DOT___001646_;
            vlSelf->wasmetal_core__DOT__load_vector__05b15__05d 
                = vlSelf->wasmetal_core__DOT___001580_;
            vlSelf->wasmetal_core__DOT__load_vector__05b13__05d 
                = vlSelf->wasmetal_core__DOT___001536_;
            vlSelf->wasmetal_core__DOT__load_vector__05b12__05d 
                = vlSelf->wasmetal_core__DOT___001524_;
            vlSelf->wasmetal_core__DOT__load_vector__05b11__05d 
                = vlSelf->wasmetal_core__DOT___001425_;
            vlSelf->wasmetal_core__DOT__load_vector__05b10__05d 
                = vlSelf->wasmetal_core__DOT___001413_;
            vlSelf->wasmetal_core__DOT__load_vector__05b9__05d 
                = vlSelf->wasmetal_core__DOT___001381_;
            vlSelf->wasmetal_core__DOT__load_vector__05b8__05d 
                = vlSelf->wasmetal_core__DOT___001369_;
        }
        if (vlSelf->wasmetal_core__DOT___019806_) {
            vlSelf->wasmetal_core__DOT____Vcellout___128899___Q 
                = (1U & (0xaa0fcccfU >> (((IData)(vlSelf->wasmetal_core__DOT___052995_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062983_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0xffffff80ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063009_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___052873_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___052872_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02etrap__05b3__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___062987_)))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128903___Q 
                = (1U & (IData)((0xccfccfcf1fd111fdULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x80a0ccff00f000ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___062981_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063013_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063019_)))))))))))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128902___Q 
                = (1U & (IData)((0xccfccfcf1fd111fdULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x80a0ccff00f000ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___062981_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063013_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063017_)))))))))))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128901___Q 
                = (1U & (IData)((0xccfccfcf1fd111fdULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x80a0ccff00f000ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___062981_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063013_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063015_)))))))))))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128900___Q 
                = (1U & (IData)((0xccfccfcf1fd111fdULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x80a0ccff00f000ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___062981_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063013_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063012_)))))))))))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128898___Q 
                = (1U & (IData)((0xffff3fff0ff35d75ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f0000000fc00faULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062994_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->insn_valid) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff000b00ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063001_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052706_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052578_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050385_)))))))))))))))));
        }
        if (vlSelf->wasmetal_core__DOT___046015_) {
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0xfdf0f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069151_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069150_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069149_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___057246_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___064017_)))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___069152_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d 
                = (1U & (0xefU >> ((4U & ((IData)((0xaf3f00000000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___069083_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069082_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b60__05d) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___054241_)))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0x11f1ffff00000000ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___069101_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057098_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012356_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___048330_)))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___069102_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069058_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069057_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xdf0f0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___069032_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___069031_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___069030_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (8U 
                                                                           >> 
                                                                           (3U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                               >> 2U))))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xafcf00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___069050_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___069049_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he11b9fc4__0))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069009_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069008_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xafcf0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___068978_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_ha6c246b8__0))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xdf0f0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___069001_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069000_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068999_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (8U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___068960_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___068959_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xef00U 
                                                           >> 
                                                           ((8U 
                                                             & ((IData)(
                                                                        (0x7f333f3f00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___068923_) 
                                                                           << 5U) 
                                                                          | ((0x10U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068922_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b57__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07144816__0))))))) 
                                                                << 3U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((0x407000fU 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b57__05d) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067049_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064664_)))))))) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & (0x70330000U 
                                                                        >> 
                                                                        ((0x18U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                             << 1U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068931_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b57__05d) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___068930_)))))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xafcf00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___068952_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___068951_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011426_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d 
                = (1U & (IData)((0xffffef00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___068911_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___068910_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xe00U 
                                                           >> 
                                                           ((8U 
                                                             & ((IData)(
                                                                        (0x153f000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___068903_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128244___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))) 
                                                                << 3U)) 
                                                            | ((4U 
                                                                & ((IData)(
                                                                           (0xcfaf0f0f00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068901_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068900_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd5ee5b41__0))))))) 
                                                                   << 2U)) 
                                                               | ((2U 
                                                                   & ((0xafcfU 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___068897_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066966_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xeeee0f0fff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068076_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068475_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068698_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb27da868__0)))))))))))))))) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___048287_))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x5300U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_ha73aa920__0)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x8fU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010377_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___060766_))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d 
                = (1U & (IData)((0xffffef00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___068864_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___068863_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x10U 
                                                           >> 
                                                           ((4U 
                                                             & ((IData)(
                                                                        (0x153f000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___068856_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128243___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xcfaf0f0f00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068854_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068853_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha04b46b6__0))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0fbf0f0ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068850_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ccf0f0000000aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002933_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066888_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063837_)))))))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x888fU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___057554_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057553_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___061333_)))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x5300U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h4d745f43__0)))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d 
                = (1U & (IData)((0xffffff70ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___068815_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___068814_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___068813_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xafcfU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___068806_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012957_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x10U 
                                                               >> 
                                                               ((4U 
                                                                 & ((IData)(
                                                                            (0x153f000000000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___068801_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128243___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))) 
                                                                    << 2U)) 
                                                                | ((2U 
                                                                    & ((IData)(
                                                                               (0xcfaf0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068799_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068798_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h59798d13__0))))))) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(
                                                                                (0xf0fbf0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068795_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ccf0f0000000aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002564_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066847_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063837_)))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0x1000ffff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068713_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068712_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xff00ffff70007070ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057099_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057118_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048505_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xcfaf0f0f00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068706_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068705_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d0edfe8__0))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0fbf0f0ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068702_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ccf0f0000000aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002324_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066642_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063837_)))))))))))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___068714_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0x1000ffff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068665_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068664_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xff00ffff70007070ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057046_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012315_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010084_)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061016_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048505_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xcfaf0f0f00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068658_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068657_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf825dcba__0))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0fbf0f0ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068654_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ccf0f0000000aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb4d5b900__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066597_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063837_)))))))))))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___068666_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0x1000ffff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068616_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068615_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xe0e0e00ffffff00ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068597_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011949_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011026_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xcfaf0f0f00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068609_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068608_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd7f74d59__0))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0fbf0f0ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068604_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ccf0f0000000aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5b64371c__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066520_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063837_)))))))))))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___068617_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d 
                = (1U & (IData)((0xffffef00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___068567_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___068566_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x10U 
                                                           >> 
                                                           ((4U 
                                                             & ((IData)(
                                                                        (0x153f000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___068559_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128242___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xcfaf0f0f00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068557_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068556_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068555_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef5b3f20__0))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0fbf0f0ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068552_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ccf0f0000000aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdb0eb761__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066394_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063837_)))))))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x88ff8f8fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011732_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011731_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060849_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___056668_))))))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019804_) {
            vlSelf->wasmetal_core__DOT____Vcellout___128967___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                                                >> 8U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128049___O) 
                                                                                >> 2U)) 
                                                                                | (vlSelf->insn_w 
                                                                                >> 0x1fU)))))))) 
                                                                             << 1U)) 
                                                                         | (vlSelf->function_entry 
                                                                            >> 0x1fU)))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x1cU)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O) 
                                                                   >> 3U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 0xfU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O) 
                                                    >> 3U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128966___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__parity) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128049___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x1eU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x1eU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x1bU)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O) 
                                                                   >> 2U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 0xeU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O) 
                                                    >> 2U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128965___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                                                >> 7U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128049___O)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x1dU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x1dU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x1aU)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O) 
                                                                   >> 1U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 0xdU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O) 
                                                    >> 1U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128964___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                                                >> 6U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128049___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x1cU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x1cU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x19U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 0xcU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128001___O))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128963___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                                                >> 5U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128048___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x1bU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x1bU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x18U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O) 
                                                                   >> 3U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 0xbU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O) 
                                                    >> 3U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128962___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                                                >> 4U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128048___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x1aU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x1aU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__parity) 
                                                                 >> 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O) 
                                                                   >> 2U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 0xaU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O) 
                                                    >> 2U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128961___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                                                >> 3U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128048___O)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x19U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x19U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x17U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O) 
                                                                   >> 1U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 9U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O) 
                                                    >> 1U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128960___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                                                >> 2U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128048___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x18U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x18U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x16U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 8U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128000___O))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128959___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                                                >> 1U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128047___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x17U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x17U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x15U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O) 
                                                                   >> 3U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__parity) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O) 
                                                    >> 3U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128958___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128047___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x16U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x16U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x14U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O) 
                                                                   >> 2U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 7U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O) 
                                                    >> 2U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128957___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__parity) 
                                                                          << 1U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128047___O)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x15U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x15U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x13U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O) 
                                                                   >> 1U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 6U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O) 
                                                    >> 1U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128956___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 0xfU)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128047___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x14U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x14U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x12U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 5U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127999___O))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128955___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 0xeU)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128046___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x13U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x13U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x11U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O) 
                                                                   >> 3U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 4U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O) 
                                                    >> 3U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128954___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 0xdU)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128046___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x12U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x12U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0x10U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O) 
                                                                   >> 2U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 3U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O) 
                                                    >> 2U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128953___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 0xcU)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128046___O)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x11U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x11U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & (IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__parity)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O) 
                                                                   >> 1U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 2U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O) 
                                                    >> 1U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128952___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 0xbU)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128046___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0x10U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0x10U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0xfU)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data 
                                                         >> 1U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127998___O))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128951___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 0xaU)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128045___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0xfU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0xfU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0xeU)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O) 
                                                                   >> 3U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e8.__PVT__data) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O) 
                                                    >> 3U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128950___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 9U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128045___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0xeU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0xeU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0xdU)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O) 
                                                                   >> 2U))))))) 
                                                  << 2U)) 
                                           | ((2U & (IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__parity)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O) 
                                                    >> 2U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128949___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 8U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128045___O)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0xdU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0xdU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0xcU)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O) 
                                                                   >> 1U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 0xfU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O) 
                                                    >> 1U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128948___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__parity) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128045___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0xcU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0xcU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0xbU)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 0xeU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127997___O))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128947___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 7U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128044___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0xbU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0xbU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 0xaU)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O) 
                                                                   >> 3U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 0xdU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O) 
                                                    >> 3U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128946___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 6U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128044___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 0xaU))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 0xaU))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 9U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O) 
                                                                   >> 2U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 0xcU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O) 
                                                    >> 2U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128945___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 5U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128044___O)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 9U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 9U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 8U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O) 
                                                                   >> 1U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 0xbU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O) 
                                                    >> 1U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128944___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 4U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128044___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 8U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 8U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__parity) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 0xaU)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127996___O))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128943___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 3U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128043___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 7U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 7U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 7U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O) 
                                                                   >> 3U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 9U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O) 
                                                    >> 3U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128942___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 2U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128043___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 6U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 6U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 6U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O) 
                                                                   >> 2U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 8U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O) 
                                                    >> 2U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128941___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data 
                                                                                >> 1U)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128043___O)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 5U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 5U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 5U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O) 
                                                                   >> 1U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__parity) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O) 
                                                    >> 1U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128940___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e2.__PVT__data) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128043___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 4U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 4U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 4U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 7U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127995___O))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128939___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e1.__PVT__parity) 
                                                                          << 1U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128042___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 3U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 3U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 3U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O) 
                                                                   >> 3U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 6U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O) 
                                                    >> 3U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128938___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e1.__PVT__data 
                                                                                >> 0xfU)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128042___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 2U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 2U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 2U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O) 
                                                                   >> 2U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 5U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O) 
                                                    >> 2U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128937___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e1.__PVT__data 
                                                                                >> 0xeU)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128042___O)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_w 
                                                                                >> 1U))))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (vlSelf->function_entry 
                                                                               >> 1U))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                                          >> 1U)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O) 
                                                                   >> 1U))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 4U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O) 
                                                    >> 1U))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128936___Q 
                = (1U & (0xccaa0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062506_) 
                                           << 3U) | 
                                          ((4U & ((0x3355f0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0xf0f55ccU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e1.__PVT__data 
                                                                                >> 0xdU)) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x33033303550f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062502_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062501_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128042___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & vlSelf->insn_w)))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & vlSelf->function_entry)))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                         >> 3U)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127994___O))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019805_) {
            vlSelf->done = (1U & (IData)((0xffffff70ffffffffULL 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054476_) 
                                               << 5U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054475_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___050360_)))))))));
        }
        if ((1U & (IData)((0xb000000000000000ULL >> 
                           (((IData)(vlSelf->wasmetal_core__DOT___053101_) 
                             << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___072279_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___053103_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___052917_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053248_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___053018_)))))))))) {
            vlSelf->mem_valid = (1U & ((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d)
                                        ? (IData)((0xcdcf0cc0cULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019415_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___019414_))))))))
                                        : (0xaa0eU 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                << 4U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___019415_))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019793_) {
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b127__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b71__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004561_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b103__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b95__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005599_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b111__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b119__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005129_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
            vlSelf->wasmetal_core__DOT__bulk_fill_value__05b87__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053955_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
        }
    }
}
