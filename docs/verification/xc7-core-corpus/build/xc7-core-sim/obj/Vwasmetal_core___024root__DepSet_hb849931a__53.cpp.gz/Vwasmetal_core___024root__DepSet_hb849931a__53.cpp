#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__3(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__3\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___052234_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h38fef573__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052220_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h95441b9a__0)))))))))));
    vlSelf->wasmetal_core__DOT___005232_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000648_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000647_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h95441b9a__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h981495cf__0)))))))));
    vlSelf->wasmetal_core__DOT___000658_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h95441b9a__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h981495cf__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000648_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000647_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b30__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052220_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h95441b9a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h38fef573__0))))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))) {
        vlSelf->wasmetal_core__DOT___000631_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4279d3a2__0))));
        vlSelf->wasmetal_core__DOT___000609_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0))));
        vlSelf->wasmetal_core__DOT___000587_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4d1ee432__0))));
        vlSelf->wasmetal_core__DOT___000560_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0))));
        vlSelf->wasmetal_core__DOT___000538_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hf6a1a834__0))));
        vlSelf->wasmetal_core__DOT___000516_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8a521099__0))));
        vlSelf->wasmetal_core__DOT___000494_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha29002c9__0))));
        vlSelf->wasmetal_core__DOT___000472_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5b213075__0))));
        vlSelf->wasmetal_core__DOT___000460_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h12d7401d__0))));
        vlSelf->wasmetal_core__DOT___000428_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4f514d50__0))));
        vlSelf->wasmetal_core__DOT___000412_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he64a7376__0))));
        vlSelf->wasmetal_core__DOT___001642_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h252dd1a8__0))));
        vlSelf->wasmetal_core__DOT___001620_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2dcfbe3b__0))));
        vlSelf->wasmetal_core__DOT___001608_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he176d11c__0))));
        vlSelf->wasmetal_core__DOT___001576_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he721caff__0))));
        vlSelf->wasmetal_core__DOT___001564_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hfc69f4da__0))));
        vlSelf->wasmetal_core__DOT___001532_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h63a71256__0))));
        vlSelf->wasmetal_core__DOT___001520_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h17123258__0))));
        vlSelf->wasmetal_core__DOT___001421_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h42734187__0))));
        vlSelf->wasmetal_core__DOT___001409_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd1ab5007__0))));
        vlSelf->wasmetal_core__DOT___001377_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0))));
        vlSelf->wasmetal_core__DOT___001365_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he0f0059b__0))));
        vlSelf->wasmetal_core__DOT___001483_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6fd66007__0))));
        vlSelf->wasmetal_core__DOT___001471_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hefb6870d__0))));
        vlSelf->wasmetal_core__DOT___001439_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0))));
        vlSelf->wasmetal_core__DOT___001433_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0))));
        vlSelf->wasmetal_core__DOT___001882_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h156b8e5c__0))));
        vlSelf->wasmetal_core__DOT___001870_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h261d1fb9__0))));
    } else {
        vlSelf->wasmetal_core__DOT___000631_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h346dffe3__0))));
        vlSelf->wasmetal_core__DOT___000609_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4641aed4__0))));
        vlSelf->wasmetal_core__DOT___000587_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb9d73245__0))));
        vlSelf->wasmetal_core__DOT___000560_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd4b6f7f5__0))));
        vlSelf->wasmetal_core__DOT___000538_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6f0fb759__0))));
        vlSelf->wasmetal_core__DOT___000516_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h64f45cce__0))));
        vlSelf->wasmetal_core__DOT___000494_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h0990f42c__0))));
        vlSelf->wasmetal_core__DOT___000472_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5680e757__0))));
        vlSelf->wasmetal_core__DOT___000460_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc8339843__0))));
        vlSelf->wasmetal_core__DOT___000428_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6fec380d__0))));
        vlSelf->wasmetal_core__DOT___000412_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4633c50c__0))));
        vlSelf->wasmetal_core__DOT___001642_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h42c0d879__0))));
        vlSelf->wasmetal_core__DOT___001620_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h464afc51__0))));
        vlSelf->wasmetal_core__DOT___001608_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h0e64e6bd__0))));
        vlSelf->wasmetal_core__DOT___001576_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h348ae581__0))));
        vlSelf->wasmetal_core__DOT___001564_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h32a20063__0))));
        vlSelf->wasmetal_core__DOT___001532_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h92680a0a__0))));
        vlSelf->wasmetal_core__DOT___001520_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc6a0da7a__0))));
        vlSelf->wasmetal_core__DOT___001421_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h77c9da1a__0))));
        vlSelf->wasmetal_core__DOT___001409_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h63e2f59d__0))));
        vlSelf->wasmetal_core__DOT___001377_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7b4dcb8a__0))));
        vlSelf->wasmetal_core__DOT___001365_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbc2ed277__0))));
        vlSelf->wasmetal_core__DOT___001483_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_haec160c4__0))));
        vlSelf->wasmetal_core__DOT___001471_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc089566f__0))));
        vlSelf->wasmetal_core__DOT___001439_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5875da01__0))));
        vlSelf->wasmetal_core__DOT___001433_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h283b87b9__0))));
        vlSelf->wasmetal_core__DOT___001882_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h86168fd0__0))));
        vlSelf->wasmetal_core__DOT___001870_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1495cfda__0))));
    }
    vlSelf->wasmetal_core__DOT___052233_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hf146791e__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052215_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4279d3a2__0)))))))))));
    vlSelf->wasmetal_core__DOT___005300_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000626_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000625_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4279d3a2__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h346dffe3__0)))))))));
    vlSelf->wasmetal_core__DOT___000636_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4279d3a2__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h346dffe3__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000626_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000625_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b29__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052215_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4279d3a2__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf146791e__0))))))));
    vlSelf->wasmetal_core__DOT___052232_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd0875e26__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052210_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0)))))))))));
    vlSelf->wasmetal_core__DOT___004892_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000604_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000603_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4641aed4__0)))))))));
    vlSelf->wasmetal_core__DOT___000614_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4641aed4__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000604_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000603_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b28__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052210_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd0875e26__0))))))));
    vlSelf->wasmetal_core__DOT___052567_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h1a1b2f4c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052564_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4d1ee432__0)))))))))));
    vlSelf->wasmetal_core__DOT___005028_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000582_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000581_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4d1ee432__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb9d73245__0)))))))));
    vlSelf->wasmetal_core__DOT___000592_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4d1ee432__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb9d73245__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000582_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000581_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b27__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052564_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4d1ee432__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1a1b2f4c__0))))))));
    vlSelf->wasmetal_core__DOT___052566_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hbb570836__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052512_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0)))))))))));
    vlSelf->wasmetal_core__DOT___004960_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000555_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000554_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd4b6f7f5__0)))))))));
    vlSelf->wasmetal_core__DOT___000565_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd4b6f7f5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000555_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000554_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b26__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052512_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hbb570836__0))))))));
    vlSelf->wasmetal_core__DOT___005368_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000533_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000532_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf6a1a834__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6f0fb759__0)))))))));
    vlSelf->wasmetal_core__DOT___000543_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf6a1a834__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6f0fb759__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000533_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000532_)))))));
    vlSelf->wasmetal_core__DOT___005096_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000511_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000510_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8a521099__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h64f45cce__0)))))))));
    vlSelf->wasmetal_core__DOT___000521_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8a521099__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h64f45cce__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000511_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000510_)))))));
    vlSelf->wasmetal_core__DOT___052527_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5d3f3876__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052517_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha29002c9__0)))))))))));
    vlSelf->wasmetal_core__DOT___005164_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000489_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000488_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha29002c9__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0990f42c__0)))))))));
    vlSelf->wasmetal_core__DOT___000499_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha29002c9__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0990f42c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000489_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000488_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b23__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052517_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha29002c9__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d3f3876__0))))))));
    vlSelf->wasmetal_core__DOT___052528_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h3c70beb3__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052522_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h5b213075__0)))))))))));
    vlSelf->wasmetal_core__DOT___003348_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000445_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000444_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5b213075__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5680e757__0)))))))));
    vlSelf->wasmetal_core__DOT___000477_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5b213075__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5680e757__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000445_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000444_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b22__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052522_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h5b213075__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h3c70beb3__0))))))));
    vlSelf->wasmetal_core__DOT___003416_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000455_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000454_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h12d7401d__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc8339843__0)))))))));
    vlSelf->wasmetal_core__DOT___000465_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h12d7401d__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc8339843__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000455_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000454_)))))));
    vlSelf->wasmetal_core__DOT___003270_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001869_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001868_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6a684ffb__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf7db9798__0)))))))));
    vlSelf->wasmetal_core__DOT___003269_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6a684ffb__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf7db9798__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001869_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001868_)))))));
    vlSelf->wasmetal_core__DOT___003936_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000407_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000406_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4f514d50__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6fec380d__0)))))))));
    vlSelf->wasmetal_core__DOT___000433_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4f514d50__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6fec380d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000407_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000406_)))))));
    vlSelf->wasmetal_core__DOT___003190_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001845_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001844_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h173fc958__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hea8c2790__0)))))))));
    vlSelf->wasmetal_core__DOT___003189_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h173fc958__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hea8c2790__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001845_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001844_)))))));
    vlSelf->wasmetal_core__DOT___052555_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5d5da343__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052550_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he64a7376__0)))))))))));
    vlSelf->wasmetal_core__DOT___003862_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000397_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000396_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he64a7376__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4633c50c__0)))))))));
    vlSelf->wasmetal_core__DOT___000420_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he64a7376__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4633c50c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000397_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000396_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b19__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052550_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he64a7376__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d5da343__0))))))));
    vlSelf->wasmetal_core__DOT___004078_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001637_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001636_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h252dd1a8__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42c0d879__0)))))))));
    vlSelf->wasmetal_core__DOT___001647_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h252dd1a8__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h42c0d879__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001637_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001636_)))))));
    vlSelf->wasmetal_core__DOT___004300_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001603_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001602_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2dcfbe3b__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h464afc51__0)))))))));
    vlSelf->wasmetal_core__DOT___001625_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h2dcfbe3b__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h464afc51__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001603_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001602_)))))));
    vlSelf->wasmetal_core__DOT___004004_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001593_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001592_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he176d11c__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0e64e6bd__0)))))))));
    vlSelf->wasmetal_core__DOT___001613_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he176d11c__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0e64e6bd__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001593_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001592_)))))));
    vlSelf->wasmetal_core__DOT___052400_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h121dc976__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052385_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he721caff__0)))))))))));
    vlSelf->wasmetal_core__DOT___003706_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001559_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001558_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he721caff__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h348ae581__0)))))))));
    vlSelf->wasmetal_core__DOT___001581_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he721caff__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h348ae581__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001559_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001558_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b15__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052385_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he721caff__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h121dc976__0))))))));
    vlSelf->wasmetal_core__DOT___052401_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hcb57359d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052393_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hfc69f4da__0)))))))))));
    vlSelf->wasmetal_core__DOT___004670_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001549_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001548_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfc69f4da__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h32a20063__0)))))))));
    vlSelf->wasmetal_core__DOT___001569_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfc69f4da__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h32a20063__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001549_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001548_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b14__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052393_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc69f4da__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcb57359d__0))))))));
    vlSelf->wasmetal_core__DOT___052257_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_habe5487e__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052251_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h63a71256__0)))))))))));
    vlSelf->wasmetal_core__DOT___004226_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001515_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001514_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h63a71256__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h92680a0a__0)))))))));
    vlSelf->wasmetal_core__DOT___001537_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h63a71256__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h92680a0a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001515_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001514_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b13__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052251_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h63a71256__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_habe5487e__0))))))));
    vlSelf->wasmetal_core__DOT___052255_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h56e67fc1__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052201_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h17123258__0)))))))))));
    vlSelf->wasmetal_core__DOT___004152_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001505_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001504_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h17123258__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc6a0da7a__0)))))))));
    vlSelf->wasmetal_core__DOT___001525_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h17123258__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc6a0da7a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001505_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001504_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b12__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052201_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h17123258__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h56e67fc1__0))))))));
    vlSelf->wasmetal_core__DOT___052477_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd416e14c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052472_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h42734187__0)))))))))));
    vlSelf->wasmetal_core__DOT___003558_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001404_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001403_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42734187__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h77c9da1a__0)))))))));
    vlSelf->wasmetal_core__DOT___001426_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h42734187__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h77c9da1a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001404_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001403_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b11__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052472_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h42734187__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd416e14c__0))))))));
    vlSelf->wasmetal_core__DOT___052476_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h382fd4d9__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052467_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd1ab5007__0)))))))))));
    vlSelf->wasmetal_core__DOT___003484_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001394_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001393_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd1ab5007__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h63e2f59d__0)))))))));
    vlSelf->wasmetal_core__DOT___001414_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd1ab5007__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h63e2f59d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001394_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001393_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b10__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052467_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd1ab5007__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h382fd4d9__0))))))));
    vlSelf->wasmetal_core__DOT___052398_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h63bcab38__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052375_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0)))))))))));
    vlSelf->wasmetal_core__DOT___003632_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001350_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001349_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7b4dcb8a__0)))))))));
    vlSelf->wasmetal_core__DOT___001382_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7b4dcb8a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001350_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001349_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b9__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052375_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h63bcab38__0))))))));
    vlSelf->wasmetal_core__DOT___052399_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h3b706e40__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052380_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he0f0059b__0)))))))))));
    vlSelf->wasmetal_core__DOT___003780_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001360_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001359_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he0f0059b__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbc2ed277__0)))))))));
    vlSelf->wasmetal_core__DOT___001370_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he0f0059b__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbc2ed277__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001360_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001359_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b8__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052380_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he0f0059b__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h3b706e40__0))))))));
    vlSelf->wasmetal_core__DOT___052557_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h86663798__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052545_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6fd66007__0)))))))))));
    vlSelf->wasmetal_core__DOT___004596_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001466_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001465_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6fd66007__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_haec160c4__0)))))))));
    vlSelf->wasmetal_core__DOT___001488_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6fd66007__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_haec160c4__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001466_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001465_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b7__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052545_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6fd66007__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h86663798__0))))))));
    vlSelf->wasmetal_core__DOT___052556_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc4ffb8dc__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052533_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hefb6870d__0)))))))))));
    vlSelf->wasmetal_core__DOT___004448_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001456_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001455_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefb6870d__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc089566f__0)))))))));
    vlSelf->wasmetal_core__DOT___001476_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hefb6870d__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc089566f__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001456_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001455_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b6__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052533_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hefb6870d__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc4ffb8dc__0))))))));
    vlSelf->wasmetal_core__DOT___052474_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc8d1ef5e__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052457_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0)))))))))));
    vlSelf->wasmetal_core__DOT___004374_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001191_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001190_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5875da01__0)))))))));
    vlSelf->wasmetal_core__DOT___001444_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5875da01__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001191_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001190_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b5__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052457_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc8d1ef5e__0))))))));
    vlSelf->wasmetal_core__DOT___052475_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h55f072d8__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052462_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0)))))))))));
    vlSelf->wasmetal_core__DOT___004522_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001201_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001200_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h283b87b9__0)))))))));
    vlSelf->wasmetal_core__DOT___001438_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h283b87b9__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001201_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001200_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b4__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052462_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h55f072d8__0))))))));
    vlSelf->wasmetal_core__DOT___052253_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h60503c86__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052241_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h156b8e5c__0)))))))))));
    vlSelf->wasmetal_core__DOT___004744_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000193_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000192_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h156b8e5c__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h86168fd0__0)))))))));
    vlSelf->wasmetal_core__DOT___001887_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h156b8e5c__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h86168fd0__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000193_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000192_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b3__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052241_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h156b8e5c__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h60503c86__0))))))));
    vlSelf->wasmetal_core__DOT___052254_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc4c8e202__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052246_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h261d1fb9__0)))))))))));
    vlSelf->wasmetal_core__DOT___004818_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000387_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000386_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h261d1fb9__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1495cfda__0)))))))));
    vlSelf->wasmetal_core__DOT___001875_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h261d1fb9__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1495cfda__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000387_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000386_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b2__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052246_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h261d1fb9__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc4c8e202__0))))))));
    vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029149_));
    vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031068_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031035_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___071405_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h48de7988__0))));
    vlSelf->wasmetal_core__DOT___071468_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h48de7988__0))));
    vlSelf->wasmetal_core__DOT___071404_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_heb46fbcb__0))));
    vlSelf->wasmetal_core__DOT___071467_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_heb46fbcb__0))));
    vlSelf->__VdfgTmp_h6ddd7671__0 = (((IData)(vlSelf->wasmetal_core__DOT___070950_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___070951_));
    vlSelf->wasmetal_core__DOT___071391_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h73075b94__0))));
    vlSelf->wasmetal_core__DOT___071454_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h73075b94__0))));
    vlSelf->wasmetal_core__DOT___071386_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h17228d9d__0))));
    vlSelf->wasmetal_core__DOT___071449_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h17228d9d__0))));
    vlSelf->wasmetal_core__DOT___071387_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7ee7d44c__0))));
    vlSelf->wasmetal_core__DOT___071450_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7ee7d44c__0))));
    vlSelf->wasmetal_core__DOT___071394_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb3e6303e__0))));
    vlSelf->wasmetal_core__DOT___071457_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb3e6303e__0))));
    vlSelf->wasmetal_core__DOT___071389_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd266b697__0))));
    vlSelf->wasmetal_core__DOT___071452_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd266b697__0))));
    vlSelf->wasmetal_core__DOT___071390_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h123a295b__0))));
    vlSelf->wasmetal_core__DOT___071453_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h123a295b__0))));
    vlSelf->wasmetal_core__DOT___071403_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5dc57786__0))));
    vlSelf->wasmetal_core__DOT___071466_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5dc57786__0))));
    vlSelf->wasmetal_core__DOT___071398_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h86abd4f4__0))));
    vlSelf->wasmetal_core__DOT___071461_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h86abd4f4__0))));
    vlSelf->wasmetal_core__DOT___071399_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h966a07d3__0))));
    vlSelf->wasmetal_core__DOT___071462_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h966a07d3__0))));
    vlSelf->wasmetal_core__DOT___071401_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8a64daef__0))));
    vlSelf->wasmetal_core__DOT___071464_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8a64daef__0))));
    vlSelf->wasmetal_core__DOT___071402_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h966312d4__0))));
    vlSelf->wasmetal_core__DOT___071465_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h966312d4__0))));
    vlSelf->wasmetal_core__DOT___071385_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha300b05f__0))));
    vlSelf->wasmetal_core__DOT___071448_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha300b05f__0))));
    vlSelf->wasmetal_core__DOT___071388_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha431143d__0))));
    vlSelf->wasmetal_core__DOT___071451_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha431143d__0))));
    vlSelf->wasmetal_core__DOT___071383_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2535fff2__0))));
    vlSelf->wasmetal_core__DOT___071446_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2535fff2__0))));
    vlSelf->wasmetal_core__DOT___071384_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hed7c6d19__0))));
    vlSelf->wasmetal_core__DOT___071447_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hed7c6d19__0))));
    vlSelf->wasmetal_core__DOT___071397_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8a6dc29d__0))));
    vlSelf->wasmetal_core__DOT___071460_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8a6dc29d__0))));
    vlSelf->wasmetal_core__DOT___071392_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he372c179__0))));
    vlSelf->wasmetal_core__DOT___071455_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he372c179__0))));
    vlSelf->wasmetal_core__DOT___071393_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8fd79857__0))));
    vlSelf->wasmetal_core__DOT___071456_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8fd79857__0))));
    vlSelf->wasmetal_core__DOT___071400_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbceb8814__0))));
    vlSelf->wasmetal_core__DOT___071463_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbceb8814__0))));
    vlSelf->wasmetal_core__DOT___071395_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1bbfb27a__0))));
    vlSelf->wasmetal_core__DOT___071458_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1bbfb27a__0))));
    vlSelf->wasmetal_core__DOT___071396_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8d7f942c__0))));
    vlSelf->wasmetal_core__DOT___071459_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8d7f942c__0))));
    vlSelf->wasmetal_core__DOT___071350_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8649aac__0))));
    vlSelf->wasmetal_core__DOT___071413_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8649aac__0))));
    vlSelf->wasmetal_core__DOT___071351_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd389bfd2__0))));
    vlSelf->wasmetal_core__DOT___071414_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd389bfd2__0))));
    vlSelf->wasmetal_core__DOT___071362_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1915a5ff__0))));
    vlSelf->wasmetal_core__DOT___071425_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1915a5ff__0))));
    vlSelf->wasmetal_core__DOT___071363_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h70b63d5e__0))));
    vlSelf->wasmetal_core__DOT___071426_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h70b63d5e__0))));
    vlSelf->wasmetal_core__DOT___071374_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1473a3fc__0))));
    vlSelf->wasmetal_core__DOT___071437_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1473a3fc__0))));
    vlSelf->wasmetal_core__DOT___071375_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbbedaddf__0))));
    vlSelf->wasmetal_core__DOT___071438_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbbedaddf__0))));
    vlSelf->wasmetal_core__DOT___071382_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3006d0f0__0))));
    vlSelf->wasmetal_core__DOT___071445_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3006d0f0__0))));
    vlSelf->wasmetal_core__DOT___071343_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5dfde09f__0))));
    vlSelf->wasmetal_core__DOT___071406_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5dfde09f__0))));
    vlSelf->wasmetal_core__DOT___071349_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7e0b807__0))));
    vlSelf->wasmetal_core__DOT___071412_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7e0b807__0))));
    vlSelf->wasmetal_core__DOT___071352_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he127cdd2__0))));
    vlSelf->wasmetal_core__DOT___071415_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he127cdd2__0))));
    vlSelf->wasmetal_core__DOT___071347_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd8bdfcc6__0))));
    vlSelf->wasmetal_core__DOT___071410_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd8bdfcc6__0))));
    vlSelf->wasmetal_core__DOT___071348_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0bf68f44__0))));
    vlSelf->wasmetal_core__DOT___071411_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0bf68f44__0))));
    vlSelf->wasmetal_core__DOT___071361_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h83bd92c8__0))));
    vlSelf->wasmetal_core__DOT___071424_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h83bd92c8__0))));
    vlSelf->wasmetal_core__DOT___071364_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf6358f59__0))));
    vlSelf->wasmetal_core__DOT___071427_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf6358f59__0))));
    vlSelf->wasmetal_core__DOT___071359_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h65437cee__0))));
    vlSelf->wasmetal_core__DOT___071422_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h65437cee__0))));
    vlSelf->wasmetal_core__DOT___071360_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4c7f02d9__0))));
    vlSelf->wasmetal_core__DOT___071423_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4c7f02d9__0))));
    vlSelf->wasmetal_core__DOT___071373_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h370a9404__0))));
    vlSelf->wasmetal_core__DOT___071436_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h370a9404__0))));
    vlSelf->wasmetal_core__DOT___071376_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h098d62f8__0))));
    vlSelf->wasmetal_core__DOT___071439_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h098d62f8__0))));
    vlSelf->wasmetal_core__DOT___071371_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdf9c0a20__0))));
    vlSelf->wasmetal_core__DOT___071434_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdf9c0a20__0))));
    vlSelf->wasmetal_core__DOT___071372_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he08c96ba__0))));
    vlSelf->wasmetal_core__DOT___071435_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he08c96ba__0))));
    vlSelf->wasmetal_core__DOT___071380_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1d04e55__0))));
    vlSelf->wasmetal_core__DOT___071443_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1d04e55__0))));
    vlSelf->wasmetal_core__DOT___071381_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha31457b4__0))));
    vlSelf->wasmetal_core__DOT___071444_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha31457b4__0))));
    vlSelf->wasmetal_core__DOT___071346_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbba81ae3__0))));
    vlSelf->wasmetal_core__DOT___071409_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbba81ae3__0))));
    vlSelf->wasmetal_core__DOT___071355_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h670f6b42__0))));
    vlSelf->wasmetal_core__DOT___071418_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h670f6b42__0))));
    vlSelf->wasmetal_core__DOT___071358_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfb8717f5__0))));
    vlSelf->wasmetal_core__DOT___071421_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfb8717f5__0))));
    vlSelf->wasmetal_core__DOT___071353_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0201c3e9__0))));
    vlSelf->wasmetal_core__DOT___071416_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0201c3e9__0))));
    vlSelf->wasmetal_core__DOT___071354_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbc582c17__0))));
    vlSelf->wasmetal_core__DOT___071417_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbc582c17__0))));
    vlSelf->wasmetal_core__DOT___071367_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5b1f350b__0))));
    vlSelf->wasmetal_core__DOT___071430_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5b1f350b__0))));
    vlSelf->wasmetal_core__DOT___071370_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h852d6a23__0))));
    vlSelf->wasmetal_core__DOT___071433_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h852d6a23__0))));
    vlSelf->wasmetal_core__DOT___071365_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9685a33e__0))));
    vlSelf->wasmetal_core__DOT___071428_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9685a33e__0))));
    vlSelf->wasmetal_core__DOT___071366_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hee7ba675__0))));
    vlSelf->wasmetal_core__DOT___071429_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hee7ba675__0))));
    vlSelf->wasmetal_core__DOT___071379_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0ba16cdb__0))));
    vlSelf->wasmetal_core__DOT___071442_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0ba16cdb__0))));
    vlSelf->wasmetal_core__DOT___071377_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0919c673__0))));
    vlSelf->wasmetal_core__DOT___071440_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0919c673__0))));
    vlSelf->wasmetal_core__DOT___071378_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc7238523__0))));
    vlSelf->wasmetal_core__DOT___071441_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc7238523__0))));
    vlSelf->wasmetal_core__DOT___071344_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h31b47573__0))));
    vlSelf->wasmetal_core__DOT___071407_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h31b47573__0))));
    vlSelf->wasmetal_core__DOT___071345_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedf8c8b5__0))));
    vlSelf->wasmetal_core__DOT___071408_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedf8c8b5__0))));
    vlSelf->wasmetal_core__DOT___071357_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h978cb234__0))));
    vlSelf->wasmetal_core__DOT___071420_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h978cb234__0))));
    vlSelf->wasmetal_core__DOT___071356_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4dc6a706__0))));
    vlSelf->wasmetal_core__DOT___071419_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4dc6a706__0))));
    vlSelf->wasmetal_core__DOT___071368_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2c74d244__0))));
    vlSelf->wasmetal_core__DOT___071431_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2c74d244__0))));
    vlSelf->wasmetal_core__DOT___071369_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5aac232__0))));
    vlSelf->wasmetal_core__DOT___071432_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5aac232__0))));
    vlSelf->__VdfgTmp_haaf717df__0 = (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054245_));
    vlSelf->__VdfgTmp_he7fbee1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054239_));
    vlSelf->__VdfgTmp_hc7c7ad9a__0 = (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054233_));
    vlSelf->__VdfgTmp_h351f56c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054227_));
    vlSelf->__VdfgTmp_hed1a6099__0 = (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054221_));
    vlSelf->__VdfgTmp_h79eb8028__0 = (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054215_));
    vlSelf->__VdfgTmp_h179c0c32__0 = (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054209_));
    vlSelf->__VdfgTmp_h8df568d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054203_));
    vlSelf->__VdfgTmp_h8e211f59__0 = (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054197_));
    vlSelf->__VdfgTmp_h1c632a11__0 = (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054191_));
    vlSelf->__VdfgTmp_h561bfeb8__0 = (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054182_));
    vlSelf->__VdfgTmp_he3a468d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054170_));
    vlSelf->__VdfgTmp_h6e6c7922__0 = (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054158_));
    vlSelf->__VdfgTmp_h42ef1750__0 = (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054127_));
    vlSelf->__VdfgTmp_hd5eac1f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054115_));
    vlSelf->__VdfgTmp_hfa74de2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054103_));
    vlSelf->wasmetal_core__DOT___071265_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054095_))));
    vlSelf->__VdfgTmp_hcc1441d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054091_));
    vlSelf->__VdfgTmp_h33545cb0__0 = (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054079_));
    vlSelf->__VdfgTmp_hdb28d3ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054067_));
    vlSelf->__VdfgTmp_h6661b389__0 = (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054055_));
    vlSelf->__VdfgTmp_h66f1f037__0 = (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054043_));
    vlSelf->wasmetal_core__DOT___064462_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___069232_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1eU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069158_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1dU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069139_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1cU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069090_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b60__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1bU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069040_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1aU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068968_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x19U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068942_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x18U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068898_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x17U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068851_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x16U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068796_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x15U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068752_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x14U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068703_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x13U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068655_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x12U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068605_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x11U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___064897_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___064730_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071263_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054103_))))));
    vlSelf->wasmetal_core__DOT___065411_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071272_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054127_))))));
    vlSelf->wasmetal_core__DOT___065301_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065187_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065058_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071267_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054115_))))));
    vlSelf->wasmetal_core__DOT___065896_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128052___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071277_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054158_))))));
    vlSelf->wasmetal_core__DOT___065800_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128052___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065698_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128052___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065602_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128052___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066276_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066123_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071282_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054170_))))));
    vlSelf->wasmetal_core__DOT___066081_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065936_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071292_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054191_))))));
    vlSelf->wasmetal_core__DOT___066602_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066525_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066399_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071287_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054182_))))));
    vlSelf->wasmetal_core__DOT___066313_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066893_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071297_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054197_))))));
    vlSelf->wasmetal_core__DOT___066852_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066769_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066647_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067194_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067153_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071302_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054203_))))));
    vlSelf->wasmetal_core__DOT___067075_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066970_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071312_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054215_))))));
    vlSelf->wasmetal_core__DOT___067454_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067342_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071307_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054209_))))));
    vlSelf->wasmetal_core__DOT___067312_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067724_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___071317_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054221_))))));
    vlSelf->wasmetal_core__DOT___067657_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & vlSelf->insn_imm[1U]) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___067606_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054182_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___071322_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054227_))))));
    vlSelf->wasmetal_core__DOT___071332_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054239_))))));
    vlSelf->wasmetal_core__DOT___071327_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054233_))))));
    vlSelf->wasmetal_core__DOT___071337_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054245_))))));
    vlSelf->__VdfgTmp_hf8819515__0 = (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054478_));
    vlSelf->wasmetal_core__DOT___054479_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054478_))));
    vlSelf->__VdfgTmp_heecb7e70__0 = (((IData)(vlSelf->wasmetal_core__DOT___004793_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b66__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001973_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001972_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004791_))));
    vlSelf->__VdfgTmp_h6b4c794b__0 = (((IData)(vlSelf->wasmetal_core__DOT___004935_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h9340bbb8__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004933_))));
    vlSelf->wasmetal_core__DOT___062477_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b122__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b122__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x19U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b122__05d)))))));
    vlSelf->wasmetal_core__DOT___052312_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h563719e8__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b98__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053153_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hacde19aa__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h563719e8__0))))))));
    vlSelf->__VdfgTmp_hdf4f28bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___004811_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hbc270d96__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004809_))));
    vlSelf->__VdfgTmp_h45f8df98__0 = (((IData)(vlSelf->wasmetal_core__DOT___004953_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hacecf0f9__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004951_))));
    vlSelf->wasmetal_core__DOT___069887_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b90__05d))));
    vlSelf->wasmetal_core__DOT___062397_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b90__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b90__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x19U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b90__05d)))))));
    vlSelf->__VdfgTmp_h2cf790ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___003459_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h2d07d754__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003457_))));
    vlSelf->wasmetal_core__DOT___062354_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b74__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b74__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 9U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b74__05d)))))));
    vlSelf->wasmetal_core__DOT___069534_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069530_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069529_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b74__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 8U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b74__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->wasmetal_core__DOT___069533_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 7U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xaU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b74__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT__value_aux__05b106__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053182_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h18ef2d35__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd9174715__0))))))));
    vlSelf->__VdfgTmp_h39365f5c__0 = (((IData)(vlSelf->wasmetal_core__DOT___003477_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd9daf5f7__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003475_))));
    vlSelf->__VdfgTmp_hd9d86825__0 = (((IData)(vlSelf->wasmetal_core__DOT___004719_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b67__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002008_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002007_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004717_))));
    vlSelf->__VdfgTmp_hfb5e3b7e__0 = (((IData)(vlSelf->wasmetal_core__DOT___004497_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h57451afb__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004495_))));
    vlSelf->wasmetal_core__DOT___062335_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b68__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b68__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 3U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b68__05d)))))));
    vlSelf->wasmetal_core__DOT___052314_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h70f8ca0f__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b123__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052279_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0589a813__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h70f8ca0f__0))))))));
    vlSelf->__VdfgTmp_h3d9b9896__0 = (((IData)(vlSelf->wasmetal_core__DOT___005003_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b123__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002873_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002872_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005001_))));
    vlSelf->__VdfgTmp_h1d47507a__0 = (((IData)(vlSelf->wasmetal_core__DOT___004349_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hed1d041c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004347_))));
    vlSelf->wasmetal_core__DOT___062338_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b69__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b69__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 4U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b69__05d)))))));
    vlSelf->__VdfgTmp_h79077a59__0 = (((IData)(vlSelf->wasmetal_core__DOT___004867_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h4e57fd92__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004865_))));
    vlSelf->wasmetal_core__DOT___062483_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b124__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b124__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x1bU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b124__05d)))))));
    vlSelf->__VdfgTmp_h13f17749__0 = (((IData)(vlSelf->wasmetal_core__DOT___005275_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h6f7c691c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005273_))));
    vlSelf->wasmetal_core__DOT___062486_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b125__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b125__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b125__05d)))))));
    vlSelf->__VdfgTmp_h8b941ffe__0 = (((IData)(vlSelf->wasmetal_core__DOT___005207_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hbeaa94ef__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005205_))));
    vlSelf->wasmetal_core__DOT___062489_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b126__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b126__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b126__05d)))))));
    vlSelf->__VdfgTmp_h9b6447c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___004423_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h06d51d42__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004421_))));
    vlSelf->wasmetal_core__DOT___069436_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b70__05d))));
    vlSelf->wasmetal_core__DOT___062343_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b70__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b70__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 5U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b70__05d)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b99__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053157_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51a38bc3__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h6e2b8153__0))))))));
    vlSelf->__VdfgTmp_h887e5924__0 = (((IData)(vlSelf->wasmetal_core__DOT___004737_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h04a005a2__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004735_))));
    vlSelf->wasmetal_core__DOT___052325_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9014fa0f__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b100__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053169_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hb29d3d73__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9014fa0f__0))))))));
    vlSelf->__VdfgTmp_hf8739cbc__0 = (((IData)(vlSelf->wasmetal_core__DOT___004515_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h2b893d79__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004513_))));
    vlSelf->wasmetal_core__DOT__value_aux__05b101__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053167_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he7b219d6__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h11abcf6d__0))))))));
    vlSelf->__VdfgTmp_h220272bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___004367_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h61430f62__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004365_))));
    vlSelf->wasmetal_core__DOT___052364_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e847741__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b102__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053173_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h2c3dfb0e__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9e847741__0))))))));
    vlSelf->__VdfgTmp_h193e1c6c__0 = (((IData)(vlSelf->wasmetal_core__DOT___004441_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf6cb6b1e__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004439_))));
    vlSelf->__VdfgTmp_hfaaa855f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005021_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b91__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002863_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002862_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005019_))));
    vlSelf->__VdfgTmp_h331e01c9__0 = (((IData)(vlSelf->wasmetal_core__DOT___004885_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h2876322d__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004883_))));
    vlSelf->wasmetal_core__DOT___069928_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b92__05d))));
    vlSelf->wasmetal_core__DOT___062402_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b92__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b92__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1bU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b92__05d)))))));
    vlSelf->__VdfgTmp_h62281c26__0 = (((IData)(vlSelf->wasmetal_core__DOT___005293_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h27483593__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005291_))));
    vlSelf->wasmetal_core__DOT___069949_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b93__05d))));
    vlSelf->wasmetal_core__DOT___062405_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b93__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b93__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b93__05d)))))));
    vlSelf->wasmetal_core__DOT___051971_ = (1U & (IData)(
                                                         (0x8888f00000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051966_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004883_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005607_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1aa0b795__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hbd6eb77c__0)))))))))));
    vlSelf->__VdfgTmp_h7482f819__0 = (((IData)(vlSelf->wasmetal_core__DOT___003533_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h6823128b__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003531_))));
    vlSelf->wasmetal_core__DOT___062357_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b75__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b75__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0xaU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b75__05d)))))));
    vlSelf->__VdfgTmp_h22e3dba7__0 = (((IData)(vlSelf->wasmetal_core__DOT___005225_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hc644e6af__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005223_))));
    vlSelf->wasmetal_core__DOT___062407_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b94__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b94__05d)))))));
    vlSelf->wasmetal_core__DOT___069968_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069964_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069963_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b94__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 0x1cU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->wasmetal_core__DOT___069967_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x1bU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1eU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->__VdfgTmp_hf7e0ef4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___004127_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h7e6d032b__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004125_))));
    vlSelf->wasmetal_core__DOT___062359_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b76__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b76__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0xbU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b76__05d)))))));
    vlSelf->wasmetal_core__DOT___069583_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069578_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069577_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b76__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 0xaU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b76__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->__VdfgTmp_h31491600__0 = (((IData)(vlSelf->wasmetal_core__DOT___004201_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h04cce861__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004199_))));
    vlSelf->wasmetal_core__DOT___069603_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069599_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069598_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b77__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 0xbU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b77__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->wasmetal_core__DOT___069602_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 8U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0xaU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xdU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b77__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT__value_aux__05b107__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062440_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hd380d548__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_he04a0e99__0))))))));
    vlSelf->__VdfgTmp_h6d082533__0 = (((IData)(vlSelf->wasmetal_core__DOT___003551_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h8b2f01bd__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003549_))));
    vlSelf->__VdfgTmp_h19aa2548__0 = (((IData)(vlSelf->wasmetal_core__DOT___004645_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h9efd96c7__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004643_))));
    vlSelf->wasmetal_core__DOT___069626_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b78__05d))));
    vlSelf->wasmetal_core__DOT___062364_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b78__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b78__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0xdU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b78__05d)))))));
    vlSelf->__VdfgTmp_hbea96df5__0 = (((IData)(vlSelf->wasmetal_core__DOT___004145_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h95c9c2c5__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004143_))));
    vlSelf->wasmetal_core__DOT___062445_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b108__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b108__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xbU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b108__05d)))))));
    vlSelf->__VdfgTmp_h01f51344__0 = (((IData)(vlSelf->wasmetal_core__DOT___004219_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h7c824381__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004217_))));
    vlSelf->wasmetal_core__DOT___062447_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b109__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b109__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xcU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b109__05d)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b110__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053205_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he9f02b45__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h8b084513__0))))))));
    vlSelf->__VdfgTmp_h7ca24d8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___004663_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hbd2119cc__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004661_))));
    vlSelf->__VdfgTmp_h6332189a__0 = (((IData)(vlSelf->wasmetal_core__DOT___004053_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h187cbe57__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004051_))));
    vlSelf->wasmetal_core__DOT___069713_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0xfU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x12U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b82__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069710_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b82__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b82__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x12U))))))))));
    vlSelf->__VdfgTmp_hb807ebfb__0 = (((IData)(vlSelf->wasmetal_core__DOT___004071_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h2098039d__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004069_))));
    vlSelf->wasmetal_core__DOT___062458_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b114__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b114__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x11U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b114__05d)))))));
    vlSelf->__VdfgTmp_h5bb31d88__0 = (((IData)(vlSelf->wasmetal_core__DOT___003243_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h9a831d1c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003241_))));
    vlSelf->wasmetal_core__DOT___062328_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b65__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b65__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & vlSelf->mem_rdata[2U]) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b65__05d)))))));
    vlSelf->wasmetal_core__DOT___052313_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8783294b__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b121__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053244_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h04b492c5__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h8783294b__0))))))));
    vlSelf->__VdfgTmp_h630336df__0 = (((IData)(vlSelf->wasmetal_core__DOT___005343_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h22773bc1__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005341_))));
    vlSelf->wasmetal_core__DOT__value_aux__05b97__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053151_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_ha36d230f__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha0b12c43__0))))))));
    vlSelf->__VdfgTmp_h0a17a2b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___003261_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hc39d0419__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003259_))));
    vlSelf->__VdfgTmp_h2b63e99d__0 = (((IData)(vlSelf->wasmetal_core__DOT___003607_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b73__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002402_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002401_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003605_))));
    vlSelf->wasmetal_core__DOT___051970_ = (1U & (IData)(
                                                         (0x8888f00000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051961_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004951_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005087_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h360aedc6__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8a29f22b__0)))))))))));
    vlSelf->__VdfgTmp_hec648199__0 = (((IData)(vlSelf->wasmetal_core__DOT___005361_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b89__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002699_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002698_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005359_))));
    vlSelf->wasmetal_core__DOT___052365_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hae654b01__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b105__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052342_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h14a07dbf__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hae654b01__0))))))));
    vlSelf->__VdfgTmp_h94e7c39f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003625_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b105__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002412_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002411_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003623_))));
    vlSelf->__VdfgTmp_ha2c9478b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003911_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h0b18d540__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003909_))));
    vlSelf->wasmetal_core__DOT___062462_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b116__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b116__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x13U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b116__05d)))))));
    vlSelf->__VdfgTmp_h1bb342d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___003391_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h75fb7e4c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003389_))));
    vlSelf->wasmetal_core__DOT___062465_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b117__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b117__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x14U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b117__05d)))))));
    vlSelf->__VdfgTmp_h90194312__0 = (((IData)(vlSelf->wasmetal_core__DOT___003323_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf100045e__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003321_))));
    vlSelf->wasmetal_core__DOT___062467_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b118__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b118__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x15U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b118__05d)))))));
    vlSelf->wasmetal_core__DOT___052054_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdcdc0b33__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b83__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052071_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h587b33f1__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hdcdc0b33__0))))))));
    vlSelf->__VdfgTmp_hd87a9123__0 = (((IData)(vlSelf->wasmetal_core__DOT___003837_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b83__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001207_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001206_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003835_))));
    vlSelf->__VdfgTmp_hed09e4ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___003855_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h00d09e7a__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003853_))));
    vlSelf->wasmetal_core__DOT___062460_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b115__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b115__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x12U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b115__05d)))))));
    vlSelf->__VdfgTmp_h98759836__0 = (((IData)(vlSelf->wasmetal_core__DOT___003929_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h0b6168e4__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003927_))));
    vlSelf->wasmetal_core__DOT___069757_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xfU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x11U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x14U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b84__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069754_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b84__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b84__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x14U))))))))));
    vlSelf->__VdfgTmp_he8c28620__0 = (((IData)(vlSelf->wasmetal_core__DOT___003409_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h4c3dd507__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003407_))));
    vlSelf->wasmetal_core__DOT___062385_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b85__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x14U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b85__05d)))))));
    vlSelf->wasmetal_core__DOT___069778_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x10U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x12U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x15U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069775_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b85__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x15U))))))))));
    vlSelf->__VdfgTmp_h2b07b055__0 = (((IData)(vlSelf->wasmetal_core__DOT___003341_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h8b19f5ab__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003339_))));
    vlSelf->wasmetal_core__DOT___069800_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x11U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x13U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x16U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b86__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069797_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b86__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b86__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x16U))))))))));
    vlSelf->__VdfgTmp_h29035176__0 = (((IData)(vlSelf->wasmetal_core__DOT___004275_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h96657cd6__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004273_))));
    vlSelf->wasmetal_core__DOT___062372_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b81__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b81__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x10U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b81__05d)))))));
    vlSelf->wasmetal_core__DOT___069696_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069691_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069690_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b81__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 0xfU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b81__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->__VdfgTmp_hf4fd0700__0 = (((IData)(vlSelf->wasmetal_core__DOT___004293_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h5f1be76b__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004291_))));
    vlSelf->wasmetal_core__DOT___062456_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b113__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b113__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x10U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b113__05d)))))));
    vlSelf->__VdfgTmp_h7e49e6e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___003163_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h3e0c1557__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003161_))));
    vlSelf->wasmetal_core__DOT___062325_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b64__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b64__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b64__05d)))))));
    vlSelf->__VdfgTmp_he61be2d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005071_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hbe2bd06c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005069_))));
    vlSelf->wasmetal_core__DOT___062472_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b120__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b120__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x17U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b120__05d)))))));
    vlSelf->__VdfgTmp_ha1faee4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003181_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hcd3797e9__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003179_))));
    vlSelf->wasmetal_core__DOT___070005_ = (1U & (IData)(
                                                         (0x45cf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b96__05d)))))))));
    vlSelf->wasmetal_core__DOT___062414_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b96__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b96__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b96__05d)))))));
    vlSelf->__VdfgTmp_h88d138aa__0 = (((IData)(vlSelf->wasmetal_core__DOT___003755_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hb156040c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003753_))));
    vlSelf->wasmetal_core__DOT___062348_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b72__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b72__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 7U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b72__05d)))))));
    vlSelf->__VdfgTmp_h15796065__0 = (((IData)(vlSelf->wasmetal_core__DOT___005089_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b88__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002660_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002659_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005087_))));
    vlSelf->wasmetal_core__DOT___052338_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4c8e22c1__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b104__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053180_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_ha9ea3386__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h4c8e22c1__0))))))));
    vlSelf->__VdfgTmp_h8103cb90__0 = (((IData)(vlSelf->wasmetal_core__DOT___003773_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h93ad939a__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003771_))));
    vlSelf->__VdfgTmp_hf123ec52__0 = (((IData)(vlSelf->wasmetal_core__DOT___003979_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h56438591__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003977_))));
    vlSelf->wasmetal_core__DOT___062370_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b80__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b80__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0xfU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b80__05d)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b112__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053222_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h1836318f__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h6806bd5e__0))))))));
    vlSelf->__VdfgTmp_hb2ba9050__0 = (((IData)(vlSelf->wasmetal_core__DOT___003997_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hbad05108__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003995_))));
    vlSelf->__VdfgTmp_hd2cb6624__0 = (((IData)(vlSelf->wasmetal_core__DOT___005591_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hb342b047__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005589_))));
    vlSelf->wasmetal_core__DOT___062492_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b127__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b127__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x1eU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b127__05d)))))));
    vlSelf->__VdfgTmp_h41785ae8__0 = (((IData)(vlSelf->wasmetal_core__DOT___004571_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h18733fd3__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004569_))));
    vlSelf->wasmetal_core__DOT___069462_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b71__05d))));
    vlSelf->wasmetal_core__DOT___062345_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b71__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b71__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b71__05d)))))));
    vlSelf->wasmetal_core__DOT___052324_ = (1U & (IData)(
                                                         (0x8888f00000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052320_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003389_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003179_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h8889c5b6__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3cd3193e__0)))))))))));
    vlSelf->__VdfgTmp_h7b80a3df__0 = (((IData)(vlSelf->wasmetal_core__DOT___004589_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd77c56a5__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004587_))));
    vlSelf->wasmetal_core__DOT___070126_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070122_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b103__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->cmd_data[3U] 
                                                                >> 6U)) 
                                                            | (1U 
                                                               & (0xf38f2779U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))));
    vlSelf->wasmetal_core__DOT___062430_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b103__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b103__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b103__05d)))))));
    vlSelf->__VdfgTmp_hf772eecc__0 = (((IData)(vlSelf->wasmetal_core__DOT___005609_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h7de933ba__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005607_))));
    vlSelf->wasmetal_core__DOT___062411_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b95__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1eU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b95__05d)))))));
    vlSelf->wasmetal_core__DOT___069987_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x1cU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (vlSelf->insn_y 
                                                                                >> 0x1fU)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069984_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b95__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (vlSelf->mem_rdata[2U] 
                                                                          >> 0x1fU)))))))));
    vlSelf->__VdfgTmp_he8484823__0 = (((IData)(vlSelf->wasmetal_core__DOT___003681_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_he10ebbb0__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003679_))));
    vlSelf->wasmetal_core__DOT___069646_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0xcU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xfU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b79__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069643_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b79__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b79__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0xfU))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b111__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053224_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hcf8490b8__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_he6df8ac0__0))))))));
    vlSelf->__VdfgTmp_he18e3e19__0 = (((IData)(vlSelf->wasmetal_core__DOT___003699_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hc7901b89__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003697_))));
    vlSelf->wasmetal_core__DOT___052305_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h533e26e9__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b119__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053240_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hed80111e__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h533e26e9__0))))))));
    vlSelf->__VdfgTmp_h3fce9550__0 = (((IData)(vlSelf->wasmetal_core__DOT___005139_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h20122d13__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005137_))));
    vlSelf->wasmetal_core__DOT__value_aux__05b87__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052103_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h128bed99__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h106a7f5e__0))))))));
    vlSelf->__VdfgTmp_h29fb25ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___005157_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b87__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002942_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002941_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005155_))));
    vlSelf->wasmetal_core__DOT___052176_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h98b5e894__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052168_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6aba24e3__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b63__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052168_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6aba24e3__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h98b5e894__0))))))));
    vlSelf->__VdfgTmp_hee23ef9b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005645_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b63__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001177_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001176_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005643_))));
    vlSelf->wasmetal_core__DOT___052445_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hf33ae1e8__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052443_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6366d506__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b51__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052443_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6366d506__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf33ae1e8__0))))))));
    vlSelf->__VdfgTmp_h5f9a0992__0 = (((IData)(vlSelf->wasmetal_core__DOT___003885_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003884_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003883_))));
    vlSelf->wasmetal_core__DOT___052447_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hccc0d080__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052439_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hbe4c2cfb__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b50__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052439_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbe4c2cfb__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hccc0d080__0))))))));
    vlSelf->__VdfgTmp_h5172aa32__0 = (((IData)(vlSelf->wasmetal_core__DOT___004101_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004100_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004099_))));
    vlSelf->wasmetal_core__DOT___052446_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h39926e96__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052435_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h650b1858__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b49__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052435_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h650b1858__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h39926e96__0))))))));
    vlSelf->__VdfgTmp_h56fd8038__0 = (((IData)(vlSelf->wasmetal_core__DOT___004323_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004322_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004321_))));
    vlSelf->wasmetal_core__DOT___052450_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h58c7b8aa__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052431_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf5ca71c3__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b48__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052431_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf5ca71c3__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h58c7b8aa__0))))))));
    vlSelf->__VdfgTmp_hde7deab4__0 = (((IData)(vlSelf->wasmetal_core__DOT___004027_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004026_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004025_))));
    vlSelf->wasmetal_core__DOT___052142_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9b219d07__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052131_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h57e567b8__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b47__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052131_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h57e567b8__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9b219d07__0))))))));
    vlSelf->__VdfgTmp_hca53b37a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003729_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003728_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003727_))));
    vlSelf->wasmetal_core__DOT___052141_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h21caabb4__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052127_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc3ffba8a__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b46__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052127_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc3ffba8a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h21caabb4__0))))))));
}
