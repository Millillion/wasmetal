#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__1(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__1\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___001027_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001022_)))));
    vlSelf->wasmetal_core__DOT___001005_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001000_)))));
    vlSelf->__VdfgTmp_h55f26059__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000934_)));
    vlSelf->wasmetal_core__DOT___000939_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000934_)))));
    vlSelf->__VdfgTmp_h4b0186c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000904_)));
    vlSelf->wasmetal_core__DOT___000909_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000904_)))));
    vlSelf->wasmetal_core__DOT___000961_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000956_)))));
    vlSelf->__VdfgTmp_h5a6445ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000914_)));
    vlSelf->wasmetal_core__DOT___000919_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000914_)))));
    vlSelf->wasmetal_core__DOT___000971_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b53__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000966_)))));
    vlSelf->__VdfgTmp_hcba3b702__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000880_)));
    vlSelf->wasmetal_core__DOT___000885_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000880_)))));
    vlSelf->wasmetal_core__DOT___000949_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000944_)))));
    vlSelf->__VdfgTmp_h5e9c07be__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000890_)));
    vlSelf->wasmetal_core__DOT___000895_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000890_)))));
    vlSelf->__VdfgTmp_h60070975__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000856_)));
    vlSelf->wasmetal_core__DOT___000861_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000856_)))));
    vlSelf->__VdfgTmp_h74f399ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000866_)));
    vlSelf->wasmetal_core__DOT___000871_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000866_)))));
    vlSelf->__VdfgTmp_h9cca9eb0__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000842_)));
    vlSelf->wasmetal_core__DOT___000847_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000842_)))));
    vlSelf->__VdfgTmp_h67445948__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000832_)));
    vlSelf->wasmetal_core__DOT___000837_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000832_)))));
    vlSelf->__VdfgTmp_h252badb1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000803_)));
    vlSelf->wasmetal_core__DOT___000808_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000803_)))));
    vlSelf->__VdfgTmp_h34a57f42__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000813_)));
    vlSelf->wasmetal_core__DOT___000818_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000813_)))));
    vlSelf->__VdfgTmp_h4e280dfe__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000779_)));
    vlSelf->wasmetal_core__DOT___000784_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000779_)))));
    vlSelf->__VdfgTmp_h054c8d5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000789_)));
    vlSelf->wasmetal_core__DOT___000794_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000789_)))));
    vlSelf->__VdfgTmp_hc00537e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000765_)));
    vlSelf->wasmetal_core__DOT___000770_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000765_)))));
    vlSelf->__VdfgTmp_h4f517b43__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000755_)));
    vlSelf->wasmetal_core__DOT___000760_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000755_)))));
    vlSelf->__VdfgTmp_haf89032c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000741_)));
    vlSelf->wasmetal_core__DOT___000746_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000741_)))));
    vlSelf->__VdfgTmp_h5500fae9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000731_)));
    vlSelf->wasmetal_core__DOT___000736_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000731_)))));
    vlSelf->__VdfgTmp_h3c930b99__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000711_)));
    vlSelf->wasmetal_core__DOT___000716_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000711_)))));
    vlSelf->__VdfgTmp_h95280768__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000701_)));
    vlSelf->wasmetal_core__DOT___000706_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000701_)))));
    vlSelf->__VdfgTmp_hf410ea07__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000677_)));
    vlSelf->wasmetal_core__DOT___000682_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000677_)))));
    vlSelf->__VdfgTmp_h2a120d0d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000687_)));
    vlSelf->wasmetal_core__DOT___000692_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000687_)))));
    vlSelf->wasmetal_core__DOT___000648_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000643_)))));
    vlSelf->wasmetal_core__DOT___000626_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000621_)))));
    vlSelf->wasmetal_core__DOT___000604_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000599_)))));
    vlSelf->wasmetal_core__DOT___000582_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000577_)))));
    vlSelf->wasmetal_core__DOT___000555_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b26__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000550_)))));
    vlSelf->wasmetal_core__DOT___000533_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000528_)))));
    vlSelf->wasmetal_core__DOT___000511_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000506_)))));
    vlSelf->wasmetal_core__DOT___000489_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000484_)))));
    vlSelf->wasmetal_core__DOT___000445_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000440_)))));
    vlSelf->wasmetal_core__DOT___000455_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000450_)))));
    vlSelf->wasmetal_core__DOT___001869_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001864_)))));
    vlSelf->__VdfgTmp_hc744024d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001864_)));
    vlSelf->wasmetal_core__DOT___000407_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000402_)))));
    vlSelf->wasmetal_core__DOT___001845_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001840_)))));
    vlSelf->__VdfgTmp_h856b720a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001840_)));
    vlSelf->wasmetal_core__DOT___000397_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000392_)))));
    vlSelf->wasmetal_core__DOT___001637_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001632_)))));
    vlSelf->wasmetal_core__DOT___001603_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001598_)))));
    vlSelf->wasmetal_core__DOT___001593_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001588_)))));
    vlSelf->wasmetal_core__DOT___001559_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001554_)))));
    vlSelf->wasmetal_core__DOT___001549_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001544_)))));
    vlSelf->wasmetal_core__DOT___001515_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001510_)))));
    vlSelf->wasmetal_core__DOT___001505_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001500_)))));
    vlSelf->wasmetal_core__DOT___001404_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001399_)))));
    vlSelf->wasmetal_core__DOT___001394_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001389_)))));
    vlSelf->wasmetal_core__DOT___001350_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001345_)))));
    vlSelf->wasmetal_core__DOT___001360_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b8__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001355_)))));
    vlSelf->wasmetal_core__DOT___001466_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001461_)))));
    vlSelf->wasmetal_core__DOT___001456_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b6__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001451_)))));
    vlSelf->wasmetal_core__DOT___001191_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b5__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001186_)))));
    vlSelf->wasmetal_core__DOT___001201_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b4__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001196_)))));
    vlSelf->wasmetal_core__DOT___000193_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b3__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000185_)))));
    vlSelf->wasmetal_core__DOT___000387_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000382_)))));
    vlSelf->__VdfgTmp_hb1ddac1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000535_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___000534_)))));
    vlSelf->__VdfgTmp_h27610e5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000513_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___000512_)))));
    vlSelf->__VdfgTmp_hda033d4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000457_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___000456_)))));
    vlSelf->__VdfgTmp_hfbabec73__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000409_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___000408_)))));
    vlSelf->__VdfgTmp_h9975f0a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001639_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001638_)))));
    vlSelf->__VdfgTmp_h40e72268__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001605_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001604_)))));
    vlSelf->__VdfgTmp_h7409986d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001595_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001594_)))));
    vlSelf->__VdfgTmp_h9340bbb8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b122__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002831_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002830_)))));
    vlSelf->__VdfgTmp_hbc270d96__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b98__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001983_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001982_)))));
    vlSelf->__VdfgTmp_hacecf0f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b90__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002821_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002820_)))));
    vlSelf->__VdfgTmp_h2d07d754__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b74__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002440_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002439_)))));
    vlSelf->__VdfgTmp_hd9daf5f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b106__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002450_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002449_)))));
    vlSelf->__VdfgTmp_h57451afb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b68__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001260_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001259_)))));
    vlSelf->__VdfgTmp_hed1d041c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b69__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001685_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001684_)))));
    vlSelf->__VdfgTmp_h4e57fd92__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b124__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002749_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002748_)))));
    vlSelf->__VdfgTmp_h6f7c691c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b125__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002789_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002788_)))));
    vlSelf->__VdfgTmp_hbeaa94ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b126__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002913_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002912_)))));
    vlSelf->__VdfgTmp_h06d51d42__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b70__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001750_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001749_)))));
    vlSelf->__VdfgTmp_h04a005a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b99__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002018_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002017_)))));
    vlSelf->__VdfgTmp_h2b893d79__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b100__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001270_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001269_)))));
    vlSelf->__VdfgTmp_h61430f62__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b101__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001695_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001694_)))));
    vlSelf->__VdfgTmp_hf6cb6b1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b102__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001760_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001759_)))));
    vlSelf->__VdfgTmp_h2876322d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b92__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002739_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002738_)))));
    vlSelf->__VdfgTmp_h27483593__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b93__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002779_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002778_)))));
    vlSelf->__VdfgTmp_h6823128b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b75__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002362_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002361_)))));
    vlSelf->__VdfgTmp_hc644e6af__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b94__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002903_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002902_)))));
    vlSelf->__VdfgTmp_h7e6d032b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b76__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002085_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002084_)))));
    vlSelf->__VdfgTmp_h04cce861__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b77__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002122_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002121_)))));
    vlSelf->__VdfgTmp_h8b2f01bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b107__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002372_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002371_)))));
    vlSelf->__VdfgTmp_h9efd96c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b78__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002159_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002158_)))));
    vlSelf->__VdfgTmp_h95c9c2c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b108__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002095_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002094_)))));
    vlSelf->__VdfgTmp_h7c824381__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b109__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002132_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002131_)))));
    vlSelf->__VdfgTmp_hbd2119cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b110__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002169_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002168_)))));
    vlSelf->__VdfgTmp_h187cbe57__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b82__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002296_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002295_)))));
    vlSelf->__VdfgTmp_h2098039d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b114__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002306_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002305_)))));
    vlSelf->__VdfgTmp_h9a831d1c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b65__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001908_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001907_)))));
    vlSelf->__VdfgTmp_h22773bc1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b121__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002709_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002708_)))));
    vlSelf->__VdfgTmp_hc39d0419__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b97__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001918_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001917_)))));
    vlSelf->__VdfgTmp_h0b18d540__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b116__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002333_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002332_)))));
    vlSelf->__VdfgTmp_h75fb7e4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b117__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002610_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002609_)))));
    vlSelf->__VdfgTmp_hf100045e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b118__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002573_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002572_)))));
    vlSelf->__VdfgTmp_h00d09e7a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b115__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001217_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001216_)))));
    vlSelf->__VdfgTmp_h0b6168e4__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b84__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002343_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002342_)))));
    vlSelf->__VdfgTmp_h4c3dd507__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b85__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002620_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002619_)))));
    vlSelf->__VdfgTmp_h8b19f5ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b86__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002583_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002582_)))));
    vlSelf->__VdfgTmp_h96657cd6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b81__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002250_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002249_)))));
    vlSelf->__VdfgTmp_h5f1be76b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b113__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002260_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002259_)))));
    vlSelf->__VdfgTmp_h3e0c1557__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b64__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001817_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001816_)))));
    vlSelf->__VdfgTmp_hbe2bd06c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b120__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002670_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002669_)))));
    vlSelf->__VdfgTmp_hcd3797e9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b96__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001827_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001826_)))));
    vlSelf->__VdfgTmp_hb156040c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b72__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002525_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002524_)))));
    vlSelf->__VdfgTmp_h93ad939a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b104__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002535_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002534_)))));
    vlSelf->__VdfgTmp_h56438591__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b80__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002047_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002046_)))));
    vlSelf->__VdfgTmp_hbad05108__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b112__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002057_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002056_)))));
    vlSelf->__VdfgTmp_h8fdf3668__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b66__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001972_)));
    vlSelf->__VdfgTmp_hcf9144f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h84ec00f9__0));
    vlSelf->__VdfgTmp_h978f5c03__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hacde19aa__0));
    vlSelf->__VdfgTmp_h567f5b99__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_heece1a14__0));
    vlSelf->__VdfgTmp_hde496412__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h76a42199__0));
    vlSelf->__VdfgTmp_h7b9c68be__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h18ef2d35__0));
    vlSelf->__VdfgTmp_hc4d9060a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b67__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___002007_)));
    vlSelf->__VdfgTmp_h04880fd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3be345de__0));
    vlSelf->__VdfgTmp_h0589a813__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b123__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___002872_)));
    vlSelf->__VdfgTmp_h27cfb5f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5d1eeffa__0));
    vlSelf->__VdfgTmp_he1a2a265__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9ef9e390__0));
    vlSelf->__VdfgTmp_hc20a91e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8261d40e__0));
    vlSelf->__VdfgTmp_h5a3a45b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfa91003e__0));
    vlSelf->__VdfgTmp_h97006b3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_had5b2ab5__0));
    vlSelf->__VdfgTmp_h3348ca28__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h51a38bc3__0));
    vlSelf->__VdfgTmp_h924e7878__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb29d3d73__0));
    vlSelf->__VdfgTmp_ha95b5bdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he7b219d6__0));
    vlSelf->__VdfgTmp_h14eebae7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h2c3dfb0e__0));
    vlSelf->__VdfgTmp_h0e2ba734__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b91__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___002862_)));
    vlSelf->__VdfgTmp_h6ab68aeb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h2a05cb02__0));
    vlSelf->__VdfgTmp_h3ecae377__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5621a27e__0));
    vlSelf->__VdfgTmp_hd368a607__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h71c3dfae__0));
    vlSelf->__VdfgTmp_hc521e256__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7b7ca35d__0));
    vlSelf->__VdfgTmp_hfbf79e7b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9946d772__0));
    vlSelf->__VdfgTmp_he0d5eea6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha028a74d__0));
    vlSelf->__VdfgTmp_hbd2d90ad__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd380d548__0));
    vlSelf->__VdfgTmp_hb62a6dc2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hce8127e9__0));
    vlSelf->__VdfgTmp_hc2399f9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8294d615__0));
    vlSelf->__VdfgTmp_h3ed820c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h563364ee__0));
    vlSelf->__VdfgTmp_haa9d6aae__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he9f02b45__0));
    vlSelf->__VdfgTmp_h336c7598__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h51bf3013__0));
    vlSelf->__VdfgTmp_h4c59d32e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h04b492c5__0));
    vlSelf->__VdfgTmp_hed1e62e4__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha36d230f__0));
    vlSelf->__VdfgTmp_h0352b565__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b89__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___002698_)));
    vlSelf->__VdfgTmp_ha5352532__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b73__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___002401_)));
    vlSelf->__VdfgTmp_h14a07dbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b105__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___002411_)));
    vlSelf->__VdfgTmp_h1e17785c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h36663d57__0));
    vlSelf->__VdfgTmp_h70b5eab4__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h1008ab3f__0));
    vlSelf->__VdfgTmp_h3971fc45__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h57ccb970__0));
    vlSelf->__VdfgTmp_h8de0b505__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc33bf0b0__0));
    vlSelf->__VdfgTmp_he4198019__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9c74c594__0));
    vlSelf->__VdfgTmp_h587b33f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b83__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001206_)));
    vlSelf->__VdfgTmp_h94eb455b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hac420052__0));
    vlSelf->__VdfgTmp_h5fa501f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hf4f843fa__0));
    vlSelf->__VdfgTmp_hcced7fa9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h84403644__0));
    vlSelf->__VdfgTmp_hb92015b3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd77b503a__0));
    vlSelf->__VdfgTmp_h33748258__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h51c7c353__0));
    vlSelf->__VdfgTmp_h5528d6fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_heb838ef1__0));
    vlSelf->__VdfgTmp_h302dd625__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h50808fd0__0));
    vlSelf->__VdfgTmp_h80bd54db__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc01010d2__0));
    vlSelf->__VdfgTmp_h76024217__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h0e59039e__0));
    vlSelf->__VdfgTmp_hab141f26__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he96756cd__0));
    vlSelf->__VdfgTmp_h7762895e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b88__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___002659_)));
    vlSelf->__VdfgTmp_hea93726f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha9ea3386__0));
    vlSelf->__VdfgTmp_h81a5b0aa__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hbef8f541__0));
    vlSelf->__VdfgTmp_h78e77464__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h1836318f__0));
    vlSelf->__VdfgTmp_hb342b047__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003072_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___003071_)))));
    vlSelf->__VdfgTmp_h18733fd3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b71__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002205_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002204_)))));
    vlSelf->__VdfgTmp_hd77c56a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b103__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002215_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002214_)))));
    vlSelf->__VdfgTmp_h7de933ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b95__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003082_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___003081_)))));
    vlSelf->__VdfgTmp_he10ebbb0__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b79__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002483_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002482_)))));
    vlSelf->__VdfgTmp_hc7901b89__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b111__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002493_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002492_)))));
    vlSelf->__VdfgTmp_h20122d13__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b119__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002952_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002951_)))));
    vlSelf->__VdfgTmp_he6a8c031__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9e0385bc__0));
    vlSelf->__VdfgTmp_hb257a383__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd2a6e22a__0));
    vlSelf->__VdfgTmp_h82193735__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc2746ec0__0));
    vlSelf->__VdfgTmp_hc0def293__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h802db31a__0));
    vlSelf->__VdfgTmp_hfe998686__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h95f4bf2d__0));
    vlSelf->__VdfgTmp_hb129d53d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcf8490b8__0));
    vlSelf->__VdfgTmp_h572d5497__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hed80111e__0));
    vlSelf->__VdfgTmp_h128bed99__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b87__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___002941_)));
    vlSelf->__VdfgTmp_h6aba24e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b63__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001176_)));
    vlSelf->__VdfgTmp_h81e66010__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b62__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e6.__PVT__parity) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_hc60de2b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e6.__PVT__data 
                                                                     >> 7U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h664f8c0a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e6.__PVT__data 
                                                                     >> 6U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h56d0d6d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e6.__PVT__data 
                                                                     >> 5U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_hb19b1393__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e6.__PVT__data 
                                                                     >> 4U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h7def20ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e6.__PVT__data 
                                                                     >> 3U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_hbc0682c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e6.__PVT__data 
                                                                     >> 2U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h80bc039f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e6.__PVT__data 
                                                                     >> 1U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h6366d506__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000930_)));
    vlSelf->__VdfgTmp_hbe4c2cfb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000900_)));
    vlSelf->__VdfgTmp_h85029f86__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e6.__PVT__data) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h650b1858__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000910_)));
    vlSelf->__VdfgTmp_h397ad7fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b53__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e5.__PVT__parity) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_hf5ca71c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000876_)));
    vlSelf->__VdfgTmp_hcef8ef16__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e5.__PVT__data 
                                                                     >> 7U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h57e567b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000886_)));
    vlSelf->__VdfgTmp_hc3ffba8a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000852_)));
    vlSelf->__VdfgTmp_ha87e62b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000862_)));
    vlSelf->__VdfgTmp_h807ad9d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000838_)));
    vlSelf->__VdfgTmp_h456da093__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000828_)));
    vlSelf->__VdfgTmp_hc5f6f937__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000799_)));
    vlSelf->__VdfgTmp_hd28cbf2a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000809_)));
    vlSelf->__VdfgTmp_hb4397905__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000775_)));
    vlSelf->__VdfgTmp_hce8a559f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000785_)));
    vlSelf->__VdfgTmp_hc5320df5__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000761_)));
    vlSelf->__VdfgTmp_hd6e95fa8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000751_)));
    vlSelf->__VdfgTmp_h8fdaff69__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000737_)));
    vlSelf->__VdfgTmp_hb26c7187__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000727_)));
    vlSelf->__VdfgTmp_hf3a0142d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000707_)));
    vlSelf->__VdfgTmp_h13262e9c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000697_)));
    vlSelf->__VdfgTmp_h1512c46f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000673_)));
    vlSelf->__VdfgTmp_h149fa621__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000683_)));
    vlSelf->__VdfgTmp_h95441b9a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e3.__PVT__data 
                                                                     >> 3U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h4279d3a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e3.__PVT__data 
                                                                     >> 2U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h7f8a4a6e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e3.__PVT__data 
                                                                     >> 1U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h4d1ee432__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e3.__PVT__data) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_hd5f7fb83__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b26__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e2.__PVT__parity) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_hf6a1a834__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000534_)));
    vlSelf->__VdfgTmp_h8a521099__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000512_)));
    vlSelf->__VdfgTmp_ha29002c9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e2.__PVT__data 
                                                                     >> 5U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h5b213075__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e2.__PVT__data 
                                                                     >> 4U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h12d7401d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000456_)));
    vlSelf->__VdfgTmp_h6a684ffb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001860_)));
    vlSelf->__VdfgTmp_h4f514d50__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000408_)));
    vlSelf->__VdfgTmp_h173fc958__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001836_)));
    vlSelf->__VdfgTmp_he64a7376__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e2.__PVT__data 
                                                                     >> 1U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h252dd1a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001638_)));
    vlSelf->__VdfgTmp_h2dcfbe3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001604_)));
    vlSelf->__VdfgTmp_he176d11c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001594_)));
    vlSelf->__VdfgTmp_he721caff__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e1.__PVT__data 
                                                                     >> 6U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_hfc69f4da__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e1.__PVT__data 
                                                                     >> 5U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h63a71256__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e1.__PVT__data 
                                                                     >> 4U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h17123258__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e1.__PVT__data 
                                                                     >> 3U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h42734187__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e1.__PVT__data 
                                                                     >> 2U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_hd1ab5007__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e1.__PVT__data 
                                                                     >> 1U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_hfc0ecf20__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e1.__PVT__data) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_he0f0059b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b8__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e0.__PVT__parity) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h6fd66007__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 7U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_hefb6870d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b6__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 6U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h84bf9c8c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b5__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 5U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h9b52bb5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b4__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 4U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h156b8e5c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b3__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 3U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->__VdfgTmp_h261d1fb9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b2__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 2U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043983_))))));
    vlSelf->wasmetal_core__DOT___003884_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000930_)))))))));
    vlSelf->wasmetal_core__DOT___004100_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000901_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000900_)))))))));
    vlSelf->wasmetal_core__DOT___004322_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000911_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000910_)))))))));
    vlSelf->wasmetal_core__DOT___004026_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000877_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000876_)))))))));
    vlSelf->wasmetal_core__DOT___003728_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000887_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000886_)))))))));
    vlSelf->wasmetal_core__DOT___004692_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000853_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000852_)))))))));
    vlSelf->wasmetal_core__DOT___004248_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000863_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000862_)))))))));
    vlSelf->wasmetal_core__DOT___004174_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000839_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000838_)))))))));
    vlSelf->wasmetal_core__DOT___003580_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000829_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000828_)))))))));
    vlSelf->wasmetal_core__DOT___003506_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000800_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000799_)))))))));
    vlSelf->wasmetal_core__DOT___003654_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000810_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000809_)))))))));
    vlSelf->wasmetal_core__DOT___003802_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000776_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000775_)))))))));
    vlSelf->wasmetal_core__DOT___004618_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000786_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000785_)))))))));
    vlSelf->wasmetal_core__DOT___004470_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000762_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000761_)))))))));
    vlSelf->wasmetal_core__DOT___004396_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000752_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000751_)))))))));
    vlSelf->wasmetal_core__DOT___004544_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000738_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000737_)))))))));
    vlSelf->wasmetal_core__DOT___004766_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000728_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000727_)))))))));
    vlSelf->wasmetal_core__DOT___004840_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000708_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000707_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128139___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O)) 
            | (IData)(vlSelf->wasmetal_core__DOT___029156_)) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029149_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128322___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031067_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031064_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031053_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031042_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031035_ = ((IData)(vlSelf->wasmetal_core__DOT___031067_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->wasmetal_core__DOT___071035_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b7__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 7U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071039_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b6__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 6U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071043_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b5__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 5U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071050_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b10__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 9U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071054_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b9__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 8U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071058_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b8__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071095_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b19__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x11U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071099_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b18__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x10U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071103_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b17__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__parity)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071110_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b22__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x14U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071114_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b21__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x13U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071118_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b20__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x12U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071155_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b31__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1cU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071159_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b30__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1bU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071163_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b29__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1aU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071170_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b34__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1fU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071174_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b33__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1eU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071178_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b32__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1dU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071215_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b43__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x27U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071219_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b42__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x26U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071223_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b41__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x25U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071230_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b46__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x29U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071234_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b45__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x28U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071238_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b44__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                >> 3U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071006_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 1U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071010_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data))))))));
    vlSelf->wasmetal_core__DOT___071020_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b4__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 4U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071024_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b3__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 3U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071028_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b2__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 2U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071065_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b13__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xcU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071069_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b12__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xbU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071073_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b11__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xaU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071080_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b16__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xfU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071084_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b15__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xeU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071088_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b14__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xdU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071125_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b25__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x17U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071129_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b24__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x16U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071133_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b23__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x15U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071140_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b28__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x19U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071144_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b27__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x18U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071148_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b26__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071185_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b37__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x21U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071189_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b36__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x20U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071193_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b35__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071200_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b40__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x24U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071204_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b39__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x23U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071208_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b38__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x22U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071245_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b47__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x2aU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___070951_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data)))))));
    vlSelf->__VdfgTmp_h48de7988__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b62__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                            >> 5U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b62__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                             >> 5U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_heb46fbcb__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b63__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x38U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b63__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x38U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___070950_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data)))))));
    vlSelf->__VdfgTmp_h73075b94__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b47__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x2aU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b47__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2aU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h17228d9d__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b46__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x29U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b46__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x29U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h7ee7d44c__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b45__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x28U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b45__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x28U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hb3e6303e__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b50__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x2dU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b50__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2dU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hd266b697__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b49__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x2cU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b49__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2cU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h123a295b__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b48__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x2bU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b48__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2bU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h5dc57786__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b59__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x35U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b59__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x35U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h86abd4f4__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b58__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x34U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b58__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x34U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h966a07d3__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b57__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x33U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b57__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x33U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h8a64daef__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b61__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x37U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b61__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x37U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h966312d4__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b60__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x36U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b60__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x36U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_ha300b05f__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b41__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x25U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b41__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x25U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_ha431143d__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b44__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                            >> 3U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b44__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                             >> 3U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h2535fff2__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b43__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x27U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b43__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x27U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hed7c6d19__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b42__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x26U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b42__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x26U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h8a6dc29d__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b53__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                            >> 4U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b53__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                             >> 4U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_he372c179__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b52__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x2fU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b52__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2fU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h8fd79857__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b51__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x2eU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b51__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2eU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hbceb8814__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b56__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x32U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b56__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x32U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h1bbfb27a__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b55__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x31U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b55__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x31U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h8d7f942c__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b54__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x30U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b54__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x30U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hb8649aac__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b10__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 9U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b10__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 9U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hd389bfd2__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b9__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 8U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b9__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 8U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h1915a5ff__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b22__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x14U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b22__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x14U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h70b63d5e__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b21__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x13U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b21__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x13U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h1473a3fc__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b34__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x1fU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b34__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1fU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hbbedaddf__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b33__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x1eU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b33__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1eU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h3006d0f0__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b38__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x22U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b38__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x22U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h5dfde09f__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b1__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 1U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b1__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 1U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hf7e0b807__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b5__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 5U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b5__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 5U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_he127cdd2__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b8__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b8__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hd8bdfcc6__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b7__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 7U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b7__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 7U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h0bf68f44__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b6__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 6U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b6__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 6U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h83bd92c8__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b17__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (IData)(vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__parity)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b17__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__parity)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hf6358f59__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b20__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x12U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b20__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x12U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h65437cee__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b19__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x11U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b19__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x11U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h4c7f02d9__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b18__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x10U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b18__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x10U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h370a9404__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b29__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x1aU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b29__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1aU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h098d62f8__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b32__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x1dU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b32__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1dU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hdf9c0a20__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b31__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x1cU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b31__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1cU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_he08c96ba__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b30__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x1bU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b30__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1bU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hc1d04e55__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b40__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x24U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b40__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x24U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_ha31457b4__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b39__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x23U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b39__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x23U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hbba81ae3__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b2__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 2U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b2__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 2U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h670f6b42__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b11__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0xaU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b11__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xaU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hfb8717f5__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b14__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0xdU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b14__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xdU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h0201c3e9__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b13__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0xcU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b13__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xcU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hbc582c17__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b12__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0xbU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b12__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xbU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h5b1f350b__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b23__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x15U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b23__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x15U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h852d6a23__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b26__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b26__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h9685a33e__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b25__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x17U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b25__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x17U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hee7ba675__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b24__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x16U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b24__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x16U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h0ba16cdb__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b35__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                            >> 2U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b35__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h0919c673__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b37__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x21U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b37__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x21U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hc7238523__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b36__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x20U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b36__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x20U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h31b47573__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b4__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 4U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b4__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 4U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hedf8c8b5__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b3__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 3U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b3__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 3U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h978cb234__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b15__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0xeU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b15__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xeU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h4dc6a706__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b16__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0xfU)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b16__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xfU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_h2c74d244__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b28__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x19U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b28__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x19U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->__VdfgTmp_hf5aac232__0 = ((2U & ((0xf77U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___070943_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b27__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT__element_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                     >> 0x18U)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a))))) 
                                             << 1U)) 
                                      | (1U & (0xf77U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___070940_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b27__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__data_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x18U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___070885_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b63__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x38U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___070886_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b62__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                             >> 5U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054247_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b63__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x38U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054245_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b62__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                             >> 5U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054243_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b61__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x37U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054241_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b60__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x36U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054239_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b59__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x35U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054237_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b58__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x34U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054235_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b57__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x33U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054233_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b56__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x32U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054231_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b55__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x31U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054229_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b54__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x30U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054227_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b53__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                             >> 4U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054225_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b52__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x2fU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054223_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b51__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x2eU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054221_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b50__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x2dU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054219_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b49__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x2cU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054217_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b48__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x2bU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054215_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b47__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x2aU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054213_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b46__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x29U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054211_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b45__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x28U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054209_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b44__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                             >> 3U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054207_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b43__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x27U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054205_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b42__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x26U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054203_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b41__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x25U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054201_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b40__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x24U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054199_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b39__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x23U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054197_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b38__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x22U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054195_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b37__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x21U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054193_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b36__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x20U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054191_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b35__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054189_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b34__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x1fU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054186_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b33__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x1eU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054182_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b32__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x1dU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054178_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b31__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x1cU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054174_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b30__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x1bU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054170_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b29__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x1aU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054166_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b28__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x19U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054162_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b27__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x18U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054158_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b26__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054135_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b25__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x17U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054131_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b24__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x16U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054127_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b23__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x15U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054123_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b22__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x14U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054119_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b21__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x13U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054115_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b20__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x12U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054111_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b19__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x11U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054107_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b18__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0x10U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054103_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b17__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__parity)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054099_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b16__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0xfU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054095_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b15__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0xeU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054091_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b14__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0xdU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054087_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b13__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0xcU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054083_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b12__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0xbU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054079_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b11__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 0xaU)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054075_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b10__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 9U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054071_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b9__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 8U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054067_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b8__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054063_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b7__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 7U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054059_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b6__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 6U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054055_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b5__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 5U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054051_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b4__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 4U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054047_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b3__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 3U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054043_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b2__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 2U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054039_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b1__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                      >> 1U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___053990_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e1__02e0.__PVT__data)))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b63__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x38U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b62__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b61__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x37U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b60__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b60__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x36U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b59__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x35U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b58__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x34U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b57__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x33U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b56__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x32U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b55__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x31U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b54__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x30U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b53__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b52__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x2fU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b51__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x2eU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b50__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x2dU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b3__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 3U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b2__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 2U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b1__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 1U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b0__05d) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data)))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b7__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 7U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b6__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 6U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b5__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 5U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b4__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 4U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b11__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0xaU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b10__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 9U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b9__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 8U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b8__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b15__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0xeU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b14__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0xdU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b13__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0xcU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b12__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0xbU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b19__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x11U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b18__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x10U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b17__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__parity)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b16__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0xfU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b23__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x15U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b22__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x14U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b21__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x13U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b20__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x12U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b27__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x18U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b26__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b25__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x17U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b24__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x16U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b31__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x1cU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b30__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x1bU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b29__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x1aU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b28__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x19U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b35__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b34__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x1fU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b33__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x1eU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b32__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x1dU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b39__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x23U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b38__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x22U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b37__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x21U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b36__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x20U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b43__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x27U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b42__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x26U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b41__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x25U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b40__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x24U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b47__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x2aU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b46__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x29U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b45__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x28U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b44__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__parity) 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b49__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x2cU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d 
        = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT___053419_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b48__05d) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e1__02e0.__PVT__data 
                                                                >> 0x2bU)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___070782_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b63__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x38U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___070783_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b62__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                             >> 5U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___054478_ = (1U & (0xf77U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b64__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x39U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a))))));
    vlSelf->wasmetal_core__DOT___004793_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5f8f87da__0))));
    vlSelf->wasmetal_core__DOT___004935_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd8a32bd__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b122__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053246_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h84ec00f9__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004933_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hbd8a32bd__0)))))))))));
    vlSelf->__VdfgTmp_h563719e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___004809_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb1d9bcba__0))));
    vlSelf->wasmetal_core__DOT___004811_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb1d9bcba__0))));
    vlSelf->wasmetal_core__DOT___004953_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h360aedc6__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b90__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053141_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_heece1a14__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004951_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h360aedc6__0)))))))))));
    vlSelf->wasmetal_core__DOT___003459_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b04a080__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b74__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052729_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h76a42199__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003457_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3b04a080__0)))))))))));
    vlSelf->__VdfgTmp_hd9174715__0 = (((IData)(vlSelf->wasmetal_core__DOT___003475_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0a7ec8f3__0))));
    vlSelf->wasmetal_core__DOT___003477_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0a7ec8f3__0))));
    vlSelf->wasmetal_core__DOT___052035_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004791_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004717_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h5f8f87da__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h6be40165__0)))))))));
    vlSelf->wasmetal_core__DOT___004719_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6be40165__0))));
    vlSelf->wasmetal_core__DOT___004497_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h252a6e11__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b68__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052714_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h3be345de__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004495_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h252a6e11__0)))))))))));
    vlSelf->__VdfgTmp_h70f8ca0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005001_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb177e111__0))));
    vlSelf->wasmetal_core__DOT___005003_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb177e111__0))));
    vlSelf->wasmetal_core__DOT___052030_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004495_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004347_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h252a6e11__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h813f07f7__0)))))))));
    vlSelf->wasmetal_core__DOT___004349_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h813f07f7__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b69__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052716_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h8261d40e__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004347_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h813f07f7__0)))))))))));
    vlSelf->wasmetal_core__DOT___052300_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004933_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004865_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hbd8a32bd__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h149c0bef__0)))))))));
    vlSelf->wasmetal_core__DOT___004867_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h149c0bef__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b124__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053159_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h5d1eeffa__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004865_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h149c0bef__0)))))))))));
    vlSelf->wasmetal_core__DOT___005275_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hce3a0449__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b125__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053161_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9ef9e390__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005273_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hce3a0449__0)))))))))));
    vlSelf->wasmetal_core__DOT___005207_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h36fcb829__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b126__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053253_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hfa91003e__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005205_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h36fcb829__0)))))))))));
    vlSelf->wasmetal_core__DOT___004423_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h37bfe82f__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b70__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062340_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_had5b2ab5__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004421_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h37bfe82f__0)))))))))));
    vlSelf->__VdfgTmp_h6e2b8153__0 = (((IData)(vlSelf->wasmetal_core__DOT___004735_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hdf1c1f2d__0))));
    vlSelf->wasmetal_core__DOT___004737_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdf1c1f2d__0))));
    vlSelf->__VdfgTmp_h9014fa0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___004513_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb173ffdf__0))));
    vlSelf->wasmetal_core__DOT___004515_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb173ffdf__0))));
    vlSelf->__VdfgTmp_h11abcf6d__0 = (((IData)(vlSelf->wasmetal_core__DOT___004365_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3fc50e0d__0))));
    vlSelf->wasmetal_core__DOT___004367_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3fc50e0d__0))));
    vlSelf->__VdfgTmp_h9e847741__0 = (((IData)(vlSelf->wasmetal_core__DOT___004439_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc1565767__0))));
    vlSelf->wasmetal_core__DOT___004441_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1565767__0))));
    vlSelf->wasmetal_core__DOT___005021_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he20a0bf9__0))));
    vlSelf->wasmetal_core__DOT___004885_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1aa0b795__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b92__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052740_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h2a05cb02__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004883_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1aa0b795__0)))))))))));
    vlSelf->wasmetal_core__DOT___005293_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h30461973__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b93__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053143_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h5621a27e__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005291_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h30461973__0)))))))))));
    vlSelf->wasmetal_core__DOT___051966_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003531_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003457_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc01dbaa7__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3b04a080__0)))))))));
    vlSelf->wasmetal_core__DOT___003533_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc01dbaa7__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b75__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052788_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h71c3dfae__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003531_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hc01dbaa7__0)))))))))));
    vlSelf->wasmetal_core__DOT___051972_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005223_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005291_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3a3933c4__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h30461973__0)))))))));
    vlSelf->wasmetal_core__DOT___005225_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3a3933c4__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b94__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053145_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h7b7ca35d__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005223_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3a3933c4__0)))))))))));
    vlSelf->wasmetal_core__DOT___004127_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h18b22471__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b76__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052790_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9946d772__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004125_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h18b22471__0)))))))))));
    vlSelf->wasmetal_core__DOT___052049_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004199_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004125_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3b77bad1__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h18b22471__0)))))))));
    vlSelf->wasmetal_core__DOT___004201_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b77bad1__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b77__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052792_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_ha028a74d__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004199_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3b77bad1__0)))))))))));
    vlSelf->__VdfgTmp_he04a0e99__0 = (((IData)(vlSelf->wasmetal_core__DOT___003549_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2657a63f__0))));
    vlSelf->wasmetal_core__DOT___003551_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2657a63f__0))));
    vlSelf->wasmetal_core__DOT___004645_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd76f194b__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b78__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052794_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hce8127e9__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004643_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hd76f194b__0)))))))))));
    vlSelf->wasmetal_core__DOT___004145_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3a5851b5__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b108__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053203_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h8294d615__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004143_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3a5851b5__0)))))))))));
    vlSelf->wasmetal_core__DOT___004219_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8e96b5b6__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b109__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053201_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h563364ee__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004217_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h8e96b5b6__0)))))))))));
    vlSelf->__VdfgTmp_h8b084513__0 = (((IData)(vlSelf->wasmetal_core__DOT___004661_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1b531bc8__0))));
    vlSelf->wasmetal_core__DOT___004663_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1b531bc8__0))));
    vlSelf->wasmetal_core__DOT___004053_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h559eadff__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b82__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053135_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h36663d57__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004051_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h559eadff__0)))))))))));
    vlSelf->wasmetal_core__DOT___004071_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he222bc5e__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b114__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053228_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h1008ab3f__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004069_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he222bc5e__0)))))))))));
    vlSelf->wasmetal_core__DOT___003243_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcb1226e0__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b65__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052642_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51bf3013__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003241_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hcb1226e0__0)))))))))));
    vlSelf->__VdfgTmp_h8783294b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005341_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1f619b05__0))));
    vlSelf->wasmetal_core__DOT___005343_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1f619b05__0))));
    vlSelf->__VdfgTmp_ha0b12c43__0 = (((IData)(vlSelf->wasmetal_core__DOT___003259_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hff0b1f3c__0))));
    vlSelf->wasmetal_core__DOT___003261_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff0b1f3c__0))));
    vlSelf->wasmetal_core__DOT___003607_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h24f58f01__0))));
    vlSelf->wasmetal_core__DOT___051961_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005019_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he20a0bf9__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h1c23d9bd__0)))))))));
    vlSelf->wasmetal_core__DOT___005361_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1c23d9bd__0))));
    vlSelf->__VdfgTmp_hae654b01__0 = (((IData)(vlSelf->wasmetal_core__DOT___003623_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf661f789__0))));
    vlSelf->wasmetal_core__DOT___003625_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf661f789__0))));
    vlSelf->wasmetal_core__DOT___052326_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004069_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003909_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he222bc5e__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h945f14c8__0)))))))));
    vlSelf->wasmetal_core__DOT___003911_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h945f14c8__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b116__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053234_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h57ccb970__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003909_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h945f14c8__0)))))))))));
    vlSelf->wasmetal_core__DOT___003391_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8889c5b6__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b117__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053236_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hc33bf0b0__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003389_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h8889c5b6__0)))))))))));
    vlSelf->wasmetal_core__DOT___003323_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9046ca2f__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b118__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053238_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9c74c594__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003321_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h9046ca2f__0)))))))))));
    vlSelf->__VdfgTmp_hdcdc0b33__0 = (((IData)(vlSelf->wasmetal_core__DOT___003835_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3e1bf990__0))));
    vlSelf->wasmetal_core__DOT___003837_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3e1bf990__0))));
    vlSelf->wasmetal_core__DOT___052340_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004143_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003853_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3a5851b5__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h72f11ee8__0)))))))));
    vlSelf->wasmetal_core__DOT___003855_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h72f11ee8__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b115__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053232_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hac420052__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003853_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h72f11ee8__0)))))))))));
    vlSelf->wasmetal_core__DOT___003929_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5c1149ce__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b84__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053137_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf4f843fa__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003927_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h5c1149ce__0)))))))))));
    vlSelf->wasmetal_core__DOT___003409_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb5e938__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b85__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062383_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h84403644__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003407_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdfb5e938__0)))))))))));
    vlSelf->wasmetal_core__DOT___003341_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hec05375a__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b86__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053139_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hd77b503a__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003339_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hec05375a__0)))))))))));
    vlSelf->wasmetal_core__DOT___004275_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc280317b__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b81__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053133_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51c7c353__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004273_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hc280317b__0)))))))))));
    vlSelf->wasmetal_core__DOT___052339_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004291_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004217_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h4896ffc2__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h8e96b5b6__0)))))))));
    vlSelf->wasmetal_core__DOT___004293_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4896ffc2__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b113__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053230_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_heb838ef1__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004291_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h4896ffc2__0)))))))))));
    vlSelf->wasmetal_core__DOT___003163_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb6d33cfc__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b64__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052640_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h50808fd0__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003161_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hb6d33cfc__0)))))))))));
    vlSelf->wasmetal_core__DOT___005071_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9ff07be6__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b120__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053242_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hc01010d2__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005069_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h9ff07be6__0)))))))))));
    vlSelf->wasmetal_core__DOT___003181_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3cd3193e__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b96__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053149_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h0e59039e__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003179_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3cd3193e__0)))))))))));
    vlSelf->wasmetal_core__DOT___052043_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003753_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003605_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h09110191__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h24f58f01__0)))))))));
    vlSelf->wasmetal_core__DOT___003755_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09110191__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b72__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052745_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he96756cd__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003753_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h09110191__0)))))))))));
    vlSelf->wasmetal_core__DOT___005089_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8a29f22b__0))));
    vlSelf->__VdfgTmp_h4c8e22c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___003771_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h5234eb1f__0))));
    vlSelf->wasmetal_core__DOT___003773_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5234eb1f__0))));
    vlSelf->wasmetal_core__DOT___003979_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0f7cbf8b__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b80__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053131_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hbef8f541__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003977_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h0f7cbf8b__0)))))))))));
    vlSelf->__VdfgTmp_h6806bd5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___003995_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h082bf779__0))));
    vlSelf->wasmetal_core__DOT___003997_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h082bf779__0))));
    vlSelf->wasmetal_core__DOT___005591_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfb9f47b1__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b127__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053165_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9e0385bc__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005589_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hfb9f47b1__0)))))))))));
    vlSelf->wasmetal_core__DOT___051979_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004569_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004421_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6d398ac8__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h37bfe82f__0)))))))));
    vlSelf->wasmetal_core__DOT___004571_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d398ac8__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b71__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052743_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hd2a6e22a__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004569_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h6d398ac8__0)))))))))));
    vlSelf->wasmetal_core__DOT___052320_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004587_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003321_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hce07ecc6__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h9046ca2f__0)))))))));
    vlSelf->wasmetal_core__DOT___004589_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hce07ecc6__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b103__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053176_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hc2746ec0__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004587_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hce07ecc6__0)))))))))));
    vlSelf->wasmetal_core__DOT___005609_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd6eb77c__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b95__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053147_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h802db31a__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005607_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hbd6eb77c__0)))))))))));
    vlSelf->wasmetal_core__DOT___052044_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003679_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004643_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hdd586d2e__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hd76f194b__0)))))))));
    vlSelf->wasmetal_core__DOT___003681_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd586d2e__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b79__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052798_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h95f4bf2d__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003679_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd586d2e__0)))))))))));
    vlSelf->__VdfgTmp_he6df8ac0__0 = (((IData)(vlSelf->wasmetal_core__DOT___003697_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2e7cac69__0))));
    vlSelf->wasmetal_core__DOT___003699_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2e7cac69__0))));
    vlSelf->__VdfgTmp_h533e26e9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005137_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc8258b97__0))));
    vlSelf->wasmetal_core__DOT___005139_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc8258b97__0))));
    vlSelf->__VdfgTmp_h106a7f5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005155_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2f54f550__0))));
    vlSelf->wasmetal_core__DOT___005157_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2f54f550__0))));
    vlSelf->__VdfgTmp_h98b5e894__0 = (((IData)(vlSelf->wasmetal_core__DOT___005643_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h10b5f536__0))));
    vlSelf->wasmetal_core__DOT___005645_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h10b5f536__0))));
    vlSelf->wasmetal_core__DOT___001165_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001159_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001158_)));
    vlSelf->wasmetal_core__DOT___001143_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001137_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001136_)));
    vlSelf->wasmetal_core__DOT___001121_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001115_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001114_)));
    vlSelf->wasmetal_core__DOT___001099_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001093_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001092_)));
    vlSelf->wasmetal_core__DOT___001077_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001071_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001070_)));
    vlSelf->wasmetal_core__DOT___001055_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001049_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001048_)));
    vlSelf->wasmetal_core__DOT___001033_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001027_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001026_)));
    vlSelf->wasmetal_core__DOT___001011_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001005_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001004_)));
    vlSelf->__VdfgTmp_hf33ae1e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___003883_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h55f26059__0))));
    vlSelf->wasmetal_core__DOT___003885_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h55f26059__0))));
    vlSelf->__VdfgTmp_hccc0d080__0 = (((IData)(vlSelf->wasmetal_core__DOT___004099_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4b0186c1__0))));
    vlSelf->wasmetal_core__DOT___004101_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4b0186c1__0))));
    vlSelf->wasmetal_core__DOT___000989_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000961_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000960_)));
}
