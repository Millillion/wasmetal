#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__11(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__11\n"); );
    // Init
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_6;
    VlWide<3>/*95:0*/ __Vtemp_12;
    VlWide<3>/*95:0*/ __Vtemp_18;
    VlWide<3>/*95:0*/ __Vtemp_24;
    VlWide<3>/*95:0*/ __Vtemp_30;
    VlWide<4>/*127:0*/ __Vtemp_38;
    VlWide<4>/*127:0*/ __Vtemp_44;
    VlWide<4>/*127:0*/ __Vtemp_50;
    VlWide<4>/*127:0*/ __Vtemp_56;
    VlWide<4>/*127:0*/ __Vtemp_62;
    // Body
    vlSelf->wasmetal_core__DOT___066710_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066709_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066708_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x11U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b20__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066793_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066792_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066791_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x12U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b21__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065287_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065284_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065283_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054055_)))))))));
    vlSelf->wasmetal_core__DOT___065732_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065724_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065723_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054071_)))))))));
    vlSelf->wasmetal_core__DOT___066954_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066953_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066952_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x14U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069646_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0xcU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xfU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b79__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069643_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b79__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b79__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0xfU))))))))));
    vlSelf->wasmetal_core__DOT___069713_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0xfU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x12U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b82__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069710_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b82__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b82__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x12U))))))))));
    vlSelf->wasmetal_core__DOT___069757_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xfU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x11U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x14U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b84__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069754_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b84__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b84__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x14U))))))))));
    vlSelf->wasmetal_core__DOT___069800_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x11U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x13U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x16U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b86__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069797_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b86__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b86__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x16U))))))))));
    vlSelf->wasmetal_core__DOT___066302_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066299_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066298_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054095_)))))))));
    vlSelf->wasmetal_core__DOT___067446_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067444_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067443_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1bU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b30__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069823_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b87__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x15U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___065792_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065789_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065788_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054075_)))))))));
    vlSelf->wasmetal_core__DOT___065888_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065885_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065884_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054079_)))))))));
    vlSelf->wasmetal_core__DOT___068471_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068467_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068466_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054215_)))))))));
    vlSelf->wasmetal_core__DOT___068017_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068013_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068012_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054199_)))))))));
    vlSelf->wasmetal_core__DOT___069008_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069005_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069004_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054237_)))))))));
    vlSelf->wasmetal_core__DOT___062407_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b94__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b94__05d)))))));
    vlSelf->wasmetal_core__DOT___069968_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069964_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069963_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b94__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 0x1cU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->wasmetal_core__DOT___069967_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x1bU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1eU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___066209_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066203_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066202_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054091_)))))))));
    vlSelf->wasmetal_core__DOT___066385_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066384_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066383_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b16__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___068147_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068142_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068141_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054203_)))))))));
    vlSelf->wasmetal_core__DOT___066624_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066623_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066622_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x10U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b19__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066875_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066873_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b22__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065399_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054059_)))))));
    vlSelf->wasmetal_core__DOT___062385_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b85__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x14U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b85__05d)))))));
    vlSelf->wasmetal_core__DOT___069778_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x10U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x12U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x15U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069775_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b85__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x15U))))))))));
    vlSelf->wasmetal_core__DOT___062411_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b95__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1eU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b95__05d)))))));
    vlSelf->wasmetal_core__DOT___069987_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x1cU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (vlSelf->insn_y 
                                                                                >> 0x1fU)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069984_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b95__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (vlSelf->mem_rdata[2U] 
                                                                          >> 0x1fU)))))))));
    __Vtemp_1[0U] = (IData)((((QData)((IData)((1U & 
                                               (8U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d)))))) 
                              << 0x3fU) | (((QData)((IData)(
                                                            (1U 
                                                             & (8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d)))))) 
                                            << 0x3eU) 
                                           | (((QData)((IData)(
                                                               (1U 
                                                                & (8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))) 
                                               << 0x3dU) 
                                              | (((QData)((IData)(
                                                                  (1U 
                                                                   & (8U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))) 
                                                  << 0x3cU) 
                                                 | (((QData)((IData)(
                                                                     (1U 
                                                                      & (8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b59__05d)))))) 
                                                     << 0x3bU) 
                                                    | (((QData)((IData)(
                                                                        (1U 
                                                                         & (8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d)))))) 
                                                        << 0x3aU) 
                                                       | (((QData)((IData)(
                                                                           (1U 
                                                                            & (8U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b57__05d)))))) 
                                                           << 0x39U) 
                                                          | (((QData)((IData)(
                                                                              (1U 
                                                                               & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d)))))) 
                                                              << 0x38U) 
                                                             | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d)))))) 
                                                                 << 0x37U) 
                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d)))))) 
                                                                    << 0x36U) 
                                                                   | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d)))))) 
                                                                       << 0x35U) 
                                                                      | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d)))))) 
                                                                          << 0x34U) 
                                                                         | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d)))))) 
                                                                             << 0x33U) 
                                                                            | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d)))))) 
                                                                                << 0x32U) 
                                                                               | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d)))))) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d)))))) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d)))))) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d)))))) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d)))))) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d)))))) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d)))))) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d)))))) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d)))))) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d)))))) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d)))))) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d)))))) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d)))))) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d)))))) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d)))))) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d)))))) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d)))))) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d)))))) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d))) 
                                                                                << 0x1fU) 
                                                                                | ((0x40000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d))) 
                                                                                << 0x1eU)) 
                                                                                | ((0x20000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b29__05d))) 
                                                                                << 0x1dU)) 
                                                                                | ((0x10000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b28__05d))) 
                                                                                << 0x1cU)) 
                                                                                | ((0x8000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b27__05d))) 
                                                                                << 0x1bU)) 
                                                                                | ((0x4000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b26__05d))) 
                                                                                << 0x1aU)) 
                                                                                | ((0x2000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b25__05d))) 
                                                                                << 0x19U)) 
                                                                                | ((0x1000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d))) 
                                                                                << 0x18U)) 
                                                                                | ((0x800000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b23__05d))) 
                                                                                << 0x17U)) 
                                                                                | ((0x400000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b22__05d))) 
                                                                                << 0x16U)) 
                                                                                | ((0x200000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b21__05d))) 
                                                                                << 0x15U)) 
                                                                                | ((0x100000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b20__05d))) 
                                                                                << 0x14U)) 
                                                                                | ((0x80000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b19__05d))) 
                                                                                << 0x13U)) 
                                                                                | ((0x40000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b18__05d))) 
                                                                                << 0x12U)) 
                                                                                | ((0x20000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b17__05d))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b16__05d))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b15__05d))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b7__05d))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b6__05d))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b4__05d))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b3__05d))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    __Vtemp_1[1U] = (IData)(((((QData)((IData)((1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d)))))) 
                               << 0x3fU) | (((QData)((IData)(
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d)))))) 
                                             << 0x3eU) 
                                            | (((QData)((IData)(
                                                                (1U 
                                                                 & (8U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))) 
                                                << 0x3dU) 
                                               | (((QData)((IData)(
                                                                   (1U 
                                                                    & (8U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))) 
                                                   << 0x3cU) 
                                                  | (((QData)((IData)(
                                                                      (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b59__05d)))))) 
                                                      << 0x3bU) 
                                                     | (((QData)((IData)(
                                                                         (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d)))))) 
                                                         << 0x3aU) 
                                                        | (((QData)((IData)(
                                                                            (1U 
                                                                             & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b57__05d)))))) 
                                                            << 0x39U) 
                                                           | (((QData)((IData)(
                                                                               (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d)))))) 
                                                               << 0x38U) 
                                                              | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d)))))) 
                                                                  << 0x37U) 
                                                                 | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d)))))) 
                                                                     << 0x36U) 
                                                                    | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d)))))) 
                                                                        << 0x35U) 
                                                                       | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d)))))) 
                                                                           << 0x34U) 
                                                                          | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d)))))) 
                                                                              << 0x33U) 
                                                                             | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d)))))) 
                                                                                << 0x32U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d)))))) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d)))))) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d)))))) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d)))))) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d)))))) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d)))))) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d)))))) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d)))))) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d)))))) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d)))))) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d)))))) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d)))))) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d)))))) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d)))))) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d)))))) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d)))))) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d)))))) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d)))))) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d))) 
                                                                                << 0x1fU) 
                                                                                | ((0x40000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d))) 
                                                                                << 0x1eU)) 
                                                                                | ((0x20000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b29__05d))) 
                                                                                << 0x1dU)) 
                                                                                | ((0x10000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b28__05d))) 
                                                                                << 0x1cU)) 
                                                                                | ((0x8000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b27__05d))) 
                                                                                << 0x1bU)) 
                                                                                | ((0x4000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b26__05d))) 
                                                                                << 0x1aU)) 
                                                                                | ((0x2000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b25__05d))) 
                                                                                << 0x19U)) 
                                                                                | ((0x1000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d))) 
                                                                                << 0x18U)) 
                                                                                | ((0x800000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b23__05d))) 
                                                                                << 0x17U)) 
                                                                                | ((0x400000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b22__05d))) 
                                                                                << 0x16U)) 
                                                                                | ((0x200000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b21__05d))) 
                                                                                << 0x15U)) 
                                                                                | ((0x100000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b20__05d))) 
                                                                                << 0x14U)) 
                                                                                | ((0x80000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b19__05d))) 
                                                                                << 0x13U)) 
                                                                                | ((0x40000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b18__05d))) 
                                                                                << 0x12U)) 
                                                                                | ((0x20000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b17__05d))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b16__05d))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b15__05d))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b7__05d))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b6__05d))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b4__05d))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b3__05d))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) 
                             >> 0x20U));
    __Vtemp_6[2U] = ((0x20U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                        << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b69__05d))) 
                               << 5U)) | ((0x10U & 
                                           ((8U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b68__05d))) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((8U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b67__05d))) 
                                               << 3U)) 
                                             | ((4U 
                                                 & ((8U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b66__05d))) 
                                                    << 2U)) 
                                                | ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b65__05d))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b64__05d)))))))));
    __Vtemp_12[2U] = ((0x800U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b75__05d))) 
                                 << 0xbU)) | ((0x400U 
                                               & ((8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b74__05d))) 
                                                  << 0xaU)) 
                                              | ((0x200U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d))) 
                                                     << 9U)) 
                                                 | ((0x100U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b72__05d))) 
                                                        << 8U)) 
                                                    | ((0x80U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b71__05d))) 
                                                           << 7U)) 
                                                       | ((0x40U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b70__05d))) 
                                                              << 6U)) 
                                                          | __Vtemp_6[2U]))))));
    __Vtemp_18[2U] = ((0x20000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b81__05d))) 
                                   << 0x11U)) | ((0x10000U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b80__05d))) 
                                                     << 0x10U)) 
                                                 | ((0x8000U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b79__05d))) 
                                                        << 0xfU)) 
                                                    | ((0x4000U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b78__05d))) 
                                                           << 0xeU)) 
                                                       | ((0x2000U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b77__05d))) 
                                                              << 0xdU)) 
                                                          | ((0x1000U 
                                                              & ((8U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b76__05d))) 
                                                                 << 0xcU)) 
                                                             | __Vtemp_12[2U]))))));
    __Vtemp_24[2U] = ((0x800000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b87__05d))) 
                                    << 0x17U)) | ((0x400000U 
                                                   & ((8U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b86__05d))) 
                                                      << 0x16U)) 
                                                  | ((0x200000U 
                                                      & ((8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d))) 
                                                         << 0x15U)) 
                                                     | ((0x100000U 
                                                         & ((8U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b84__05d))) 
                                                            << 0x14U)) 
                                                        | ((0x80000U 
                                                            & ((8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b83__05d))) 
                                                               << 0x13U)) 
                                                           | ((0x40000U 
                                                               & ((8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b82__05d))) 
                                                                  << 0x12U)) 
                                                              | __Vtemp_18[2U]))))));
    __Vtemp_30[2U] = ((0x20000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b93__05d))) 
                                      << 0x1dU)) | 
                      ((0x10000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b92__05d))) 
                                       << 0x1cU)) | 
                       ((0x8000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b91__05d))) 
                                       << 0x1bU)) | 
                        ((0x4000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b90__05d))) 
                                        << 0x1aU)) 
                         | ((0x2000000U & ((8U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b89__05d))) 
                                           << 0x19U)) 
                            | ((0x1000000U & ((8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b88__05d))) 
                                              << 0x18U)) 
                               | __Vtemp_24[2U]))))));
    __Vtemp_38[3U] = ((0x20U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b101__05d))) 
                                << 5U)) | ((0x10U & 
                                            ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b100__05d))) 
                                             << 4U)) 
                                           | ((8U & 
                                               ((8U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b99__05d))) 
                                                << 3U)) 
                                              | ((4U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b97__05d))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b96__05d)))))))));
    __Vtemp_44[3U] = ((0x800U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b107__05d))) 
                                 << 0xbU)) | ((0x400U 
                                               & ((8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b106__05d))) 
                                                  << 0xaU)) 
                                              | ((0x200U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b105__05d))) 
                                                     << 9U)) 
                                                 | ((0x100U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b104__05d))) 
                                                        << 8U)) 
                                                    | ((0x80U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b103__05d))) 
                                                           << 7U)) 
                                                       | ((0x40U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b102__05d))) 
                                                              << 6U)) 
                                                          | __Vtemp_38[3U]))))));
    __Vtemp_50[3U] = ((0x20000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b113__05d))) 
                                   << 0x11U)) | ((0x10000U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d))) 
                                                     << 0x10U)) 
                                                 | ((0x8000U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b111__05d))) 
                                                        << 0xfU)) 
                                                    | ((0x4000U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b110__05d))) 
                                                           << 0xeU)) 
                                                       | ((0x2000U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b109__05d))) 
                                                              << 0xdU)) 
                                                          | ((0x1000U 
                                                              & ((8U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b108__05d))) 
                                                                 << 0xcU)) 
                                                             | __Vtemp_44[3U]))))));
    __Vtemp_56[3U] = ((0x800000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b119__05d))) 
                                    << 0x17U)) | ((0x400000U 
                                                   & ((8U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b118__05d))) 
                                                      << 0x16U)) 
                                                  | ((0x200000U 
                                                      & ((8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b117__05d))) 
                                                         << 0x15U)) 
                                                     | ((0x100000U 
                                                         & ((8U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b116__05d))) 
                                                            << 0x14U)) 
                                                        | ((0x80000U 
                                                            & ((8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b115__05d))) 
                                                               << 0x13U)) 
                                                           | ((0x40000U 
                                                               & ((8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b114__05d))) 
                                                                  << 0x12U)) 
                                                              | __Vtemp_50[3U]))))));
    __Vtemp_62[3U] = ((0x20000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b125__05d))) 
                                      << 0x1dU)) | 
                      ((0x10000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b124__05d))) 
                                       << 0x1cU)) | 
                       ((0x8000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b123__05d))) 
                                       << 0x1bU)) | 
                        ((0x4000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b122__05d))) 
                                        << 0x1aU)) 
                         | ((0x2000000U & ((8U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b121__05d))) 
                                           << 0x19U)) 
                            | ((0x1000000U & ((8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b120__05d))) 
                                              << 0x18U)) 
                               | __Vtemp_56[3U]))))));
    vlSelf->result_data[0U] = __Vtemp_1[0U];
    vlSelf->result_data[1U] = __Vtemp_1[1U];
    vlSelf->result_data[2U] = (((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d))) 
                                << 0x1fU) | ((0x40000000U 
                                              & ((8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d))) 
                                                 << 0x1eU)) 
                                             | __Vtemp_30[2U]));
    vlSelf->result_data[3U] = (((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b127__05d))) 
                                << 0x1fU) | ((0x40000000U 
                                              & ((8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b126__05d))) 
                                                 << 0x1eU)) 
                                             | __Vtemp_62[3U]));
    vlSelf->wasmetal_core__DOT___067397_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067395_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b29__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___067144_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067142_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067141_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b26__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069201_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069198_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069197_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054245_)))))))));
    vlSelf->wasmetal_core__DOT___068513_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054217_)))))));
    vlSelf->wasmetal_core__DOT___067099_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067098_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067097_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b25__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___067025_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067024_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067023_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x15U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b24__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___067253_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067252_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067251_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b27__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065047_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065044_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054047_)))))));
    vlSelf->wasmetal_core__DOT___064887_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064883_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054043_)))))));
    vlSelf->wasmetal_core__DOT___065160_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065157_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054051_)))))));
    vlSelf->wasmetal_core__DOT___067538_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067537_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067536_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1cU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___064722_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064717_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064716_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054039_)))))))));
    vlSelf->wasmetal_core__DOT___064456_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064451_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064450_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053990_)))))))));
    vlSelf->wasmetal_core__DOT___053060_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053059_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053058_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053057_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053056_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053055_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053054_)))))))));
    vlSelf->wasmetal_core__DOT___053044_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053023_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053022_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053021_)))));
    vlSelf->wasmetal_core__DOT___053045_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053043_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053042_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053041_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___053030_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053029_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___053028_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053027_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xc0000000aULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053025_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053024_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha0b2a3dd__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___031968_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053478_))));
    vlSelf->wasmetal_core__DOT___031967_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053478_))));
    vlSelf->wasmetal_core__DOT___069275_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050361_))));
    vlSelf->wasmetal_core__DOT___062606_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053483_)))));
    vlSelf->wasmetal_core__DOT___062605_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050361_))));
    vlSelf->wasmetal_core__DOT___050441_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050361_))));
    vlSelf->wasmetal_core__DOT___050362_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030721_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->__VdfgTmp_hf224ceca__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h6eb17b7a__0));
    vlSelf->__VdfgTmp_hc52c52a3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h43b9ff93__0));
    vlSelf->wasmetal_core__DOT___007371_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9ebbc558__0))))));
    vlSelf->__VdfgTmp_hbda9acd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hab3c597f__0));
    vlSelf->wasmetal_core__DOT___007370_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h84d68e3f__0))))));
    vlSelf->__VdfgTmp_hc57757c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h437f0271__0));
    vlSelf->__VdfgTmp_h855fc881__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h83a675b5__0));
    vlSelf->__VdfgTmp_h40471efb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hc08ecb6b__0));
    vlSelf->wasmetal_core__DOT___007345_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5f14afc9__0))))));
    vlSelf->wasmetal_core__DOT___007484_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb18976f4__0))))));
    vlSelf->wasmetal_core__DOT___007344_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hdc49a285__0))))));
    vlSelf->__VdfgTmp_h40b73a73__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hc03ee7e3__0));
    vlSelf->__VdfgTmp_h624c4f06__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hde99fb2e__0));
    vlSelf->__VdfgTmp_h2e0ea116__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h1ad74d3e__0));
    vlSelf->__VdfgTmp_h6ab1a2ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd6444f5a__0));
    vlSelf->__VdfgTmp_hc3b7ffa9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h3d3eaa9d__0));
    vlSelf->wasmetal_core__DOT___007472_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h68d11ed0__0))))));
    vlSelf->__VdfgTmp_he34a288c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h5d9bd5b8__0));
    vlSelf->__VdfgTmp_hffa75465__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h692f01d1__0));
    vlSelf->__VdfgTmp_h127745a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h0e7ef094__0));
    vlSelf->wasmetal_core__DOT___007285_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hce0059e1__0))))));
    vlSelf->__VdfgTmp_h41aaabca__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hbf3b567a__0));
    vlSelf->wasmetal_core__DOT___007284_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h86c1a93d__0))))));
    vlSelf->__VdfgTmp_h8f363e22__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h79bfec12__0));
    vlSelf->__VdfgTmp_h878f9978__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h815644ec__0));
    vlSelf->__VdfgTmp_h5ba532b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hc530df9f__0));
    vlSelf->wasmetal_core__DOT___007258_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8916279c__0))))));
    vlSelf->__VdfgTmp_h7690c014__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hf2656e40__0));
    vlSelf->wasmetal_core__DOT___007257_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbb98e230__0))))));
    vlSelf->__VdfgTmp_hd1dc222f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h4f29d017__0));
    vlSelf->__VdfgTmp_h01d6394a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hff1fe4fa__0));
    vlSelf->__VdfgTmp_h6ee5998b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd9f044bb__0));
    vlSelf->__VdfgTmp_hc18298c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h3f534570__0));
    vlSelf->__VdfgTmp_hee719ca8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h5a84499c__0));
    vlSelf->wasmetal_core__DOT___007231_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h890db370__0))))));
    vlSelf->wasmetal_core__DOT___007230_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7751d301__0))))));
    vlSelf->__VdfgTmp_h88de5544__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h782800f0__0));
    vlSelf->wasmetal_core__DOT___007373_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_haf65e04e__0))))));
    vlSelf->__VdfgTmp_h7146d025__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hef8f7e11__0));
    vlSelf->wasmetal_core__DOT___007347_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha4d9f57f__0))))));
    vlSelf->wasmetal_core__DOT___007730_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h707c99af__0))))));
    vlSelf->wasmetal_core__DOT___007719_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2e164c3d__0))))));
    vlSelf->wasmetal_core__DOT___007287_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4f418a9b__0))))));
    vlSelf->__VdfgTmp_h4fcd3c01__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hb918ea35__0));
    vlSelf->wasmetal_core__DOT___007260_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbb6385ec__0))))));
    vlSelf->__VdfgTmp_h15014ab6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h13d4f79e__0));
    vlSelf->wasmetal_core__DOT___007233_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9fcdfa16__0))))));
    vlSelf->wasmetal_core__DOT___007397_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7a210d44__0))))));
    vlSelf->__VdfgTmp_h62d1863a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hde24342a__0));
    vlSelf->wasmetal_core__DOT___007396_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb4659c85__0))))));
    vlSelf->__VdfgTmp_h4a43ab44__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hb69256f0__0));
    vlSelf->__VdfgTmp_h69484b9c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd79df6c8__0));
    vlSelf->__VdfgTmp_h1fccf85f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h0919a607__0));
    vlSelf->wasmetal_core__DOT___007399_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ce01618__0))))));
    vlSelf->__VdfgTmp_h6127a0a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hdfae4d94__0));
    vlSelf->__VdfgTmp_h284fdec6__0 = (((IData)(vlSelf->wasmetal_core__DOT___054692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054691_));
    vlSelf->__VdfgTmp_hffdded68__0 = (((IData)(vlSelf->wasmetal_core__DOT___054709_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054708_));
    vlSelf->__VdfgTmp_h705cf6e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054688_));
    vlSelf->__VdfgTmp_h3265141f__0 = (((IData)(vlSelf->wasmetal_core__DOT___054706_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054705_));
    vlSelf->__VdfgTmp_hff6b6a1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___054778_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054777_));
    vlSelf->__VdfgTmp_h6ad9b652__0 = (((IData)(vlSelf->wasmetal_core__DOT___054675_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054674_));
    vlSelf->__VdfgTmp_ha89e6386__0 = (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054698_));
    vlSelf->__VdfgTmp_h014e1215__0 = (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007882_));
    vlSelf->__VdfgTmp_h73cf3648__0 = (((IData)(vlSelf->wasmetal_core__DOT___054675_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054692_))));
    vlSelf->__VdfgTmp_hebcfe313__0 = (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054682_));
    vlSelf->wasmetal_core__DOT___061606_ = (1U & (IData)(
                                                         (0xff55550f0f3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054709_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054706_)))))))));
    vlSelf->__VdfgTmp_h52d73039__0 = (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054706_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054709_))));
    vlSelf->__VdfgTmp_hbbe663c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054701_));
    vlSelf->wasmetal_core__DOT___061450_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007247_))));
    vlSelf->__VdfgTmp_ha9869a20__0 = (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007870_));
    vlSelf->__VdfgTmp_hef814ba9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007886_));
    vlSelf->wasmetal_core__DOT___061449_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007274_))));
    vlSelf->__VdfgTmp_h1327a702__0 = (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007894_));
    vlSelf->wasmetal_core__DOT___061994_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007334_))));
    vlSelf->__VdfgTmp_hc9c602ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007907_));
    vlSelf->__VdfgTmp_h57efbd27__0 = (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007915_));
    vlSelf->__VdfgTmp_hc326eb38__0 = (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007923_));
    vlSelf->__VdfgTmp_h5d6eeee4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007431_));
    vlSelf->__VdfgTmp_hfd347d5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007431_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007946_));
    vlSelf->wasmetal_core__DOT___061452_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007246_))));
    vlSelf->__VdfgTmp_hf8763693__0 = (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007246_));
    vlSelf->__VdfgTmp_h83053a2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007246_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007954_));
    vlSelf->__VdfgTmp_h5af86920__0 = (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007273_));
    vlSelf->__VdfgTmp_h67f18e55__0 = (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007962_));
    vlSelf->wasmetal_core__DOT___061451_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007273_))));
    vlSelf->__VdfgTmp_h8d9b1452__0 = (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007300_));
    vlSelf->__VdfgTmp_h64194573__0 = (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007970_));
    vlSelf->__VdfgTmp_h413b142d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007983_));
    vlSelf->__VdfgTmp_h744f9b35__0 = (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007991_));
    vlSelf->__VdfgTmp_h8f3d454e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007999_));
    vlSelf->wasmetal_core__DOT___007340_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h504ea901__0)))));
    vlSelf->__VdfgTmp_h34f2d08e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008294_));
    vlSelf->__VdfgTmp_ha1697357__0 = (((IData)(vlSelf->wasmetal_core__DOT___007246_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007248_));
    vlSelf->__VdfgTmp_h6deef1cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008115_));
    vlSelf->__VdfgTmp_h03e9ae47__0 = (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008123_));
    vlSelf->wasmetal_core__DOT___061457_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007275_))));
    vlSelf->__VdfgTmp_hdc04b3f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007302_));
    vlSelf->__VdfgTmp_h2596a796__0 = (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008131_));
    vlSelf->__VdfgTmp_hc5a57f40__0 = (((IData)(vlSelf->wasmetal_core__DOT___007333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007335_));
    vlSelf->__VdfgTmp_h169cd931__0 = (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008144_));
    vlSelf->__VdfgTmp_h584cbf3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008152_));
    vlSelf->wasmetal_core__DOT___057461_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007387_))));
    vlSelf->__VdfgTmp_h7102b895__0 = (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008160_));
    vlSelf->__VdfgTmp_hb9d2a0bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008257_));
    vlSelf->__VdfgTmp_hb372eb0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008198_));
    vlSelf->wasmetal_core__DOT___061464_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007279_))));
    vlSelf->__VdfgTmp_h9cbd3d8a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008206_));
    vlSelf->__VdfgTmp_h29bca591__0 = (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008219_));
    vlSelf->wasmetal_core__DOT___007771_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h528a2190__0)))));
    vlSelf->__VdfgTmp_h93fbfa25__0 = (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008227_));
    vlSelf->__VdfgTmp_h7e30f70e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008235_));
    vlSelf->__VdfgTmp_h05980b33__0 = (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007278_));
    vlSelf->__VdfgTmp_h3fcf358e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008273_));
    vlSelf->wasmetal_core__DOT___061466_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007278_))));
    vlSelf->__VdfgTmp_h37472320__0 = (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007305_));
    vlSelf->__VdfgTmp_h31aacdc1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008281_));
    vlSelf->__VdfgTmp_h4ce8c3b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008302_));
    vlSelf->__VdfgTmp_h8565eee7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008310_));
    vlSelf->__VdfgTmp_ha7da5f58__0 = (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008190_));
    vlSelf->__VdfgTmp_h05777dd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007280_));
    vlSelf->__VdfgTmp_hd69bf43a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008424_));
    vlSelf->wasmetal_core__DOT___061472_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007280_))));
    vlSelf->__VdfgTmp_hfcd73105__0 = (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007307_));
    vlSelf->__VdfgTmp_h2577a83c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008432_));
    vlSelf->__VdfgTmp_hdf1f98b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008453_));
    vlSelf->__VdfgTmp_hb79381c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008461_));
    vlSelf->wasmetal_core__DOT___061467_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007251_))));
    vlSelf->__VdfgTmp_h860ce20a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007251_));
    vlSelf->__VdfgTmp_h9d165bb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008265_));
    vlSelf->__VdfgTmp_hf1275c5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007253_));
    vlSelf->__VdfgTmp_he43dd87d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008416_));
    vlSelf->__VdfgTmp_h551248b6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007248_));
    vlSelf->__VdfgTmp_h2c8d302e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008040_));
    vlSelf->__VdfgTmp_h80fea7fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007275_));
    vlSelf->__VdfgTmp_ha7321d4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008048_));
    vlSelf->wasmetal_core__DOT___061455_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007276_))));
    vlSelf->__VdfgTmp_h8499ba72__0 = (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007302_));
    vlSelf->__VdfgTmp_h0cb45e24__0 = (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008056_));
    vlSelf->__VdfgTmp_hb187f8bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007335_));
    vlSelf->__VdfgTmp_h9ba8d2dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008069_));
    vlSelf->__VdfgTmp_hf20faaf0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007361_));
    vlSelf->__VdfgTmp_h7ef390f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008077_));
    vlSelf->__VdfgTmp_ha38d193b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007387_));
    vlSelf->__VdfgTmp_hf0027c26__0 = (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008085_));
    vlSelf->wasmetal_core__DOT___007341_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3c09d3eb__0)))));
    vlSelf->__VdfgTmp_h797b2590__0 = (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007280_));
    vlSelf->__VdfgTmp_hb1732b67__0 = (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008349_));
    vlSelf->wasmetal_core__DOT___061470_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007281_))));
    vlSelf->__VdfgTmp_hb4c136ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007307_));
    vlSelf->__VdfgTmp_h68f6955f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008357_));
    vlSelf->__VdfgTmp_h372c3d93__0 = (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007366_));
    vlSelf->__VdfgTmp_haaeadd36__0 = (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008378_));
    vlSelf->__VdfgTmp_h447558a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007392_));
    vlSelf->__VdfgTmp_hd96a7b90__0 = (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008386_));
    vlSelf->__VdfgTmp_hca913760__0 = (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007253_));
    vlSelf->__VdfgTmp_he7f579a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008341_));
    vlSelf->wasmetal_core__DOT___062163_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007413_))));
    vlSelf->__VdfgTmp_h57d78adc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007931_));
    vlSelf->wasmetal_core__DOT___061458_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007248_))));
    vlSelf->__VdfgTmp_hc63c8631__0 = (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008107_));
    vlSelf->wasmetal_core__DOT___061465_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007252_))));
    vlSelf->__VdfgTmp_h5ad8b1f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007432_));
    vlSelf->__VdfgTmp_h69457925__0 = (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008182_));
    vlSelf->wasmetal_core__DOT___061456_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007249_))));
    vlSelf->__VdfgTmp_hd163f969__0 = (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007430_));
    vlSelf->__VdfgTmp_h84d44246__0 = (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008032_));
    vlSelf->wasmetal_core__DOT___007772_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc859778d__0)))));
    vlSelf->wasmetal_core__DOT___061651_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061648_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007412_))));
    vlSelf->__VdfgTmp_h69142c13__0 = (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008007_));
    vlSelf->wasmetal_core__DOT___061650_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007414_)))));
    vlSelf->wasmetal_core__DOT___061763_ = (1U & (0x7f7f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048385_)))))));
    vlSelf->wasmetal_core__DOT___057671_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007414_))));
    vlSelf->__VdfgTmp_h567d9bb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008168_));
    vlSelf->__VdfgTmp_hd3c93d4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008243_));
    vlSelf->__VdfgTmp_h92b02c04__0 = (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008318_));
    vlSelf->wasmetal_core__DOT___061649_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007419_))));
    vlSelf->wasmetal_core__DOT___057602_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007419_))));
    vlSelf->__VdfgTmp_hb23bd85a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008469_));
    vlSelf->__VdfgTmp_h5b76ab14__0 = (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007414_));
    vlSelf->__VdfgTmp_hd8562240__0 = (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008093_));
    vlSelf->__VdfgTmp_h2df8dd7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007419_));
    vlSelf->__VdfgTmp_h2225d234__0 = (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008394_));
    vlSelf->wasmetal_core__DOT___067605_ = (1U & (0xc500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054478_))))));
    vlSelf->wasmetal_core__DOT___068554_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x10U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067748_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068019_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 6U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068078_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 7U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068154_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 9U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068239_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xaU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068292_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xbU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068346_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xcU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068401_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xdU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067896_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 4U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067962_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 5U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067809_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 3U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068425_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xeU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068477_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xfU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068103_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 8U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___063790_ = (1U & (IData)(
                                                         (0xc5f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063789_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063788_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048277_)))))))));
    vlSelf->wasmetal_core__DOT___068606_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054478_))));
    vlSelf->wasmetal_core__DOT___065935_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066080_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067311_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065601_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065799_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066398_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066524_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066646_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066768_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066892_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065410_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065186_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065697_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066275_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066312_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066601_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066851_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067453_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065895_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067341_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066122_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___064896_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065061_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065300_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067074_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067152_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054158_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067193_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066969_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067479_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___064729_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___064464_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050371_)))));
    vlSelf->wasmetal_core__DOT___050383_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050371_))));
    vlSelf->wasmetal_core__DOT___067604_ = (1U & (0xf00088U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b64__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x39U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___052843_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052841_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052840_))));
    vlSelf->wasmetal_core__DOT___019808_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((7U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052806_))));
    vlSelf->wasmetal_core__DOT___019809_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071471_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)))))));
    vlSelf->wasmetal_core__DOT___039935_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039878_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034647_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039883_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034658_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039882_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039881_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034680_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039880_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039871_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039879_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034697_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039876_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034698_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039875_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034699_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039874_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034637_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039873_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034638_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039884_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034639_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039885_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034640_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039886_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034641_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039893_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034642_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039909_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034643_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039898_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034644_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039897_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034645_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039896_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034646_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039895_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034648_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039877_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034649_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039894_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034650_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039891_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039890_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034652_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039889_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034653_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039888_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034654_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039899_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034655_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039900_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034656_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039901_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034657_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039908_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034659_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039924_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034660_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___039913_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034661_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT___039912_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034662_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT___039911_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034663_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___039910_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034664_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b35__05d)))))));
    vlSelf->wasmetal_core__DOT___039892_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034665_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT___039887_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___039906_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034667_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT___039905_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034668_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT___039904_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___039903_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034671_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT___039914_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034672_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT___039915_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034673_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___039916_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034674_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___039923_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034675_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT___039940_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034676_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___039928_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b47__05d)))))));
    vlSelf->wasmetal_core__DOT___039927_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034678_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT___039926_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___039925_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034681_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT___039907_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034682_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT___039902_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034683_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___039921_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034684_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b53__05d)))))));
    vlSelf->wasmetal_core__DOT___039920_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034685_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___039919_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034686_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___039918_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034687_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b56__05d)))))));
    vlSelf->wasmetal_core__DOT___039929_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034688_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b57__05d)))))));
    vlSelf->wasmetal_core__DOT___039930_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034689_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___039931_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034690_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d)))))));
    vlSelf->wasmetal_core__DOT___039939_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034692_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d)))))));
    vlSelf->wasmetal_core__DOT___039955_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___039944_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034694_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b62__05d)))))));
    vlSelf->wasmetal_core__DOT___039943_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___039998_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039942_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039941_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039922_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039917_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039937_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039936_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039934_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039933_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039945_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039946_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039947_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039954_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039970_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039959_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039958_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039957_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039956_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039938_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039932_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039952_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039951_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039950_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039949_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039960_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039961_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039962_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039969_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b27__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039985_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039974_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039973_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___039972_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT___039971_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT___039953_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b33__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___039948_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b34__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b35__05d)))))));
    vlSelf->wasmetal_core__DOT___039967_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b35__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT___039966_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___039965_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b37__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT___039964_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b38__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT___039975_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b39__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___039976_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b40__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT___039977_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b41__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT___039984_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b42__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___040001_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b43__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___039989_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b44__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT___039988_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b45__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___039987_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b46__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b47__05d)))))));
    vlSelf->wasmetal_core__DOT___039986_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b47__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT___039968_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b48__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___039963_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b49__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT___039982_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b50__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT___039981_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b51__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___039980_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b53__05d)))))));
    vlSelf->wasmetal_core__DOT___039979_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b53__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___039990_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b54__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___039991_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b55__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d)))))));
    vlSelf->wasmetal_core__DOT___039992_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d)))))));
    vlSelf->wasmetal_core__DOT___040000_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___040015_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d)))))));
    vlSelf->wasmetal_core__DOT___040005_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d)))))));
    vlSelf->wasmetal_core__DOT___040004_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___040003_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d)))))));
    vlSelf->wasmetal_core__DOT___040002_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___040038_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___040037_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___040032_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___040031_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___040036_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128721___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___040035_ = (1U & (IData)(
                                                         (0xa2aea2a2a2a2a2a2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054542_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___040034_ = (1U & (IData)(
                                                         (0xa2a2aeaeaea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128721___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___040033_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128721___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___019810_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->reset) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052730_))));
    vlSelf->wasmetal_core__DOT___060773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060720_))));
    vlSelf->wasmetal_core__DOT___019220_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060720_))));
    vlSelf->wasmetal_core__DOT___055434_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h384cc7f9__0)))));
    vlSelf->wasmetal_core__DOT___055723_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008107_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008182_))))));
    vlSelf->wasmetal_core__DOT___055753_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008115_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008190_))))));
    vlSelf->wasmetal_core__DOT___055754_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008416_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054767_))))));
    vlSelf->wasmetal_core__DOT___055755_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008265_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008341_))))));
    vlSelf->wasmetal_core__DOT___055761_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008123_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008198_))))));
    vlSelf->wasmetal_core__DOT___055783_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008131_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008206_))))));
    vlSelf->wasmetal_core__DOT___055784_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008432_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051493_))))));
    vlSelf->wasmetal_core__DOT___055785_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008281_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008357_))))));
    vlSelf->wasmetal_core__DOT___055795_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008144_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008219_))))));
    vlSelf->wasmetal_core__DOT___055796_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008445_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054899_))))));
    vlSelf->wasmetal_core__DOT___055797_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008294_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008370_))))));
    vlSelf->wasmetal_core__DOT___055811_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008152_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008227_))))));
    vlSelf->wasmetal_core__DOT___055812_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008453_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054948_))))));
    vlSelf->wasmetal_core__DOT___055813_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008378_))))));
    vlSelf->wasmetal_core__DOT___055832_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008160_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008235_))))));
    vlSelf->wasmetal_core__DOT___055343_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9ea6e74c__0)))));
    vlSelf->wasmetal_core__DOT___055379_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfa99a91b__0)))));
    vlSelf->wasmetal_core__DOT___055380_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4d3bb7ef__0)))));
    vlSelf->wasmetal_core__DOT___055381_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008190_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008265_))))));
    vlSelf->wasmetal_core__DOT___055504_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9a7588ae__0)))));
    vlSelf->wasmetal_core__DOT___055505_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf10e2308__0)))));
    vlSelf->wasmetal_core__DOT___055506_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008206_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008281_))))));
    vlSelf->wasmetal_core__DOT___055524_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc06d6619__0)))));
    vlSelf->wasmetal_core__DOT___055525_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb8ee9e15__0)))));
    vlSelf->wasmetal_core__DOT___055526_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008219_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008294_))))));
    vlSelf->wasmetal_core__DOT___055600_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h90a7e66d__0)))));
    vlSelf->wasmetal_core__DOT___055601_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8de67bd6__0)))));
    vlSelf->wasmetal_core__DOT___055602_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008227_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008302_))))));
    vlSelf->wasmetal_core__DOT___055656_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd9d9e38d__0)))));
    vlSelf->wasmetal_core__DOT___055418_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055422_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055423_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055424_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055425_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055426_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054816_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055427_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054815_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055428_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054820_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055429_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054818_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055416_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055419_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008349_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055667_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78e7e4d8__0)))));
    vlSelf->wasmetal_core__DOT___055855_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008168_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008243_))))));
    vlSelf->wasmetal_core__DOT___055317_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008257_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055320_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008408_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055321_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055326_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054708_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055328_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054698_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055329_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054701_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055330_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054688_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055331_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055332_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054674_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055333_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054682_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055367_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054768_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055369_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055370_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054769_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055371_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054777_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055372_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054775_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055373_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054781_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055374_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054779_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055492_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051491_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051496_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055495_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055496_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055497_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054860_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054865_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055499_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054863_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055512_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054898_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055514_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054901_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055515_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054900_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055516_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054907_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055517_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054906_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055518_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054909_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055519_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054908_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055588_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054949_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055590_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054951_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055591_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054950_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055592_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054957_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055593_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054956_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055594_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054959_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055595_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054958_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055638_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008310_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055640_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008461_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055641_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008386_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055644_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055645_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054987_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055646_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054990_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055647_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055648_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055649_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054995_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055650_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055651_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055663_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055665_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008469_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055666_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008394_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055671_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055034_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055672_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055673_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055036_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055674_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055675_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055676_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055677_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055046_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055678_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055044_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___055325_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055322_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054672_)))))))));
    vlSelf->wasmetal_core__DOT___054686_ = (1U & (IData)(
                                                         (0xbf00bfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_x 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054672_)))))))));
    vlSelf->wasmetal_core__DOT___054676_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054672_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053773_)))));
    vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___033033_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___033033_))));
    vlSelf->wasmetal_core__DOT___063833_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042140_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___042082_ = (1U & (0xb2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___042140_)))));
    vlSelf->wasmetal_core__DOT___063865_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063860_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))))));
    vlSelf->wasmetal_core__DOT___042294_ = (1U & (0xb2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0)))))));
    vlSelf->wasmetal_core__DOT___030093_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h30dbdcaa__0))));
    vlSelf->wasmetal_core__DOT___030221_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h30dbdcaa__0))));
    vlSelf->wasmetal_core__DOT___064469_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h78ac86a2__0))));
    vlSelf->wasmetal_core__DOT___042094_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063930_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))))));
    vlSelf->wasmetal_core__DOT___030104_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0817566b__0))));
    vlSelf->wasmetal_core__DOT___030232_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0817566b__0))));
    vlSelf->wasmetal_core__DOT___063728_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff00fff1ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff4ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab155f14__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___064522_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048342_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hab155f14__0))))));
    vlSelf->wasmetal_core__DOT___072045_ = (1U & (0x17U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab155f14__0))));
    vlSelf->wasmetal_core__DOT___064734_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h769a413d__0))));
    vlSelf->wasmetal_core__DOT___063986_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11b4d04e__0))));
    vlSelf->wasmetal_core__DOT___064901_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11b4d04e__0))));
    vlSelf->wasmetal_core__DOT___042175_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063934_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063930_))));
    vlSelf->__VdfgTmp_hb39b7a55__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hf4328824__0)) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hab155f14__0))));
    vlSelf->wasmetal_core__DOT___042355_ = (1U & (IData)(
                                                         (0xf571ffff71500000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070507_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001476_)))))))));
    vlSelf->wasmetal_core__DOT___042154_ = (1U & (IData)(
                                                         (0xbb2bffff2b220000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0))))))));
    vlSelf->wasmetal_core__DOT___042096_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063934_))));
    vlSelf->wasmetal_core__DOT___064500_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc4a801d__0))));
    vlSelf->wasmetal_core__DOT___001937_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcc4a801d__0))))));
    vlSelf->wasmetal_core__DOT___063985_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h425ce738__0))));
    vlSelf->wasmetal_core__DOT___065199_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h425ce738__0))));
    vlSelf->wasmetal_core__DOT___001339_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h776ad714__0))))));
    vlSelf->wasmetal_core__DOT___064502_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46c82ccf__0))));
    vlSelf->wasmetal_core__DOT___065307_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46c82ccf__0))));
    vlSelf->wasmetal_core__DOT___063948_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063947_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063946_))));
    vlSelf->wasmetal_core__DOT___001723_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbfd77ec1__0))))));
    vlSelf->wasmetal_core__DOT___063984_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf2f5c69c__0))));
    vlSelf->wasmetal_core__DOT___065424_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf2f5c69c__0))));
    vlSelf->wasmetal_core__DOT___065616_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8926b37c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065607_))));
    vlSelf->wasmetal_core__DOT___066283_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8926b37c__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065611_)))));
    vlSelf->wasmetal_core__DOT___063886_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h776ad714__0))))));
    vlSelf->wasmetal_core__DOT___001340_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h03893f91__0))))));
    vlSelf->wasmetal_core__DOT___064501_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61294ca4__0))));
    vlSelf->wasmetal_core__DOT___001724_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h61294ca4__0))))));
    vlSelf->wasmetal_core__DOT___063990_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h42e273c2__0))));
    vlSelf->wasmetal_core__DOT___065707_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h42e273c2__0))));
    vlSelf->wasmetal_core__DOT___042179_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063949_))));
    vlSelf->wasmetal_core__DOT___072046_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hdbb03d5c__0)))))))));
    vlSelf->wasmetal_core__DOT___001341_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_haa154e86__0))))));
    vlSelf->wasmetal_core__DOT___064506_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hadcc7972__0))));
    vlSelf->wasmetal_core__DOT___065809_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hadcc7972__0))));
    vlSelf->wasmetal_core__DOT___042098_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063939_))));
    vlSelf->wasmetal_core__DOT___001725_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h06dc5af9__0))))));
    vlSelf->wasmetal_core__DOT___063989_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e67285f__0))));
    vlSelf->wasmetal_core__DOT___065905_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e67285f__0))));
    vlSelf->wasmetal_core__DOT___063891_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_haa154e86__0))))));
    vlSelf->wasmetal_core__DOT___001342_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9d768121__0))))));
    vlSelf->wasmetal_core__DOT___064505_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfdfbee0__0))));
    vlSelf->wasmetal_core__DOT___065929_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfdfbee0__0))));
    vlSelf->wasmetal_core__DOT___042180_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063939_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063955_))));
    vlSelf->wasmetal_core__DOT___001726_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdd9104ee__0))))));
    vlSelf->wasmetal_core__DOT___063992_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hea943ba9__0))));
    vlSelf->wasmetal_core__DOT___066074_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hea943ba9__0))));
    vlSelf->wasmetal_core__DOT___042099_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063955_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063954_))));
    vlSelf->wasmetal_core__DOT___001495_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb5d0a138__0))))));
    vlSelf->wasmetal_core__DOT___064508_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09210432__0))));
    vlSelf->wasmetal_core__DOT___066131_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09210432__0))));
    vlSelf->wasmetal_core__DOT___001729_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9040377d__0))))));
    vlSelf->wasmetal_core__DOT___063991_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h688ac52f__0))));
    vlSelf->wasmetal_core__DOT___066266_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h688ac52f__0))));
    vlSelf->wasmetal_core__DOT___066321_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066319_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065607_))));
    vlSelf->wasmetal_core__DOT___067488_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066281_)))));
    vlSelf->wasmetal_core__DOT___042181_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063954_))));
    vlSelf->__VdfgTmp_h144113a8__0 = ((2U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h5b878e76__0)) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_hdbb03d5c__0))));
    vlSelf->__VdfgTmp_h3a315b1c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5b878e76__0)))));
    vlSelf->wasmetal_core__DOT___063892_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0))))));
    vlSelf->wasmetal_core__DOT___001496_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7dd7d539__0))))));
    vlSelf->wasmetal_core__DOT___066529_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h061491a4__0))));
    vlSelf->wasmetal_core__DOT___064493_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h061491a4__0))));
    vlSelf->wasmetal_core__DOT___001731_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9e6b526c__0))))));
    vlSelf->wasmetal_core__DOT___066610_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb776b144__0))));
    vlSelf->wasmetal_core__DOT___042101_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063951_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063950_))));
    vlSelf->wasmetal_core__DOT___063976_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3613bfb2__0))));
    vlSelf->wasmetal_core__DOT___001498_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3613bfb2__0))))));
    vlSelf->wasmetal_core__DOT___066651_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5145bf91__0))));
    vlSelf->wasmetal_core__DOT___064492_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5145bf91__0))));
    vlSelf->wasmetal_core__DOT___000176_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h898e287a__0))))));
    vlSelf->wasmetal_core__DOT___066773_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h19f2f351__0))));
    vlSelf->wasmetal_core__DOT___063979_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h19f2f351__0))));
    vlSelf->wasmetal_core__DOT___042183_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063950_))));
    vlSelf->wasmetal_core__DOT___001654_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8b010904__0))))));
    vlSelf->wasmetal_core__DOT___066860_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1479cba4__0))));
    vlSelf->wasmetal_core__DOT___064495_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1479cba4__0))));
    vlSelf->wasmetal_core__DOT___042102_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063952_))));
    vlSelf->wasmetal_core__DOT___000177_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2a3dbf89__0))))));
    vlSelf->wasmetal_core__DOT___066897_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cc94077__0))));
    vlSelf->wasmetal_core__DOT___063978_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cc94077__0))));
    vlSelf->wasmetal_core__DOT___063878_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0))))));
    vlSelf->wasmetal_core__DOT___001655_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf22a37d9__0))))));
    vlSelf->wasmetal_core__DOT___066979_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c78c397__0))));
    vlSelf->wasmetal_core__DOT___064494_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c78c397__0))));
    vlSelf->wasmetal_core__DOT___042184_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063952_))));
    vlSelf->wasmetal_core__DOT___000178_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4438b1a5__0))))));
    vlSelf->wasmetal_core__DOT___042362_ = (1U & (IData)(
                                                         (0xbb2bffff2b220000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070508_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2be29f89__0))))))));
    vlSelf->wasmetal_core__DOT___067083_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfc0b7a98__0))));
    vlSelf->wasmetal_core__DOT___063973_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfc0b7a98__0))));
    vlSelf->wasmetal_core__DOT___042161_ = (1U & (IData)(
                                                         (0xf571ffff71500000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd856a856__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h879a663d__0))))))));
    vlSelf->wasmetal_core__DOT___042103_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063942_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd856a856__0))))));
    vlSelf->wasmetal_core__DOT___001656_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6cb2731d__0))))));
    vlSelf->wasmetal_core__DOT___067161_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9e2f527__0))));
    vlSelf->wasmetal_core__DOT___064489_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9e2f527__0))));
    vlSelf->wasmetal_core__DOT___000179_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf4e6deac__0))))));
    vlSelf->wasmetal_core__DOT___067202_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h992e16df__0))));
    vlSelf->wasmetal_core__DOT___063972_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h992e16df__0))));
    vlSelf->__VdfgTmp_h7da480c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___063932_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063931_));
    vlSelf->__VdfgTmp_h66324e1d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x6996U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((0x96U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2e3bd00c__0)) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___072034_))))))));
    vlSelf->wasmetal_core__DOT___063872_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0))))));
    vlSelf->wasmetal_core__DOT___001657_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdba97a87__0))))));
    vlSelf->wasmetal_core__DOT___067306_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd466e7f__0))));
    vlSelf->wasmetal_core__DOT___064488_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd466e7f__0))));
    vlSelf->wasmetal_core__DOT___042342_ = (1U & (IData)(
                                                         (0xbb2bffff2b220000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070509_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0f13542d__0))))))));
    vlSelf->wasmetal_core__DOT___042141_ = (1U & (IData)(
                                                         (0xf571ffff71500000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3b20cbca__0))))))));
    vlSelf->wasmetal_core__DOT___000572_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_had26118d__0))))));
    vlSelf->wasmetal_core__DOT___067336_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha86315e0__0))));
    vlSelf->wasmetal_core__DOT___063970_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha86315e0__0))));
    vlSelf->wasmetal_core__DOT___001660_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h717e9861__0))))));
    vlSelf->wasmetal_core__DOT___064486_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h15099632__0))));
    vlSelf->wasmetal_core__DOT___042165_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063937_)))));
    vlSelf->wasmetal_core__DOT___000573_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2bd8c9ed__0))))));
    vlSelf->wasmetal_core__DOT___064920_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064487_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h2e505808__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h717e9861__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___063867_));
    vlSelf->wasmetal_core__DOT___064014_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048342_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff00fff1ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff4ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha04cce4c__0)))))))))))))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d)))))))))))));
    vlSelf->wasmetal_core__DOT___063971_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha04cce4c__0))));
    vlSelf->wasmetal_core__DOT___042142_ = (1U & (0x8ecf0c8eU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___070494_)))))));
    vlSelf->wasmetal_core__DOT___030117_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8ccb0334__0))));
    vlSelf->wasmetal_core__DOT___030245_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8ccb0334__0))));
    vlSelf->__VdfgTmp_h607fca11__0 = ((2U & ((0x40U 
                                              >> ((4U 
                                                   & ((9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d)))) 
                                             << 1U)) 
                                      | (1U & (0x4000U 
                                               >> (
                                                   (8U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d)))))));
    vlSelf->__VdfgTmp_hff973d2d__0 = ((2U & ((0x40U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                   << 2U) 
                                                  | ((2U 
                                                      & ((9U 
                                                          >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___000657_)))) 
                                             << 1U)) 
                                      | (1U & (0x4000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000635_)))))));
    vlSelf->wasmetal_core__DOT___042343_ = (1U & (0xbf233b02U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)))))))));
    vlSelf->wasmetal_core__DOT___042095_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063937_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (9U 
                                                            >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)))))));
    vlSelf->__VdfgTmp_h0033f05e__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf0c7a5d6__0)))));
    vlSelf->wasmetal_core__DOT___042344_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8c76b9e6__0))))))));
    vlSelf->wasmetal_core__DOT___042143_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8c76b9e6__0))))))));
    vlSelf->wasmetal_core__DOT___042168_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063961_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___063922_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46a92a2b__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h101b2914__0))))));
    vlSelf->wasmetal_core__DOT___042345_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h46a92a2b__0))))))));
    vlSelf->wasmetal_core__DOT___042144_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h46a92a2b__0))))))));
    vlSelf->wasmetal_core__DOT___042346_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hae598e91__0))))))));
    vlSelf->wasmetal_core__DOT___042145_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hae598e91__0))))))));
    vlSelf->wasmetal_core__DOT___063915_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063912_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha5696d37__0))))));
    vlSelf->wasmetal_core__DOT___042347_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h22bd1162__0))))))));
    vlSelf->wasmetal_core__DOT___042146_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h22bd1162__0))))))));
    vlSelf->__VdfgTmp_h1065bf0b__0 = ((2U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_he0af74c9__0)) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_ha0d25e26__0))));
    vlSelf->__VdfgTmp_h4e2d279b__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_he0af74c9__0)))));
    vlSelf->wasmetal_core__DOT___063916_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063914_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h22bd1162__0))))));
    vlSelf->wasmetal_core__DOT___063921_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063918_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7c266aa9__0))))));
    vlSelf->wasmetal_core__DOT___042166_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063964_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he88617ec__0))))));
    vlSelf->wasmetal_core__DOT___042348_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h503e9cd3__0))))))));
    vlSelf->wasmetal_core__DOT___042147_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h503e9cd3__0))))))));
    vlSelf->wasmetal_core__DOT___063901_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2489b5__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1e5c31ac__0))))));
    vlSelf->wasmetal_core__DOT___042349_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c2489b5__0))))))));
    vlSelf->wasmetal_core__DOT___042148_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c2489b5__0))))))));
    vlSelf->__VdfgTmp_h65785f77__0 = ((2U & ((0x40U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                   << 2U) 
                                                  | ((2U 
                                                      & ((9U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001168_)))) 
                                             << 1U)) 
                                      | (1U & (0x41000000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001146_))))))));
    vlSelf->__VdfgTmp_h67b52d18__0 = ((2U & ((0x40U 
                                              >> ((4U 
                                                   & ((9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d)))) 
                                             << 1U)) 
                                      | (1U & (0x41000000U 
                                               >> (
                                                   (0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d))))))));
    vlSelf->wasmetal_core__DOT___042177_ = (1U & (0x90090000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001146_)))))));
    vlSelf->wasmetal_core__DOT___064538_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063903_))));
    vlSelf->__VdfgTmp_had66fb55__0 = (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h1a9e6a0c__0));
    vlSelf->wasmetal_core__DOT___001707_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4575751b__0)))))));
    vlSelf->wasmetal_core__DOT___000921_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4575751b__0)))));
    vlSelf->wasmetal_core__DOT___063902_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h67451104__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1a9e6a0c__0))))));
    vlSelf->wasmetal_core__DOT___001313_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h67451104__0))))));
    vlSelf->wasmetal_core__DOT___001783_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h67451104__0))))));
    vlSelf->wasmetal_core__DOT___001708_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4fe6474e__0))))));
    vlSelf->wasmetal_core__DOT___000922_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4fe6474e__0))))));
    vlSelf->__VdfgTmp_h78a92bf8__0 = (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h60f9d0d9__0));
    vlSelf->__VdfgTmp_h9cfb7302__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x6996U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((0x96U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h74f7a068__0)) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (6U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h4a43881d__0))))))))));
    vlSelf->wasmetal_core__DOT___001709_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h131eee20__0)))))));
    vlSelf->wasmetal_core__DOT___000923_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h131eee20__0)))));
    vlSelf->wasmetal_core__DOT___063908_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfe7af35a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h60f9d0d9__0))))));
    vlSelf->wasmetal_core__DOT___001315_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfe7af35a__0))))));
    vlSelf->wasmetal_core__DOT___001785_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfe7af35a__0))))));
    vlSelf->__VdfgTmp_h7b621139__0 = ((4U & ((0x96U 
                                              >> (IData)(vlSelf->__VdfgTmp_h1811a1bb__0)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d)));
    vlSelf->wasmetal_core__DOT___001710_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd5d1004a__0))))));
    vlSelf->wasmetal_core__DOT___002233_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd5d1004a__0))))));
    vlSelf->__VdfgTmp_h75b63843__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h8f6175c0__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___063903_));
    vlSelf->__VdfgTmp_h8eb0ad88__0 = (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8f6175c0__0));
    vlSelf->wasmetal_core__DOT___001711_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4f90e104__0)))))));
    vlSelf->wasmetal_core__DOT___002234_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4f90e104__0)))));
    vlSelf->wasmetal_core__DOT___064507_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89e0a965__0))));
    vlSelf->wasmetal_core__DOT___066323_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89e0a965__0))));
    vlSelf->wasmetal_core__DOT___066403_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd14327b4__0))));
    vlSelf->wasmetal_core__DOT___063977_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd14327b4__0))));
    vlSelf->wasmetal_core__DOT___042100_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063945_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063935_))));
    vlSelf->wasmetal_core__DOT___042182_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063945_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063951_))));
    vlSelf->wasmetal_core__DOT___001730_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h238b010e__0))))));
    vlSelf->wasmetal_core__DOT___063877_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he924c244__0))))));
    vlSelf->wasmetal_core__DOT___001497_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he924c244__0))))));
    vlSelf->__VdfgTmp_hca6242ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___001286_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001285_));
    vlSelf->__VdfgTmp_hcbbf7a95__0 = (((IData)(vlSelf->wasmetal_core__DOT___001285_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001662_));
    vlSelf->__VdfgTmp_hec35f81b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000717_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000574_));
    vlSelf->__VdfgTmp_h0fd3d582__0 = (((IData)(vlSelf->wasmetal_core__DOT___000718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000717_));
    vlSelf->wasmetal_core__DOT___001809_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h33bf650d__0))))));
    vlSelf->wasmetal_core__DOT___001900_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d)))))));
    vlSelf->wasmetal_core__DOT___001949_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d)))))));
    vlSelf->wasmetal_core__DOT___001252_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d)))))));
    vlSelf->wasmetal_core__DOT___001677_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d)))))));
    vlSelf->wasmetal_core__DOT___001742_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d)))))));
    vlSelf->wasmetal_core__DOT___002197_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d)))))));
    vlSelf->wasmetal_core__DOT___002517_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3fcac4a1__0))))));
    vlSelf->wasmetal_core__DOT___002394_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d)))))));
    vlSelf->wasmetal_core__DOT___002922_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5fb0de62__0))))));
    vlSelf->wasmetal_core__DOT___002640_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048862_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048861_))))));
    vlSelf->wasmetal_core__DOT___002679_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048842_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048841_))))));
    vlSelf->wasmetal_core__DOT___002432_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d)))))));
    vlSelf->wasmetal_core__DOT___002798_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048860_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048859_))))));
    vlSelf->wasmetal_core__DOT___002840_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048685_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048684_))))));
    vlSelf->wasmetal_core__DOT___002354_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d)))))));
    vlSelf->wasmetal_core__DOT___002718_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048852_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048851_))))));
    vlSelf->wasmetal_core__DOT___002758_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048850_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048849_))))));
    vlSelf->wasmetal_core__DOT___003053_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048923_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048922_))))));
    vlSelf->wasmetal_core__DOT___002882_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048870_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048869_))))));
    vlSelf->wasmetal_core__DOT___002077_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d)))))));
    vlSelf->wasmetal_core__DOT___002114_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d)))))));
    vlSelf->wasmetal_core__DOT___002151_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d)))))));
    vlSelf->wasmetal_core__DOT___002478_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048730_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048729_))))));
}
