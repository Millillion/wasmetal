#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__34(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__34\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006729_;
    wasmetal_core__DOT___006729_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036630_;
    wasmetal_core__DOT___036630_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036842_;
    wasmetal_core__DOT___036842_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036843_;
    wasmetal_core__DOT___036843_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036844_;
    wasmetal_core__DOT___036844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056735_;
    wasmetal_core__DOT___056735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057091_;
    wasmetal_core__DOT___057091_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127436___O;
    wasmetal_core__DOT____Vcellout___127436___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128060___O;
    wasmetal_core__DOT____Vcellout___128060___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128080___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128080___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128080___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128080___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128097___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128097___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128098___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128098___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128098___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128098___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128098___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128098___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128114___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128114___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128115___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128115___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128115___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128115___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128115___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128115___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128124___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128124___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128125___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128125___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128125___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128125___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128125___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128125___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128438___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128438___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128438___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128438___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128666___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128666___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128666___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128666___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h5013759b__0;
    __VdfgTmp_h5013759b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h7baa8c24__0;
    __VdfgTmp_h7baa8c24__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd2b66780__0;
    __VdfgTmp_hd2b66780__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8a9ed06f__0;
    __VdfgTmp_h8a9ed06f__0 = 0;
    CData/*2:0*/ __VdfgTmp_ha1bf32a7__0;
    __VdfgTmp_ha1bf32a7__0 = 0;
    CData/*2:0*/ __VdfgTmp_hfc0d441b__0;
    __VdfgTmp_hfc0d441b__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6ec4eab1__0;
    __VdfgTmp_h6ec4eab1__0 = 0;
    CData/*1:0*/ __VdfgTmp_h635c29e2__0;
    __VdfgTmp_h635c29e2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h986ee838__0;
    __VdfgTmp_h986ee838__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___012957_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h3c43f86a__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057389_)))))));
    vlSelf->__VdfgTmp_h3b7e1022__0 = (((IData)(vlSelf->wasmetal_core__DOT___012780_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3c43f86a__0));
    vlSelf->wasmetal_core__DOT___012926_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010085_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                    ? 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___012779_))))
                                                    : 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012780_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___012778_)))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012782_))));
    vlSelf->wasmetal_core__DOT___057447_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012782_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___011426_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xff00ffcfffafffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h140002d8__0)))))))));
    vlSelf->wasmetal_core__DOT___011550_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h140002d8__0))))))));
    vlSelf->wasmetal_core__DOT___011656_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011331_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h140002d8__0))))))));
    vlSelf->wasmetal_core__DOT___011128_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xff00ffcfffafffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hb3a32b8e__0)))))))));
    vlSelf->wasmetal_core__DOT___011082_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb3a32b8e__0))))))));
    vlSelf->__VdfgTmp_hfde06fd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb3a32b8e__0));
    vlSelf->wasmetal_core__DOT___013035_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdaecee48__0))))))));
    vlSelf->wasmetal_core__DOT___057537_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hdaecee48__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))));
    vlSelf->__VdfgTmp_h25b48e48__0 = (((IData)(vlSelf->wasmetal_core__DOT___013056_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hdaecee48__0));
    vlSelf->wasmetal_core__DOT___065822_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011781_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011780_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___012707_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd9ebd9b4__0)))))));
    vlSelf->wasmetal_core__DOT___012576_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9ebd9b4__0))));
    vlSelf->wasmetal_core__DOT___057098_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057090_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->__VdfgTmp_he11b9fc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___056891_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->__VdfgTmp_ha6c246b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___056771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___066419_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011296_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011294_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011293_)))))))));
    vlSelf->wasmetal_core__DOT___056668_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011294_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->wasmetal_core__DOT___056334_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011091_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->__VdfgTmp_hf218f314__0 = (((IData)(vlSelf->wasmetal_core__DOT___057577_) 
                                       << 3U) | ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                   & (IData)(
                                                             (0x555533330f0f00ffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                                      << 3U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h358fed79__0))))))) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___057627_))));
    __VdfgTmp_h7baa8c24__0 = ((2U & ((0x2bU >> (IData)(vlSelf->__VdfgTmp_h839fe08c__0)) 
                                     << 1U)) | (1U 
                                                & (0x2bU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___072212_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha7d2f4a8__0)))));
    vlSelf->__VdfgTmp_h84670069__0 = (((IData)(vlSelf->wasmetal_core__DOT___072199_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___072198_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h39564552__0)))));
    vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___134164___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036841_)) 
                 & (0x69U >> (IData)(vlSelf->__VdfgTmp_h1399f995__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127463___O 
        = (((8U & ((0xeU >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h13976eb2__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022737_)))));
    vlSelf->wasmetal_core__DOT___022741_ = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___023741_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d));
    wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d) {
        wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d;
        vlSelf->wasmetal_core__DOT___023931_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d;
    } else {
        wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023931_ = wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___006635_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003810_))))));
    vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006085_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022652_));
    vlSelf->wasmetal_core__DOT___019034_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019006_))));
    vlSelf->wasmetal_core__DOT___018274_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019006_))));
    vlSelf->wasmetal_core__DOT___017184_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019006_))));
    vlSelf->wasmetal_core__DOT___050115_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006051_))))));
    vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005948_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023449_));
    vlSelf->__VdfgTmp_h8ac5901b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013787_));
    vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013785_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023570_));
    vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___022786_)) 
                 & (1U >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0))));
    wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) {
        wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d;
        vlSelf->wasmetal_core__DOT___022889_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d;
    } else {
        wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022889_ = wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___070230_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053850_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b110__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049481_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049482_)))))))));
    vlSelf->wasmetal_core__DOT___070142_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053825_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x802aaaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b104__05d)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053823_)))))))));
    vlSelf->wasmetal_core__DOT___068094_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068093_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x802aaaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b40__05d)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053823_)))))))));
    vlSelf->wasmetal_core__DOT___070363_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053889_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xa802aaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b120__05d)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051322_)))))))));
    vlSelf->wasmetal_core__DOT___068910_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051334_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbfbfbfU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051331_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b56__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6a1d65be__0)))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb829d41d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051332_)))))))));
    vlSelf->wasmetal_core__DOT___069846_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053638_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b88__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0x1fe0000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7578f7f__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050641_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051330_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053634_))))))))))))));
    vlSelf->wasmetal_core__DOT___070125_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b103__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009512_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009513_)))))))));
    vlSelf->wasmetal_core__DOT___069826_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053585_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050981_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051291_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053581_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b87__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053582_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050795_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070347_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b119__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h47401135__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053883_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053581_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051293_)))))))))))));
    vlSelf->wasmetal_core__DOT___068863_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0xbbff33000f0f0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b55__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xef00efefULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___051294_) 
                                                                                << 5U) 
                                                                               | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051293_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xff55ccf0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h35851421__0)))))))))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h47401135__0))))))));
    vlSelf->wasmetal_core__DOT___069804_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053556_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050067_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051117_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053551_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b86__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053553_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050041_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070335_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b118__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051110_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051109_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053879_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053551_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051119_)))))))))))));
    vlSelf->wasmetal_core__DOT___051121_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051110_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b54__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051109_))))));
    vlSelf->wasmetal_core__DOT___069782_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053549_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051063_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051062_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053545_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b85__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xd1c40000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((0xc0aU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051065_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070323_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b117__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h37b9b4c8__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053875_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053545_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009523_)))))))))))));
    vlSelf->wasmetal_core__DOT___068763_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b53__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h37b9b4c8__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT___009501_)) 
                                                            & (IData)(
                                                                      (0xffffffff10ff1010ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___009524_) 
                                                                         << 5U) 
                                                                        | ((0x10U 
                                                                            & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 4U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009523_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009520_))))))))))))));
    vlSelf->wasmetal_core__DOT___070200_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053842_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b108__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xe01fffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050879_)))))))));
    vlSelf->wasmetal_core__DOT___070082_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053804_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b100__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x807fffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053802_)))))))));
    vlSelf->wasmetal_core__DOT___066721_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066717_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf7770000f333f333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065163_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066715_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b20__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053531_)))))))));
    vlSelf->wasmetal_core__DOT___070310_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053873_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b116__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xf807ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050722_)))))))));
    vlSelf->wasmetal_core__DOT___068714_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050724_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b52__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xf807ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009506_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050722_)))))))));
    vlSelf->wasmetal_core__DOT___067859_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053921_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf4ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051843_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051842_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051841_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053798_)))))))));
    vlSelf->wasmetal_core__DOT___069761_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053538_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x70U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b84__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0x7fff80000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 3U))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050705_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050704_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053534_))))))))))))));
    vlSelf->wasmetal_core__DOT___068307_ = (1U & (IData)(
                                                         (0xff00ff4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050882_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b44__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048681_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048680_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050880_)))))))));
    vlSelf->wasmetal_core__DOT___069102_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051556_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b60__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051553_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048673_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051554_)))))))));
    vlSelf->wasmetal_core__DOT___069929_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053668_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              >> 1U)) 
                                                                          | ((2U 
                                                                              & ((0xa300U 
                                                                                >> 
                                                                                ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051552_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053663_)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052603_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b92__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x6020U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                               << 3U) 
                                                                              | ((6U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052601_)))))))))))));
    vlSelf->wasmetal_core__DOT___067744_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054756_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f7700003f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050896_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050974_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053712_)))))))));
    vlSelf->wasmetal_core__DOT___069717_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052723_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049809_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049808_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052718_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b82__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052720_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | ((2U 
                                                                                & ((0xf0880000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070285_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b114__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049793_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049792_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053863_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052718_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049821_)))))))))))));
    vlSelf->wasmetal_core__DOT___049823_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049793_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b50__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049792_))))));
    vlSelf->wasmetal_core__DOT___070169_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050819_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b106__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xe00ee0000ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b106__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053832_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xbcU 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050868_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051660_)))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050818_))))))))))));
    vlSelf->wasmetal_core__DOT___051662_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050819_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b42__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050818_))))));
    vlSelf->wasmetal_core__DOT___069888_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053650_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x9f00df00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b90__05d) 
                                                                              << 3U) 
                                                                             | ((6U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053647_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051370_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051369_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053646_))))))))))))));
    vlSelf->wasmetal_core__DOT___070387_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053897_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b122__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051362_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051363_)))))))));
    vlSelf->wasmetal_core__DOT___069009_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b58__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051363_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051362_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051374_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___051373_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051372_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___067958_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067955_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x2202ff0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067953_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051989_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053811_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053810_)))))))));
    vlSelf->wasmetal_core__DOT___070110_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053814_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x48ccc8ccU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 4U) 
                                                                          | ((0xcU 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b102__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053811_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0xbbb0U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053810_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051764_))))))))))))));
    vlSelf->wasmetal_core__DOT___068416_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049542_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b46__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049539_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049538_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049537_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049540_)))))))));
    vlSelf->wasmetal_core__DOT___070437_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053912_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b126__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051609_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051610_)))))))));
    vlSelf->wasmetal_core__DOT___051621_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051610_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b62__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051609_))))));
    vlSelf->wasmetal_core__DOT___069739_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053523_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b83__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0xd1c40000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053519_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049897_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049896_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049895_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053518_))))))))))))));
    vlSelf->wasmetal_core__DOT___070297_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b115__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049882_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049881_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053867_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053518_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049902_)))))))))))));
    vlSelf->wasmetal_core__DOT___049904_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049882_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b51__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049881_))))));
    vlSelf->wasmetal_core__DOT___069558_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051840_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051839_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b75__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x2c00U 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051837_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___068254_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b43__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050842_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___050841_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050832_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050831_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___070183_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050842_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b107__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xe00ee0000ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b107__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053836_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xe1f5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                                << 3U) 
                                                                                | ((6U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050825_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050831_)))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050841_))))))))))));
    vlSelf->wasmetal_core__DOT___070399_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051517_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b123__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xbb00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053898_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051527_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053652_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051516_))))))))))));
    vlSelf->wasmetal_core__DOT___051529_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051517_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b59__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051516_))))));
    vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028122_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 9U)));
    vlSelf->wasmetal_core__DOT___067680_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053797_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b33__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053706_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009506_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053708_)))))))));
    vlSelf->wasmetal_core__DOT___066474_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066470_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf454545454545ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051593_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x44ff0fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b17__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h558c6a5e__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049740_))))))))))));
    vlSelf->wasmetal_core__DOT___067617_ = (1U & (IData)(
                                                         (0xff8f8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067616_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccffffa000f0ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b32__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051654_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009537_)))))))));
    vlSelf->wasmetal_core__DOT___069671_ = (1U & (0xfe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051894_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xaa33f00000000000ULL 
                                                                      >> 
                                                                      ((0x38U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___049719_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049718_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051889_)))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x802aaaaaaaaaaaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b80__05d))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009501_)))))));
    vlSelf->wasmetal_core__DOT___070261_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053857_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b112__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049695_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049696_)))))))));
    vlSelf->wasmetal_core__DOT___068515_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b48__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049696_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049695_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049724_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___049723_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049722_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___069991_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053699_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b95__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0xfe540000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053695_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053389_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051634_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051633_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053694_))))))))))))));
    vlSelf->wasmetal_core__DOT___070449_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053916_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b127__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051626_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051627_)))))))));
    vlSelf->wasmetal_core__DOT___051640_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051627_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b63__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051626_))))));
    vlSelf->wasmetal_core__DOT___069695_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052637_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa33f00000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049761_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049760_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052633_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b81__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xab300000U 
                                                                             >> 
                                                                             ((0x1cU 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049764_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052634_)))))))))))));
    vlSelf->wasmetal_core__DOT___070273_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b113__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049745_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049744_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053859_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052633_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049769_)))))))))))));
    vlSelf->wasmetal_core__DOT___049771_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049745_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b49__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049744_))))));
    vlSelf->wasmetal_core__DOT___069867_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053644_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051350_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051349_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053640_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b89__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xd1c40000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053641_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051351_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070375_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b121__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051343_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051342_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053891_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053640_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051355_)))))))))))));
    vlSelf->wasmetal_core__DOT___051357_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051343_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b57__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051342_))))));
    vlSelf->wasmetal_core__DOT___067915_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053530_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaa0ccc0fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053525_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b37__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha128d41e__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053528_)))))))));
    vlSelf->wasmetal_core__DOT___070215_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b109__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049336_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049334_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053844_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051857_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049245_)))))))))))));
    vlSelf->wasmetal_core__DOT___068361_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049336_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b45__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xd0U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b45__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049244_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049243_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)))) 
                                                                                << 1U)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049245_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049334_))))))))))));
    vlSelf->wasmetal_core__DOT___070424_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053908_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b125__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051577_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051578_)))))))));
    vlSelf->wasmetal_core__DOT___069152_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b61__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051578_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051577_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051588_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___051587_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051586_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___069950_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053687_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x1111f00000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053114_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x503U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x3333aaaaf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0x5cU 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc0f91dc6__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049132_))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xf0faaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049142_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0a02dc0e__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049120_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048585_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048584_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf502c6b2__0))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xf0faaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049747_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfbafed17__0))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049794_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049883_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4cf0cb93__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf0faaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051345_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7cd11e4f__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051364_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051518_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h36154466__0)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xfeff0000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053680_) 
                                                                                << 3U) 
                                                                                | (4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b93__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053684_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053112_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001625_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128114___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028847_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT____Vcellout___128079___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028467_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028466_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028465_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028464_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028430_)))));
    vlSelf->wasmetal_core__DOT___028434_ = ((IData)(vlSelf->wasmetal_core__DOT___028467_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003706_));
    wasmetal_core__DOT___128097___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028642_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004670_));
    vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029085_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    wasmetal_core__DOT___128124___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028954_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b14__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128437___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128437___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032260_)))));
    vlSelf->wasmetal_core__DOT___032264_ = ((IData)(vlSelf->wasmetal_core__DOT___001580_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___001580_)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028745_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->wasmetal_core__DOT___044907_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O))))))))));
    vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026457_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026423_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b12__05d));
    vlSelf->wasmetal_core__DOT___045017_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h77f7c585__0)))))))))));
    vlSelf->wasmetal_core__DOT___045041_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h77f7c585__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054075_)))))))));
    vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026667_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->wasmetal_core__DOT___070692_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054346_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 9U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027137_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127868___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026564_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026563_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026593_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026592_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026559_)))));
    vlSelf->wasmetal_core__DOT___026498_ = ((IData)(vlSelf->wasmetal_core__DOT___026564_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001426_));
    vlSelf->wasmetal_core__DOT___070795_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054345_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 9U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026937_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h5a182b30__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->wasmetal_core__DOT____Vcellout___128665___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128437___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034510_)))));
    vlSelf->wasmetal_core__DOT___034514_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001580_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030124_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d));
    vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030284_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d));
    wasmetal_core__DOT____Vcellout___128060___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028287_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028286_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028316_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028315_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028282_)))));
    vlSelf->wasmetal_core__DOT___028254_ = ((IData)(vlSelf->wasmetal_core__DOT___028287_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028222_));
    vlSelf->__VdfgTmp_hca11f007__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                             >> 1U)) 
                                      | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h48aaf6cb__0))));
    vlSelf->__VdfgTmp_h19390f5d__0 = ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h1065bf0b__0)) 
                                             << 2U)) 
                                      | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h48aaf6cb__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc8f262c3__0)))));
    vlSelf->__VdfgTmp_h0341114f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h4e2d279b__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc8f262c3__0)))));
    wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127953___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027335_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027334_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027396_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027395_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027330_)))));
    vlSelf->wasmetal_core__DOT___027270_ = ((IData)(vlSelf->wasmetal_core__DOT___027335_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b11__05d));
    vlSelf->wasmetal_core__DOT___023230_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006092_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb6ef8d81__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb6ef8d81__0)))));
    vlSelf->wasmetal_core__DOT___023229_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc21b3046__0))));
    vlSelf->wasmetal_core__DOT___023228_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fa4f51d__0))));
    vlSelf->wasmetal_core__DOT___023227_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005982_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h41461f4e__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h41461f4e__0)))));
    vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003810_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128143___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128478___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029130_)))));
    vlSelf->wasmetal_core__DOT___029134_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128478___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128326___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031052_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031051_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031050_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031049_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031016_)))));
    vlSelf->wasmetal_core__DOT___031020_ = ((IData)(vlSelf->wasmetal_core__DOT___031052_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->__VdfgTmp_h9cfb33d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___057090_) 
                                       << 2U) | ((2U 
                                                  & ((0x5300U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1c56b6c5__0)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (1U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___012405_))))));
    vlSelf->__VdfgTmp_h3b8e8d7c__0 = (((IData)(vlSelf->wasmetal_core__DOT___011091_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011024_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010085_)));
    vlSelf->__VdfgTmp_h7884ece4__0 = (((IData)(vlSelf->wasmetal_core__DOT___056772_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___056771_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h11d85c9f__0)));
    vlSelf->__VdfgTmp_hdf888c66__0 = (((IData)(vlSelf->wasmetal_core__DOT___011781_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h11d85c9f__0));
    vlSelf->wasmetal_core__DOT___067212_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056892_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056891_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heceb31a8__0))))))));
    vlSelf->wasmetal_core__DOT___056988_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0xf4f4f4f4ffffff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012216_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012215_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012214_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_heceb31a8__0))))))));
    vlSelf->wasmetal_core__DOT___065919_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012214_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3659b78c__0))));
    vlSelf->wasmetal_core__DOT___056906_ = (1U & (IData)(
                                                         (0xf0f000ee00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056892_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056891_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3659b78c__0))))))));
    vlSelf->wasmetal_core__DOT___057167_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012407_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h745845c2__0))));
    vlSelf->__VdfgTmp_h186e290b__0 = (((IData)(vlSelf->wasmetal_core__DOT___012574_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_h07e757d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___012574_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012607_));
    vlSelf->wasmetal_core__DOT___012752_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xccffaafff0fff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4fcaab62__0))))))));
    vlSelf->wasmetal_core__DOT___012567_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x335500000f0fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h4fcaab62__0)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012558_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___065323_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012818_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012809_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012810_)))))));
    vlSelf->wasmetal_core__DOT___066870_ = (1U & (0x5500fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057454_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057453_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012957_)))))));
    vlSelf->wasmetal_core__DOT___012883_ = (1U & (IData)(
                                                         (0xf0feeee00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057455_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012957_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057454_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057453_)))))))));
    vlSelf->__VdfgTmp_h3545ce03__0 = (((IData)(vlSelf->wasmetal_core__DOT___057380_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xff00ccccf0f0aaaaULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                                    << 3U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h3b7e1022__0))))))));
    vlSelf->wasmetal_core__DOT___011907_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056716_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3b7e1022__0)))))));
    vlSelf->wasmetal_core__DOT___068413_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012926_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->__VdfgTmp_hca606f65__0 = (((IData)(vlSelf->wasmetal_core__DOT___057381_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___012926_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___057380_))));
    vlSelf->__VdfgTmp_h4fe8c7bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___057447_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___067094_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011428_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011426_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011425_)))))))));
    vlSelf->wasmetal_core__DOT___011679_ = (1U & (IData)(
                                                         (0xff110f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x330f0f0fff55ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011437_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056599_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056600_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011426_)))))))));
    vlSelf->wasmetal_core__DOT___056605_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                               ? 
                                                              (0xf0f000eeU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011296_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011294_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011293_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___010085_))))))
                                                               : 
                                                              (2U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011295_))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                ? 
                                                               (0xf0f000eeU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011428_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011426_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hc7461e30__0)))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011427_)))))))));
    vlSelf->wasmetal_core__DOT___011556_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011550_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc7461e30__0))));
    vlSelf->__VdfgTmp_hd6248a2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___011293_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011656_));
    vlSelf->wasmetal_core__DOT___066990_ = (1U & (IData)(
                                                         (0xff0000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011128_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011130_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdab8ca95__0))))))));
    vlSelf->__VdfgTmp_ha73aa920__0 = (((IData)(vlSelf->wasmetal_core__DOT___011128_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___065632_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011082_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hac971038__0))));
    vlSelf->wasmetal_core__DOT___056482_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0xffff4444fff0fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011082_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011081_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011080_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdab8ca95__0))))))));
    vlSelf->wasmetal_core__DOT___011025_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfde06fd4__0)))))));
    vlSelf->wasmetal_core__DOT___012388_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfde06fd4__0)))))));
    vlSelf->wasmetal_core__DOT___013114_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013035_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4aee2d94__0))));
    vlSelf->wasmetal_core__DOT___066912_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057537_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057663_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057664_)))))));
    vlSelf->__VdfgTmp_h4d745f43__0 = (((IData)(vlSelf->wasmetal_core__DOT___057537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___013187_ = (1U & (IData)(
                                                         (0xf0feeee00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057665_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057537_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057664_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057663_)))))))));
    vlSelf->__VdfgTmp_ha052db73__0 = ((2U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h25b48e48__0)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___057627_));
    vlSelf->wasmetal_core__DOT___012255_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h25b48e48__0)))))));
    vlSelf->wasmetal_core__DOT___068166_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065822_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->wasmetal_core__DOT___011678_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056668_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x30303000aa0000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056607_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056598_))))))))))))));
    vlSelf->wasmetal_core__DOT___066295_ = (1U & (IData)(
                                                         (0xff0000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf218f314__0))))));
    vlSelf->wasmetal_core__DOT___036846_ = (1U & (IData)(
                                                         (0xff7f7f1717010100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072167_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072165_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072217_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h7baa8c24__0))))))));
    vlSelf->__VdfgTmp_h15cdecdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___072165_) 
                                       << 2U) | (IData)(__VdfgTmp_h7baa8c24__0));
    vlSelf->wasmetal_core__DOT___036629_ = (1U & (0x96696996U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h74dc1f9c__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072203_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072202_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___072201_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x69U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h84670069__0)))))))));
    vlSelf->wasmetal_core__DOT___072213_ = (1U & (0xd4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072203_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072202_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x69U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h84670069__0)))))));
    vlSelf->wasmetal_core__DOT___072214_ = (1U & (IData)(
                                                         (0xb24d4db24db2b24dULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072212_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xb2U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h39564552__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((9U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha7d2f4a8__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h84670069__0)))))));
    vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___013683_ = (1U & ((~ 
                                                   (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127462___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___002193_)))) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127462___O) 
                                                                     << 1U)) 
                                                                 | ((8U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (0xeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))))))))))));
    vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013705_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022741_));
    vlSelf->wasmetal_core__DOT____Vcellout___127625___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024031_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d) {
        vlSelf->wasmetal_core__DOT___024058_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d;
        wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024058_ = wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023931_;
    }
    vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023752_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127609___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023904_)))));
    vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006015_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005809_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___057759_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8ac5901b__0)))));
    vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013788_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127488___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022948_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d) {
        vlSelf->wasmetal_core__DOT___022952_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d;
        wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022952_ = wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022889_;
    }
    vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022797_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127480___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022885_)))));
    vlSelf->wasmetal_core__DOT___068814_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051121_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050064_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ff00ff1fffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b54__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050040_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051119_)))))))));
    vlSelf->wasmetal_core__DOT___068617_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049823_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xef00efefefefULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049820_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0xf0f0f77U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049821_)))))))));
    vlSelf->wasmetal_core__DOT___068199_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051662_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f7700003f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050869_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050868_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b42__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050867_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051660_)))))))));
    vlSelf->wasmetal_core__DOT___069202_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051621_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbf00bfbfbfbfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051618_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051617_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb829d41d__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051619_)))))))));
    vlSelf->wasmetal_core__DOT___068666_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049904_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049901_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049900_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049899_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049902_)))))))));
    vlSelf->wasmetal_core__DOT___069058_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051529_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051526_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051525_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b59__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051524_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051527_)))))))));
    vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028092_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0xaU)));
    vlSelf->wasmetal_core__DOT___069252_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051640_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b63__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051637_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                (4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051638_)))))))));
    vlSelf->wasmetal_core__DOT___068566_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049771_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049768_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049767_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b49__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049766_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049769_)))))))));
    vlSelf->wasmetal_core__DOT___068960_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051357_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051354_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051353_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051352_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051355_)))))))));
    vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001647_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128114___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028848_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028847_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028877_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028876_)))) 
           ^ (((IData)(wasmetal_core__DOT___128114___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028843_)))));
    vlSelf->wasmetal_core__DOT___028814_ = ((IData)(vlSelf->wasmetal_core__DOT___028848_)
                                             ? (IData)(wasmetal_core__DOT___128114___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___028852_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001580_))));
    vlSelf->wasmetal_core__DOT___028851_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001568_))));
    vlSelf->wasmetal_core__DOT___028850_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001536_))));
    vlSelf->wasmetal_core__DOT___028849_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001524_))));
    vlSelf->wasmetal_core__DOT___128080___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028468_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028434_)
            : (IData)(vlSelf->wasmetal_core__DOT___004004_));
    vlSelf->wasmetal_core__DOT____Vcellout___128097___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028643_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028642_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028641_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028640_)))) 
           ^ (((IData)(wasmetal_core__DOT___128097___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028606_)))));
    vlSelf->wasmetal_core__DOT___028610_ = ((IData)(vlSelf->wasmetal_core__DOT___028643_)
                                             ? (IData)(wasmetal_core__DOT___128097___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003706_));
    vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029055_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT____Vcellout___128124___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028955_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028954_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028953_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028952_)))) 
           ^ (((IData)(wasmetal_core__DOT___128124___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028918_)))));
    vlSelf->wasmetal_core__DOT___028922_ = ((IData)(vlSelf->wasmetal_core__DOT___028955_)
                                             ? (IData)(wasmetal_core__DOT___128124___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b15__05d));
    vlSelf->wasmetal_core__DOT___128438___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001612_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001612_)
            : (IData)(vlSelf->wasmetal_core__DOT___032264_));
    vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028746_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026458_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b13__05d));
    vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026668_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT___070694_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054344_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070692_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)))))))))));
    vlSelf->wasmetal_core__DOT___070693_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070692_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054344_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027138_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d));
    vlSelf->wasmetal_core__DOT___045493_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071352_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071351_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071350_))))))));
    vlSelf->wasmetal_core__DOT___045517_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071352_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071351_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071350_)))))))));
    vlSelf->wasmetal_core__DOT___045289_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071415_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071414_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071413_))))))));
    vlSelf->wasmetal_core__DOT___045313_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071415_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071414_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071413_)))))))));
    vlSelf->wasmetal_core__DOT___127869___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026565_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026498_)
            : (IData)(vlSelf->wasmetal_core__DOT___001525_));
    vlSelf->wasmetal_core__DOT___070797_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054343_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070795_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)))))))))));
    vlSelf->wasmetal_core__DOT___070796_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070795_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054343_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026938_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_he974eeb2__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT___040019_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___040018_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___040017_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___040016_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b15__05d)))))))));
    vlSelf->__VdfgTmp_h6e8006f3__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->__VdfgTmp_h25861896__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->__VdfgTmp_hd8f0618c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->__VdfgTmp_hb05848c8__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT___128666___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001612_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034514_));
    vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030094_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d));
    vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030222_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d));
    vlSelf->wasmetal_core__DOT___063144_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128060___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063150_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128060___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063156_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128060___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063162_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128060___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028288_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028254_)
            : (IData)(vlSelf->wasmetal_core__DOT___028223_));
    vlSelf->__VdfgTmp_h45f0a758__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> (IData)(vlSelf->__VdfgTmp_hca11f007__0))));
    vlSelf->__VdfgTmp_h1ffb08a2__0 = ((4U & ((1U >> (IData)(vlSelf->__VdfgTmp_h1065bf0b__0)) 
                                             << 2U)) 
                                      | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hca11f007__0)) 
                                                << 1U)) 
                                         | (1U & (0x2bU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h19390f5d__0)))));
    vlSelf->__VdfgTmp_h5ffdcb06__0 = ((4U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h868ae0cf__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x69U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h19390f5d__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h0341114f__0)))));
    vlSelf->__VdfgTmp_h9a02691e__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9cfb7302__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0341114f__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127969___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O)) 
            | (IData)(vlSelf->wasmetal_core__DOT___027473_)) 
           ^ (((IData)(wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027436_)))));
    vlSelf->wasmetal_core__DOT___027466_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027336_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027270_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b12__05d));
    vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006204_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128479___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029134_));
    vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031054_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031020_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    vlSelf->wasmetal_core__DOT___067326_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9cfb33d2__0)))));
    vlSelf->wasmetal_core__DOT___067172_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7884ece4__0))))));
    wasmetal_core__DOT___056735_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                    & (IData)((0xf4f4f4f4ffffff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011783_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011782_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdf888c66__0)))))));
    vlSelf->wasmetal_core__DOT___012206_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056988_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056987_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xfaf3U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5b3d01ff__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056985_)))))))));
    vlSelf->wasmetal_core__DOT___065920_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065919_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012216_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012215_)))))));
    vlSelf->__VdfgTmp_h895eb4d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___057167_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057162_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057161_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___011047_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x503U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1c56b6c5__0)))))));
    vlSelf->wasmetal_core__DOT___066103_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012576_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h186e290b__0))));
    vlSelf->__VdfgTmp_h4eea07db__0 = (((IData)(vlSelf->wasmetal_core__DOT___012752_) 
                                       << 3U) | ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                   & (IData)(
                                                             (0x55550f0f00ff3333ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___011299_))))))))) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___012558_))));
    vlSelf->wasmetal_core__DOT___065210_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012567_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h07056034__0))))));
    vlSelf->wasmetal_core__DOT___067913_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012567_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->wasmetal_core__DOT___057330_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 3U)) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                           & (IData)(
                                                                     (0xff33ff00f0f0f5f5ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012576_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___012608_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07e757d2__0)))))))) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xf4U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057322_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xf0feU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2163f181__0)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___057320_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___012567_)
                                                                    : 
                                                                   (1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h07056034__0)))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012620_))))))))));
    vlSelf->wasmetal_core__DOT___067472_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3545ce03__0)))));
    vlSelf->wasmetal_core__DOT___012894_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057447_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3545ce03__0))))))));
    vlSelf->wasmetal_core__DOT___011949_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011907_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    __VdfgTmp_h8a9ed06f__0 = (((IData)(vlSelf->wasmetal_core__DOT___011908_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011907_));
    vlSelf->wasmetal_core__DOT___066148_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hca606f65__0))))));
    vlSelf->wasmetal_core__DOT___057397_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf0fff1100000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                           << 4U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hca606f65__0))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xf4U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057388_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & (((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                                             & (IData)(
                                                                                (0xff00ffaafff0fff3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012806_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012805_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012804_))))))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___057386_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___012818_)
                                                                    : 
                                                                   (1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___012810_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___012809_))))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012811_))))))))));
    vlSelf->wasmetal_core__DOT___065719_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011556_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_haf8803a1__0))))));
    vlSelf->wasmetal_core__DOT___068115_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011556_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    if (vlSelf->wasmetal_core__DOT___010376_) {
        vlSelf->wasmetal_core__DOT___056628_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___011556_)
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_haf8803a1__0))));
        vlSelf->wasmetal_core__DOT___056783_ = (1U 
                                                & (0xf0f000eeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011951_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011949_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d9b5f2a__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___056628_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011549_)));
        vlSelf->wasmetal_core__DOT___056783_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011950_)));
    }
    vlSelf->wasmetal_core__DOT___064529_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd6248a2d__0))));
    vlSelf->wasmetal_core__DOT___068090_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065632_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->wasmetal_core__DOT___056483_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056482_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf72e2656__0)))))));
    vlSelf->wasmetal_core__DOT___056464_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0xf0f00ff11111111ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011025_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011024_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he19177ad__0))))))));
    __VdfgTmp_hd2b66780__0 = (((IData)(vlSelf->wasmetal_core__DOT___011025_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011024_));
    vlSelf->__VdfgTmp_h8267970c__0 = (((IData)(vlSelf->wasmetal_core__DOT___012388_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012387_));
    wasmetal_core__DOT___057091_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012388_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___065434_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013114_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8088f5ad__0))))));
    vlSelf->wasmetal_core__DOT___057542_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057538_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4d745f43__0))))))));
    vlSelf->wasmetal_core__DOT___057661_ = (1U & (IData)(
                                                         (0xfafc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha052db73__0))))))));
    vlSelf->wasmetal_core__DOT___056908_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012255_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->__VdfgTmp_he65514a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___012256_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012255_));
    vlSelf->wasmetal_core__DOT___036632_ = (1U & (IData)(
                                                         (0x188e7118e7718ee7ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072167_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072217_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h15cdecdf__0)))))));
    __VdfgTmp_h5013759b__0 = ((2U & ((0x69969669U >> 
                                      ((0x10U & ((1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                 << 4U)) 
                                       | (((IData)(vlSelf->wasmetal_core__DOT___072217_) 
                                           << 3U) | (IData)(vlSelf->__VdfgTmp_h15cdecdf__0)))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xbfab2a022a02bfabULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___072212_) 
                                                             << 5U) 
                                                            | ((0x10U 
                                                                & ((9U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_ha7d2f4a8__0)) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___072198_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___072199_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0x96U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h39564552__0)) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (0xb2U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h39564552__0))))))))))));
    wasmetal_core__DOT___036842_ = (1U & (0x4db2U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___036629_) 
                                            << 3U) 
                                           | (IData)(vlSelf->__VdfgTmp_h1399f995__0))));
    wasmetal_core__DOT___036630_ = (1U & (0x96U >> 
                                          ((4U & ((0xe8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he9efeda2__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___072214_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___072213_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128549___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033480_)))));
    vlSelf->wasmetal_core__DOT___033421_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013692_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d) {
        wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d;
        wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d;
    } else {
        wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024058_;
        wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023763_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d));
    vlSelf->__VdfgTmp_hd6d3a7f5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->__VdfgTmp_h96e8cece__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005745_));
    vlSelf->__VdfgTmp_h3a9f8450__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005921_));
    vlSelf->__VdfgTmp_ha0adc294__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006092_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005882_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013796_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) {
        wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d;
        wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d;
    } else {
        wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022952_;
        wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022808_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0))));
    vlSelf->__VdfgTmp_h916673f4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->__VdfgTmp_hed8e8f6b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005745_));
    vlSelf->__VdfgTmp_hbac08a4b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005921_));
    vlSelf->__VdfgTmp_h5774c299__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    vlSelf->wasmetal_core__DOT____Vcellout___128044___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028093_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028092_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028122_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028121_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028088_)))));
    vlSelf->wasmetal_core__DOT___028061_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028093_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0xbU)));
    vlSelf->wasmetal_core__DOT____Vcellout___128650___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000420_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001647_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___001625_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001613_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034353_)))));
    vlSelf->wasmetal_core__DOT___034357_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000420_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128115___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028849_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028814_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    wasmetal_core__DOT___128080___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028469_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128080___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004300_));
    vlSelf->wasmetal_core__DOT___054084_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128097___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054088_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128097___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054092_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128097___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054096_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128097___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    wasmetal_core__DOT___128098___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028644_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028610_)
            : (IData)(vlSelf->wasmetal_core__DOT___004004_));
    vlSelf->wasmetal_core__DOT____Vcellout___128132___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029056_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029055_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029085_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029084_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029051_)))));
    vlSelf->wasmetal_core__DOT___029022_ = ((IData)(vlSelf->wasmetal_core__DOT___029056_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___029060_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001580_))));
    vlSelf->wasmetal_core__DOT___029059_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001568_))));
    vlSelf->wasmetal_core__DOT___029058_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001536_))));
    vlSelf->wasmetal_core__DOT___029057_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001524_))));
    wasmetal_core__DOT___128125___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028956_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028922_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b16__05d));
    wasmetal_core__DOT___128438___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001624_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001624_)
            : (IData)(vlSelf->wasmetal_core__DOT___128438___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128106___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028747_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028746_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028745_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028744_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028710_)))));
    vlSelf->wasmetal_core__DOT___028714_ = ((IData)(vlSelf->wasmetal_core__DOT___028747_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026459_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b14__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127886___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026669_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026668_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026667_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026666_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026600_)))));
    vlSelf->wasmetal_core__DOT___026604_ = ((IData)(vlSelf->wasmetal_core__DOT___026669_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->wasmetal_core__DOT___045245_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054342_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___045221_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070694_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054346_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 9U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054342_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070693_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127937___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027139_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027138_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027137_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027136_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027070_)))));
    vlSelf->wasmetal_core__DOT___027074_ = ((IData)(vlSelf->wasmetal_core__DOT___027139_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d));
    wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026566_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127869___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001537_));
    vlSelf->wasmetal_core__DOT___044973_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070796_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___044949_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070797_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054345_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 9U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054341_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070796_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127920___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026939_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026938_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026937_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026936_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026870_)))));
    vlSelf->wasmetal_core__DOT___026874_ = ((IData)(vlSelf->wasmetal_core__DOT___026939_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->wasmetal_core__DOT____Vcellout___127903___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hb96516e6__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_he974eeb2__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5a182b30__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h3daf64ed__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026735_)))));
    vlSelf->wasmetal_core__DOT___026739_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb96516e6__0)))
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->wasmetal_core__DOT___030099_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6e8006f3__0)))));
    vlSelf->wasmetal_core__DOT___030227_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6e8006f3__0)))));
    vlSelf->wasmetal_core__DOT___030098_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h25861896__0)))));
    vlSelf->wasmetal_core__DOT___030226_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h25861896__0)))));
    vlSelf->wasmetal_core__DOT___030097_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8f0618c__0)))));
    vlSelf->wasmetal_core__DOT___030225_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8f0618c__0)))));
    vlSelf->wasmetal_core__DOT___030096_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb05848c8__0)))));
    vlSelf->wasmetal_core__DOT___030224_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb05848c8__0)))));
    wasmetal_core__DOT___128666___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001624_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128666___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128233___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030095_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030094_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030124_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030123_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030090_)))));
    vlSelf->wasmetal_core__DOT___030063_ = ((IData)(vlSelf->wasmetal_core__DOT___030095_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128247___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030223_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030222_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030284_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030283_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030218_)))));
    vlSelf->wasmetal_core__DOT___030159_ = ((IData)(vlSelf->wasmetal_core__DOT___030223_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d));
    vlSelf->wasmetal_core__DOT___063147_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063144_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063143_)))))));
    vlSelf->wasmetal_core__DOT___063153_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063150_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063149_)))))));
    vlSelf->wasmetal_core__DOT___063159_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063156_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063155_)))))));
    vlSelf->wasmetal_core__DOT___063165_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063162_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063161_)))))));
    vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028289_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028224_));
    __VdfgTmp_h635c29e2__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O) 
                                     << 1U)) | (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h45f0a758__0))));
    __VdfgTmp_h986ee838__0 = ((2U & ((6U >> (IData)(vlSelf->__VdfgTmp_h45f0a758__0)) 
                                     << 1U)) | (1U 
                                                & (0x2bU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1ffb08a2__0))));
    __VdfgTmp_h6ec4eab1__0 = ((4U & ((0xe8U >> (IData)(vlSelf->__VdfgTmp_h868ae0cf__0)) 
                                     << 2U)) | ((2U 
                                                 & ((0x69U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h1ffb08a2__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0x2bU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5ffdcb06__0)))));
    __VdfgTmp_hfc0d441b__0 = ((4U & ((0x69U >> (IData)(vlSelf->__VdfgTmp_hf5f2577b__0)) 
                                     << 2U)) | ((2U 
                                                 & ((0x69U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5ffdcb06__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0x17U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9a02691e__0)))));
    __VdfgTmp_ha1bf32a7__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                               << 2U) | ((2U & ((0x96U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h7b621139__0)) 
                                                << 1U)) 
                                         | (1U & (0x96U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9a02691e__0)))));
    vlSelf->wasmetal_core__DOT___044881_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O) 
                                                       >> 1U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027466_));
    vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027337_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b13__05d));
    wasmetal_core__DOT____Vcellout___127436___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hadeaba1a__0))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022506_)))));
    vlSelf->wasmetal_core__DOT___022510_ = ((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128479___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031055_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___056736_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056735_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he54a047f__0)))))));
    vlSelf->wasmetal_core__DOT___012451_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h895eb4d9__0)))));
    vlSelf->wasmetal_core__DOT___066787_ = (1U & (IData)(
                                                         (0xff0000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4eea07db__0))))));
    vlSelf->wasmetal_core__DOT___012899_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012895_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012894_)))));
    vlSelf->wasmetal_core__DOT___056887_ = (1U & (IData)(
                                                         (0xff11f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x30303000aa0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011955_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056769_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011949_)))))))));
    vlSelf->wasmetal_core__DOT___064775_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h8a9ed06f__0))));
    vlSelf->wasmetal_core__DOT___056860_ = (1U & (IData)(
                                                         (0xf0f3f0f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h8a9ed06f__0))))))));
    vlSelf->wasmetal_core__DOT___056750_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0x33335555000f000fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011910_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011909_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h8a9ed06f__0))))))));
    vlSelf->wasmetal_core__DOT___064540_ = (1U & (0xf0011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064529_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h95aabd6f__0))))));
    vlSelf->wasmetal_core__DOT___064018_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hd2b66780__0))));
    vlSelf->wasmetal_core__DOT___056389_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056388_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00fff400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011082_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdab8ca95__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f5f0f300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_hd2b66780__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xffff8000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056384_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___057177_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8267970c__0))));
    vlSelf->wasmetal_core__DOT___012476_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057091_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xccaaf0f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012387_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h7d32537f__0))))))))));
    vlSelf->wasmetal_core__DOT___057099_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057091_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011026_)))));
    vlSelf->wasmetal_core__DOT___066619_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056909_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056908_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012256_)))))))));
    vlSelf->wasmetal_core__DOT___057046_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056908_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->wasmetal_core__DOT___012171_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he65514a2__0))));
    vlSelf->wasmetal_core__DOT___036845_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036632_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h5013759b__0))));
    wasmetal_core__DOT___036844_ = (1U & (0x8e71U >> 
                                          ((8U & ((9U 
                                                   >> (IData)(__VdfgTmp_h5013759b__0)) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___072214_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((0xe8U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he9efeda2__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___072213_))))));
    wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036842_) ? (IData)(vlSelf->wasmetal_core__DOT___134164___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036629_));
    wasmetal_core__DOT___036843_ = (1U & (IData)((0x8ee8e88e71171771ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___036630_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072203_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072202_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x69U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h84670069__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x17U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h74dc1f9c__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___072201_)))))))));
    vlSelf->wasmetal_core__DOT___011076_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O))))))));
    vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033421_));
    wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013712_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d) {
        wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d;
        wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d;
    } else {
        wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127585___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023774_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023763_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023752_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023741_)))) 
           ^ (((IData)(wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___023711_ = ((IData)(vlSelf->wasmetal_core__DOT___023774_)
                                             ? (IData)(wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d));
    vlSelf->wasmetal_core__DOT___058750_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0))))));
    vlSelf->wasmetal_core__DOT___023801_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d))));
    vlSelf->wasmetal_core__DOT___058864_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d))));
    vlSelf->wasmetal_core__DOT___058736_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                             >> 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0))))))));
    vlSelf->wasmetal_core__DOT___023800_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d))));
    vlSelf->wasmetal_core__DOT___058872_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___023796_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d))));
    vlSelf->wasmetal_core__DOT___058913_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)))))));
    vlSelf->wasmetal_core__DOT___023785_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___127456___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005875_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006085_)))) 
           ^ (((IData)(wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022652_)))));
    vlSelf->wasmetal_core__DOT___022656_ = ((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                            & (IData)(wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127559___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005802_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005948_)))) 
           ^ (((IData)(wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023449_)))));
    vlSelf->wasmetal_core__DOT___023453_ = ((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                            & (IData)(wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127576___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013797_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h7faa2984__0))) 
           ^ (((IData)(wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023570_)))));
    vlSelf->wasmetal_core__DOT___023574_ = ((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                            & (IData)(wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) {
        wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d;
        wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d;
    } else {
        wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127469___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022810_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022808_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022797_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022786_)))) 
           ^ (((IData)(wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022779_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022810_)
                                                   ? (IData)(wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7e209046__0))));
    vlSelf->wasmetal_core__DOT___059189_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))))));
    vlSelf->wasmetal_core__DOT___059165_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))))));
    vlSelf->wasmetal_core__DOT___022814_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))))));
    vlSelf->wasmetal_core__DOT___059103_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))))));
    vlSelf->wasmetal_core__DOT___022813_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))))));
    vlSelf->wasmetal_core__DOT___022812_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0))))));
    vlSelf->wasmetal_core__DOT___059082_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))))));
    vlSelf->wasmetal_core__DOT___059166_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))))));
    vlSelf->wasmetal_core__DOT___022811_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))))));
    vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028094_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028061_)
                  : (vlSelf->insn_x >> 0xcU)));
    vlSelf->wasmetal_core__DOT___054558_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001613_)))));
    vlSelf->wasmetal_core__DOT___054559_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001625_)))));
    vlSelf->wasmetal_core__DOT___054560_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001647_)))));
    vlSelf->wasmetal_core__DOT___054561_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000420_)))));
    vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000433_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034357_));
    wasmetal_core__DOT___128115___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028850_)
            ? (IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    wasmetal_core__DOT___128080___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028470_)
            ? (IData)(wasmetal_core__DOT___128080___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004078_));
    wasmetal_core__DOT___128098___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028645_)
            ? (IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004300_));
    vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029057_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029022_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    wasmetal_core__DOT___128125___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028957_)
            ? (IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b17__05d));
    wasmetal_core__DOT___128438___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001646_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001646_)
            : (IData)(wasmetal_core__DOT___128438___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045370_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b44__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b46__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___045382_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b46__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b45__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128106___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028748_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028714_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    vlSelf->wasmetal_core__DOT____Vcellout___127853___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026460_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026459_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026458_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026457_)))) 
           ^ (((IData)(wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026423_)))));
    vlSelf->wasmetal_core__DOT___026427_ = ((IData)(vlSelf->wasmetal_core__DOT___026460_)
                                             ? (IData)(wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b15__05d));
    vlSelf->__VdfgTmp_hbe940684__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054083_)))));
    vlSelf->wasmetal_core__DOT___045336_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052263_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052141_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052264_)))))))));
    vlSelf->wasmetal_core__DOT___045348_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052141_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052264_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052263_)))))))));
    vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026670_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026604_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    vlSelf->wasmetal_core__DOT___054354_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054356_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054352_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027140_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027074_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d));
    wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026567_)
            ? (IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001569_));
    vlSelf->wasmetal_core__DOT___054353_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054349_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054355_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054351_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026940_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026874_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    vlSelf->wasmetal_core__DOT___045922_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052255_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052257_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052401_))))))));
    vlSelf->wasmetal_core__DOT___045934_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052257_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052255_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052401_)))))))));
    vlSelf->wasmetal_core__DOT___045404_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha17b8b2d__0))))));
    vlSelf->wasmetal_core__DOT___045416_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004684_)))))))));
    vlSelf->wasmetal_core__DOT___045086_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071003_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071002_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071001_))))))));
    vlSelf->wasmetal_core__DOT___045110_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071003_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071002_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071001_)))))))));
    vlSelf->wasmetal_core__DOT___045876_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004152_)))))))));
    vlSelf->wasmetal_core__DOT___045900_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004152_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003558_)))))))));
    vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h560b7672__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026739_)
            : (IData)(vlSelf->wasmetal_core__DOT___001612_));
    wasmetal_core__DOT___128666___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001646_)) 
           & (IData)(wasmetal_core__DOT___128666___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030096_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030063_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d));
    vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030224_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030159_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d));
    vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028290_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028225_));
    vlSelf->__VdfgTmp_h0bfb68a4__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O)) 
                                      | (1U & (8U >> (IData)(__VdfgTmp_h635c29e2__0))));
    vlSelf->__VdfgTmp_h935fcb03__0 = ((2U & ((6U >> (IData)(__VdfgTmp_h635c29e2__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> (IData)(__VdfgTmp_h986ee838__0))));
    vlSelf->__VdfgTmp_hab776b02__0 = ((2U & ((9U >> (IData)(__VdfgTmp_h986ee838__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (IData)(__VdfgTmp_h6ec4eab1__0))));
    vlSelf->wasmetal_core__DOT___036652_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xe8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf5f2577b__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x96U 
                                                           >> (IData)(__VdfgTmp_h6ec4eab1__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x2bU 
                                                            >> (IData)(__VdfgTmp_hfc0d441b__0)))))));
    vlSelf->wasmetal_core__DOT___036651_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7b621139__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x69U 
                                                           >> (IData)(__VdfgTmp_hfc0d441b__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x17U 
                                                            >> (IData)(__VdfgTmp_ha1bf32a7__0)))))));
    vlSelf->__VdfgTmp_h009676e6__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(__VdfgTmp_ha1bf32a7__0)))));
    vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027338_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b14__05d));
    vlSelf->__VdfgTmp_h201788e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                                                >> 3U)))))));
    vlSelf->__VdfgTmp_h16a355a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_h3cbf3996__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___127436___O)))))));
    vlSelf->__VdfgTmp_h6ec85b19__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->__VdfgTmp_h21955c47__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h6d7fd34d__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_));
    vlSelf->__VdfgTmp_h445a0824__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_));
    vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003807_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022510_));
    vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128479___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031056_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    vlSelf->wasmetal_core__DOT___067742_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064775_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->__VdfgTmp_hb961a9be__0 = (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057177_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((0xc0aU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7d32537f__0)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xf0fe00000000ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057174_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057162_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___010395_))))))))))));
    vlSelf->wasmetal_core__DOT___012166_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012171_))
                                                   : 
                                                  (0xf0faf0fcU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xf0fe00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056962_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012221_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012218_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))))) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h75e79c91__0)))))));
    wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___036843_) ? (IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__)
            : (IData)(wasmetal_core__DOT___036630_));
    vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127464___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013690_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h3f696fc8__0))) 
           ^ (((IData)(wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022741_)))));
    vlSelf->wasmetal_core__DOT___022722_ = ((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                            & (IData)(wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d) {
        wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d;
        vlSelf->wasmetal_core__DOT___023873_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d;
    } else {
        wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023873_ = wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023785_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023711_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d));
    vlSelf->wasmetal_core__DOT___050131_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006092_))))));
    vlSelf->__VdfgTmp_h0d021fbc__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005745_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022656_));
    vlSelf->wasmetal_core__DOT___050114_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005882_))))));
    vlSelf->wasmetal_core__DOT___050102_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005948_))));
    wasmetal_core__DOT___006729_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h76242b02__0))))))));
    vlSelf->__VdfgTmp_hfb6e9604__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005802_));
    vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005955_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023453_));
    vlSelf->wasmetal_core__DOT___057763_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013785_)))))))));
    vlSelf->wasmetal_core__DOT___013774_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8ac5901b__0)))));
    vlSelf->wasmetal_core__DOT___057755_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013797_))));
    vlSelf->wasmetal_core__DOT___013776_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013786_))))));
    vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013795_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023574_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) {
        wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d;
        vlSelf->wasmetal_core__DOT___022863_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d;
    } else {
        wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022863_ = wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022811_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022779_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))));
    vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028095_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0xdU)));
    vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000465_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128115___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028851_)
            ? (IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT____Vcellout___128080___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028471_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028470_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028469_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028468_)))) 
           ^ (((IData)(wasmetal_core__DOT___128080___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128080___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128080___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028434_)))));
    vlSelf->wasmetal_core__DOT___028438_ = ((IData)(vlSelf->wasmetal_core__DOT___028471_)
                                             ? (IData)(wasmetal_core__DOT___128080___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003862_));
    wasmetal_core__DOT___128098___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028646_)
            ? (IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004078_));
    vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029058_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    wasmetal_core__DOT___128125___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028958_)
            ? (IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b18__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128438___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128438___S) 
           ^ (((IData)(wasmetal_core__DOT___128438___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128438___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128438___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032264_)))));
    vlSelf->wasmetal_core__DOT___032268_ = ((IData)(vlSelf->wasmetal_core__DOT___000419_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___000419_)
                                             : (IData)(wasmetal_core__DOT___128438___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028749_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->wasmetal_core__DOT___044908_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026461_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026427_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b16__05d));
    vlSelf->wasmetal_core__DOT___045018_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hbe940684__0)))))))))));
    vlSelf->wasmetal_core__DOT___045042_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbe940684__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054087_)))))))));
    vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026671_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->wasmetal_core__DOT___070697_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054352_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xcU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027141_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127869___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026568_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026567_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026566_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026565_)))) 
           ^ (((IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127869___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026498_)))));
    vlSelf->wasmetal_core__DOT___026502_ = ((IData)(vlSelf->wasmetal_core__DOT___026568_)
                                             ? (IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001581_));
    vlSelf->wasmetal_core__DOT___070800_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054351_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xcU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026941_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127921___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h63306680__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128071___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001624_));
    vlSelf->wasmetal_core__DOT____Vcellout___128666___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128438___S) 
           ^ (((IData)(wasmetal_core__DOT___128666___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128666___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128666___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034514_)))));
    vlSelf->wasmetal_core__DOT___034518_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___000419_)) 
                                            & (IData)(wasmetal_core__DOT___128666___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030097_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d));
    vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030225_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128061___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028291_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028290_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028289_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028288_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028254_)))));
    vlSelf->wasmetal_core__DOT___028258_ = ((IData)(vlSelf->wasmetal_core__DOT___028291_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028226_));
    vlSelf->wasmetal_core__DOT___036981_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0bfb68a4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h935fcb03__0))));
    vlSelf->wasmetal_core__DOT___036980_ = (1U & (0xb4U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h935fcb03__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab776b02__0))));
    vlSelf->wasmetal_core__DOT___036979_ = (1U & (0x8e71U 
                                                  >> 
                                                  ((8U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hab776b02__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0x96U 
                                                           >> (IData)(__VdfgTmp_h6ec4eab1__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xe8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf5f2577b__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x2bU 
                                                               >> (IData)(__VdfgTmp_hfc0d441b__0))))))));
    vlSelf->wasmetal_core__DOT___036978_ = (1U & (0x8e71U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036652_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x69U 
                                                           >> (IData)(__VdfgTmp_hfc0d441b__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x17U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7b621139__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x17U 
                                                               >> (IData)(__VdfgTmp_ha1bf32a7__0))))))));
    vlSelf->wasmetal_core__DOT___036977_ = (1U & (0x17e8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036651_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h009676e6__0))));
    vlSelf->wasmetal_core__DOT___036976_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x96U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h009676e6__0))))));
    vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127954___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027339_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027338_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027337_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027336_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027270_)))));
    vlSelf->wasmetal_core__DOT___027274_ = ((IData)(vlSelf->wasmetal_core__DOT___027339_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b15__05d));
    vlSelf->wasmetal_core__DOT___023226_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6ec85b19__0))));
    vlSelf->wasmetal_core__DOT___023225_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___003810_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h21955c47__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h21955c47__0)))));
    vlSelf->wasmetal_core__DOT___023223_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d7fd34d__0))));
    vlSelf->wasmetal_core__DOT___023222_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h445a0824__0))));
    vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128144___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128479___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029134_)))));
    vlSelf->wasmetal_core__DOT___029139_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128479___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128327___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031057_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031056_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031055_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031054_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031020_)))));
    vlSelf->wasmetal_core__DOT___031025_ = ((IData)(vlSelf->wasmetal_core__DOT___031057_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134164___O 
        = ((((IData)(wasmetal_core__DOT___036844_) 
             << 3U) | (((IData)(wasmetal_core__DOT___036843_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036842_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036841_)))) 
           ^ (((IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___134164___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___036837_ = (1U & ((IData)(wasmetal_core__DOT___036844_)
                                                   ? (IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(__VdfgTmp_h5013759b__0))));
    vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h87a694d3__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013690_));
    vlSelf->wasmetal_core__DOT___127465___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013654_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022722_));
    vlSelf->wasmetal_core__DOT____Vcellout___127626___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024058_)))));
    vlSelf->wasmetal_core__DOT___024000_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023796_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127610___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023931_)))));
    vlSelf->wasmetal_core__DOT___050130_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0d021fbc__0)))));
    vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005921_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___006707_ = ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                & (IData)(wasmetal_core__DOT___006729_))
                                             : (IData)(wasmetal_core__DOT___006729_));
    vlSelf->wasmetal_core__DOT___050104_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfb6e9604__0)))));
    vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005788_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___057762_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013776_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O)))))));
    vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013798_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127489___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022952_)))));
    vlSelf->wasmetal_core__DOT___022926_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022812_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127481___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022889_)))));
    vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028096_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0xeU)));
    vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000477_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128651___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128115___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028852_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028851_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028850_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028849_)))) 
           ^ (((IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028814_)))));
    vlSelf->wasmetal_core__DOT___028818_ = ((IData)(vlSelf->wasmetal_core__DOT___028852_)
                                             ? (IData)(wasmetal_core__DOT___128115___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->wasmetal_core__DOT___028856_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000419_))));
    vlSelf->wasmetal_core__DOT___028855_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001646_))));
    vlSelf->wasmetal_core__DOT___028854_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001624_))));
    vlSelf->wasmetal_core__DOT___028853_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001612_))));
    vlSelf->wasmetal_core__DOT___128081___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028473_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028438_)
            : (IData)(vlSelf->wasmetal_core__DOT___003936_));
    vlSelf->wasmetal_core__DOT____Vcellout___128098___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028647_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028646_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028645_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028644_)))) 
           ^ (((IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028610_)))));
    vlSelf->wasmetal_core__DOT___028614_ = ((IData)(vlSelf->wasmetal_core__DOT___028647_)
                                             ? (IData)(wasmetal_core__DOT___128098___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003862_));
    vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029059_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128133___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT____Vcellout___128125___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028959_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028958_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028957_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028956_)))) 
           ^ (((IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028922_)))));
    vlSelf->wasmetal_core__DOT___028926_ = ((IData)(vlSelf->wasmetal_core__DOT___028959_)
                                             ? (IData)(wasmetal_core__DOT___128125___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b19__05d));
    vlSelf->wasmetal_core__DOT___128439___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___000432_)
            ? (IData)(vlSelf->wasmetal_core__DOT___000432_)
            : (IData)(vlSelf->wasmetal_core__DOT___032268_));
    vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028750_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128107___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026462_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b17__05d));
    vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026672_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128089___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001646_));
    vlSelf->wasmetal_core__DOT___070699_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054350_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070697_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)))))))))));
    vlSelf->wasmetal_core__DOT___070698_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027142_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127938___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d));
    vlSelf->wasmetal_core__DOT___045494_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071355_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071354_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071353_))))))));
    vlSelf->wasmetal_core__DOT___045518_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071355_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071354_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071353_)))))))));
}
